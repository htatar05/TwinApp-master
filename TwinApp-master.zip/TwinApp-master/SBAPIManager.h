//
//  SBAPIManager.h
//  RealEstate_App
//
//  Created by admin on 10/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import "AFHTTPRequestOperationManager.h"

@interface SBAPIManager : AFHTTPRequestOperationManager

- (void)setUsername:(NSString *)username andPassword:(NSString *)password;

+ (SBAPIManager *)sharedManager;
+ (void)cancelAllRequests;

@end
