//
//  LastSaleTaxCell.h
//  RealEstate_App
//
//  Created by Octal on 23/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LastSaleTaxCell : UITableViewCell
{
}

@property(nonatomic,strong)IBOutlet UIImageView *imgBackground;
@property(nonatomic,strong)IBOutlet UILabel *lblLastSale;
@property(nonatomic,strong)IBOutlet UILabel *lblPrice;
@property(nonatomic,strong)IBOutlet UILabel *lblDate;
@property(nonatomic,strong)IBOutlet UILabel *lblSale;
@property(nonatomic,strong)IBOutlet UILabel *lblMalNum;
@end
