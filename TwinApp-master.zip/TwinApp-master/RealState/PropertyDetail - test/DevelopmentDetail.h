//
//  DevelopmentDetail.h
//  RealEstate_App
//
//  Created by Octal on 01/12/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DevelopmentDetail : UIViewController
{
    IBOutlet UILabel *lblTitle;
}
@property (nonatomic,strong)NSMutableDictionary *detailDict;
@end
