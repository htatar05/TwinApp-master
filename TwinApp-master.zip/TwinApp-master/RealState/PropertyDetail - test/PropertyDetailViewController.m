//  PropertyDetailViewController.m
//  RealState
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "PropertyDetailViewController.h"
#import "NSAttributedString+Attributes.h"
#import "PropertyTvCellView.h"
#import "PropertyAgentTvCellView.h"
#import "REWebService.h"
#import "UIImageView+UIActivityIndicatorForSDWebImage.h"
#import "UIImageView+HighlightedWebCache.h"
#import "MBProgressHUD.h"
#import "AppDelegate.h"
#import "Utils.h"
#import "LoginViewController.h"
#import "AddNotes.h"
#import <Social/Social.h>
#import <MessageUI/MessageUI.h>
#import "SavedSearchViewController.h"
#import "LoginViewController.h"
#import "DevelopmentInfoCell.h"
#import "LastSaleTaxCell.h"
#import "DevelopmentDetail.h"



@interface PropertyDetailViewController ()
@end

@implementation PropertyDetailViewController

- (CGFloat)textViewHeightForAttributedText:(NSMutableAttributedString*)text
{
    UITextView *txtSavedSearch = [[UITextView alloc] init];
    [txtSavedSearch setAttributedText:text];
    CGSize size = [txtSavedSearch sizeThatFits:CGSizeMake(280, 34)];
    return size.height;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    NSLog(@"my index---%ld",(long)self.selectedIndex);
    strAddress=@"1";
    strInfo=@"2";
    strHomeType=@"0";
    showDevelopment = true;
    showSaleTax  = true;
    _delegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    arrText = [[NSMutableArray alloc] initWithObjects:@"210, Plam Street,",@"dfsdf fdsdfsd ",@"4sdf eeege g edhre 4564 fghgrh fhfg4 5t4fg hgf 45hhfgh f353 6s" ,nil];
    [self getpropertyDetail];
    dictCheck = [[NSMutableDictionary alloc] init];
    for (int i=0;i<2;i++)
    {
        [dictCheck setValue:@"0" forKey:[NSString stringWithFormat:@"%d",i]];
    }

    arrImage = [[NSMutableArray alloc]init];
    
    pageControl.currentPage = 0;
    pageControl.numberOfPages = [arrImage count];

    if(IsRunningTallPhone())
        [self.view setFrame:CGRectMake(0, 0, 320, 568)];
    else
        [self.view setFrame:CGRectMake(0, 0, 320, 480)];
    
    if (!IS_IPHONE) {
        
        [self.view setFrame:CGRectMake(0, 0, 768, 1024)];
    }
    
    UIView *viewProperty = [[UIView alloc] init];
    viewProperty.backgroundColor = [UIColor clearColor];
    if(IsRunningTallPhone())
        viewProperty.frame = CGRectMake(0,0,320,568);
    else
        viewProperty.frame = CGRectMake(0,0,320,480);
    
    if (!IS_IPHONE) {
         viewProperty.frame = CGRectMake(0,0,768,1024);
    }

    [self.view addSubview:viewProperty];
    UIImageView *img = [[UIImageView alloc] init];
    img.backgroundColor = [UIColor clearColor];
    if (IS_IPHONE) {
        img.frame = CGRectMake(0, 0, 320, 44);
    } else {
        img.frame = CGRectMake(0, 0, 768, 60);
    }
    
    img.image = [UIImage imageNamed:@"top_blue.png"];
    [viewProperty addSubview:img];
    
    UIButton *btnBack = [UIButton buttonWithType:UIButtonTypeCustom];
    if (IS_IPHONE) {
         btnBack.frame=CGRectMake(18,7,70,30);
    } else {
         btnBack.frame=CGRectMake(18,15,70,30);
    }
   
    btnBack.backgroundColor=[UIColor clearColor];
    [btnBack setContentEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
    [btnBack setImage:[UIImage imageNamed:@"slider_left_arrow.png"] forState:UIControlStateNormal];
    btnBack.titleLabel.font = [UIFont fontWithName:@"Helvetica" size:18.0];
    [btnBack setTitle:@" Back" forState:UIControlStateNormal];
    btnBack.titleLabel.textColor = [UIColor whiteColor];
    [btnBack addTarget:self action:@selector(btnBack) forControlEvents:UIControlEventTouchUpInside];
    [viewProperty addSubview:btnBack];
    
     // Update label counter
  
    
    btnUpArrow = [UIButton buttonWithType:UIButtonTypeCustom];
    btnUpArrow.backgroundColor=[UIColor clearColor];
    if (IS_IPHONE) {
         btnUpArrow.frame=CGRectMake(245,7,31,30);
    } else {
         btnUpArrow.frame=CGRectMake(670,15,31,30);
    }
   
    [btnUpArrow setImage:[UIImage imageNamed:@"top_arrow.png"] forState:UIControlStateNormal];
    [btnUpArrow addTarget:self action:@selector(buttonUpArrow) forControlEvents:UIControlEventTouchUpInside];
    [viewProperty addSubview:btnUpArrow];
    
    
    btnDownArrow = [UIButton buttonWithType:UIButtonTypeCustom];
    btnDownArrow.backgroundColor=[UIColor clearColor];
    if (IS_IPHONE) {
        btnDownArrow.frame=CGRectMake(280,7,31,30);
    } else {
        btnDownArrow.frame=CGRectMake(710,15,31,30);
    }
    
    [btnDownArrow setImage:[UIImage imageNamed:@"bottom_arrow.png"] forState:UIControlStateNormal];
    [btnDownArrow addTarget:self action:@selector(buttonDownArrow) forControlEvents:UIControlEventTouchUpInside];
    [viewProperty addSubview:btnDownArrow];
    
    if (self.selectedIndex<=0) {
      
        btnDownArrow.enabled = NO;
    } else {
       
        btnDownArrow.enabled = YES;
    }
    
    if (IS_IPHONE) {
        lblCounter1 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-50,7,100,30)];
    } else {
        lblCounter1 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-50,15,100,30)];
    }
    lblCounter1.text = @"";
    lblCounter1.textColor = [UIColor whiteColor];
    lblCounter1.textAlignment  = NSTextAlignmentCenter;
    [viewProperty addSubview:lblCounter1];
    

    if(IsRunningTallPhone())
        scrlView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 44, 320, 568)];
    else
        scrlView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 44, 320, 480)];
    
    if (!IS_IPHONE) {
        scrlView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 60, 768, 1024)];
    }

    scrlView.backgroundColor = [UIColor clearColor];
    [viewProperty addSubview:scrlView];
    
    
    if (IS_IPHONE) {
        scrlViewImage = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 200)];
    } else {
        scrlViewImage = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 768, 220)];
    }
    scrlViewImage.backgroundColor = [UIColor clearColor];
    scrlViewImage.showsHorizontalScrollIndicator=FALSE;
    [scrlViewImage setCanCancelContentTouches:NO];

    scrlViewImage.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    scrlViewImage.scrollEnabled = YES;
	scrlViewImage.pagingEnabled = YES;
    scrlViewImage.scrollsToTop = NO;
    [scrlView addSubview:scrlViewImage];
    
    scrlViewImage.delegate=self;
    CGRect frame = scrlViewImage.frame;
    frame.origin.x = frame.size.width * num;
    frame.origin.y = 0;
	[scrlViewImage scrollRectToVisible:frame animated:NO];
    pageControlUsed = YES;

    UIImageView *imgNextBack = [[UIImageView alloc] init];
    imgNextBack.backgroundColor = [UIColor blackColor];
    if (IS_IPHONE) {
        imgNextBack.frame = CGRectMake(0, 156, 320, 44);
    } else {
        imgNextBack.frame = CGRectMake(0, 156, 768, 44);
    }
    
    imgNextBack.alpha = 0.5f;
    [scrlView addSubview:imgNextBack];
    
    btnPrevious = [UIButton buttonWithType:UIButtonTypeCustom];
    btnPrevious.backgroundColor=[UIColor clearColor];
    
    if (IS_IPHONE) {
        btnPrevious.frame=CGRectMake(11,164,29,29);
    } else {
        btnPrevious.frame=CGRectMake(11,160,35,35);
    }
    
    [btnPrevious setImage:[UIImage imageNamed:@"slider_left_arrow"] forState:UIControlStateNormal];
    [btnPrevious addTarget:self action:@selector(btnPreviousClicked) forControlEvents:UIControlEventTouchUpInside];
    [scrlView addSubview:btnPrevious];
    btnPrevious.userInteractionEnabled=FALSE;
    
    btnNext = [UIButton buttonWithType:UIButtonTypeCustom];
    btnNext.backgroundColor=[UIColor clearColor];
    if (IS_IPHONE) {
         btnNext.frame=CGRectMake(281,164,29,29);
    } else {
        btnNext.frame=CGRectMake(728,160,35,35);
    }
    [btnNext setImage:[UIImage imageNamed:@"slider_right_arrow"] forState:UIControlStateNormal];
    [btnNext addTarget:self action:@selector(btnNextClicked) forControlEvents:UIControlEventTouchUpInside];
    [scrlView addSubview:btnNext];
    
    if (IS_IPHONE) {
        lblCounter2 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-65,164,130,30)];
        lblCounter2.text = @"";
        lblCounter2.textColor = [UIColor whiteColor];
        [scrlView addSubview:lblCounter2];
    } else {
       // lblCounter2 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-65,164,130,30)];
         lblCounter2 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-65,162,130,30)];
        lblCounter2.text = @"";
        lblCounter2.textColor = [UIColor whiteColor];
        [scrlView addSubview:lblCounter2];
    }
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[arrText objectAtIndex:0]];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica-Bold" size:17.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        h1=0.0;
        if(height1>34)
        {
            h1=height1-34;
        }
    }
    else
    {
        txtViewHeight = [[UITextView alloc] init];
        txtViewHeight.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
        txtViewHeight.text = [arrText objectAtIndex:0];
        txtViewHeight.frame = CGRectMake(0, 0, 280, 34);
        [self.view addSubview:txtViewHeight];
        rect = txtViewHeight.frame;
        rect.size = txtViewHeight.contentSize;
        txtViewHeight.frame = rect;
        [txtViewHeight removeFromSuperview];
        if(rect.size.height>34)
            h1=rect.size.height-34;
    }
    imgViewHome = [[UIImageView alloc] init];
    imgViewHome.backgroundColor = [UIColor clearColor];
    imgViewHome.frame = CGRectMake(14, 45+200+h1, 24, 24);
    [scrlView addSubview:imgViewHome];
    
    lblHomeType = [[UILabel alloc] init];
    lblHomeType.frame = CGRectMake(44, 46+200+h1, 75, 27);
    lblHomeType.backgroundColor = [UIColor clearColor];
    lblHomeType.font = [UIFont fontWithName:@"Helvetica-Bold" size:16.0];
    [scrlView addSubview:lblHomeType];
    
    lblHomeTmp = [[UILabel alloc] init];
    lblHomeTmp.backgroundColor = [UIColor clearColor];
    
    if([strHomeType isEqualToString:@"0"])
    {
        lblHomeTmp.text = @"";
        lblHomeTmp.frame = CGRectMake(119, 45+200+h1, 100, 27);
    }
    else if([strHomeType isEqualToString:@"1"])
    {
        lblHomeTmp.text = @"";
        lblHomeTmp.frame = CGRectMake(119, 45+200+h1, 100, 27);
    }
    else if([strHomeType isEqualToString:@"2"])
    {
        lblHomeTmp.text = @"";
        lblHomeTmp.frame = CGRectMake(114, 45+200+h1, 100, 27);
    }
    else if([strHomeType isEqualToString:@"3"])
    {
        lblHomeTmp.text = @"";
        lblHomeTmp.frame = CGRectMake(121, 45+200+h1, 100, 27);
    }
    lblHomeTmp.textColor = [UIColor colorWithRed:74/255.0 green:74/255.0 blue:74/255.0 alpha:1.0];
    lblHomeTmp.font = [UIFont fontWithName:@"Helvetica" size:17.0];
    [scrlView addSubview:lblHomeTmp];
   
    
    titleLabel = [[OHAttributedLabel alloc] init];
    titleLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [titleLabel setFrame:CGRectMake(14, 80+200+h1, 288, 50)];
    titleLabel.numberOfLines = 2;
    // titleLabel.attributedText=attrStr;
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [scrlView addSubview:titleLabel];
    
    lblBedBath = [[UILabel alloc] init];
    lblBedBath.frame = CGRectMake(14, 108+200+h1, 170, 27);
    lblBedBath.backgroundColor = [UIColor clearColor];
    lblBedBath.textColor = [UIColor colorWithRed:58/255.0 green:103/255.0 blue:253/255.0 alpha:1.0];
    lblBedBath.font = [UIFont fontWithName:@"Helvetica" size:15.0];
    [scrlView addSubview:lblBedBath];
    
    lblYear = [[UILabel alloc] init];
    lblYear.frame = CGRectMake(225, 109+200+h1, 90, 27);
    lblYear.backgroundColor = [UIColor clearColor];
    lblYear.textColor = [UIColor colorWithRed:58/255.0 green:103/255.0 blue:253/255.0 alpha:1.0];
    lblYear.font = [UIFont fontWithName:@"Helvetica" size:15.0];
    [scrlView addSubview:lblYear];
    
    lblOpenHome = [[UILabel alloc] init];
    lblOpenHome.frame = CGRectMake(14, 130+200+h1, 200, 27);
    lblOpenHome.backgroundColor = [UIColor clearColor];
    lblOpenHome.textColor = [UIColor colorWithRed:133/255.0 green:133/255.0 blue:133/255.0 alpha:1.0];
    lblOpenHome.font = [UIFont fontWithName:@"Helvetica" size:15.0];
    [scrlView addSubview:lblOpenHome];
    
    UIImageView *imgViewSep = [[UIImageView alloc] init];
    imgViewSep.backgroundColor = [UIColor clearColor];
    imgViewSep.frame = CGRectMake(0, 163+200+h1, 320, 1);
    imgViewSep.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep];
    
    UIImageView *imgViewSepBack = [[UIImageView alloc] init];
    imgViewSepBack.backgroundColor = [UIColor colorWithRed:244/255.0 green:244/255.0 blue:244/255.0 alpha:1.0f];
    imgViewSepBack.frame = CGRectMake(0, 164+200+h1, 320, 72);
    [scrlView addSubview:imgViewSepBack];
    
    btnSave = [UIButton buttonWithType:UIButtonTypeCustom];
    btnSave.backgroundColor=[UIColor clearColor];
    btnSave.frame=CGRectMake(6,170+200+h1,57,57);
    [btnSave setImage:[UIImage imageNamed:@"save_tab.png"] forState:UIControlStateNormal];
    [btnSave addTarget:self action:@selector(buttonTitlesClicked:) forControlEvents:UIControlEventTouchUpInside];
    btnSave.tag = 100;
    [scrlView addSubview:btnSave];
    
    btnAddNote = [UIButton buttonWithType:UIButtonTypeCustom];
    btnAddNote.backgroundColor=[UIColor clearColor];
    btnAddNote.frame=CGRectMake(69,170+200+h1,57,57);
    [btnAddNote setImage:[UIImage imageNamed:@"addNote_tab.png"] forState:UIControlStateNormal];
    [btnAddNote addTarget:self action:@selector(buttonTitlesClicked:) forControlEvents:UIControlEventTouchUpInside];
    btnAddNote.tag = 200;
    [scrlView addSubview:btnAddNote];
    
    btnAddPhoto = [UIButton buttonWithType:UIButtonTypeCustom];
    btnAddPhoto.backgroundColor=[UIColor clearColor];
    btnAddPhoto.frame=CGRectMake(132,170+200+h1,57,57);
    [btnAddPhoto setImage:[UIImage imageNamed:@"aadPhoto_tab.png"] forState:UIControlStateNormal];
    [btnAddPhoto addTarget:self action:@selector(buttonTitlesClicked:) forControlEvents:UIControlEventTouchUpInside];
    btnAddPhoto.tag = 300;
    [scrlView addSubview:btnAddPhoto];
    
    btnShare = [UIButton buttonWithType:UIButtonTypeCustom];
    btnShare.backgroundColor=[UIColor clearColor];
    btnShare.frame=CGRectMake(195,170+200+h1,57,57);
    [btnShare setImage:[UIImage imageNamed:@"share_tab.png"] forState:UIControlStateNormal];
    [btnShare addTarget:self action:@selector(buttonTitlesClicked:) forControlEvents:UIControlEventTouchUpInside];
     btnShare.tag = 400;
    [scrlView addSubview:btnShare];
    
    btnContact = [UIButton buttonWithType:UIButtonTypeCustom];
    btnContact.backgroundColor=[UIColor clearColor];
    btnContact.frame=CGRectMake(258,170+200+h1,57,57);
    [btnContact setImage:[UIImage imageNamed:@"contact_tab.png"] forState:UIControlStateNormal];
    [btnContact addTarget:self action:@selector(buttonTitlesClicked:) forControlEvents:UIControlEventTouchUpInside];
    btnContact.tag = 500;
    [scrlView addSubview:btnContact];
    
    UIImageView *imgViewSep1 = [[UIImageView alloc] init];
    imgViewSep1.backgroundColor = [UIColor clearColor];
    imgViewSep1.frame = CGRectMake(0, 235+200+h1, 320, 1);
    imgViewSep1.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep1];
    
    UIImageView *imgViewPropertyDesc = [[UIImageView alloc] init];
    imgViewPropertyDesc.backgroundColor = [UIColor colorWithRed:244/255.0 green:244/255.0 blue:244/255.0 alpha:1.0f];
    imgViewPropertyDesc.frame = CGRectMake(0, 236+200+h1, 320, 44);
    [scrlView addSubview:imgViewPropertyDesc];
    
    UILabel *lblPropertyDesc = [[UILabel alloc] init];
    lblPropertyDesc.frame = CGRectMake(12, 245+200+h1, 200, 27);
    lblPropertyDesc.backgroundColor = [UIColor clearColor];
    lblPropertyDesc.textColor = [UIColor colorWithRed:58/255.0 green:104/255.0 blue:253/255.0 alpha:1.0];
    lblPropertyDesc.text=@"Property Description";
    lblPropertyDesc.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
    [scrlView addSubview:lblPropertyDesc];
    
    UIImageView *imgViewSep2 = [[UIImageView alloc] init];
    imgViewSep2.backgroundColor = [UIColor clearColor];
    imgViewSep2.frame = CGRectMake(0, 280+200+h1, 320, 1);
    imgViewSep2.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep2];
    
    UIImageView *imgViewPropertyBack = [[UIImageView alloc] init];
    imgViewPropertyBack.backgroundColor = [UIColor clearColor];
    imgViewPropertyBack.backgroundColor = [UIColor colorWithRed:251/255.0 green:251/255.0 blue:251/255.0 alpha:1.0];
    [scrlView addSubview:imgViewPropertyBack];
    
    /*****/
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[arrText objectAtIndex:1]];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:15.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        h2=0.0;
        if(height1>34)
        {
            h2=height1-34;
        }
    }
    else
    {
        txtViewHeight = [[UITextView alloc] init];
        txtViewHeight.font = [UIFont fontWithName:@"Helvetica" size:15.0];
        txtViewHeight.text = [arrText objectAtIndex:1];
        txtViewHeight.frame = CGRectMake(0, 0, 280, 34);
        [self.view addSubview:txtViewHeight];
        rect = txtViewHeight.frame;
        rect.size = txtViewHeight.contentSize;
        txtViewHeight.frame = rect;
        [txtViewHeight removeFromSuperview];
        if(rect.size.height>34)
            h2=rect.size.height-34;
    }
    
    txtViewPropertyDes = [[UITextView alloc] initWithFrame: CGRectMake(self.view.frame.origin.x+6, 285+200+h1, self.view.frame.size.width-12, 84+h2)];
    txtViewPropertyDes.editable=NO;
    txtViewPropertyDes.scrollEnabled=YES;
    txtViewPropertyDes.backgroundColor = [UIColor clearColor];
    txtViewPropertyDes.font = [UIFont fontWithName:@"Helvetica" size:15.0];
    txtViewPropertyDes.textColor = [UIColor colorWithRed:80/255.0 green:80/255.0 blue:80/255.0 alpha:1.0];
    txtViewPropertyDes.text = [arrText objectAtIndex:1];
    [scrlView addSubview:txtViewPropertyDes];
    
    UIImageView *imgViewSep3 = [[UIImageView alloc] init];
    imgViewSep3.backgroundColor = [UIColor clearColor];
    imgViewSep3.frame = CGRectMake(0, 321+250+h1+h2, 320, 1);
    imgViewSep3.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep3];
    
    UILabel *lblInterior = [[UILabel alloc] init];
    lblInterior.frame = CGRectMake(12, 327+250+h1+h2, 200, 27);
    lblInterior.backgroundColor = [UIColor clearColor];
    lblInterior.textColor = [UIColor colorWithRed:70/255.0 green:70/255.0 blue:70/255.0 alpha:1.0];
    lblInterior.text=@"Interior";
    lblInterior.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
    [scrlView addSubview:lblInterior];
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[arrText objectAtIndex:2]];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:15.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        h3=0.0;
        if(height1>34)
        {
            h3=height1-34;
        }
    }
    else
    {
        txtViewHeight = [[UITextView alloc] init];
        txtViewHeight.font = [UIFont fontWithName:@"Helvetica" size:15.0];
        txtViewHeight.text = [arrText objectAtIndex:2];
        txtViewHeight.frame = CGRectMake(0, 0, 280, 34);
        [self.view addSubview:txtViewHeight];
        rect = txtViewHeight.frame;
        rect.size = txtViewHeight.contentSize;
        txtViewHeight.frame = rect;
        [txtViewHeight removeFromSuperview];
        if(rect.size.height>34)
            h3=rect.size.height-34;
    }
    
    txtViewInterior = [[UITextView alloc] initWithFrame: CGRectMake(self.view.frame.origin.x+6, 350+250+h1+h2, self.view.frame.size.width-12, 34+h3)];
    txtViewInterior.editable=NO;
    txtViewInterior.scrollEnabled=YES;
    txtViewInterior.backgroundColor = [UIColor clearColor];
    txtViewInterior.font = [UIFont fontWithName:@"Helvetica" size:15.0];
    txtViewInterior.textColor = [UIColor grayColor];
    txtViewInterior.text =  @"Interior";//[arrText objectAtIndex:2];
    [scrlView addSubview:txtViewInterior];
    
    UIImageView *imgViewSep4 = [[UIImageView alloc] init];
    imgViewSep4.backgroundColor = [UIColor clearColor];
    imgViewSep4.frame = CGRectMake(0, 384+250+h1+h2+h3, 320, 1);
    imgViewSep4.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep4];
    
    UILabel *lblFees = [[UILabel alloc] init];
    lblFees.frame = CGRectMake(12, 391+250+h1+h2+h3, 200, 27);
    lblFees.backgroundColor = [UIColor clearColor];
    lblFees.textColor = [UIColor colorWithRed:70/255.0 green:70/255.0 blue:70/255.0 alpha:1.0];
    lblFees.text=@"Fees";
    lblFees.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
    [scrlView addSubview:lblFees];
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[arrText objectAtIndex:2]];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:15.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        h4=0.0;
        if(height1>34)
        {
            h4=height1-34;
        }
    }
    else
    {
        txtViewHeight = [[UITextView alloc] init];
        txtViewHeight.font = [UIFont fontWithName:@"Helvetica" size:15.0];
        txtViewHeight.text = [arrText objectAtIndex:2];
        txtViewHeight.frame = CGRectMake(0, 0, 280, 34);
        [self.view addSubview:txtViewHeight];
        rect = txtViewHeight.frame;
        rect.size = txtViewHeight.contentSize;
        txtViewHeight.frame = rect;
        [txtViewHeight removeFromSuperview];
        if(rect.size.height>34)
            h4=rect.size.height-34;
    }
    
    UITextView *txtViewFees = [[UITextView alloc] initWithFrame: CGRectMake(self.view.frame.origin.x+6, 411+250+h1+h2+h3, self.view.frame.size.width-12, 34+h4)];
    txtViewFees.editable=NO;
    txtViewFees.scrollEnabled=NO;
    txtViewFees.backgroundColor = [UIColor clearColor];
    txtViewFees.font = [UIFont fontWithName:@"Helvetica" size:15.0];
    txtViewFees.textColor = [UIColor grayColor];
    txtViewFees.text = [arrText objectAtIndex:2];
    [scrlView addSubview:txtViewFees];
    
    UIImageView *imgViewSep5 = [[UIImageView alloc] init];
    imgViewSep5.backgroundColor = [UIColor clearColor];
    imgViewSep5.frame = CGRectMake(0, 450+250+h1+h2+h3+h4, 320, 1);
    imgViewSep5.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep5];
    
    UILabel *lblRental = [[UILabel alloc] init];
    lblRental.frame = CGRectMake(12, 457+250+h1+h2+h3+h4, 200, 27);
    lblRental.backgroundColor = [UIColor clearColor];
    lblRental.textColor = [UIColor colorWithRed:70/255.0 green:70/255.0 blue:70/255.0 alpha:1.0];
    lblRental.text=@"Rental Restrictions";
    lblRental.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
    [scrlView addSubview:lblRental];
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[arrText objectAtIndex:2]];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:15.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        h5=0.0;
        if(height1>34)
        {
            h5=height1-34;
        }
    }
    else
    {
        txtViewHeight = [[UITextView alloc] init];
        txtViewHeight.font = [UIFont fontWithName:@"Helvetica" size:15.0];
        txtViewHeight.text = [arrText objectAtIndex:2];
        txtViewHeight.frame = CGRectMake(0, 0, 280, 34);
        [self.view addSubview:txtViewHeight];
        rect = txtViewHeight.frame;
        rect.size = txtViewHeight.contentSize;
        txtViewHeight.frame = rect;
        [txtViewHeight removeFromSuperview];
        if(rect.size.height>34)
            h5=rect.size.height-34;
    }
    
    txtViewRental = [[UITextView alloc] initWithFrame: CGRectMake(self.view.frame.origin.x+6, 478+250+h1+h2+h3+h4, self.view.frame.size.width-12, 34+h5)];
    txtViewRental.editable=NO;
    txtViewRental.scrollEnabled=YES;
    txtViewRental.backgroundColor = [UIColor clearColor];
    txtViewRental.font = [UIFont fontWithName:@"Helvetica" size:15.0];
    txtViewRental.textColor = [UIColor grayColor];
    txtViewRental.text = [arrText objectAtIndex:2];
    [scrlView addSubview:txtViewRental];
    
    UIImageView *imgViewSep6 = [[UIImageView alloc] init];
    imgViewSep6.backgroundColor = [UIColor clearColor];
    imgViewSep6.frame = CGRectMake(0, 512+250+h1+h2+h3+h4+h5, 320, 1);
    imgViewSep6.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep6];
    
    UILabel *lblAmenities = [[UILabel alloc] init];
    lblAmenities.frame = CGRectMake(12, 519+250+h1+h2+h3+h4+h5, 200, 27);
    lblAmenities.backgroundColor = [UIColor clearColor];
    lblAmenities.textColor = [UIColor colorWithRed:70/255.0 green:70/255.0 blue:70/255.0 alpha:1.0];
    lblAmenities.text=@"Amenities";
    lblAmenities.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
    [scrlView addSubview:lblAmenities];
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[arrText objectAtIndex:2]];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:15.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        h6=0.0;
        if(height1>34)
        {
            h6=height1-34;
        }
    }
    else
    {
        txtViewHeight = [[UITextView alloc] init];
        txtViewHeight.font = [UIFont fontWithName:@"Helvetica" size:15.0];
        txtViewHeight.text = [arrText objectAtIndex:2];
        txtViewHeight.frame = CGRectMake(0, 0, 280, 34);
        [self.view addSubview:txtViewHeight];
        rect = txtViewHeight.frame;
        rect.size = txtViewHeight.contentSize;
        txtViewHeight.frame = rect;
        [txtViewHeight removeFromSuperview];
        if(rect.size.height>34)
            h6=rect.size.height-34;
    }
    
    
    txtViewAmenties = [[UITextView alloc] initWithFrame: CGRectMake(self.view.frame.origin.x+6, 539+250+h1+h2+h3+h4+h5, self.view.frame.size.width-12, 34+h6)];
    txtViewAmenties.editable=NO;
    txtViewAmenties.scrollEnabled=YES;
    txtViewAmenties.backgroundColor = [UIColor clearColor];
    txtViewAmenties.font = [UIFont fontWithName:@"Helvetica" size:15.0];
    txtViewAmenties.textColor = [UIColor grayColor];
    txtViewAmenties.text = [arrText objectAtIndex:2];
    [scrlView addSubview:txtViewAmenties];
    
    UIImageView *imgViewSep7 = [[UIImageView alloc] init];
    imgViewSep7.backgroundColor = [UIColor clearColor];
    imgViewSep7.frame = CGRectMake(0, 575+250+h1+h2+h3+h4+h5+h6, 320, 1);
    imgViewSep7.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep7];
    
    UILabel *lblExterior = [[UILabel alloc] init];
    lblExterior.frame = CGRectMake(12, 580+250+h1+h2+h3+h4+h5+h6, 200, 27);
    lblExterior.backgroundColor = [UIColor clearColor];
    lblExterior.textColor = [UIColor colorWithRed:70/255.0 green:70/255.0 blue:70/255.0 alpha:1.0];
    lblExterior.text=@"Exterior";
    lblExterior.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
    [scrlView addSubview:lblExterior];
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[arrText objectAtIndex:2]];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:15.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        h7=0.0;
        if(height1>34)
        {
            h7=height1-34;
        }
    }
    else
    {
        txtViewHeight = [[UITextView alloc] init];
        txtViewHeight.font = [UIFont fontWithName:@"Helvetica" size:15.0];
        txtViewHeight.text = [arrText objectAtIndex:2];
        txtViewHeight.frame = CGRectMake(0, 0, 280, 34);
        [self.view addSubview:txtViewHeight];
        rect = txtViewHeight.frame;
        rect.size = txtViewHeight.contentSize;
        txtViewHeight.frame = rect;
        [txtViewHeight removeFromSuperview];
        if(rect.size.height>34)
            h7=rect.size.height-34;
    }
    
    txtViewExterior = [[UITextView alloc] initWithFrame: CGRectMake(self.view.frame.origin.x+6, 601+250+h1+h2+h3+h4+h5+h6, self.view.frame.size.width-12, 34+h7)];
    txtViewExterior.editable=NO;
    txtViewExterior.scrollEnabled=YES;
    txtViewExterior.backgroundColor = [UIColor clearColor];
    txtViewExterior.font = [UIFont fontWithName:@"Helvetica" size:15.0];
    txtViewExterior.textColor = [UIColor grayColor];
    txtViewExterior.text = @"exterior";
    [scrlView addSubview:txtViewExterior];
    
    tblDevelopmentInfo = [[UITableView alloc] init];
    tblDevelopmentInfo.frame = CGRectMake(0, 636+250+h1+h2+h3+h4+h5+h6+h7, 320, 205);
    tblDevelopmentInfo.backgroundColor = [UIColor clearColor];
    tblDevelopmentInfo.delegate=self;
    tblDevelopmentInfo.dataSource=self;
    tblDevelopmentInfo.separatorStyle = UITableViewCellSeparatorStyleNone;
    [scrlView addSubview:tblDevelopmentInfo];
    tblDevelopmentInfo.rowHeight=125;
    tblDevelopmentInfo.showsVerticalScrollIndicator = NO;
    tblDevelopmentInfo.showsHorizontalScrollIndicator = NO;
    tblDevelopmentInfo.scrollEnabled = NO;
    
    
    UIImageView *imgViewSep11 = [[UIImageView alloc] init];
    imgViewSep11.frame = CGRectMake(0, 838+250+h1+h2+h3+h4+h5+h6+h7+h8, 320, 1);
    imgViewSep11.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep11];
    
    UIImageView *imgDevelopment1 = [[UIImageView alloc] init];
    imgDevelopment1.backgroundColor = [UIColor colorWithRed:244/255.0 green:244/255.0 blue:244/255.0 alpha:1.0];
    imgDevelopment1.frame = CGRectMake(0, 839+250+h1+h2+h3+h4+h5+h6+h7+h8, 320, 15);
    [scrlView addSubview:imgDevelopment1];
    
    UIImageView *imgViewSep12 = [[UIImageView alloc] init];
    imgViewSep12.frame = CGRectMake(0, 854+250+h1+h2+h3+h4+h5+h6+h7+h8, 320, 1);
    imgViewSep12.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep12];
    
    UILabel *lblRecent = [[UILabel alloc] init];
    lblRecent.frame = CGRectMake(12, 860+250+h1+h2+h3+h4+h5+h6+h7+h8, 300, 27);
    lblRecent.backgroundColor = [UIColor clearColor];
    lblRecent.textColor = [UIColor colorWithRed:58/255.0 green:104/255.0 blue:253/255.0 alpha:1.0];
    lblRecent.text=@"Recent Comparable Sales";
    lblRecent.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
    [scrlView addSubview:lblRecent];
    
    int count = 2;
    int tblPlus;
    CGFloat tblHeight;
    if(count==1)
    {
        tblHeight = 142;
        tblPlus=1;
    }
    else if(count==2)
    {
        tblHeight = 284;
        tblPlus=2;
    }
    else
    {
        tblHeight=426;
        tblPlus=3;
    }
    tblViewRecentComparable = [[UITableView alloc] init];
    tblViewRecentComparable.frame = CGRectMake(0, 890+250+h1+h2+h3+h4+h5+h6+h7+h8, 320, tblHeight);
    tblViewRecentComparable.backgroundColor = [UIColor clearColor];
    tblViewRecentComparable.delegate=self;
    tblViewRecentComparable.dataSource=self;
    tblViewRecentComparable.separatorStyle = UITableViewCellSeparatorStyleNone;
    [scrlView addSubview:tblViewRecentComparable];
    tblViewRecentComparable.rowHeight=142;
    
    UIImageView *imgViewDisclousre = [[UIImageView alloc] init];
    imgViewDisclousre.backgroundColor = [UIColor colorWithRed:244/255.0 green:244/255.0 blue:244/255.0 alpha:1.0];
    imgViewDisclousre.frame = CGRectMake(0, 890+250+h1+h2+h3+h4+h5+h6+h7+h8+tblHeight, 320, 15);
    [scrlView addSubview:imgViewDisclousre];
    
    UIImageView *imgViewSep13 = [[UIImageView alloc] init];
    imgViewSep13.frame = CGRectMake(0, 905+250+h1+h2+h3+h4+h5+h6+h7+h8+tblHeight, 320, 1);
    imgViewSep13.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep13];

    UIImageView *imgViewDisclosure1 = [[UIImageView alloc] init];
    imgViewDisclosure1.layer.borderWidth=1.0;
    imgViewDisclosure1.layer.borderColor=[UIColor clearColor].CGColor;
    imgViewDisclosure1.frame = CGRectMake(14, 913+250+h1+h2+h3+h4+h5+h6+h7+h8+tblHeight, 55, 55);
    imgViewDisclosure1.image = [UIImage imageNamed:@"big_home.png"];
    [scrlView addSubview:imgViewDisclosure1];

    lblListingCourtesy = [[UILabel alloc] init];
    lblListingCourtesy.frame = CGRectMake(76, 911+250+h1+h2+h3+h4+h5+h6+h7+h8+tblHeight, self.view.frame.size.width-76, 30);
    lblListingCourtesy.numberOfLines = 2;
    lblListingCourtesy.backgroundColor = [UIColor clearColor];
    lblListingCourtesy.textColor = [UIColor colorWithRed:70/255.0 green:70/255.0 blue:70/255.0 alpha:1.0];
    lblListingCourtesy.font = [UIFont fontWithName:@"Helvetica" size:13.0];
    [scrlView addSubview:lblListingCourtesy];
    
    UILabel *lblPropertyCome = [[UILabel alloc] init];
    lblPropertyCome.frame = CGRectMake(76, 933+250+h1+h2+h3+h4+h5+h6+h7+h8+tblHeight, 160, 27);
    lblPropertyCome.backgroundColor = [UIColor clearColor];
    lblPropertyCome.textColor = [UIColor colorWithRed:70/255.0 green:70/255.0 blue:70/255.0 alpha:1.0];
    lblPropertyCome.text=@"Property Come From:";
    lblPropertyCome.font = [UIFont fontWithName:@"Helvetica" size:13.0];
    [scrlView addSubview:lblPropertyCome];
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[arrText objectAtIndex:2]];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:14.0]];
        UITextView *txtSavedSearch = [[UITextView alloc] init];
        [txtSavedSearch setAttributedText:attributedString];
        CGSize size = [txtSavedSearch sizeThatFits:CGSizeMake(240, 34)];
        h9=0.0;
        if(size.height>34)
        {
            h9=size.height-34;
        }
    }
    else
    {
        txtViewHeight = [[UITextView alloc] init];
        txtViewHeight.font = [UIFont fontWithName:@"Helvetica" size:14.0];
        txtViewHeight.text = [arrText objectAtIndex:2];
        txtViewHeight.frame = CGRectMake(0, 0, 240, 34);
        [self.view addSubview:txtViewHeight];
        rect = txtViewHeight.frame;
        rect.size = txtViewHeight.contentSize;
        txtViewHeight.frame = rect;
        [txtViewHeight removeFromSuperview];
        if(rect.size.height>34)
            h9=rect.size.height-34;
    }

    UITextView *txtViewDisclosureInfo = [[UITextView alloc] initWithFrame: CGRectMake(71, 951+250+h1+h2+h3+h4+h5+h6+h7+h8+tblHeight, 240, 34+h9)];
    txtViewDisclosureInfo.editable=NO;
    txtViewDisclosureInfo.scrollEnabled=NO;
    txtViewDisclosureInfo.backgroundColor = [UIColor clearColor];
    txtViewDisclosureInfo.font = [UIFont fontWithName:@"Helvetica" size:13.0];
    txtViewDisclosureInfo.textColor = [UIColor colorWithRed:70/255.0 green:70/255.0 blue:70/255.0 alpha:1.0];
    txtViewDisclosureInfo.text = [arrText objectAtIndex:2];
    [scrlView addSubview:txtViewDisclosureInfo];
    
    UIImageView *imgViewSep14 = [[UIImageView alloc] init];
    imgViewSep14.frame = CGRectMake(0, 981+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight, 320, 1);
    imgViewSep14.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep14];
    
    UIImageView *imgViewAddFav = [[UIImageView alloc] init];
    imgViewAddFav.backgroundColor = [UIColor colorWithRed:241/255.0 green:241/255.0 blue:241/255.0 alpha:1.0];
    imgViewAddFav.frame = CGRectMake(0, 982+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight, 320, 50);
    [scrlView addSubview:imgViewAddFav];
    
    UIButton *btnAddFavoriteHome = [UIButton buttonWithType:UIButtonTypeCustom];
    btnAddFavoriteHome.titleLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:16.0];
    btnAddFavoriteHome.frame=CGRectMake(50, 987+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight, 220, 40);
    [btnAddFavoriteHome addTarget:self action:@selector(AddFavoriteHome:) forControlEvents:UIControlEventTouchUpInside];
    [scrlView addSubview:btnAddFavoriteHome];
    [btnAddFavoriteHome setTitle:@"Add to Favorites Home" forState:UIControlStateNormal];
    btnAddFavoriteHome.backgroundColor=[UIColor clearColor];
    [btnAddFavoriteHome setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [btnAddFavoriteHome setTitleColor:[UIColor redColor] forState:UIControlStateReserved];
    [btnAddFavoriteHome setTitleColor:[UIColor redColor] forState:UIControlStateHighlighted];
    
    
    UIImageView *imgViewSep15 = [[UIImageView alloc] init];
    imgViewSep15.frame = CGRectMake(0, 1027+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight, 320, 1);
    imgViewSep15.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep15];
    
    /*********Agent List*********/
    int intAgentcount = 2;
    int intAgentPlus;
    CGFloat tblAgentHeight;
    if(intAgentcount==1)
    {
        tblAgentHeight = 106;
        intAgentPlus=1;
    }
    else if(intAgentcount==2)
    {
        tblAgentHeight = 212;
        intAgentPlus=2;
    }
    else
    {
        tblAgentHeight=318;
        intAgentPlus=3;
    }
    tblAgent = [[UITableView alloc] init];
    tblAgent.frame = CGRectMake(0, 1028+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight, 320, tblAgentHeight+25);
    tblAgent.backgroundColor = [UIColor colorWithRed:244/255.0 green:244/255.0 blue:244/255.0 alpha:1.0];
    tblAgent.delegate=self;
    tblAgent.dataSource=self;
    tblAgent.separatorStyle = UITableViewCellSeparatorStyleNone;
    [scrlView addSubview:tblAgent];
    tblAgent.rowHeight=142;
    
    /************User Information**********/
    UIImageView *imgViewSep16 = [[UIImageView alloc] init];
    imgViewSep16.frame = CGRectMake(0, 1045+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 320, 8);
    imgViewSep16.image = [UIImage imageNamed:@"arrow_sep.png"];
    [scrlView addSubview:imgViewSep16];
    
    UIImageView *imgViewInformation = [[UIImageView alloc] init];
    imgViewInformation.frame = CGRectMake(0, 1053+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 320, 157);
    imgViewInformation.backgroundColor = [UIColor whiteColor];
    [scrlView addSubview:imgViewInformation];
    
    
    txtFieldEmail = [[UITextField alloc] init];
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
        [txtFieldEmail setFrame:CGRectMake(17, 1053+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 296, 36)];
    else
        [txtFieldEmail setFrame:CGRectMake(17, 1059+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 296, 36)];
    txtFieldEmail.placeholder = @"Email";
    [txtFieldEmail setValue:[UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    txtFieldEmail.delegate=self;
    txtFieldEmail.font = [UIFont fontWithName:@"Helvetica" size:17.0];
    txtFieldEmail.backgroundColor = [UIColor clearColor];
    [scrlView addSubview:txtFieldEmail];
    
    UIImageView *imgViewSep17 = [[UIImageView alloc] init];
    imgViewSep17.frame = CGRectMake(0, 1089+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 320, 1);
    imgViewSep17.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep17];
    
    
    txtFieldPhone = [[UITextField alloc] init];
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
        [txtFieldPhone setFrame:CGRectMake(17, 1091+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 296, 36)];
    else
        [txtFieldPhone setFrame:CGRectMake(17, 1097+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 296, 36)];
    
    txtFieldPhone.placeholder = @"Phone";
    [txtFieldPhone setValue:[UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    txtFieldPhone.delegate=self;
    txtFieldPhone.font = [UIFont fontWithName:@"Helvetica" size:17.0];
    txtFieldPhone.backgroundColor = [UIColor clearColor];
    txtFieldPhone.textColor = [UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1.0];
    [scrlView addSubview:txtFieldPhone];

    UIImageView *imgViewSep18 = [[UIImageView alloc] init];
    imgViewSep18.frame = CGRectMake(0, 1126+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 320, 1);
    imgViewSep18.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep18];
    
    txtViewMesaage = [[UITextView alloc] init];
    [txtViewMesaage setFrame:CGRectMake(10, 1127+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 308, 85)];
    txtViewMesaage.delegate=self;
    txtViewMesaage.font = [UIFont fontWithName:@"Helvetica" size:17.0];
    txtViewMesaage.backgroundColor = [UIColor clearColor];
    txtViewMesaage.text = @"Message";
    txtViewMesaage.textColor = [UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1.0];
    [scrlView addSubview:txtViewMesaage];

    UIImageView *imgViewSep19 = [[UIImageView alloc] init];
    imgViewSep19.frame = CGRectMake(0, 1219+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 320, 1);
    imgViewSep19.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep19];
    
    btnCheckApprove = [UIButton buttonWithType:UIButtonTypeCustom];
    btnCheckApprove.backgroundColor=[UIColor clearColor];
    btnCheckApprove.frame = CGRectMake(14, 1226+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 24, 24);
    [btnCheckApprove setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
    [btnCheckApprove addTarget:self action:@selector(btnApprovedClicked) forControlEvents:UIControlEventTouchUpInside];
    [scrlView addSubview:btnCheckApprove];
    
    UILabel *lblGetApproved = [[UILabel alloc] init];
    lblGetApproved.frame = CGRectMake(42, 1221+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 278, 36);
    lblGetApproved.backgroundColor = [UIColor clearColor];
    lblGetApproved.textColor = [UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1.0];
    lblGetApproved.text=@"I also want to get pre-approved";
    lblGetApproved.font = [UIFont fontWithName:@"Helvetica" size:16.0];
    [scrlView addSubview:lblGetApproved];
    
    UIImageView *imgViewSep20 = [[UIImageView alloc] init];
    imgViewSep20.frame = CGRectMake(0, 1257+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 320, 1);
    imgViewSep20.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgViewSep20];
    
    UIImageView *imgViewSend = [[UIImageView alloc] init];
    imgViewSend.frame = CGRectMake(0, 1258+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 320, 50);
    imgViewSend.backgroundColor = [UIColor colorWithRed:244/255.0 green:244/255.0 blue:244/255.0 alpha:1.0];
    [scrlView addSubview:imgViewSend];
    
    UIButton *btnSend = [UIButton buttonWithType:UIButtonTypeCustom];
   // btnSend.backgroundColor=[UIColor blueColor];
    btnSend.frame = CGRectMake(110, 1270+250+h1+h2+h3+h4+h5+h6+h7+h8+h9+tblHeight+tblAgentHeight, 100, 24);
    [btnSend setTitle:@"Send" forState:UIControlStateNormal];
    btnSend.titleLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:19.0];
    btnSend.titleLabel.textColor=[UIColor darkGrayColor];
   // btnSend.titleLabel.textColor=[UIColor colorWithRed:66/255.0 green:133/255.0 blue:255/255.0 alpha:1.0];
    [btnSend addTarget:self action:@selector(popToView) forControlEvents:UIControlEventTouchUpInside];
    [scrlView addSubview:btnSend];
    
    [scrlView setContentSize:CGSizeMake(320,1553+50+h1+h2+h3+h4+h5+h6+h7+h8+h9+(142*tblPlus)+(106*intAgentPlus))];
    lblCounter1.text = [NSString stringWithFormat:@"%ld of %lu",self.selectedIndex+1,(unsigned long)self.totalPropertyArr.count];
}

-(void)btnApprovedClicked
{
	if (boolKeepmeApproved)
    {
		boolKeepmeApproved=FALSE;
		[btnCheckApprove setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
	}
	else
	{
		boolKeepmeApproved=TRUE;
		[btnCheckApprove setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
	}
}

-(IBAction)btnCheckPress:(id)sender
{
    int i = [sender tag];
    PropertyAgentTvCellView *cell = (PropertyAgentTvCellView *)[tblAgent cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i  inSection:0]];
    
    if(cell.boolCheck)
    {
        cell.boolCheck=NO;
        [cell.btnCheck setImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
        [dictCheck setValue:@"0" forKey:[NSString stringWithFormat:@"%d",i]];
    }
    else
    {
        cell.boolCheck=YES;
        [cell.btnCheck setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
        [dictCheck setValue:@"1" forKey:[NSString stringWithFormat:@"%d",i]];
    }
}


#pragma mark - Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    if(tableView==tblViewRecentComparable)
        return 142;
    
    else if (tableView==tblDevelopmentInfo)
    {
        
        if (indexPath.row==0) {
            
            if (showSaleTax==false) {
                NSLog(@"Sale Tax false");
                return 0;
            }
            else
            {
                NSLog(@"Sale Tax true");
                return 105;
            }
            
        } else {
            
            if (showDevelopment==false)
            {
                NSLog(@"Development false");
                return 0;
            } else
            {
                NSLog(@"Development true");
                return 105;
            }
        }
    }
    else
    {
     return 106;
    }
   
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tableView==tblViewRecentComparable)
        return 2;
    else if (tableView==tblDevelopmentInfo)
    {
        if(showDevelopment && showSaleTax) {
            return 2;
        } else if(!showDevelopment && !showSaleTax) {
            return 0;
        }else {
            return 1;
        }
    }
    else
    {
        return 2;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier1 = @"Cell";
    static NSString *CellIdentifier2 = @"Cell";
    static NSString *CellIdentifier3 = @"Cell";

    PropertyTvCellView *cell1 = (PropertyTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier1];
    PropertyAgentTvCellView *cell2 = (PropertyAgentTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier2];
    LastSaleTaxCell *lastSaleTax = (LastSaleTaxCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier3];
    DevelopmentInfoCell *developmentInfo = (DevelopmentInfoCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier3];

    if(tableView==tblViewRecentComparable)
    {
        if (cell1 == nil)
        {
            UIViewController *view = [[UIViewController alloc]initWithNibName:@"PropertyTvCellView_iPhone" bundle:nil];
            cell1 = (PropertyTvCellView *)view.view;
        }
        return cell1;
    }
    else if (tableView==tblDevelopmentInfo)
    {
       
        if (indexPath.row==0) {
            
            
            if (showSaleTax && showDevelopment) {
                
                if (lastSaleTax == nil)
                {
                    UIViewController *view = [[UIViewController alloc]initWithNibName:@"LastSaleTaxCell" bundle:nil];
                    lastSaleTax = (LastSaleTaxCell *)view.view;
                    lastSaleTax.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
                    
                    NSInteger *intPrice = [[infoDict valueForKey:@"price_sold"] integerValue];
                    NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                    NSString *tempSoldPrice = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                     numberStyle:NSNumberFormatterCurrencyStyle];
                    
                    
                    NSString *newString;
                    {
                        newString = [tempSoldPrice substringFromIndex:3];
                        newString =  [newString substringToIndex:[newString length]-3];
                        
                    }
                    
                    lastSaleTax.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
                    lastSaleTax.lblDate.text = [NSString stringWithFormat:@"%@",[infoDict valueForKey:@"dateclosed"]];
                    lastSaleTax.lblMalNum.text = [NSString stringWithFormat:@"%@",[infoDict valueForKey:@"id"]];
                    
                    return lastSaleTax;
                }
                
            } else if (showSaleTax && !showDevelopment)
            {
                if (lastSaleTax == nil)
                {
                    UIViewController *view = [[UIViewController alloc]initWithNibName:@"LastSaleTaxCell" bundle:nil];
                    lastSaleTax = (LastSaleTaxCell *)view.view;
                    lastSaleTax.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
                    return lastSaleTax;
                }
                
            }
            else if (!showSaleTax && showDevelopment)
            {
                if (developmentInfo == nil)
                {
                    UIViewController *view = [[UIViewController alloc]initWithNibName:@"DevelopmentInfoCell" bundle:nil];
                    developmentInfo = (DevelopmentInfoCell *)view.view;
                    developmentInfo.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
                  
                  
                    developmentInfo.lblLocation.text = [NSString stringWithFormat:@"Location : %@",[infoDict valueForKey:@"Development"]];
                    developmentInfo.lblDevelopedIn.text = [NSString stringWithFormat:@"Developed in : %@",[infoDict valueForKey:@"Development"]];
                    
                    
                    [developmentInfo.img setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[arrImage objectAtIndex:0]]] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                    
                    
                    return developmentInfo;
                }
            
            }
            else
            {
                return nil;
            }
            
        } else
        {
            UIViewController *view = [[UIViewController alloc]initWithNibName:@"DevelopmentInfoCell" bundle:nil];
            developmentInfo = (DevelopmentInfoCell *)view.view;
            developmentInfo.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
            
            developmentInfo.lblLocation.text = [NSString stringWithFormat:@"Location : %@",[infoDict valueForKey:@"Development"]];
            developmentInfo.lblDevelopedIn.text = [NSString stringWithFormat:@"Developed in : %@",[infoDict valueForKey:@"Development"]];
            if (arrImage.count) {
                [developmentInfo.img setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[arrImage objectAtIndex:0]]] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            }
            
            
            return developmentInfo;
        }
        
        
       
    
    }
    else
    {
        if (cell2 == nil)
        {
            UIViewController *view = [[UIViewController alloc]initWithNibName:@"PropertyAgentTvCellView_iPhone" bundle:nil];
            cell2 = (PropertyAgentTvCellView *)view.view;
            cell2.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
            if ([[dictCheck valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] isEqualToString:@"0"])
            {
                cell2.boolCheck=NO;
                [cell2.btnCheck setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
            }
            else
            {
                cell2.boolCheck=YES;
                [cell2.btnCheck setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
            }
            cell2.imgBackground.layer.borderWidth=0.75;
            cell2.btnCheck.tag=indexPath.row;
            [cell2.btnCheck addTarget:self action:@selector(btnCheckPress:) forControlEvents:UIControlEventTouchUpInside];

        }
        return cell2;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView==tblViewRecentComparable)
        [tblViewRecentComparable deselectRowAtIndexPath:indexPath animated:YES];
    else if (tableView==tblDevelopmentInfo)
    {
        
        if (indexPath.row==0) {
            
            if (showSaleTax && showDevelopment)
            {
                NSLog(@"sale tax clicked");
                
            }
            else if (showSaleTax && !showDevelopment)
            {
              NSLog(@"sale tax clicked");
            }
            else if (!showSaleTax && showDevelopment)
            {
               NSLog(@"development info clicked");
                DevelopmentDetail *detail;
                if (IS_IPHONE) {
                    detail = [[DevelopmentDetail alloc] initWithNibName:@"DevelopmentDetail" bundle:nil];
                } else {
                    detail = [[DevelopmentDetail alloc] initWithNibName:@"DevelopmentDetail_iPad" bundle:nil];
                }
              
              detail.detailDict = infoDict;
              [self.navigationController pushViewController:detail animated:YES];
            }
            
        } else {
            
            DevelopmentDetail *detail;
            if (IS_IPHONE) {
                detail = [[DevelopmentDetail alloc] initWithNibName:@"DevelopmentDetail" bundle:nil];
            } else {
                detail = [[DevelopmentDetail alloc] initWithNibName:@"DevelopmentDetail_iPad" bundle:nil];
            }
           
            detail.detailDict = infoDict;
            [self.navigationController pushViewController:detail animated:YES];
           
        }
    }
    else
        [tblAgent deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)sender
{
   	if (pageControlUsed)
    {
        return;
    }
    CGFloat pageWidth = scrlViewImage.frame.size.width;
    int page = floor((scrlViewImage.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    pageControl.currentPage = page;
    num=page;
    
    if (IS_IPHONE) {
        if((int)scrlViewImage.contentOffset.x==0)
            btnPrevious.userInteractionEnabled=FALSE;
        else
            btnPrevious.userInteractionEnabled=TRUE;
        
        if((int)scrlViewImage.contentOffset.x == (320*([arrImage count]-1)))
            btnNext.userInteractionEnabled=FALSE;
        else
            btnNext.userInteractionEnabled=TRUE;
    } else {
        
        if((int)scrlViewImage.contentOffset.x==0)
            btnPrevious.userInteractionEnabled=FALSE;
        else
            btnPrevious.userInteractionEnabled=TRUE;
        
        if((int)scrlViewImage.contentOffset.x == (768*([arrImage count]-1)))
            btnNext.userInteractionEnabled=FALSE;
        else
            btnNext.userInteractionEnabled=TRUE;
    }
    
    
   
    lblCounter2.text = [NSString stringWithFormat:@"%d of %lu Photos",num+1,(unsigned long)arrImage.count];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    pageControlUsed = NO;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    pageControlUsed = NO;
}

#pragma mark Next Previous button
-(void)btnNextClicked
{
    num = num+1;
    if(num == [arrImage count]-1)
    {
        if (IS_IPHONE) {
            [scrlViewImage setContentOffset:CGPointMake(320*num, 0) animated:YES];
        } else {
            [scrlViewImage setContentOffset:CGPointMake(768*num, 0) animated:YES];
        }
        
        btnNext.userInteractionEnabled=FALSE;
        btnPrevious.userInteractionEnabled=TRUE;
      
    }
    else
    {
        
        if (IS_IPHONE) {
            [scrlViewImage setContentOffset:CGPointMake(320*num, 0) animated:YES];
        } else {
            [scrlViewImage setContentOffset:CGPointMake(768*num, 0) animated:YES];
        }
        btnNext.userInteractionEnabled=TRUE;
        btnPrevious.userInteractionEnabled=TRUE;
      
    }
   
    lblCounter2.text = [NSString stringWithFormat:@"%d of %lu Photos",num+1,(unsigned long)arrImage.count];
    pageControlUsed=YES;
}

-(void)btnPreviousClicked
{
    num = num-1;
    if(num == 0 || num == -1)
    {
        if (IS_IPHONE) {
            [scrlViewImage setContentOffset:CGPointMake(320*num, 0) animated:YES];
        } else {
            [scrlViewImage setContentOffset:CGPointMake(768*num, 0) animated:YES];
        }
        btnNext.userInteractionEnabled=TRUE;
        btnPrevious.userInteractionEnabled=FALSE;

    }
    else
    {
        
        if (IS_IPHONE) {
            [scrlViewImage setContentOffset:CGPointMake(320*num, 0) animated:YES];
        } else {
            [scrlViewImage setContentOffset:CGPointMake(768*num, 0) animated:YES];
        }
        
        btnNext.userInteractionEnabled=TRUE;
        btnPrevious.userInteractionEnabled=TRUE;

    }
    lblCounter2.text = [NSString stringWithFormat:@"%d of %lu Photos",num+1,(unsigned long)arrImage.count];
    pageControlUsed=YES;
}

-(void)btnBack
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)getpropertyDetail
{
    [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"userData"]||_delegate.loginUser )
    {
        [dict setValue:self.PropertyId forKey:@"id"];
        [dict setValue:[[[NSUserDefaults standardUserDefaults]objectForKey:@"userData"] objectForKey:@"user_id"] forKey:@"user_id"];
        
    } else
    {
        [dict setValue:self.PropertyId forKey:@"id"];
    }
    [REWebService CallGetParticularPropertyDetail:dict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:_delegate.window animated:YES];
        
        if (!error){
            
            NSInteger totalImage = 0;
            NSLog(@"%@",dictResult);
           totalImage = [[[[dictResult valueForKey:@"response"] valueForKey:@"data"] valueForKey:@"num_images"] integerValue];
            
            responseDict =[[dictResult valueForKey:@"response"] valueForKey:@"data"];
            infoDict = [[NSMutableDictionary alloc]initWithDictionary:responseDict];
            NSString *imgUrl = [[[dictResult valueForKey:@"response"] valueForKey:@"data"] valueForKey:@"first_image_path"];
            NSArray* foo = [imgUrl componentsSeparatedByString: @"1.jpg"];
            isFavourite = [[dictResult valueForKey:@"response"] valueForKey:@"is_favourite"];
            for (NSInteger i = 0; i<totalImage; i++)
            {
                NSString *nextImage = [NSString stringWithFormat:@"%@%ld.jpg",[foo objectAtIndex:0],i+1];
                [arrImage addObject:nextImage];
            }
            for(int i=0;i<[arrImage count];i++)
            {
                
                if (IS_IPHONE) {
                     xPosition = 320*i;
                } else {
                     xPosition = 768*i;
                }
               
                imgProperty = [[UIImageView alloc] initWithFrame:CGRectMake(xPosition, -20, 768, 220)];
                //imgProperty.backgroundColor = [UIColor redColor];
                [imgProperty setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[arrImage objectAtIndex:i]]] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                
                [scrlViewImage addSubview:imgProperty];
                if (IS_IPHONE) {
                     [scrlViewImage setContentSize:CGSizeMake(320+xPosition, 0)];
                } else {
                     [scrlViewImage setContentSize:CGSizeMake(768+xPosition, 0)];
                }
               
            }
            
            
            if (self.selectedIndex==self.totalPropertyArr.count-1) {
                btnUpArrow.enabled = NO;
                
            }
            if (self.selectedIndex==0){
                
                btnDownArrow.enabled = NO;
                
            }
            
            pageControl.numberOfPages = [arrImage count];
            pageControl.currentPage = num;
            lblCounter2.text = [NSString stringWithFormat:@"%d of %lu Photos",num+1,(unsigned long)arrImage.count];
            lblBedBath.text = [NSString stringWithFormat:@"%@bd-%@ba %@ sq ft",[responseDict valueForKey:@"numbedrooms"],[responseDict valueForKey:@"totalfullbaths"],[responseDict valueForKey:@"sqft"]];
            lblYear.text = [NSString stringWithFormat:@"Built in %@",[responseDict valueForKey:@"yearbuilt"]];
            
            // set open house
            if ([[responseDict valueForKey:@"OpenHouseUpcoming"] isEqualToString:@""]) {
                
                lblOpenHome.text = [NSString stringWithFormat:@"Open House Not Available"];
                
            } else {
               lblOpenHome.text=[NSString stringWithFormat:@"%@",[responseDict valueForKey:@"OpenHouseUpcoming"]];
            }
          //  set price label
            NSString *strActulPrice;
            NSString *strPriceCut;
            if ([[responseDict valueForKey:@"status"]isEqualToString:@"for_sale"])
            {
                NSInteger *intPrice = [[responseDict valueForKey:@"price_for_sale"] integerValue];
                NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                strActulPrice = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                   numberStyle:NSNumberFormatterDecimalStyle];
                
                strPriceCut= [responseDict valueForKey:@"price_cut"];
                lblHomeType.text = @"For Sale";
                lblHomeType.textColor = [UIColor colorWithRed:57/255.0 green:156/255.0 blue:42/255.0 alpha:1];
                imgViewHome.image = [UIImage imageNamed:@"for_sale.png"];
                showSaleTax = false;
                
            }
            else if ([[responseDict valueForKey:@"status"]isEqualToString:@"for_rent"]){
                
                NSInteger *intPrice = [[responseDict valueForKey:@"pricerented"] integerValue];
                NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                strActulPrice = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                 numberStyle:NSNumberFormatterDecimalStyle];
                
                 strPriceCut= [responseDict valueForKey:@"price_cut"];
                lblHomeType.text = @"For Rent";
                lblHomeType.textColor = [UIColor orangeColor];
                imgViewHome.image = [UIImage imageNamed:@"for_rent"];
                showSaleTax = false;
            }
            else{
                //sold
                NSInteger *intPrice = [[responseDict valueForKey:@"price_sold"] integerValue];
                NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                strActulPrice = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                 numberStyle:NSNumberFormatterDecimalStyle];
                 strPriceCut= [responseDict valueForKey:@"price_cut"];
                lblHomeType.text = @"Sold";
                lblHomeType.textColor = [UIColor redColor];
                imgViewHome.image = [UIImage imageNamed:@"sold"];
                showSaleTax = true;
            
            }
           
            NSString *priceStr = [NSString stringWithFormat:@"$%@  Price Cut:%@",strActulPrice,strPriceCut];
             NSMutableAttributedString* attrStr = [NSMutableAttributedString attributedStringWithString:priceStr];
            
            [attrStr setFont:[UIFont fontWithName:@"Helvetica-Bold" size:17] range:NSMakeRange(0,[strActulPrice length]+1)];
            [attrStr setTextColor:[UIColor colorWithRed:65/255.0 green:65/255.0 blue:65/255.0 alpha:1.0] range:NSMakeRange(0,[strActulPrice length]+1)];
            
            [attrStr setFont:[UIFont fontWithName:@"Helvetica" size:14] range:NSMakeRange([strActulPrice length]+3,10)];
            [attrStr setTextColor:[UIColor colorWithRed:64/255.0 green:115/255.0 blue:254/255.0 alpha:1.0] range:NSMakeRange([strActulPrice length]+3,10)];
          
            [attrStr setFont:[UIFont fontWithName:@"Helvetica" size:14] range:NSMakeRange([strActulPrice length]+13,[strPriceCut length])];
            
            [attrStr setTextColor:[UIColor colorWithRed:133/255.0 green:133/255.0 blue:133/255.0 alpha:1.0] range:NSMakeRange([strActulPrice length]+13,[strPriceCut length])];
            
            titleLabel.attributedText = attrStr;
            txtViewInterior.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"interior"]];
            txtViewExterior.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"exterior"]];
            txtViewPropertyDes.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"property_description"]];
            txtViewAmenties.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"amenities"]];
            txtViewRental.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"restrictions"]];
            lblHomeTmp.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"id"]];
            
            txtViewAddress = [[UITextView alloc] initWithFrame: CGRectMake(10, 10+200, self.view.frame.size.width-10, 34+h1)];
            txtViewAddress.editable=NO;
            txtViewAddress.scrollEnabled=NO;
            txtViewAddress.backgroundColor = [UIColor clearColor];
            txtViewAddress.font = [UIFont fontWithName:@"Helvetica-Bold" size:15.0];
            
            txtViewAddress.textColor = [UIColor colorWithRed:58/255.0 green:104/255.0 blue:253/255.0 alpha:1.0];
            txtViewAddress.text =[NSString stringWithFormat:@"%@%@",[responseDict valueForKey:@"fulladdress"],[responseDict valueForKey:@"fulladdress1"]];
            [scrlView addSubview:txtViewAddress];
            lblListingCourtesy.text= [NSString stringWithFormat:@"Listing Courtesy:%@",[responseDict valueForKey:@"listing_courtesy"]];
            self.contactNum = [responseDict valueForKey:@"phone"];
            
            
            if ([[responseDict valueForKey:@"development_info_show"] isEqualToString:@"1"])
            {
                showDevelopment = true;
            }
            else
            {
                showDevelopment = false;
            }
            
            [tblDevelopmentInfo reloadData];
            [tblDevelopmentInfo beginUpdates];
            [tblDevelopmentInfo endUpdates];
            
            if ([isFavourite isEqualToString:@"1"])
            {
                [btnContact setImage:[UIImage imageNamed:@"contact_tab.png"] forState:UIControlStateNormal];
                [btnSave setImage:[UIImage imageNamed:@"save_tab_active.png"] forState:UIControlStateNormal];
                [btnAddNote setImage:[UIImage imageNamed:@"addNote_tab.png"] forState:UIControlStateNormal];
                [btnAddPhoto setImage:[UIImage imageNamed:@"aadPhoto_tab.png"] forState:UIControlStateNormal];
                [btnShare setImage:[UIImage imageNamed:@"share_tab.png"] forState:UIControlStateNormal];
                [btnSave setTitle:@"Un Save" forState:UIControlStateNormal];
                
            } else {
                [btnContact setImage:[UIImage imageNamed:@"contact_tab.png"] forState:UIControlStateNormal];
                [btnSave setImage:[UIImage imageNamed:@"save_tab.png"] forState:UIControlStateNormal];
                [btnAddNote setImage:[UIImage imageNamed:@"addNote_tab.png"] forState:UIControlStateNormal];
                [btnAddPhoto setImage:[UIImage imageNamed:@"aadPhoto_tab.png"] forState:UIControlStateNormal];
                [btnShare setImage:[UIImage imageNamed:@"share_tab.png"] forState:UIControlStateNormal];
                
            }
        }
        
    }];
    
}
-(IBAction)AddFavoriteHome:(id)sender
{
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"userData"]||_delegate.loginUser )
    {
        if ([isFavourite isEqualToString:@"1"]) {
            
            NSMutableDictionary *dataDict  = [[NSMutableDictionary alloc]init];
            [dataDict setValue:self.PropertyId forKey:@"id"];
            [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"user_id"];
            [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
            [REWebService deleteFavouriteProperties:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
                [MBProgressHUD hideAllHUDsForView:_delegate.window animated:YES];
                
                if (!error) {
                    if ([[[dictResult valueForKey:@"response"]valueForKey:@"message"]isEqualToString:@"success"])
                    {
                        [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"]valueForKey:@"msg"]];
                        isFavourite = @"0";
                       
                    }
                    else
                    {
                        [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"]valueForKey:@"msg"]];
                    }
                    
                } else {
                    
                }
                
            }];
            
            
        } else{
            
            [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
            NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
            [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"user_id"];
            [dataDict setValue:self.PropertyId forKey:@"id"];
            [REWebService addFavouriteProperties:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
                [MBProgressHUD hideAllHUDsForView:_delegate.window animated:YES];
                if (!error) {
                    
                    if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]){
                        
                        [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                        isFavourite = @"1";
                        
                    }
                    else
                    {
                        [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                    }
                    
                }
                
            }];
            
        }
        
        
    }else
    {
        LoginViewController*loginVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPhone" bundle:nil];
        [self.navigationController presentViewController:loginVC animated:YES completion:nil];
    }

}

-(IBAction)buttonTitlesClicked:(id)sender
{
    switch ([sender tag]){
        case 100:
             [btnContact setImage:[UIImage imageNamed:@"contact_tab.png"] forState:UIControlStateNormal];
             [btnSave setImage:[UIImage imageNamed:@"save_tab_active.png"] forState:UIControlStateNormal];
             [btnAddNote setImage:[UIImage imageNamed:@"addNote_tab.png"] forState:UIControlStateNormal];
             [btnAddPhoto setImage:[UIImage imageNamed:@"aadPhoto_tab.png"] forState:UIControlStateNormal];
             [btnShare setImage:[UIImage imageNamed:@"share_tab.png"] forState:UIControlStateNormal];
             NSLog( @"Save button");
             [self AddFavoriteHome:self];
            break;
        case 200:
            [btnContact setImage:[UIImage imageNamed:@"contact_tab.png"] forState:UIControlStateNormal];
            [btnSave setImage:[UIImage imageNamed:@"save_tab.png"] forState:UIControlStateNormal];
            [btnAddNote setImage:[UIImage imageNamed:@"addNote_tab_active.png"] forState:UIControlStateNormal];
            [btnAddPhoto setImage:[UIImage imageNamed:@"aadPhoto_tab.png"] forState:UIControlStateNormal];
            [btnShare setImage:[UIImage imageNamed:@"share_tab.png"] forState:UIControlStateNormal];
            if ([[NSUserDefaults standardUserDefaults] valueForKey:@"userData"]||_delegate.loginUser )
            {
                AddNotes *addNoteVc;
                if (IS_IPHONE) {
                    addNoteVc = [[AddNotes alloc] initWithNibName:@"AddNotes" bundle:nil];
                } else {
                    addNoteVc = [[AddNotes alloc] initWithNibName:@"AddNotes_iPad" bundle:nil];
                }
                
                addNoteVc.propertyId = self.PropertyId;
                [self.navigationController pushViewController:addNoteVc animated:YES];
            }
            else
            {
                [Utils showAlertMessage:@"Twin Realty" Message:@"Please login first"];
            }
            
            
            NSLog( @"Add note");
            break;
        case 300:
            [btnContact setImage:[UIImage imageNamed:@"contact_tab.png"] forState:UIControlStateNormal];
            [btnSave setImage:[UIImage imageNamed:@"save_tab.png"] forState:UIControlStateNormal];
            [btnAddNote setImage:[UIImage imageNamed:@"addNote_tab.png"] forState:UIControlStateNormal];
            [btnAddPhoto setImage:[UIImage imageNamed:@"aadPhoto_tab_active.png"] forState:UIControlStateNormal];
            [btnShare setImage:[UIImage imageNamed:@"share_tab.png"] forState:UIControlStateNormal];
            if ([[NSUserDefaults standardUserDefaults] valueForKey:@"userData"]||_delegate.loginUser )
            {
               [self AddPhoto];
            }
            else
            {
                [Utils showAlertMessage:@"Twin Realty" Message:@"Please login first"];
            }
            NSLog( @"Add photo");
            break;
        case 400:
            [btnContact setImage:[UIImage imageNamed:@"contact_tab.png"] forState:UIControlStateNormal];
            [btnSave setImage:[UIImage imageNamed:@"save_tab.png"] forState:UIControlStateNormal];
            [btnAddNote setImage:[UIImage imageNamed:@"addNote_tab.png"] forState:UIControlStateNormal];
            [btnAddPhoto setImage:[UIImage imageNamed:@"aadPhoto_tab.png"] forState:UIControlStateNormal];
            [btnShare setImage:[UIImage imageNamed:@"share_tab_active.png"] forState:UIControlStateNormal];
            NSLog( @"Share");
            [self ShareOnFacebook];
            break;
        case 500:
            [btnContact setImage:[UIImage imageNamed:@"contact_tab_active.png"] forState:UIControlStateNormal];
            [btnSave setImage:[UIImage imageNamed:@"save_tab.png"] forState:UIControlStateNormal];
            [btnAddNote setImage:[UIImage imageNamed:@"addNote_tab.png"] forState:UIControlStateNormal];
            [btnAddPhoto setImage:[UIImage imageNamed:@"aadPhoto_tab.png"] forState:UIControlStateNormal];
            [btnShare setImage:[UIImage imageNamed:@"share_tab.png"] forState:UIControlStateNormal];
            NSString *str = [NSString stringWithFormat:@"Call %@ ?",self.contactNum];
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:str message:@"" preferredStyle:UIAlertControllerStyleAlert];
            
            [alertController addAction:[UIAlertAction actionWithTitle:@"Yes" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [self makeCall];
            }]];
            
            [alertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                [self closeAlertview];
            }]];
            
            dispatch_async(dispatch_get_main_queue(), ^ {
                [self presentViewController:alertController animated:YES completion:nil];
            });
            break;
        default:
            break;
    
    }
}

-(void)closeAlertview
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)makeCall
{
    NSString *URLString = [@"tel://" stringByAppendingString:self.contactNum];
    NSURL *URL = [NSURL URLWithString:URLString];
    [[UIApplication sharedApplication] openURL:URL];
}

-(void)ShareOnFacebook
{
    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook]) {
        
        SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        
        if (controller != nil){
            
            [controller setInitialText:@"I am a very happy user of the Twin Realty app.It is effective and so convenient! Give it a try too! Check out www.twinrealty.com to get started."];
            [controller addURL:[NSURL URLWithString:@""]];
            [controller addImage:[UIImage imageNamed:@"logo1"]];
            [self presentViewController:controller animated:YES completion:Nil];
        }
        else{
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Twin Realty" message:@"Sorry, cannot load facebook. Please try again latter." preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            [self presentViewController:alertController animated:YES completion:nil];
        }
        
    }
    else
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"No Facebook Account" message:@"There are no Facebook accounts configured. You can add or create a Facebook account in Settings." preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        [self presentViewController:alertController animated:YES completion:nil];
    }
}
-(void)AddPhoto
{
    
    UIAlertController* alert = [UIAlertController
                                alertControllerWithTitle:nil
                                message:nil
                                preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* button0 = [UIAlertAction
                              actionWithTitle:@"Cancel"
                              style:UIAlertActionStyleCancel
                              handler:^(UIAlertAction * action)
                              {
                                  
                              }];
    
    UIAlertAction* button1 = [UIAlertAction
                              actionWithTitle:@"Take photo"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                 
                                  UIImagePickerController *imagePickerController= [[UIImagePickerController alloc] init];
                                  imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
                                  imagePickerController.delegate = self;
                                  [self presentViewController:imagePickerController animated:YES completion:^{}];
                              }];
    
    UIAlertAction* button2 = [UIAlertAction
                              actionWithTitle:@"Choose Existing"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  
                                  UIImagePickerController *imagePickerController= [[UIImagePickerController alloc] init];
                                  imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                  imagePickerController.delegate = self;
                                  [self presentViewController:imagePickerController animated:YES completion:^{}];
                              }];
    
    [alert addAction:button0];
    [alert addAction:button1];
    [alert addAction:button2];
    [self presentViewController:alert animated:YES completion:nil];
    
    
    
    [alert setModalPresentationStyle:UIModalPresentationPopover];
    
//    UIPopoverPresentationController *popPresenter = [alert
//                                                     popoverPresentationController];
//    popPresenter.sourceView = scrollView;
//    popPresenter.sourceRect = scrollView.bounds;
//    [self presentViewController:alert animated:YES completion:nil];

}


#pragma mark -
#pragma mark UIImagePickerControllerDelegate

- (void) imagePickerController:(UIImagePickerController *)picker
         didFinishPickingImage:(UIImage *)image
                   editingInfo:(NSDictionary *)editingInfo
{
    [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
     NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"user_id"];
    [dataDict setValue:self.PropertyId forKey:@"property_id"];
    [REWebService addImageProperty:dataDict image:image withBlock:^(NSDictionary *dictResult, NSError *error) {
    [MBProgressHUD hideAllHUDsForView:_delegate.window animated:YES];
        
        if (!error) {
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"])
            {
                
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                [self dismissViewControllerAnimated:YES completion:nil];
            } else
            {
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
            }
            
        }
        
    }];
    
}

-(void)buttonUpArrow
{
    self.selectedIndex = self.selectedIndex+1;
     NSLog(@"next %ld",(long)self.selectedIndex);
    if (self.selectedIndex==self.totalPropertyArr.count) {
         btnUpArrow.enabled = NO;
       
    } else
    {
        PropertyDetail *temp = [self.totalPropertyArr objectAtIndex:self.selectedIndex];
        if ([temp isKindOfClass:[NSDictionary class]]) {
             self.PropertyId = [temp valueForKey:@"id"];
        } else {
             self.PropertyId = temp.Id;
        }
       
        [self updateNextProperty];
    }
    btnDownArrow.enabled = YES;
    
    
}
-(void)buttonDownArrow
{
    self.selectedIndex = self.selectedIndex-1;
    NSLog(@"prev %ld",(long)self.selectedIndex);
    if (self.selectedIndex<0){
     
        btnDownArrow.enabled = NO;
        
    } else {
        PropertyDetail *temp = [self.totalPropertyArr objectAtIndex:self.selectedIndex];
       // self.PropertyId = temp.Id;
        if ([temp isKindOfClass:[NSDictionary class]]) {
            self.PropertyId = [temp valueForKey:@"id"];
        } else {
            self.PropertyId = temp.Id;
        }
        [self updateNextProperty];
    }
     btnUpArrow.enabled = YES;
}

-(void)updateNextProperty
{
    [arrImage removeAllObjects];
    [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    if ([[NSUserDefaults standardUserDefaults] valueForKey:@"userData"]||_delegate.loginUser )
    {
        [dict setValue:self.PropertyId forKey:@"id"];
        [dict setValue:[[[NSUserDefaults standardUserDefaults]objectForKey:@"userData"] objectForKey:@"user_id"] forKey:@"user_id"];
        
    } else
    {
        [dict setValue:self.PropertyId forKey:@"id"];
    }
    [REWebService CallGetParticularPropertyDetail:dict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:_delegate.window animated:YES];
        
        if (!error){
            
            NSInteger totalImage = 0;
            NSLog(@"%@",dictResult);
            totalImage = [[[[dictResult valueForKey:@"response"] valueForKey:@"data"] valueForKey:@"num_images"] integerValue];
            
            responseDict =[[dictResult valueForKey:@"response"] valueForKey:@"data"];
            infoDict = [[NSMutableDictionary alloc]initWithDictionary:responseDict];
            NSString *imgUrl = [[[dictResult valueForKey:@"response"] valueForKey:@"data"] valueForKey:@"first_image_path"];
            NSArray* foo = [imgUrl componentsSeparatedByString: @"1.jpg"];
            isFavourite = [[dictResult valueForKey:@"response"] valueForKey:@"is_favourite"];
            for (NSInteger i = 0; i<totalImage; i++)
            {
                NSString *nextImage = [NSString stringWithFormat:@"%@%ld.jpg",[foo objectAtIndex:0],i+1];
                [arrImage addObject:nextImage];
            }
            for(int i=0;i<[arrImage count];i++)
            {
                if (IS_IPHONE) {
                     xPosition = 320*i;
                } else {
                     xPosition = 768*i;
                }
                imgProperty = [[UIImageView alloc] initWithFrame:CGRectMake(xPosition, -20, 320, 220)];
                [imgProperty setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[arrImage objectAtIndex:i]]] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                
                [scrlViewImage addSubview:imgProperty];
                if (IS_IPHONE) {
                     [scrlViewImage setContentSize:CGSizeMake(320+xPosition, 0)];
                } else {
                     [scrlViewImage setContentSize:CGSizeMake(768+xPosition, 0)];
                }
               
            }
             NSLog(@"Final %ld",(long)self.selectedIndex);
            if (self.selectedIndex==self.totalPropertyArr.count-1) {
                btnUpArrow.enabled = NO;
                
            }
            if (self.selectedIndex==0){
                
                btnDownArrow.enabled = NO;
                
            }
            pageControl.numberOfPages = [arrImage count];
            pageControl.currentPage = num;
            lblCounter1.text = [NSString stringWithFormat:@"%ld of %lu",self.selectedIndex+1,(unsigned long)self.totalPropertyArr.count];
            lblCounter2.text = [NSString stringWithFormat:@"%d of %lu Photos",num+1,(unsigned long)arrImage.count];
            lblBedBath.text = [NSString stringWithFormat:@"%@bd-%@ba %@ sq ft",[responseDict valueForKey:@"numbedrooms"],[responseDict valueForKey:@"totalfullbaths"],[responseDict valueForKey:@"sqft"]];
            lblYear.text = [NSString stringWithFormat:@"Built in %@",[responseDict valueForKey:@"yearbuilt"]];
            
            // set open house
            if ([[responseDict valueForKey:@"OpenHouseUpcoming"] isEqualToString:@""]) {
                
                lblOpenHome.text = [NSString stringWithFormat:@"Open House Not Available"];
                
            } else {
                lblOpenHome.text=[NSString stringWithFormat:@"%@",[responseDict valueForKey:@"OpenHouseUpcoming"]];
            }
            //  set price label
            NSString *strActulPrice;
            NSString *strPriceCut;
            if ([[responseDict valueForKey:@"status"]isEqualToString:@"for_sale"]){
                
                NSInteger *intPrice = [[responseDict valueForKey:@"price_for_sale"] integerValue];
                NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                strActulPrice = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                 numberStyle:NSNumberFormatterDecimalStyle];
                             
                strPriceCut= [responseDict valueForKey:@"price_cut"];
                lblHomeType.text = @"For Sale";
                lblHomeType.textColor = [UIColor colorWithRed:57/255.0 green:156/255.0 blue:42/255.0 alpha:1];
                imgViewHome.image = [UIImage imageNamed:@"for_sale.png"];
                showSaleTax = false;
                
            }
            else if ([[responseDict valueForKey:@"status"]isEqualToString:@"for_rent"]){
                
                NSInteger *intPrice = [[responseDict valueForKey:@"pricerented"] integerValue];
                NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                strActulPrice = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                 numberStyle:NSNumberFormatterDecimalStyle];
                
                strPriceCut= [responseDict valueForKey:@"price_cut"];
                lblHomeType.text = @"For Rent";
                lblHomeType.textColor = [UIColor orangeColor];
                imgViewHome.image = [UIImage imageNamed:@"for_rent"];
                showSaleTax = false;
                
            }
            else{
                NSInteger *intPrice = [[responseDict valueForKey:@"price_sold"] integerValue];
                NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                strActulPrice = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                 numberStyle:NSNumberFormatterDecimalStyle];
                strPriceCut= [responseDict valueForKey:@"price_cut"];
                lblHomeType.text = @"Sold";
                lblHomeType.textColor = [UIColor redColor];
                imgViewHome.image = [UIImage imageNamed:@"sold"];
                showSaleTax = true;
                
            }
            
            NSString *priceStr = [NSString stringWithFormat:@"$%@  Price Cut:%@",strActulPrice,strPriceCut];
            NSMutableAttributedString* attrStr = [NSMutableAttributedString attributedStringWithString:priceStr];
            
            [attrStr setFont:[UIFont fontWithName:@"Helvetica-Bold" size:17] range:NSMakeRange(0,[strActulPrice length]+1)];
            [attrStr setTextColor:[UIColor colorWithRed:65/255.0 green:65/255.0 blue:65/255.0 alpha:1.0] range:NSMakeRange(0,[strActulPrice length]+1)];
            
            [attrStr setFont:[UIFont fontWithName:@"Helvetica" size:14] range:NSMakeRange([strActulPrice length]+3,10)];
            [attrStr setTextColor:[UIColor colorWithRed:64/255.0 green:115/255.0 blue:254/255.0 alpha:1.0] range:NSMakeRange([strActulPrice length]+3,10)];
            
            [attrStr setFont:[UIFont fontWithName:@"Helvetica" size:14] range:NSMakeRange([strActulPrice length]+13,[strPriceCut length])];
            
            [attrStr setTextColor:[UIColor colorWithRed:133/255.0 green:133/255.0 blue:133/255.0 alpha:1.0] range:NSMakeRange([strActulPrice length]+13,[strPriceCut length])];
            
            titleLabel.attributedText = attrStr;
            txtViewInterior.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"interior"]];
            txtViewExterior.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"exterior"]];
            txtViewPropertyDes.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"property_description"]];
            txtViewAmenties.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"amenities"]];
            txtViewRental.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"restrictions"]];
            lblHomeTmp.text = [NSString stringWithFormat:@"%@",[responseDict valueForKey:@"id"]];
            txtViewAddress.text =[NSString stringWithFormat:@"%@%@",[responseDict valueForKey:@"fulladdress"],[responseDict valueForKey:@"fulladdress1"]];
            lblListingCourtesy.text= [NSString stringWithFormat:@"Listing Courtesy:%@",[responseDict valueForKey:@"listing_courtesy"]];
            self.contactNum = [responseDict valueForKey:@"phone"];
            
            
            if ([[responseDict valueForKey:@"development_info_show"] isEqualToString:@"1"])
            {
                showDevelopment = true;
            }
            else
            {
                showDevelopment = false;
            }
            
            [tblDevelopmentInfo reloadData];
            [tblDevelopmentInfo beginUpdates];
            [tblDevelopmentInfo endUpdates];
            
            if ([isFavourite isEqualToString:@"1"])
            {
                [btnContact setImage:[UIImage imageNamed:@"contact_tab.png"] forState:UIControlStateNormal];
                [btnSave setImage:[UIImage imageNamed:@"save_tab_active.png"] forState:UIControlStateNormal];
                [btnAddNote setImage:[UIImage imageNamed:@"addNote_tab.png"] forState:UIControlStateNormal];
                [btnAddPhoto setImage:[UIImage imageNamed:@"aadPhoto_tab.png"] forState:UIControlStateNormal];
                [btnShare setImage:[UIImage imageNamed:@"share_tab.png"] forState:UIControlStateNormal];
                [btnSave setTitle:@"Un Save" forState:UIControlStateNormal];
                
            } else {
                [btnContact setImage:[UIImage imageNamed:@"contact_tab.png"] forState:UIControlStateNormal];
                [btnSave setImage:[UIImage imageNamed:@"save_tab.png"] forState:UIControlStateNormal];
                [btnAddNote setImage:[UIImage imageNamed:@"addNote_tab.png"] forState:UIControlStateNormal];
                [btnAddPhoto setImage:[UIImage imageNamed:@"aadPhoto_tab.png"] forState:UIControlStateNormal];
                [btnShare setImage:[UIImage imageNamed:@"share_tab.png"] forState:UIControlStateNormal];
                
            }
        }
        
    }];
    
}
@end
