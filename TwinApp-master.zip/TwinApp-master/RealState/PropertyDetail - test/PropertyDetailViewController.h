//
//  PropertyDetailViewController.h
//  RealState
//
//  Created by Kapil Goyal on 26/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h> 
#import "PropertyDetail.h"
#import "OHAttributedLabel.h"
#import "AppDelegate.h"
#import <MessageUI/MessageUI.h>


@interface PropertyDetailViewController : UIViewController<OHAttributedLabelDelegate,UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,UITextViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,MFMailComposeViewControllerDelegate>
{
    OHAttributedLabel *lblPrice;
    NSMutableArray *arrImage;
    NSMutableArray *arrText;
    int num;
    int xPosition;
    float h1,h2,h3,h4,h5,h6,h7,h8,h9,h10;
    NSString *strAddress;
    NSString *strInfo;
    NSString *strHomeType;
    NSString *strHomeOpen;
    NSString *strDay;
    NSString *strOpenTime;
    UIButton *btnNext;
    UIButton *btnPrevious;
    UIButton *btnSave;
    UIButton *btnAddNote;
    UIButton *btnAddPhoto;
    UIButton *btnShare;
    UIButton *btnContact;
    UIButton *btnCheckApprove;
    UIButton *btnUpArrow;
    UIButton *btnDownArrow;
    CGRect rect;
    UIScrollView *scrlViewImage;
    UIPageControl *pageControl;
    UIImageView *imgProperty;
    UITableView *tblViewRecentComparable;
    UITableView *tblAgent;
    
    UITableView *tblDevelopmentInfo;
    
    UITextField *txtFieldEmail;
    UITextField *txtFieldPhone;
    UITextView *txtViewMesaage;
    UITextView *txtViewHeight;
    UIScrollView *scrlView;
    BOOL pageControlUsed;
    BOOL boolKeepmeApproved;
    NSMutableDictionary *dictCheck;
    UILabel *lblBedBath;
    UILabel *lblYear;
    UILabel *lblOpenHome;
    AppDelegate * _delegate;
    NSDictionary *responseDict;
    UILabel *lblCounter1;
    UILabel *lblCounter2;
    UITextView *txtViewInterior;
    UITextView *txtViewExterior;
    UITextView *txtViewPropertyDes;
    UITextView *txtViewAmenties;
    UITextView *txtViewRental;
    OHAttributedLabel *titleLabel;
    NSString *isFavourite;
    UILabel *lblHomeTmp;
    UILabel *lblHomeType;
    UIImageView *imgViewHome;
    UITextView *txtViewAddress;
    UILabel *lblListingCourtesy;
    bool showDevelopment;
    bool showSaleTax;
    NSMutableDictionary *infoDict;
   
}

@property (nonatomic,strong)NSString *PropertyId;
@property (nonatomic,strong)NSString *contactNum;
@property (nonatomic,strong)NSMutableArray *totalPropertyArr;
@property (assign) NSInteger selectedIndex;
@end
