//
//  DevelopmentInfoCell.h
//  RealEstate_App
//
//  Created by Octal on 23/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DevelopmentInfoCell : UITableViewCell
{
}

@property(nonatomic,strong)IBOutlet UIImageView *imgBackground;
@property(nonatomic,strong)IBOutlet UIImageView *img;
@property(nonatomic,strong)IBOutlet UILabel *lblDevelopmentInfo;
@property(nonatomic,strong)IBOutlet UILabel *lblLocation;
@property(nonatomic,strong)IBOutlet UILabel *lblDevelopedIn;

@end
