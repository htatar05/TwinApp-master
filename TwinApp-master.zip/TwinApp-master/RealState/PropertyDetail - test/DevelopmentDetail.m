//
//  DevelopmentDetail.m
//  RealEstate_App
//
//  Created by Octal on 01/12/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import "DevelopmentDetail.h"

@interface DevelopmentDetail ()

@end

@implementation DevelopmentDetail

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)backButtonTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
