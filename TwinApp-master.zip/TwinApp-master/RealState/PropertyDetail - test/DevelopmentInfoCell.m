//
//  DevelopmentInfoCell.m
//  RealEstate_App
//
//  Created by Octal on 23/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import "DevelopmentInfoCell.h"

@implementation DevelopmentInfoCell

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
