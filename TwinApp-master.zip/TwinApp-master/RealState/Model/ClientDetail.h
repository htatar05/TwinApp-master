//
//  Agent.h
//  RealState
//
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ClientDetail : NSObject

@property (nonatomic, strong) NSString *strId;
@property (nonatomic, strong) NSString *strName;
@property (nonatomic, strong) NSString *strFName;
@property (nonatomic, strong) NSString *strLName;
@property (nonatomic, strong) NSString *strEmail;
@property (nonatomic, strong) NSString *strPhoneNo;
@property (nonatomic, strong) NSString *strAddress;
@property (nonatomic, strong) NSString *strImage;

@end
