//
//  PropertyDetail.m
//  RealState
//
//  Created by Kapil Goyal on 26/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "PropertyDetail.h"

@implementation PropertyDetail


-(id) initWithDict:(NSDictionary *) dict{
    
    
    if (self == [super init]) {
        if ((NSNull *)dict != [NSNull null] || dict != nil ) {
            
            self.foreclosedyn = [dict objectForKey:@"foreclosedyn"];
            self.fulladdress = [dict objectForKey:@"fulladdress"];
            self.Id = [dict objectForKey:@"id"];
            self.latitude = [dict objectForKey:@"latitude"];
            self.longitude = [dict objectForKey:@"longitude"];
            self.numbedrooms = [dict objectForKey:@"numbedrooms"];
            self.pricelist = [dict objectForKey:@"pricelist"];
            self.priceRented = [dict objectForKey:@"pricerented"];
            self.PriceSold = [dict objectForKey:@"price_sold"];
            self.priceSale = [dict objectForKey:@"price_for_sale"];
            self.propertytype = [dict objectForKey:@"propertytype"];
            self.shortsaleyn = [dict objectForKey:@"shortsaleyn"];
            self.status = [dict objectForKey:@"status"];
            self.totalfloorareasqft = [dict objectForKey:@"sqft"];
            self.totalfullbaths = [dict objectForKey:@"totalfullbaths"];
            self.imgProperty = [dict objectForKey:@"first_image_path"];
            self.availableImages = [dict objectForKey:@"num_images"];
            self.openHouse =       [dict objectForKey:@"OpenHouseUpcoming"];
            self.listingCourtesy = [dict objectForKey:@"listing_courtesy"];
            self.dateSold = [dict objectForKey:@"sold_date"];
            self.propClass = [dict objectForKey:@"propclass"];
            self.acres   = [dict objectForKey:@"acres"];
            self.PropertyKind  = [dict objectForKey:@"Property_kind"];
            self.yearBuilt = [dict objectForKey:@"yearbuilt"];
            self.developmentImageArr = [dict objectForKey:@"development_images"];
            self.fromTime = [dict objectForKey:@"from_time"];
            self.toTime = [dict objectForKey:@"to_time"];
            self.agentName = [dict objectForKey:@"listagentname"];
            self.agentCell = [dict objectForKey:@"listagentcell"];
            self.fullAddress1 = [dict objectForKey:@"fulladdress1"];
            
            
           
        }
        else{
            self.foreclosedyn = @"";
            self.fulladdress  = @"";
            self.Id= @"";
            self. latitude= @"";
            self.longitude= @"";
            self.numbedrooms= @"";
            self.pricelist= @"";
            self. priceRented= @"";
            self. PriceSold= @"";
            self.priceSale = @"";
            self. propertytype= @"";
            self. shortsaleyn= @"";
            self. status= @"";
            self.totalfloorareasqft= @"";
            self.totalfullbaths= @"";
            self.imgProperty = @"";
            self.availableImages =@"";
            self.openHouse = @"";
            self.listingCourtesy = @"";
            self.dateSold = @"";
            self.propClass = @"";
            self.acres   = @"";
            self.PropertyKind  = @"";
            self.yearBuilt = @"";
            self.developmentImageArr = nil;
            self.fromTime = @"";
            self.toTime = @"";
            self.agentName = @"";
            self.agentCell = @"";
            self.fullAddress1 = @"";
            
        }
    }
    return self;
    
}

@end
