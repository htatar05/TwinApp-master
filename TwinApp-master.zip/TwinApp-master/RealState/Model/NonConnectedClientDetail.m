//
//  Agent.m
//  RealState
//
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "NonConnectedClientDetail.h"

@implementation NonConnectedClientDetail
@synthesize strId,strUserName,strFirstName,strLastName,strEmail,strPassword,strCPassword,strImage,strPhone;

@end
