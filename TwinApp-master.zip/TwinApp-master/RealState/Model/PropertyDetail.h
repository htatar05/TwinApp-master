//
//  PropertyDetail.h
//  RealState
//
//  Created by Kapil Goyal on 26/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PropertyDetail : NSObject
{
    
}

@property (nonatomic, strong) NSString * foreclosedyn, *fulladdress,*Id,*latitude, *longitude,*numbedrooms
,*pricelist,*priceRented,*priceSale,*propertytype,*shortsaleyn,*status,*totalfloorareasqft,*totalfullbaths,*imgProperty,*PriceSold,*availableImages,*openHouse,*listingCourtesy,*dateSold,*propClass,*acres,*PropertyKind,*yearBuilt,*fromTime,*toTime,*agentName,*agentCell,*fullAddress1;
@property (nonatomic, strong) NSArray *developmentImageArr;


-(id) initWithDict:(NSDictionary *) dict;

@end
