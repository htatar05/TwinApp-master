//
//  Agent.m
//  RealState
//
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "ClientDetail.h"

@implementation ClientDetail
@synthesize strId,strName,strEmail,strPhoneNo,strImage,strAddress,strFName,strLName;

@end
