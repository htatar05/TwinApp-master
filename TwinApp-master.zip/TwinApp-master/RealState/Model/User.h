//
//  User.h
//  RealState
//
//  Created by Kapil Goyal on 20/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject

@property (nonatomic, strong) NSString *strFName;
@property (nonatomic, strong) NSString *strLName;
@property (nonatomic, strong) NSString *strEmail;
@property (nonatomic, strong) NSString *strUserName;
@property (nonatomic, strong) NSString *strPassword;
@property (nonatomic, strong) NSString *strConfirmPassword;
@property (nonatomic, strong) NSString *strAgentName;
@property (nonatomic, strong) NSString *strPhoneNo;
@property (nonatomic, strong) NSString *strAddress1;
@property (nonatomic, strong) NSString *strAddress2;
@property (nonatomic, strong) NSString *strPostalCode;
@property (nonatomic, strong) NSString *strAgentId;
@property (nonatomic, strong) NSString *strRoleId;
@property (nonatomic, strong) NSString *strUserImage;

@end
