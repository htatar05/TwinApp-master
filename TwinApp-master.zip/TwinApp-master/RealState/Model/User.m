//
//  User.m
//  RealState
//
//  Created by Kapil Goyal on 20/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "User.h"

@implementation User
@synthesize strFName,strLName,strEmail,strUserName,strPassword,strConfirmPassword,strAgentName,
            strPhoneNo,strAddress1,strAddress2,strPostalCode,strAgentId,strRoleId,strUserImage;
@end
