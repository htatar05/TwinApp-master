//
//  AgentListViewController.h
//  RealState
//
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "JTRevealSidebarV2Delegate.h"
#import "UIViewController+JTRevealSidebarV2.h"
#import "UINavigationItem+JTRevealSidebarV2.h"
#import "AppDelegate.h"

#import "Utils.h"
#import "MBProgressHUD.h"
#import "RealEstateService.h"
#import "AgentListDetailInvocation.h"
#import "NonConnectedClientDetail.h"
#import "DeleteNonConnectedClientDetailInvocation.h"

@interface NonClientListViewController : UIViewController<UITableViewDelegate, UITableViewDataSource,JTRevealSidebarV2Delegate,NonConnectedClientListDetailInvocationDelegate,DeleteNonConnectedClientDetailInvocationDelegate>
{
    int count;
    AppDelegate *appDelegate;
    AgentDetailView *agentDetailView;
    RealEstateService *service;
    NonConnectedClientDetail *nonConnectedClientDetail;
    
    IBOutlet UIView *viewNonClientList;
    IBOutlet UIButton *btnNavigation;
    IBOutlet UIButton *btnAdd;
    IBOutlet UIButton *btnEdit;
    IBOutlet UIButton *btnDelete;
    IBOutlet UIButton *btnEditClient;
    IBOutlet UIView *viewClient;
    NSMutableArray *arrData;
    NSMutableArray *arrNonConnectedClientData;
    NSMutableArray *arrNonConnectedClientsId;
}

@property(nonatomic,strong) IBOutlet UITableView *tblNonClientList;
@property(nonatomic, strong) SidebarViewController *leftSidebarViewController;
-(IBAction)btnAddClicked;
-(IBAction)btnEditClicked;
-(IBAction)btnDeleteClicked;

//http://stackoverflow.com/questions/17615996/uitableviewcell-custom-edit-view
//http://stackoverflow.com/questions/5365074/uitableview-in-edit-mode-edit-button-doesnt-change-status
//http://stackoverflow.com/questions/17718346/uitableviewcontroller-custom-seteditinganimated
//http://stackoverflow.com/questions/742829/animating-custom-drawn-uitableviewcell-when-entering-edit-mode?rq=1

//http://iosdev12.blogspot.in/2013/06/custom-editing-control-for.html
//https://www.google.co.in/?gws_rd=cr&ei=QQluUuyILMmPrQfy-YDwBg#q=own+custom+editing+mode+for+uitableview
@end
