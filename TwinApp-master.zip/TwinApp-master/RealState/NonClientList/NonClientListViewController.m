//  AgentListViewController.m
//  RealState
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "NonClientListViewController.h"
#import "NonConnectClientTvCellView.h"
#import "AddNonConnectedClientViewController.h"
#import "Utils.h"
#import "NSString+md5.h"
#import "AgentTvCellView.h"
#import "Config.h"

@interface NonClientListViewController ()
@end

@implementation NonClientListViewController
@synthesize tblNonClientList;

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    self.navigationItem.revealSidebarDelegate=self;
    [btnNavigation addTarget:self action:@selector(revealLeftSidebar:) forControlEvents:UIControlEventTouchUpInside];
   
    service = [[RealEstateService alloc] init];
    arrNonConnectedClientData = [[NSMutableArray alloc] init];
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    arrNonConnectedClientsId = [[NSMutableArray alloc]init];

    if(IsRunningTallPhone())
    {
        [viewNonClientList setFrame:CGRectMake(0, 0, 320, 568)];
        [tblNonClientList setFrame:CGRectMake(0, 44, 320, 470)];
        [viewClient setFrame:CGRectMake(0, 518, 320, 50)];
    }
    else
    {
        [viewNonClientList setFrame:CGRectMake(0, 0, 320, 480)];
        [tblNonClientList setFrame:CGRectMake(0, 44, 320, 380)];
        [viewClient setFrame:CGRectMake(0, 430, 320, 50)];
    }
    
    self.tblNonClientList.allowsMultipleSelectionDuringEditing = YES;
}

-(void)viewWillAppear:(BOOL)animated
{
    count = 0;
    btnEditClient.hidden = YES;
    btnDelete.hidden=YES;
    btnAdd.hidden=NO;
    [tblNonClientList setEditing:NO animated:YES];
    [btnEdit setTitle:@"Edit" forState:UIControlStateNormal];
    
    [AppDelegate sharedDelegate].globalReference = nil;
    [AppDelegate sharedDelegate].globalReference = self.navigationController;
    if(isInternetAvailable())
    {
        [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
        [service NonConnectedClientListDetailInvocation:[[[NSUserDefaults standardUserDefaults] valueForKey:@"userData"] valueForKey:@"user_id"] delegate:self];
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Internet connection is not available"];
    }
}

-(void)NonConnectedClientListDetailInvocationDidFinish:(NonConnectedClientListDetailInvocation*)invocation
                              withResults:(NSMutableArray*)result
                             withMessages:(NSString*)msg
                                withError:(NSError*)error;
{
    [arrNonConnectedClientData removeAllObjects];
    [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
    if(!error)
    {
        if(result==nil || result==(NSArray*)[NSNull null])
        {
            [Utils showAlertMessage:@"Twin Realty" Message:msg];
        }
        else
        {
            if([result count]>0)
            {
                if([[[result objectAtIndex:0] objectForKey:@"message"] isEqualToString:@"failed"])
                {
                    btnEdit.userInteractionEnabled=FALSE;
                }
                else
                {
                    btnEdit.userInteractionEnabled=TRUE;
                    for (int i=0; i<[result count]; i++)
                    {
                        nonConnectedClientDetail = [[NonConnectedClientDetail alloc] init];
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"nonclient_id"]!=[NSNull null])
                            nonConnectedClientDetail.strId = [[result objectAtIndex:i] objectForKey:@"nonclient_id"];
                        
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"nonclientfirst_name"]!=[NSNull null])
                            nonConnectedClientDetail.strFirstName = [[result objectAtIndex:i] objectForKey:@"nonclientfirst_name"];
                        
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"nonclientlast_name"]!=[NSNull null])
                            nonConnectedClientDetail.strLastName = [[result objectAtIndex:i] objectForKey:@"nonclientlast_name"];
                        
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"nonclinetuser_name"]!=[NSNull null])
                            nonConnectedClientDetail.strUserName = [[result objectAtIndex:i] objectForKey:@"nonclinetuser_name"];
                        
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"nonclient_email"]!=[NSNull null])
                            nonConnectedClientDetail.strEmail = [[result objectAtIndex:i] objectForKey:@"nonclient_email"];
                        
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"nonclient_password"]!=[NSNull null]){
                            nonConnectedClientDetail.strPassword = [[result objectAtIndex:i] objectForKey:@"nonclient_password"];
                        }
                        [arrNonConnectedClientData addObject:nonConnectedClientDetail];
                    }
                }
                [tblNonClientList reloadData];
            }
        }
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"error"];
    }
}

-(IBAction)btnAddClicked
{
    
    if (IS_IPHONE) {
        AddNonConnectedClientViewController *add = [[AddNonConnectedClientViewController alloc] initWithNibName:@"AddNonConnectedClientViewController_iPhone" bundle:nil];
        add.intType=0;
        [self.navigationController pushViewController:add animated:YES];
    } else {
        AddNonConnectedClientViewController *add = [[AddNonConnectedClientViewController alloc] initWithNibName:@"AddNonConnectedClientViewController_iPad" bundle:nil];
        add.intType=0;
        [self.navigationController pushViewController:add animated:YES];
    }
    
}

-(IBAction)btnEditClicked
{
    if([btnEdit.titleLabel.text isEqualToString:@"Edit"])
    {
        count = 0;
        [tblNonClientList setEditing:YES animated:YES];
        [btnEdit setTitle:@"Done" forState:UIControlStateNormal];

        btnAdd.hidden=YES;
        btnEditClient.hidden = NO;
        btnDelete.hidden=NO;
        btnEditClient.alpha=0.5;
        btnDelete.alpha=0.5;
        btnEditClient.userInteractionEnabled=FALSE;
        btnDelete.userInteractionEnabled=FALSE;
    }
    else
    {
        [btnEdit setTitle:@"Edit" forState:UIControlStateNormal];
        [btnDelete setTitle:@"Delete" forState:UIControlStateNormal];
        btnAdd.hidden=NO;
        btnEditClient.hidden = YES;
        btnDelete.hidden=YES;
        [tblNonClientList setEditing:NO animated:YES];
    }
}

-(void)updateSelectionCount
{
    if(count==0)
    {
        [btnDelete setTitle:@"Delete" forState:UIControlStateNormal];
        btnDelete.alpha=0.5;
        btnEditClient.alpha=0.5;
        btnDelete.userInteractionEnabled=FALSE;
        btnEditClient.userInteractionEnabled=FALSE;
    }
    if(count>0)
    {
        btnDelete.userInteractionEnabled=TRUE;
        [btnDelete setTitle:[NSString stringWithFormat:@"Delete (%d)", count] forState:UIControlStateNormal];
        btnDelete.alpha=1.0;
        btnEditClient.alpha=1.0;
        if(count==1)
        {
            btnEditClient.alpha=1.0;
            btnEditClient.userInteractionEnabled=TRUE;
        }
        else
        {
            btnEditClient.alpha=0.5;
            btnEditClient.userInteractionEnabled=FALSE;
        }
    }
}

-(IBAction)btnDeleteClicked
{
    arrNonConnectedClientsId = [[NSMutableArray alloc] init];
    NSMutableIndexSet *indexes = [[NSMutableIndexSet alloc ]init];
    NSMutableArray *arrTmp = [[NSMutableArray alloc] init];
    NSArray *selectedRows = [self.tblNonClientList indexPathsForSelectedRows];
    for (int i=0; i<[selectedRows count]; i++)
    {
         NSIndexPath *indexPath = [selectedRows objectAtIndex:i];
        [arrTmp addObject:indexPath];
        [indexes addIndex:indexPath.row];
        
        nonConnectedClientDetail = [arrNonConnectedClientData objectAtIndex:indexPath.row];
        [arrNonConnectedClientsId addObject:nonConnectedClientDetail.strId];
    }
    
    [arrNonConnectedClientData removeObjectsAtIndexes:indexes];
    
    [self.tblNonClientList beginUpdates];
    [self.tblNonClientList deleteRowsAtIndexPaths:arrTmp withRowAnimation:UITableViewRowAnimationFade];
    [self.tblNonClientList endUpdates];
    count = 0;
    [btnDelete setTitle:@"Delete" forState:UIControlStateNormal];
    btnDelete.alpha = 0.5;
    btnEditClient.alpha = 0.5;
    btnDelete.userInteractionEnabled=FALSE;
    btnEditClient.userInteractionEnabled=FALSE;
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    [service DeleteNonConnectedClientDetailInvocation:arrNonConnectedClientsId delegate:self];
}

-(void)DeleteNonConnectedClientDetailInvocationDidFinish:(DeleteNonConnectedClientDetailInvocation*)invocation
                                             withResults:(NSMutableDictionary*)result
                                            withMessages:(NSString*)result1
                                               withError:(NSError*)error;
{
    [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
    if(!error)
    {
        if(result==nil || result==(NSMutableDictionary*)[NSNull null]){
            [Utils showAlertMessage:@"Twin Realty" Message:result1];
        }
        else if([[result objectForKey:@"message"] isEqualToString:@"success"])
        {
            if([arrNonConnectedClientData count]==0)
            {
                btnEdit.userInteractionEnabled=FALSE;
                [btnEdit setTitle:@"Edit" forState:UIControlStateNormal];
                btnEditClient.hidden=YES;
                btnDelete.hidden=YES;
                btnAdd.hidden=NO;
                [tblNonClientList setEditing:NO animated:YES];
            }
        }
        else
        {
            [Utils showAlertMessage:@"Twin Realty" Message:result1];
        }
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"error"];
    }
}

#pragma mark JTRevealSidebarDelegate
- (void)revealLeftSidebar:(id)sender
{
    [self.navigationController toggleRevealState:JTRevealedStateLeft];
}

- (UIView *)viewForLeftSidebar{
    
    CGRect viewFrame = self.navigationController.applicationViewFrame;
    UITableViewController *controller = self.leftSidebarViewController;
    if (!controller)
    {
        self.leftSidebarViewController = [[SidebarViewController alloc] init];
        self.leftSidebarViewController.sidebarDelegate = [AppDelegate sharedDelegate];
        controller = self.leftSidebarViewController;
    }
    controller.view.frame = CGRectMake(0, viewFrame.origin.y, 270, viewFrame.size.height);
    controller.view.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
    return controller.view;
}

//Optional delegate methods for additional configuration after reveal state changed
- (void)didChangeRevealedStateForViewController:(UIViewController *)viewController {
    // Example to disable userInteraction on content view while sidebar is revealing
    if (viewController.revealedState == JTRevealedStateNo)
    {
        tblNonClientList.userInteractionEnabled=YES;
    }
    else
    {
        tblNonClientList.userInteractionEnabled=NO;
    }
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrNonConnectedClientData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*
    NonConnectClientTvCellView *cell;
    static NSString *CellIdentifier = @"Cell";
    cell = (NonConnectClientTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (tblNonClientList.isEditing) {
        cell.selectionStyle = UITableViewCellSelectionStyleBlue;
    }

    if (cell == nil)
    {
        UIViewController *view = [[UIViewController alloc]initWithNibName:@"NonConnectClientTvCellView_iPhone" bundle:nil];
        cell = (NonConnectClientTvCellView *)view.view;
    }
    cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    cell.imgBackground.layer.borderWidth=0.75;
    cell.tag = indexPath.row;
    nonConnectedClientDetail = [arrNonConnectedClientData objectAtIndex:indexPath.row];
    cell.lblNonConnectedClient.text = nonConnectedClientDetail.strUserName;
    cell.lbNonConnectedClientEmail.text = nonConnectedClientDetail.strEmail;
     */
    
    
    static NSString *CellIdentifier = @"Cell";
    AgentTvCellView *cell = (AgentTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view ;
        if (IS_IPHONE) {
            view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPhone" bundle:nil];
        } else {
           view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPad" bundle:nil];
        }
        
        cell = (AgentTvCellView *)view.view;
    }
    
    if (tblNonClientList.isEditing) {
        cell.selectionStyle = UITableViewCellSelectionStyleBlue;
    }
    
    if (cell == nil)
    {
        UIViewController *view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPhone" bundle:nil];
        cell = (AgentTvCellView *)view.view;
    }
    
    
    cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    if (IS_IPHONE) {
        cell.imgBackground.layer.borderWidth=0.5;
    } else {
        cell.imgBackground.layer.borderWidth=1.5;
    }
    
    
    cell.imgUserPhoto.backgroundColor = [UIColor clearColor];
    cell.imgUserPhoto.layer.borderColor = [UIColor grayColor].CGColor;
    cell.imgUserPhoto.placeholderImage = [UIImage imageNamed:@"upload_pic"];
    nonConnectedClientDetail = [arrNonConnectedClientData objectAtIndex:indexPath.row];
    
    NSString *url = [NSString stringWithFormat:@"%@%@",WebserviceImageUrl,nonConnectedClientDetail.strImage];
    cell.imgUserPhoto.imageURL  = [NSURL URLWithString:url];
    cell.lblUserName.text = [NSString stringWithFormat:@"%@ %@",nonConnectedClientDetail.strFirstName,nonConnectedClientDetail.strLastName];
    
    cell.lblUserEmailId.text = nonConnectedClientDetail.strEmail;
    cell.lblUserPhone.text = nonConnectedClientDetail.strPhone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.tblNonClientList.isEditing){
        count--;
    }
    [self updateSelectionCount];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.tblNonClientList.isEditing){
        count++;
        [self updateSelectionCount];
        
    }
    else
    {
        [tblNonClientList deselectRowAtIndexPath:indexPath animated:YES];
        AddNonConnectedClientViewController *add ;
        if (IS_IPHONE) {
            add = [[AddNonConnectedClientViewController alloc] initWithNibName:@"AddNonConnectedClientViewController_iPhone" bundle:nil];
        } else {
          add = [[AddNonConnectedClientViewController alloc] initWithNibName:@"AddNonConnectedClientViewController_iPad" bundle:nil];
        }
        
        add.intType=1;
        add.nonConnectedClientDetailTmp = [arrNonConnectedClientData objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:add animated:YES];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (IS_IPHONE) {
        return 100;
    } else {
        return 130;
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(IBAction)editClient:(id)sender
{
    AddNonConnectedClientViewController *add;
    if (IS_IPHONE) {
        add = [[AddNonConnectedClientViewController alloc] initWithNibName:@"AddNonConnectedClientViewController_iPhone" bundle:nil];
    } else {
       add = [[AddNonConnectedClientViewController alloc] initWithNibName:@"AddNonConnectedClientViewController_iPad" bundle:nil];
    }
    
    add.intType=1;
    add.nonConnectedClientDetailTmp = [arrNonConnectedClientData objectAtIndex:[tblNonClientList indexPathForSelectedRow].row];
    [self.navigationController pushViewController:add animated:YES];
}
@end
