//  AddNotes.m
//  RealEstate_App
//  Created by Octal on 13/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import "AddNotes.h"
#import "Utils.h"
#import "REWebService.h"
#import "MBProgressHUD.h"

@interface AddNotes ()

@end

@implementation AddNotes

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark Actions

-(IBAction)backButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)addNoteButtonClicked:(id)sender
{
    if (txtNote.text.length==0)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter note"];
        
    } else
    {
        [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
         NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
        [dataDict setValue:txtNote.text forKey:@"note"];
        [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"user_id"];
        [dataDict setValue:self.propertyId forKey:@"property_id"];
        [REWebService addNoteProperty:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self->appDelegate.window animated:YES];
            if (!error)
            {
                if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"])
                {
                    [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                    self->txtNote.text = @"";
                    [self.navigationController popViewControllerAnimated:YES];
                    
                } else
                {
                    [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                }
                
            }
            
            
        }];
        
        
    }
    
    
    
    
}
@end
