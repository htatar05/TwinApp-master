//  RegisterViewController.m
//  RealState
//  Created by Kapil Goyal on 04/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "RegisterViewController.h"
#import "MainViewController.h"
#import "REWebService.h"
#import "Config.h"
#import "UIImageView+UIActivityIndicatorForSDWebImage.h"
#import "UIImageView+HighlightedWebCache.h"
#import "NSDictionary+NullReplacement.h"
#import "NSArray+NullReplacement.h"

@interface RegisterViewController ()
@end

@implementation RegisterViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    userObj = [[User alloc] init];
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    service = [[RealEstateService alloc] init];
    self.navigationController.navigationBarHidden = YES;
    arrAgentList = [[NSMutableArray alloc] init];
    arrAgentListTmp = [[NSMutableArray alloc] init];
    
    arrAgentId = [[NSMutableArray alloc] init];
    arrAgentTempId = [[NSMutableArray alloc] init];
    imgViewAgentList.hidden=YES;
    tblAgentList.hidden=YES;
    [service AgentListInvocation:self];
    btnUserImage.titleLabel.numberOfLines = 2;
    /*
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
       // [scrlView setFrame:CGRectMake(0, 44, 320, 436)];
       // [scrlView setContentSize:CGSizeMake(320, 620)];
        //[scrlView setContentSize:CGSizeMake(320, 620)];
        [tblAgentList setSeparatorInset:UIEdgeInsetsZero];

        if(IsRunningTallPhone())
        {
            [scrlView setFrame:CGRectMake(0, 44, 320, 524)];
            [scrlView setContentSize:CGSizeMake(320, 510)];
        }
    }
    else
    {
        [scrlView setFrame:CGRectMake(0, 44, 320, 436)];
        [scrlView setContentSize:CGSizeMake(320, 620)];
        if(IsRunningTallPhone())
        {
            [scrlView setFrame:CGRectMake(0, 44, 320, 524)];
            [scrlView setContentSize:CGSizeMake(320, 510)];
        }
    }
    */
    
    [scrlView setFrame:CGRectMake(0, 44, 320, self.view.frame.size.height-94)];
    [scrlView setContentSize:CGSizeMake(320, 610)];
}

-(IBAction)btnBackClick
{
    [txtFieldFName resignFirstResponder];
    [txtFieldLName resignFirstResponder];
    [txtFieldPassword resignFirstResponder];
    [txtFieldConfirmPassword resignFirstResponder];
    [txtFieldEMail resignFirstResponder];
    [txtFieldAgentName resignFirstResponder];
    [txtFieldAddress1 resignFirstResponder];
    [txtFieldAddress2 resignFirstResponder];
    [txtFieldTelephoneNo resignFirstResponder];
    [txtFieldZipCode resignFirstResponder];
    [txtFieldUserName resignFirstResponder];
    
    if(appDelegate.boolLoginNotNow)
    {
        [UIView animateWithDuration:0.5
                              delay:0.0
                            options:1
                         animations:^{
                             if(IsRunningTallPhone())
                                 self.view.frame=CGRectMake(320, 0, 320, 568);
                             else
                                 self.view.frame=CGRectMake(320, 0, 320, 480);
                         }completion:^(BOOL finished){}];    }
    else if(appDelegate.boolLogin)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if(appDelegate.boolLoginPresent)
    {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    else
    {
      [self.navigationController popViewControllerAnimated:YES];
    }
}

-(IBAction)btnCancelClick
{
    txtFieldFName.text=@"";
    txtFieldLName.text=@"";
    txtFieldEMail.text=@"";
    txtFieldPassword.text=@"";
    txtFieldConfirmPassword.text=@"";
    txtFieldAgentName.text=@"";
    txtFieldTelephoneNo.text=@"";
    txtFieldAddress1.text=@"";
    txtFieldAddress2.text=@"";
    txtFieldZipCode.text=@"";
    txtFieldUserName.text=@"";
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"

    keyboardControls.textFields = [NSArray arrayWithObjects:txtFieldFName,txtFieldLName,txtFieldEMail,txtFieldUserName, txtFieldPassword,txtFieldConfirmPassword,txtFieldAgentName,txtFieldTelephoneNo,txtFieldAddress1,txtFieldAddress2,txtFieldZipCode, nil];
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"Previous";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"Next";
    
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] bounds];
    CGFloat availableHeight;
    if(IsRunningTallPhone())
        availableHeight = applicationFrame.size.height; //- 200; // Remove area covered by keyboard
    else
        availableHeight = applicationFrame.size.height; // - 260; // Remove area covered by keyboard

    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
    [scrlView setContentOffset:CGPointMake(0, y) animated:YES];
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    [controls.activeTextField resignFirstResponder];
    [imgViewAgentList setHidden:YES];
    [tblAgentList setHidden:YES];
    [scrlView setContentOffset:CGPointMake(0, 0) animated:YES];
}

- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    if(textField == txtFieldAgentName)
    {
        [tblAgentList setHidden:NO];
        [imgViewAgentList setHidden:NO];
    }
    else
    {
        [tblAgentList setHidden:YES];
        [imgViewAgentList setHidden:YES];
    }
    [self scrollViewToCenterOfScreen:textField];
}

#pragma mark TextField Delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([keyboardControls.textFields containsObject:textField])
        keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    
//    if(textField==txtFieldAgentName)
//    {
//        if (txtFieldAgentName.text.length>1) {
//            imgViewAgentList.hidden=NO;
//            tblAgentList.hidden=NO;
//        }
//        else
//        {
//            imgViewAgentList.hidden=YES;
//            tblAgentList.hidden=YES;
//        
//        }
    
  //  imgViewAgentList.hidden=NO;
   // tblAgentList.hidden=NO;
        
   // }
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if([textField isEqual:txtFieldAgentName])
    {
        NSString *text = [textField.text stringByReplacingCharactersInRange:range withString:string];
        if(text.length>0)
        {
            [arrAgentList removeAllObjects];
            [arrAgentId removeAllObjects];
            if([textField isEqual:txtFieldAgentName])
            {
                for(int i=0;i<[arrAgentListTmp count];i++)
                {
                    NSString *data = [arrAgentListTmp objectAtIndex:i];
                    if([[data lowercaseString] rangeOfString:[text lowercaseString]].length>0)
                    {
                        [arrAgentList addObject:data];
                        [arrAgentId addObject:[arrAgentTempId objectAtIndex:i]];
                    }
                }
            }
            [tblAgentList reloadData];
            imgViewAgentList.hidden=NO;
            tblAgentList.hidden=NO;
        }
        else
        {
            [arrAgentList removeAllObjects];
            [arrAgentId removeAllObjects];
            for(int i=0;i<[arrAgentListTmp count];i++)
                [arrAgentList addObject:[arrAgentListTmp objectAtIndex:i]];
            for(int i=0;i<[arrAgentTempId count];i++)
                [arrAgentId addObject:[arrAgentTempId objectAtIndex:i]];
            [tblAgentList reloadData];
            imgViewAgentList.hidden=NO;
            tblAgentList.hidden=NO;
        }
    }
    else if([textField isEqual:txtFieldTelephoneNo])
    {
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init] ;
        if([string length]==0)
        {
            [formatter setGroupingSeparator:@"-"];
            [formatter setGroupingSize:4];
            [formatter setUsesGroupingSeparator:YES];
            [formatter setSecondaryGroupingSize:3];
            NSString *num = textField.text ;
            num= [num stringByReplacingOccurrencesOfString:@"-" withString:@""];
            NSString *str = [formatter stringFromNumber:[NSNumber numberWithDouble:[num doubleValue]]];
            
            textField.text=str;
            NSLog(@"%@",str);
            return YES;
        }
        else {
            [formatter setGroupingSeparator:@"-"];
            [formatter setGroupingSize:3];
            [formatter setUsesGroupingSeparator:YES];
            [formatter setSecondaryGroupingSize:3];
            NSString *num = textField.text ;
            if(![num isEqualToString:@""])
            {
                num= [num stringByReplacingOccurrencesOfString:@"-" withString:@""];
                NSString *str = [formatter stringFromNumber:[NSNumber numberWithDouble:[num doubleValue]]];
                
                textField.text=str;
            }
            
            return YES;
        }
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
   // [scrlView setContentOffset:CGPointMake(0, 0) animated:YES];
    [textField resignFirstResponder];
    [tblAgentList setHidden:YES];
    return YES;
}

#pragma mark Touch Delegate
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [tblAgentList setHidden:YES];
}

- (void)resignKeyboard
{
    [txtFieldFName resignFirstResponder];
    [txtFieldLName resignFirstResponder];
    [txtFieldEMail resignFirstResponder];
    [txtFieldPassword resignFirstResponder];
    [txtFieldConfirmPassword resignFirstResponder];
    [txtFieldAgentName resignFirstResponder];
    [txtFieldTelephoneNo resignFirstResponder];
    [txtFieldAddress1 resignFirstResponder];
    [txtFieldAddress2 resignFirstResponder];
    [txtFieldZipCode resignFirstResponder];
    [txtFieldUserName resignFirstResponder];
}

-(void)AgentListInvocationDidFinish:(AgentListInvocation*)invocation withResults:(NSArray*)result withMessages:(NSString*)msg withError:(NSError*)error
{
    [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
    [arrAgentList removeAllObjects];
    [arrAgentListTmp removeAllObjects];
    
    [arrAgentId removeAllObjects];
    [arrAgentTempId removeAllObjects];
    
    if(!error){
        if(result==nil || result==(NSArray*)[NSNull null])
        {
            [Utils showAlertMessage:@"Twin Realty" Message:msg];
        }
        else
        {
            for(int i=0;i<[result count];i++)
            {
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"agent_name"]!=[NSNull null])
                {
                    [arrAgentList addObject:[[result objectAtIndex:i] objectForKey:@"agent_name"]];
                    [arrAgentListTmp addObject:[[result objectAtIndex:i] objectForKey:@"agent_name"]];
                }
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"agent_id"]!=[NSNull null])
                {
                   [arrAgentId addObject:[[result objectAtIndex:i] objectForKey:@"agent_id"]];
                   [arrAgentTempId addObject:[[result objectAtIndex:i] objectForKey:@"agent_id"]];
                }
            }
            [tblAgentList reloadData];
        }
    }
}

#pragma mark Registration method
- (BOOL)userNameValidate:(NSString *)strName;
{
    NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890_-"];
    s = [s invertedSet];
    NSRange r = [strName rangeOfCharacterFromSet:s];
    if (r.location != NSNotFound)
        return YES;
    return YES;
}

-(IBAction)btnRegisterClick
{
    [self resignKeyboard];
    if(isInternetAvailable())
    {
        [self registerValidationTxtFields];
    }
    else{
        [Utils showAlertMessage:@"Twin Realty" Message:@"Internet connection is not available"];
    }
}

- (void)registerValidationTxtFields
{
	userObj.strFName = [txtFieldFName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	userObj.strLName = [txtFieldLName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	userObj.strEmail = [txtFieldEMail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    userObj.strUserName = [txtFieldUserName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	userObj.strPassword = [txtFieldPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	userObj.strConfirmPassword = [txtFieldConfirmPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	userObj.strAgentName = [txtFieldAgentName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    userObj.strPhoneNo = [txtFieldTelephoneNo.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	userObj.strAddress1 = [txtFieldAddress1.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	userObj.strAddress2 = [txtFieldAddress2.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	userObj.strPostalCode = [txtFieldZipCode.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];

    flag = (validateEmail(userObj.strEmail));
    boolFirstName = [self userNameValidate:txtFieldFName.text];
    boolLastName = [self userNameValidate:txtFieldLName.text];
    NSLog(@"length=%lu",(unsigned long)[userObj.strPhoneNo length]);
    
    if(userObj.strAgentId.length == 0 && userObj.strAgentId == nil)
        userObj.strAgentId=@"";
    if(userObj.strPhoneNo.length == 0 && userObj.strPhoneNo == nil)
        userObj.strPhoneNo = @"";
    if(userObj.strAddress1.length == 0 && userObj.strAddress1 == nil)
        userObj.strAddress1 = @"";
    if(userObj.strAddress2.length == 0 && userObj.strAddress2 == nil)
        userObj.strAddress2 = @"";
    if(userObj.strPostalCode.length == 0 && userObj.strPostalCode == nil)
        userObj.strPostalCode = @"";
    
    if (!boolFirstName)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter a valid name!"];
		[txtFieldFName becomeFirstResponder];
        return;
    }
    
    else if(userObj.strFName == NULL || [userObj.strFName length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter first name!"];
		[txtFieldFName becomeFirstResponder];
        return;
	}
    else if(txtFieldLName.text.length==0)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter last name!"];
		[txtFieldLName becomeFirstResponder];
        return;
    }
    else if(userObj.strLName == NULL || [userObj.strLName length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter last name!"];
		[txtFieldLName becomeFirstResponder];
	}
    else if(userObj.strEmail == NULL || [userObj.strEmail length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter an email address!"];
		[txtFieldEMail becomeFirstResponder];
        return;
	}
	else if (!flag) {
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter valid email address!"];
		[txtFieldEMail becomeFirstResponder];
        return;
	}
    if(txtFieldTelephoneNo.text.length==0)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter phone number!"];
        return;

    }
    else if(userObj.strPassword == NULL || [userObj.strPassword length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter a password!"];
		[txtFieldPassword becomeFirstResponder];
        return;
	}
    else if(userObj.strPassword.length<6) {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter password at least 6 characters!"];
        [txtFieldPassword becomeFirstResponder];
        
        return;
    }
	else if(userObj.strConfirmPassword == NULL || [userObj.strConfirmPassword length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter confrim password!"];
		[txtFieldConfirmPassword becomeFirstResponder];
        return;
	}
    else if(userObj.strConfirmPassword.length<6) {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter confirm password at least 6 characters!"];
        [txtFieldConfirmPassword becomeFirstResponder];
        return;
    }
    
//    else if(userObj.strPassword.length>15)
//    {
//        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter password 6 to 15 characters!"];
//		[txtFieldPassword becomeFirstResponder];
//        return;
//    }
    
//    else if(userObj.strConfirmPassword.length>15)
//    {
//        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter confirm password 6 to 15 characters!"];
//		[txtFieldConfirmPassword becomeFirstResponder];
//        return;
//    }
	else if (![userObj.strConfirmPassword isEqualToString:userObj.strPassword])
	{
		[Utils showAlertMessage:@"Twin Realty" Message:@"Password and Confirmation password don’t match!"];
		[txtFieldConfirmPassword becomeFirstResponder];
        return;
	}
    else
    {
       [self LoadRegisterData];
    }
    
}

-(void)LoadRegisterData
{
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    [txtFieldFName resignFirstResponder];
    [txtFieldLName resignFirstResponder];
    [txtFieldEMail resignFirstResponder];
    [txtFieldPassword resignFirstResponder];
    [txtFieldConfirmPassword resignFirstResponder];
    [txtFieldAgentName resignFirstResponder];
    [txtFieldTelephoneNo resignFirstResponder];
    [txtFieldAddress1 resignFirstResponder];
    [txtFieldAddress2 resignFirstResponder];
    [txtFieldZipCode resignFirstResponder];
    [txtFieldUserName resignFirstResponder];
    NSString*strDeviceToken = [[NSUserDefaults standardUserDefaults] valueForKey:@"devicetoken"];
    
    if ([strDeviceToken length]==0)
    {
        strDeviceToken=@"SampleDeviceToken";
    }
     NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
     [dataDict setValue:strDeviceToken forKey:@"device_token"];
     [dataDict setValue:userObj.strEmail forKey:@"email"];
     [dataDict setValue:userObj.strAgentId forKey:@"agent_id"];
     [dataDict setValue:userObj.strFName forKey:@"first_name"];
     [dataDict setValue:userObj.strLName forKey:@"last_name"];
     [dataDict setValue:userObj.strPassword forKey:@"password"];
     [dataDict setValue:userObj.strAddress1 forKey:@"address1"];
     [dataDict setValue:userObj.strAddress2 forKey:@"address2"];
     [dataDict setValue:userObj.strPostalCode forKey:@"post_code"];
     [dataDict setValue:userObj.strPhoneNo forKey:@"phone_no"];
     [dataDict setValue:txtCity.text forKey:@"city"];
     [dataDict setValue:txtState.text forKey:@"state"];
     NSLog(@"my token %@",dataDict);
     UIImage *regImage;
    if (boolImage)
    {
        regImage = imgViewUser.image;
    }
    else
    {
      regImage = [UIImage imageNamed:@""];
    }
   
    [REWebService CallRegistrationWithImage:dataDict image:regImage withBlock:^(NSDictionary *responseData, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self->appDelegate.window animated:YES];
        if((NSNull*)[[responseData objectForKey:@"response"] objectForKey:@"message"]!=[NSNull null])
        {
            if([[[responseData objectForKey:@"response"] objectForKey:@"message"] isEqualToString:@"success"])
            {
                if((NSNull*)[[responseData objectForKey:@"response"] objectForKey:@"user_id"]!=[NSNull null])
                    [[NSUserDefaults standardUserDefaults] setObject:[[responseData objectForKey:@"response"] objectForKey:@"user_id"] forKey:@"user_id"];
                if((NSNull*)[[responseData objectForKey:@"response"] objectForKey:@"role_id"]!=[NSNull null])
                    [[NSUserDefaults standardUserDefaults] setObject:[[responseData objectForKey:@"response"] objectForKey:@"role_id"] forKey:@"role_id"];
                
                NSDictionary *rerg = [responseData objectForKey:@"response"];
               
               [[NSUserDefaults standardUserDefaults] setObject:[rerg dictionaryByReplacingNullsWithBlanks] forKey:@"userData"];
                
                [[NSUserDefaults standardUserDefaults] setObject:[rerg objectForKey:@"user_id"] forKey:@"user_id"];
                [[NSUserDefaults standardUserDefaults] setObject:[rerg objectForKey:@"role_id"] forKey:@"role_id"];
                [[NSUserDefaults standardUserDefaults] setObject:[rerg objectForKey:@"role_id"] forKey:@"RoleId"];
                
                if((NSNull*)[[responseData objectForKey:@"response"] objectForKey:@"msg"]!=[NSNull null])
                {
                    if(self->appDelegate.boolLoginNotNow)
                    {
                        [UIView animateWithDuration:0.5
                                              delay:0.0
                                            options:1
                                         animations:^{
                                             self.view.frame=CGRectMake(320, 0, 320, 480);
                                         }completion:^(BOOL finished){}];
                    }
                    else if(self->appDelegate.boolLogin)
                    {
                       
                        [self.navigationController popViewControllerAnimated:YES];
                    }
                    else if(self->appDelegate.boolLoginPresent)
                    {
                        [self dismissViewControllerAnimated:YES completion:nil];
                    }
                }
                
                [Utils showAlertMessage:@"Twin Realty" Message:[[responseData objectForKey:@"response"] objectForKey:@"msg"]];
                
                
                if (IS_IPHONE) {
                    
                    MainViewController *main = [[MainViewController alloc] initWithNibName:@"MainViewController_iPhone" bundle:nil];
                    [self.navigationController pushViewController:main animated:YES];
                    
                } else {
                    
                    MainViewController *main = [[MainViewController alloc] initWithNibName:@"MainViewController_iPad" bundle:nil];
                    [self.navigationController pushViewController:main animated:YES];
                }
                
                
            }
            else if([[[responseData objectForKey:@"response"] objectForKey:@"message"] isEqualToString:@"error"])
            {
                [Utils showAlertMessage:@"Twin Realty" Message:[[responseData objectForKey:@"response"] objectForKey:@"msg"]];
            }
        }
        
    }];
    
}

#pragma mark ActionSheet and UIImagePickerController delegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex == 1)
    {
        UIImagePickerController* picker = [[UIImagePickerController alloc] init];
        picker.sourceType =UIImagePickerControllerSourceTypePhotoLibrary;
        picker.delegate = self;
        picker.allowsEditing = YES;
        if(appDelegate.boolLoginNotNow)
            [self presentViewController:picker animated:YES completion:nil];
        else
            [[self navigationController] presentViewController:picker animated:YES completion:nil];

    }
	else if(buttonIndex == 0)
    {
		if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])  {
            UIImagePickerController* picker = [[UIImagePickerController alloc] init];
            picker.sourceType =UIImagePickerControllerSourceTypeCamera;
            picker.delegate = self;
            if(appDelegate.boolLoginNotNow)
                [self presentViewController:picker animated:YES completion:nil];
            else
                [[self navigationController] presentViewController:picker animated:YES completion:nil];		}
		else
        {
			UIImagePickerController* picker = [[UIImagePickerController alloc] init];
			picker.sourceType =UIImagePickerControllerSourceTypePhotoLibrary;
            picker.delegate = self;
            if(appDelegate.boolLoginNotNow)
                [self presentViewController:picker animated:YES completion:nil];
            else
                [[self navigationController] presentViewController:picker animated:YES completion:nil];		}
	}
}

-(IBAction)btnUploadPhotoClick
{
    [self resignKeyboard];
    UIActionSheet *myActionSheet=[[UIActionSheet alloc] initWithTitle:@"" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Use Camera",@"Photo Library",nil];
    [myActionSheet showInView:[UIApplication sharedApplication].keyWindow];
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)editingInfo
{
    dataPhoto = [[NSData alloc] init];
    dataPhoto = UIImageJPEGRepresentation([editingInfo objectForKey:@"UIImagePickerControllerOriginalImage"],0.20f);
    UIImage *image = [editingInfo valueForKey:UIImagePickerControllerOriginalImage];
    imgViewUser.image = [self fixOrientationForImage:image];
    boolImage = TRUE;
    imgViewUser.layer.masksToBounds=YES;
    imgViewUser.layer.cornerRadius=35.0;
    [btnUserImage setTitle:@"" forState:UIControlStateNormal];
    [self dismissViewControllerAnimated:YES completion:nil];
}


- (UIImage *)fixOrientationForImage:(UIImage*)neededImage {
    
    // No-op if the orientation is already correct
    if (neededImage.imageOrientation == UIImageOrientationUp) return neededImage;
    
    // We need to calculate the proper transformation to make the image upright.
    // We do it in 2 steps: Rotate if Left/Right/Down, and then flip if Mirrored.
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    switch (neededImage.imageOrientation) {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, neededImage.size.width, neededImage.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, neededImage.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, neededImage.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationUpMirrored:
            break;
    }
    
    switch (neededImage.imageOrientation) {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, neededImage.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, neededImage.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationDown:
        case UIImageOrientationLeft:
        case UIImageOrientationRight:
            break;
    }
    
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, neededImage.size.width, neededImage.size.height,
                                             CGImageGetBitsPerComponent(neededImage.CGImage), 0,
                                             CGImageGetColorSpace(neededImage.CGImage),
                                             CGImageGetBitmapInfo(neededImage.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (neededImage.imageOrientation) {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,neededImage.size.height,neededImage.size.width), neededImage.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,neededImage.size.width,neededImage.size.height), neededImage.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}


#pragma mark UITableView Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrAgentList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell=nil;
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(20, 2, 292, 31)];
    lbl.text=[arrAgentList objectAtIndex:indexPath.row];
    lbl.font =[UIFont fontWithName:@"Helvetica" size:15.0];
    [cell.contentView addSubview:lbl];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    txtFieldAgentName.text = [arrAgentList objectAtIndex:indexPath.row];
    userObj.strAgentId = [arrAgentId objectAtIndex:indexPath.row];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)loadDataForUserProfile
{
    
    NSString *userImage;
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]){
       userImage =[NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults]objectForKey:@"userData"] valueForKey:@"userimage"]];
       
       
        txtFieldFName.text = [NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults] objectForKey:@"userData"] valueForKey:@"username"]];
        
        txtFieldEMail.text = [NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults] objectForKey:@"userData"] valueForKey:@"email"]];
        
    } else if (appDelegate.loginUser) {
        
         userImage = [AppDelegate sharedDelegate].user.strUserImage;
         txtFieldFName.text = [NSString stringWithFormat:@"%@",[AppDelegate sharedDelegate].user.strFName];
         txtFieldEMail.text = [NSString stringWithFormat:@"%@",[AppDelegate sharedDelegate].user.strEmail];
        
    }
    else
    {
        userImage = @"";
        txtFieldFName.text = @"";
        txtFieldEMail.text = @"";
    }
    
    
    NSString *strTemp = [NSString stringWithFormat:@"%@%@",profileImage,userImage];
    [imgViewUser setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",strTemp]] placeholderImage:[UIImage imageNamed:@"non_connected_clients"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    

    imgViewUser.layer.masksToBounds=YES;
    imgViewUser.layer.cornerRadius=35.0;
    lblRegister.text = @"My Profile";
    btnCancel.hidden = YES;
    btnRegister.hidden = YES;
    btnUploadPic.userInteractionEnabled  = NO;
    btnUserImage.userInteractionEnabled = NO;
    tblAgentList.hidden = YES;
    [txtFieldFName setEnabled:NO];
    [txtFieldLName setEnabled:NO];
    [txtFieldEMail setEnabled:NO];
    [txtFieldPassword setEnabled:NO];
    [txtFieldConfirmPassword setEnabled:NO];
    [txtFieldAgentName setEnabled:NO];
    [txtFieldTelephoneNo setEnabled:NO];
    [txtFieldAddress1 setEnabled:NO];
    [txtFieldAddress2 setEnabled:NO];
    [txtFieldZipCode setEnabled:NO];
    [txtFieldUserName setEnabled:NO];
}

-(void)loadDataRegister
{
    lblRegister.text = @"Register";
    btnCancel.hidden = NO;
    btnRegister.hidden = NO;
    btnUploadPic.userInteractionEnabled  = YES;
    btnUserImage.userInteractionEnabled = YES;
    tblAgentList.hidden = NO;
    [txtFieldFName setEnabled:YES];
    [txtFieldLName setEnabled:YES];
    [txtFieldEMail setEnabled:YES];
    [txtFieldPassword setEnabled:YES];
    [txtFieldConfirmPassword setEnabled:YES];
    [txtFieldAgentName setEnabled:YES];
    [txtFieldTelephoneNo setEnabled:YES];
    [txtFieldAddress1 setEnabled:YES];
    [txtFieldAddress2 setEnabled:YES];
    [txtFieldZipCode setEnabled:YES];
    [txtFieldUserName setEnabled:YES];
}


@end
