//  RegisterViewController.h
//  RealState
//  Created by Kapil Goyal on 04/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "User.h"
#import "Utils.h"
#import "SBJSON.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "RealEstateService.h"
#import "BSKeyboardControls.h"
#import "AgentListInvocation.h"
#import "TPKeyboardAvoidingScrollView.h"

@interface RegisterViewController : UIViewController<UIScrollViewDelegate, UITextFieldDelegate,BSKeyboardControlsDelegate,UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate, UIAlertViewDelegate,AgentListInvocationDelegate,UITableViewDelegate, UITableViewDataSource,UINavigationControllerDelegate>
{
    User *userObj;
    AppDelegate *appDelegate;
    RealEstateService *service;
    BSKeyboardControls *keyboardControls;
    
    IBOutlet TPKeyboardAvoidingScrollView *scrlView;
    IBOutlet UIImageView *imgHeaderView;
    IBOutlet UILabel *lblRegister;
    IBOutlet UIButton *btnBack;
    IBOutlet UIImageView *imgViewBack1;
    IBOutlet UIImageView *imgViewFName;
    IBOutlet UIImageView *imgViewLName;
    IBOutlet UIImageView *imgViewEmail;
    IBOutlet UIImageView *imgViewUser;
    IBOutlet UIButton *btnUserImage;
    IBOutlet UITextField *txtFieldFName;
    IBOutlet UITextField *txtFieldLName;
    IBOutlet UITextField *txtFieldEMail;
    IBOutlet UITextField *txtFieldUserName;
    IBOutlet UIButton *btnUploadPic;
    IBOutlet UIImageView *imgViewBack2;
    IBOutlet UIImageView *imgViewPassword;
    IBOutlet UIImageView *imgViewConfirmPassword;
    IBOutlet UITextField *txtFieldPassword;
    IBOutlet UITextField *txtFieldConfirmPassword;
    IBOutlet UILabel *lblBelowOptions;
    IBOutlet UIImageView *imgViewBack3;
    IBOutlet UIImageView *imgViewAgentName;
    IBOutlet UIImageView *imgViewTelephoneNo;
    IBOutlet UIImageView *imgViewAddress1;
    IBOutlet UIImageView *imgViewAddress2;
    IBOutlet UIImageView *imgViewZipCode;
    IBOutlet UITextField *txtFieldAgentName;
    IBOutlet UITextField *txtFieldTelephoneNo;
    IBOutlet UITextField *txtFieldAddress1;
    IBOutlet UITextField *txtFieldAddress2;
    IBOutlet UITextField *txtFieldZipCode;
    IBOutlet UIButton *btnCancel;
    IBOutlet UIButton *btnRegister;
    IBOutlet UITableView *tblAgentList;
    IBOutlet UIImageView *imgViewAgentList;
    IBOutlet UIBarButtonItem *barButton;
    IBOutlet UITextField *txtCity;
    IBOutlet UITextField *txtState;
    
    NSArray *arrRegisterField;
    NSMutableArray *arrAgentList;
    NSMutableArray *arrAgentListTmp;
    NSMutableArray *arrAgentId;
    NSMutableArray *arrAgentTempId;
    NSMutableDictionary *results1;
    NSMutableData *urlData;
    UIAlertView *signupAlert;
    NSData *dataPhoto;
    
    BOOL boolFirstName;
    BOOL boolLastName;
    BOOL flag;
    BOOL boolImage;
    
    RegisterViewController *registerController;
}
@property (nonatomic,strong)NSString *isFromRegister;
@end
