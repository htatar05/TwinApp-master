//  LoginViewController.m
//  RealState
//  Created by Kapil Goyal on 27/08/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "LoginViewController.h"
#import "MainViewController.h"
#import "SettingsViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController
@synthesize window;
@synthesize leftSidebarViewController;

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    service = [[RealEstateService alloc] init];
    userObj = [[User alloc] init];
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    [btnBack addTarget:self action:@selector(btnBackClicked) forControlEvents:UIControlEventTouchUpInside];
    BOOL boolValue = [[NSUserDefaults standardUserDefaults] boolForKey:@"loginstatus"];
    boolValue = TRUE;
    if (boolValue)
    {
        boolKeepMeLogin=TRUE;
        appDelegate.isAutoLogin = TRUE;
		[btnRemember setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
    }
	else
    {
        boolKeepMeLogin=FALSE;
        appDelegate.isAutoLogin = FALSE;
		[btnRemember setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
    }
    
    self.navigationController.navigationBarHidden = YES;
    if(IsRunningTallPhone())
        [viewForgot setFrame:CGRectMake(0, 518, 530, 50)];
    else
        [viewForgot setFrame:CGRectMake(0, 430, 530, 50)];
    [self addKeyboardControls];
}

-(IBAction)btnRegisterClicked
{
    if (IS_IPHONE) {
        registerController = [[RegisterViewController alloc] initWithNibName:@"RegisterViewController_iPhone" bundle:nil];
    } else {
        registerController = [[RegisterViewController alloc] initWithNibName:@"RegisterViewController_iPad" bundle:nil];
    }
    registerController.isFromRegister = @"Yes";
    if(appDelegate.boolLoginNotNow)
    {
        if(IsRunningTallPhone())
            registerController.view.frame=CGRectMake(320, 0, 320, 568);
        else
            registerController.view.frame=CGRectMake(320, 0, 320, 480);

        [[AppDelegate sharedDelegate].window addSubview:registerController.view];
        [UIView animateWithDuration:0.5
                              delay:0.0
                            options:1
                         animations:^{
                             if(IsRunningTallPhone())
                                 self->registerController.view.frame=CGRectMake(0, 0, 320, 568);
                             else
                                 self->registerController.view.frame=CGRectMake(0, 0, 320, 480);
                         }
                         completion:^(BOOL finished){}];
        
    }
    else
    {
        appDelegate.boolLogin=TRUE;
        [self.navigationController pushViewController:registerController animated:YES];
    }
}

#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    
   // keyboardControls.textFields = [NSArray arrayWithObjects:txtFieldEmail,txtFieldPassword, nil];
    
   //  keyboardControls.textFields = [NSArray arrayWithObjects:nil,nil, nil];
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"Previous";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"Next";
    
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] applicationFrame];
    
    CGFloat availableHeight = applicationFrame.size.height - 230; // Remove area covered by keyboard
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    [controls.activeTextField resignFirstResponder];
}

- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([keyboardControls.textFields containsObject:textField])
        keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark Forgot Password method

-(IBAction)btnForgotPasswordClicked
{

        sendForgotPasswordAlert = [[UIAlertView alloc] initWithTitle:@"" message:@"Please enter your email address" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Send", nil];
    
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        [sendForgotPasswordAlert setAlertViewStyle:UIAlertViewStylePlainTextInput];
        [sendForgotPasswordAlert show];
    }
    else{
        	txtForgotPassword = [[UITextField alloc] initWithFrame:CGRectMake(12.0, -35, 260.0, 25.0)];
        	[txtForgotPassword setBackgroundColor:[UIColor whiteColor]];
            txtForgotPassword.tag = 100;
        	CGAffineTransform myTrans = CGAffineTransformMakeTranslation(0.0, 80.0);
        	[txtForgotPassword setTransform:myTrans];
        	txtForgotPassword.delegate=self;
        	[txtForgotPassword setKeyboardType:UIKeyboardTypeEmailAddress];
        	[sendForgotPasswordAlert addSubview:txtForgotPassword];
            [txtForgotPassword becomeFirstResponder];
        	[sendForgotPasswordAlert show];
    }
}

#pragma mark Alert View delegate method
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        if (buttonIndex==1)
        {
            UITextField *filed = (UITextField*)[alertView textFieldAtIndex:0];
            filed.text  = [filed.text  stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceAndNewlineCharacterSet]];
            BOOL boolForgot = validateEmail(filed.text);
            if(filed.text == NULL || [filed.text length] == 0)
            {
                [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter your email address"];
                [filed becomeFirstResponder];
            }
            else if (!boolForgot)
            {
                [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter a valid email address"];
                [filed becomeFirstResponder];
            }
            else
            {
                if(isInternetAvailable())
                {
                    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
                    [service ForgotPasswordInvocation:filed.text  delegate:self];
                }
                else
                {
                    [Utils showAlertMessage:@"Twin Realty" Message:@"Internet connection is not available"];
                }
            }
        }
    }
    else if(alertView==sendForgotPasswordAlert)
    {
        if (buttonIndex==1)
        {
            txtForgotPassword.text  = [txtForgotPassword.text  stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            BOOL boolForgot = validateEmail(txtForgotPassword.text);
            if(txtForgotPassword.text == NULL || [txtForgotPassword.text length] == 0)
            {
                [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter your email address"];
                [txtForgotPassword becomeFirstResponder];
            }
            else if (!boolForgot)
            {
                [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter a valid email address"];
                [txtForgotPassword becomeFirstResponder];
            }
            else
            {
                if(isInternetAvailable())
                {
                    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
                    [service ForgotPasswordInvocation:txtForgotPassword.text  delegate:self];
                }
                else
                {
                    [Utils showAlertMessage:@"Twin Realty" Message:@"Internet connection is not available"];
                }
            }
        }
    }
}

#pragma mark Forgot Password delegate method
-(void)ForgotPasswordInvocationDidFinish:(ForgotPasswordInvocation*)invocation
                             withResults:(NSString*)result
                            withMessages:(NSString*)msg
                               withError:(NSError*)error
{
   [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
    if(!error){
        if(result==nil || result==(NSString*)[NSNull null])
        {
            [Utils showAlertMessage:@"Twin Realty" Message:msg];
        }
        else {
            [Utils showAlertMessage:@"Twin Realty" Message:result];
        }
    }
}

#pragma mark Login method
-(IBAction)btnRemrmberClicked:(id)sender
{
	if (boolKeepMeLogin)
    {
        appDelegate.isAutoLogin = FALSE;
		boolKeepMeLogin=FALSE;
		[btnRemember setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
	}
	else
	{
		boolKeepMeLogin=TRUE;
        appDelegate.isAutoLogin = TRUE;
		[btnRemember setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
	}
}

- (BOOL)loginValidationTxtFields
{
	userObj.strEmail = [txtFieldEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    userObj.strPassword=[txtFieldPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    BOOL flag = (validateEmail(userObj.strEmail));

    if(userObj.strEmail == NULL || [userObj.strEmail length] == 0)
    {
        boolLogin=TRUE;
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter your email address"];
		[txtFieldEmail becomeFirstResponder];
	}
    else if (!flag) {
        boolLogin=TRUE;
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter a valid email address"];
		[txtFieldEmail becomeFirstResponder];
	}
    else if(userObj.strPassword == NULL || [userObj.strPassword length] == 0)
    {
        boolLogin=TRUE;
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter your password"];
		[txtFieldPassword becomeFirstResponder];
    }
//    else if(userObj.strPassword.length<6)
//    {
//        boolLogin=TRUE;
//        [Utils showAlertMessage:@"Twin Realty" Message:@"Please re-enter your password"];
//		[txtFieldPassword becomeFirstResponder];
//    }
//    else if(userObj.strPassword.length>15)
//    {
//        boolLogin=TRUE;
//        [Utils showAlertMessage:@"Twin Realty" Message:@"Please re-enter your password"];
//		[txtFieldPassword becomeFirstResponder];
//    }
    
    else
    {
        boolLogin=FALSE;
    }
	return boolLogin;
}

-(IBAction)btnLoginClicked
{
    if(isInternetAvailable())
    {
        strDeviceToken = [[NSUserDefaults standardUserDefaults] valueForKey:@"devicetoken"];
        if ([strDeviceToken length]==0)
        {
            strDeviceToken=@"SampleDeviceToken";
        }
        BOOL boolVal =  [self loginValidationTxtFields];
        if(!boolVal)
        {
            [txtFieldEmail resignFirstResponder];
            [txtFieldPassword resignFirstResponder];
            [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
            [service LoginInvocation:txtFieldEmail.text password:txtFieldPassword.text  deviceToken:strDeviceToken deviceType:@"iphone" delegate:self];
        }
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Internet connection is not available"];
    }
}

-(IBAction)btnBackClicked
{
    [txtFieldEmail resignFirstResponder];
    [txtFieldPassword resignFirstResponder];
    if(appDelegate.boolLoginNotNow)
    {
        
        [UIView animateWithDuration:0.5
                              delay:0.0
                            options:1
                         animations:^{
                             
                             if (IS_IPHONE) {
                                 if(IsRunningTallPhone())
                                     self.view.frame=CGRectMake(0, 568, 320, 568);
                                 else
                                     self.view.frame=CGRectMake(0, 480, 320, 480);
                             } else {
                                 self.view.frame=CGRectMake(0, 1024, 768, 1024);
                             }
                             
                             
                         }completion:^(BOOL finished){}];
        [self dismissViewControllerAnimated:YES completion:nil];
       
        
        
    }
    else if(appDelegate.boolLogin)
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if(appDelegate.boolLoginPresent)
    {
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}

-(void)LoginInvocationDidFinish:(LoginInvocation*)invocation withResults:(NSString*)result withError:(NSError*)error
{
	if(!error)
    {
		if([result isEqualToString:@"success"])
        {
            if(appDelegate.boolLogin)
            {
                if(boolKeepMeLogin)
                {
                    [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:@"loginstatus"];
                    [[NSUserDefaults standardUserDefaults] setObject:userObj.strEmail forKey:@"email"];
                    [[NSUserDefaults standardUserDefaults] setObject:userObj.strPassword forKey:@"password"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    [self navigateToMapView];
                }
                else
                {
                    [self navigateToMapView];
                }
            }
            else if(appDelegate.boolLoginNotNow)
            {
                if (boolKeepMeLogin)
                {
                    [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:@"loginstatus"];
                    [[NSUserDefaults standardUserDefaults] setObject:userObj.strEmail forKey:@"email"];
                    [[NSUserDefaults standardUserDefaults] setObject:userObj.strPassword forKey:@"password"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    
                    if(appDelegate.boolLoginNotNow)
                    {
                        [UIView animateWithDuration:0.5
                                              delay:0.0
                                            options:1
                                         animations:^{
                                             
                                             if (IS_IPHONE) {
                                                 
                                                 if(IsRunningTallPhone())
                                                     self.view.frame=CGRectMake(0, 568, 320, 568);
                                                 else
                                                     self.view.frame=CGRectMake(0, 480, 320, 480);
                                             } else {
                                                 
                                                 self.view.frame=CGRectMake(0, 1024, 768, 1024);
                                             }
                                             
                                         }completion:^(BOOL finished){
                                
                                         }];
                        NSLog(@"%@",[AppDelegate sharedDelegate].sideBar);
                        [[AppDelegate sharedDelegate].sideBar loadData];
                    }
                }
                else
                {
                    if(appDelegate.boolLoginNotNow)
                    {
                        [UIView animateWithDuration:0.5
                                              delay:0.0
                                            options:1
                                         animations:^{
                                           
                                             if (IS_IPHONE) {
                                                 if(IsRunningTallPhone())
                                                     self.view.frame=CGRectMake(0, 568, 320, 568);
                                                 else
                                                     self.view.frame=CGRectMake(0, 480, 320, 480);
                                             } else {
                                                 
                                                 self.view.frame=CGRectMake(0, 1024, 768, 1024);
                                             }
                                             
                                         }completion:^(BOOL finished){}];
                       
                        NSLog(@"%@",[AppDelegate sharedDelegate].sideBar);
                        [[AppDelegate sharedDelegate].sideBar loadData];
                    }
                    
                }
            }
            else if(appDelegate.boolLoginPresent)
            {
                if (boolKeepMeLogin)
                {
                    [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:@"loginstatus"];
                    [[NSUserDefaults standardUserDefaults] setObject:userObj.strEmail forKey:@"email"];
                    [[NSUserDefaults standardUserDefaults] setObject:userObj.strPassword forKey:@"password"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    
                    if(appDelegate.boolLoginPresent)
                    {
                        [[AppDelegate sharedDelegate].sideBar loadData];
                        [self dismissViewControllerAnimated:YES completion:nil];
                    }
                }
                else
                {
                    if(appDelegate.boolLoginPresent)
                    {
                        [[AppDelegate sharedDelegate].sideBar loadData];
                        [self dismissViewControllerAnimated:YES completion:nil];
                    }
                }
            }
        }
        else
        {
            [[NSUserDefaults standardUserDefaults] setBool:FALSE forKey:@"loginstatus"];
            txtFieldEmail.text=@"";
            txtFieldPassword.text=@"";
        }
    }
   [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
}

-(void)navigateToMapView
{
    if (IS_IPHONE) {
        
        MainViewController *main = [[MainViewController alloc] initWithNibName:@"MainViewController_iPhone" bundle:nil];
        [self.navigationController pushViewController:main animated:YES];
        
    } else {
        
        MainViewController *main = [[MainViewController alloc] initWithNibName:@"MainViewController_iPad" bundle:nil];
        [self.navigationController pushViewController:main animated:YES];
    }
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
