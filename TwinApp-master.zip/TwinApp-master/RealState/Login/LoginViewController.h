//
//  LoginViewController.h
//  RealState
//
//  Created by Kapil Goyal on 27/08/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "User.h"
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "LoginInvocation.h"
#import "RealEstateService.h"
#import "BSKeyboardControls.h"
#import "RegisterViewController.h"
#import "ForgotPasswordInvocation.h"
#import "REWebService.h"

#import "JTRevealSidebarV2Delegate.h"
#import "UIViewController+JTRevealSidebarV2.h"
#import "UINavigationItem+JTRevealSidebarV2.h"

@interface LoginViewController : UIViewController<BSKeyboardControlsDelegate,UITextFieldDelegate, LoginInvocationDelegate, ForgotPasswordInvocationDelegate, UIAlertViewDelegate>
{
    User *userObj;
    AppDelegate *appDelegate;
    RealEstateService *service;
    BSKeyboardControls *keyboardControls;
    

    IBOutlet UIImageView *imgHeaderView;
    IBOutlet UIButton *btnBack;
    IBOutlet UILabel *lblName;
    IBOutlet UITextField *txtFieldEmail;
    IBOutlet UITextField *txtFieldPassword;
    IBOutlet UIButton *btnRemember;
    IBOutlet UIView *viewForgot;
    
    UIAlertView *sendForgotPasswordAlert;
    UITextField *txtForgotPassword;
    NSArray *arrRegisterField;
    NSString *strDeviceToken;
    
    BOOL boolKeepMeLogin;
    BOOL boolLogin;
    RegisterViewController *registerController;
    
}
-(IBAction)btnBackClicked;
-(IBAction)btnLoginClicked;
-(IBAction)btnRemrmberClicked:(id)sender;
-(IBAction)btnForgotPasswordClicked;
-(IBAction)btnRegisterClicked;
@property (nonatomic,strong) UIWindow *window;
@property (nonatomic,strong) SidebarViewController *leftSidebarViewController;

@end

