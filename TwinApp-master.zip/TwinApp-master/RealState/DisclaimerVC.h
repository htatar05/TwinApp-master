//  DisclaimerVC.h
//  RealEstate_App
//  Created by Octal on 13/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.


#import <UIKit/UIKit.h>
#import "AppDelegate.h"


@interface DisclaimerVC : UIViewController<UITableViewDelegate, UITableViewDataSource>
{

    IBOutlet UITableView *myTable;
    IBOutlet UITextView *defaultText;
    AppDelegate *appdelegate;
}

@property (nonatomic,retain) NSMutableArray *dataArray;
@property (nonatomic,retain) NSArray *feedArray;
@property (nonatomic,retain) NSString *defaultDisclaimer;
@property (nonatomic,retain) NSString *isCountAvail;

@end
