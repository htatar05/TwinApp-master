//  SavedSearchPropertyViewController.m
//  RealState
//  Created by Kapil Goyal on 14/11/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "AddShowingViewController.h"
#import "PropertySavedSearchTvCellView.h"
#import <QuartzCore/QuartzCore.h>
#import "Utils.h"
#import "REWebService.h"
#import "MBProgressHUD.h"

@interface AddShowingViewController ()
@end

@implementation AddShowingViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    fromTime.hidden = YES;
    ToTime.hidden = YES;
    appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    if(IsRunningTallPhone())
    {
        [self.view setFrame:CGRectMake(0, 0, 320, 568)];
        [scrlView setFrame:CGRectMake(0, 44, 320, 475)];
        [imgSep1 setFrame:CGRectMake(0, 518, 320, 1)];
        [btnAdd setFrame:CGRectMake(129, 528, 62, 30)];
        
    }
    else
    {
        [self.view setFrame:CGRectMake(0, 0, 320, 480)];
        [scrlView setFrame:CGRectMake(0, 44, 320, 383)];
        [imgSep1 setFrame:CGRectMake(0, 427, 320, 1)];
        [btnAdd setFrame:CGRectMake(129, 438, 62, 30)];
    }
    
    if (!IS_IPHONE) {
        
        [self.view setFrame:CGRectMake(0, 0, 768, 1024)];
        [scrlView setFrame:CGRectMake(224, 60, 320, 367)];
        [imgSep1 setFrame:CGRectMake(224, 427, 320, 1)];
        [btnAdd setFrame:CGRectMake(360, 438, 62, 30)];
    }
    
    [imgBackground setFrame:CGRectMake(0, 0, 320, 190)];
    imgView1 = [[UIImageView alloc] init];
    imgView1.backgroundColor = [UIColor clearColor];
    imgView1.frame = CGRectMake(10, 45, 297, 40);
    imgView1.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    imgView1.layer.borderWidth=0.75;
    imgView1.image = [UIImage imageNamed:@"drop_dwn.png"];
    
//    if (!IS_IPHONE) {
//        
//        
//        [imgBackground setFrame:CGRectMake(224, 0, 320, 190)];
//        imgView1 = [[UIImageView alloc] init];
//        imgView1.backgroundColor = [UIColor redColor];
//        imgView1.frame = CGRectMake(10, 45, 297, 40);
//        imgView1.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
//        imgView1.layer.borderWidth=0.75;
//        imgView1.image = [UIImage imageNamed:@"drop_dwn.png"];
//        
//    }
    [scrlView addSubview:imgView1];
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        txtFieldDate = [[UITextField alloc] initWithFrame:CGRectMake(19, 51, 280, 30)];
        selectDate   = [[UIButton alloc] initWithFrame:CGRectMake(19, 51, 280, 30)];
        
    }
    else
    {
        txtFieldDate = [[UITextField alloc] initWithFrame:CGRectMake(19, 54, 280, 30)];
        selectDate   = [[UIButton alloc] initWithFrame:CGRectMake(19, 54, 280, 30)];
    }
    [selectDate addTarget:self action:@selector(setDate) forControlEvents:UIControlEventTouchUpInside];
    txtFieldDate.tag = 100;
    txtFieldDate.userInteractionEnabled = NO;
    txtFieldDate.backgroundColor = [UIColor clearColor];
    txtFieldDate.font = [UIFont fontWithName:@"Helvetica" size:16.0];
    txtFieldDate.placeholder=@"Select Showing Date";
    [txtFieldDate setValue:[UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    txtFieldDate.delegate =self;
    txtFieldDate.textColor = [UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0];
    [scrlView addSubview:txtFieldDate];
    [scrlView addSubview:selectDate];
    
    imgView2 = [[UIImageView alloc] init];
    imgView2.backgroundColor = [UIColor clearColor];
    imgView2.frame = CGRectMake(10, 94, 297, 40);
    imgView2.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    imgView2.layer.borderWidth=0.75;
    imgView2.image = [UIImage imageNamed:@"input.png"];
    [scrlView addSubview:imgView2];
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        txtFieldPropertyId = [[UITextField alloc] initWithFrame:CGRectMake(19, 99, 280, 30)];
        txtFieldTime = [[UITextField alloc] initWithFrame:CGRectMake(19, 150, 280, 30)];
        selectTime = [[UIButton alloc] initWithFrame:CGRectMake(19, 150, 280, 30)];
    }
    else
    {
        txtFieldPropertyId = [[UITextField alloc] initWithFrame:CGRectMake(19, 102, 280, 30)];
        txtFieldTime = [[UITextField alloc] initWithFrame:CGRectMake(19, 153, 280, 30)];
        selectTime = [[UIButton alloc] initWithFrame:CGRectMake(19, 153, 280, 30)];
    }
    [selectTime addTarget:self action:@selector(setTime) forControlEvents:UIControlEventTouchUpInside];
    
    txtFieldPropertyId.tag = 200;
    txtFieldPropertyId.backgroundColor = [UIColor clearColor];
    txtFieldDate.font = [UIFont fontWithName:@"Helvetica" size:16.0];
    txtFieldPropertyId.placeholder = @"Enter Property Id";
    [txtFieldPropertyId setValue:[UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    txtFieldPropertyId.delegate=self;
    txtFieldPropertyId.textColor = [UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0];
    [scrlView addSubview:txtFieldPropertyId];
    
    txtFieldTime.userInteractionEnabled = NO;
    txtFieldTime.tag = 300;
    txtFieldTime.backgroundColor = [UIColor clearColor];
    txtFieldTime.font = [UIFont fontWithName:@"Helvetica" size:16.0];
    txtFieldTime.placeholder = @"Select Time";
    [txtFieldTime setValue:[UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    txtFieldTime.delegate=self;
    txtFieldTime.textColor = [UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0];
    
    imgView3 = [[UIImageView alloc] init];
    imgView3.backgroundColor = [UIColor clearColor];
    imgView3.frame = CGRectMake(10, 145, 297, 40);
    imgView3.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    imgView3.layer.borderWidth=0.75;
    imgView3.image = [UIImage imageNamed:@"input.png"];
    
    [scrlView addSubview:imgView3];
    [scrlView addSubview:txtFieldTime];
    [scrlView addSubview:selectTime];
    imgSep = [[UIImageView alloc] init];
    imgSep.backgroundColor = [UIColor clearColor];
    imgSep.frame = CGRectMake(0, 190, 320, 1);
    imgSep.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    imgSep.layer.borderWidth=0.75;
    imgSep.image = [UIImage imageNamed:@"sep.png"];
    [scrlView addSubview:imgSep];
    [self addKeyboardControls];
    [self setDate];
    dateView.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, 260);
    [self.view addSubview:dateView];
    lblClientName.text = self.strClientName;
    lblClientName.backgroundColor = [UIColor clearColor];
    [scrlView addSubview:lblClientName];
    txtFieldPropertyId.keyboardType = UIKeyboardTypeNumberPad;
}


-(void)setTime
{
    [txtFieldPropertyId resignFirstResponder];
    pickerType = @"Time";
    lblPickerTitle.text = @"Select Time :";
    fromTime.hidden = NO;
    ToTime.hidden = NO;
    datePicker.hidden = YES;
    datePicker.date = [NSDate date];
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    dateView.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
    [UIView commitAnimations];
    [self.view addSubview:dateView];
    [dateView bringSubviewToFront:self.view];
}
-(IBAction)btnBackClicked
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnAddClicked
{
    if ([txtFieldDate.text length]==0)
    {
        [Utils showAlertMessage:@"" Message:@"Please fill date"];
    }
    else if ([txtFieldPropertyId.text length]==0)
    {
        [Utils showAlertMessage:@"" Message:@"Please fill property id"];
    }
    else if ([txtFieldTime.text length]==0)
    {
         [Utils showAlertMessage:@"" Message:@"Please select time"];
    }
    else
    {
        NSMutableArray *array  = [[NSMutableArray alloc]init];
        NSMutableArray *dateArr  = [[NSMutableArray alloc]init];
        NSMutableArray *timeArr  = [[NSMutableArray alloc]init];
        NSMutableArray *propertyIdArr  = [[NSMutableArray alloc]init];
        for(UIView *view in [scrlView subviews])
        {
            if ([view isKindOfClass:[UITextField class]]){
                UITextField *textField = (UITextField *)view;
                if (textField.tag == 100)
                {
                    [dateArr addObject:textField.text];
                }
                else if (textField.tag == 200)
                {
                    [propertyIdArr addObject:textField.text];
                }
                else{
                    [timeArr addObject:textField.text];
                
                }
            }
        }
        for (NSInteger i= 0; i<dateArr.count; i++) {
            NSDictionary *dict = [[NSMutableDictionary alloc]init];
            NSString *myString = [dateArr objectAtIndex:i];
            NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
            dateFormatter.dateFormat = @"MMM dd, yyyy";
            NSDate *yourDate = [dateFormatter dateFromString:myString];
            dateFormatter.dateFormat = @"yyyy-MM-dd";
            NSLog(@"%@",[dateFormatter stringFromDate:yourDate]);
           
            [dict setValue:[dateFormatter stringFromDate:yourDate] forKey:@"date"];
            [dict setValue:[propertyIdArr objectAtIndex:i] forKey:@"property_id"];
            [dict setValue:[timeArr objectAtIndex:i] forKey:@"time"];
            [array addObject:dict];
        }
        
        NSLog(@"%@",array);
        [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
        NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
        [dataDict setValue:self.strClientId forKey:@"client_id"];
        [dataDict setValue:array forKey:@"showing_data"];
        [REWebService addShowingWithData:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
            NSLog(@"%@",dictResult);
            if (!error) {
                
                if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]) {
                    
                     [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                    [self.navigationController popViewControllerAnimated:YES];
                    
                } else {
                    
                    [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                }
            }
            
        }];
        
        //save_showing_add
        //client_id
        //showing_data
        
    }
   
}

-(IBAction)btnAddMoreClicked
{
    [txtFieldDate resignFirstResponder];
    [txtFieldPropertyId resignFirstResponder];
    if ([txtFieldDate.text length]==0)
    {
        [Utils showAlertMessage:@"" Message:@"Please fill date"];
        
    }
    else if ([txtFieldPropertyId.text length]==0)
    {
        [Utils showAlertMessage:@"" Message:@"Please fill property id"];
    }
    else {
        /*
        count++;
        [imgBackground setFrame:CGRectMake(0, 0, 320, 147+(114*count))];
        [btnAddMore setFrame:CGRectMake(70, 170+(114*count), 177, 40)];
        imgView1 = [[UIImageView alloc] init];
        imgView1.backgroundColor = [UIColor clearColor];
        imgView1.frame = CGRectMake(10, 45+(114*count), 297, 40);
        imgView1.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
        imgView1.layer.borderWidth=0.75;
        imgView1.image = [UIImage imageNamed:@"drop_dwn.png"];
        [scrlView addSubview:imgView1];
        if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
        {
            txtFieldDate = [[UITextField alloc] initWithFrame:CGRectMake(19, 51+(114*count), 280, 30)];
            selectDate = [[UIButton alloc] initWithFrame:CGRectMake(19, 51+(114*count), 280, 30)];
        }
        else
        {
            txtFieldDate = [[UITextField alloc] initWithFrame:CGRectMake(19, 54+(114*count), 280, 30)];
            selectDate   = [[UIButton alloc] initWithFrame:CGRectMake(19, 54+(114*count), 280, 30)];
        }
        [selectDate addTarget:self action:@selector(setDate) forControlEvents:UIControlEventTouchUpInside];
        [scrlView bringSubviewToFront:selectDate];
        [scrlView addSubview:selectDate];
        
        txtFieldDate.tag = 100;
        txtFieldDate.userInteractionEnabled = NO;
        txtFieldDate.backgroundColor = [UIColor clearColor];
        txtFieldDate.font = [UIFont fontWithName:@"Helvetica" size:16.0];
        txtFieldDate.placeholder=@"Select Showing Date and Time";
        [txtFieldDate setValue:[UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
        txtFieldDate.delegate =self;
        txtFieldDate.textColor = [UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0];
        [scrlView addSubview:txtFieldDate];
        imgView2 = [[UIImageView alloc] init];
        imgView2.backgroundColor = [UIColor clearColor];
        imgView2.frame = CGRectMake(10, 94+(114*count), 297, 40);
        imgView2.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
        imgView2.layer.borderWidth=0.75;
        imgView2.image = [UIImage imageNamed:@"input.png"];
        [scrlView addSubview:imgView2];
        if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
            txtFieldPropertyId = [[UITextField alloc] initWithFrame:CGRectMake(19, 99+(114*count), 280, 30)];
        else
            txtFieldPropertyId = [[UITextField alloc] initWithFrame:CGRectMake(19, 102+(114*count), 280, 30)];
        
        txtFieldPropertyId.tag = 200;
        txtFieldPropertyId.backgroundColor = [UIColor clearColor];
        txtFieldDate.font = [UIFont fontWithName:@"Helvetica" size:16.0];
        txtFieldPropertyId.placeholder = @"Enter Property Id";
        [txtFieldPropertyId setValue:[UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
        txtFieldPropertyId.delegate=self;
        txtFieldPropertyId.textColor = [UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0];
        [scrlView addSubview:txtFieldPropertyId];
        
        imgSep = [[UIImageView alloc] init];
        imgSep.backgroundColor = [UIColor clearColor];
        imgSep.frame = CGRectMake(0, 147+(114*count), 320, 1);
        imgSep.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
        imgSep.layer.borderWidth=0.75;
        imgSep.image = [UIImage imageNamed:@"sep.png"];
        [scrlView addSubview:imgSep];
        
        if(count==1)
            [scrlView setContentSize:CGSizeMake(320, 383+50)];
        
        if(count>=2)
            [scrlView setContentSize:CGSizeMake(320, 383+115*(count-1))];
        [self addKeyboardControls];
        */
        [self checkPropertyIdExistInDb];
    }
    
    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
-(void)textFieldDidBeginEditing:(UITextField *)textField {
    //Keyboard becomes visible
    
    if (IS_IPHONE) {
        scrlView.frame = CGRectMake(scrlView.frame.origin.x,
                                    scrlView.frame.origin.y,
                                    scrlView.frame.size.width,
                                    scrlView.frame.size.height - 315 + 65);
        
    }
    
}

-(void)textFieldDidEndEditing:(UITextField *)textField {
    //keyboard will hide
    if (IS_IPHONE) {
        scrlView.frame = CGRectMake(scrlView.frame.origin.x,
                                    scrlView.frame.origin.y,
                                    scrlView.frame.size.width,
                                    scrlView.frame.size.height + 315 - 65);
    }
    
}

#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    
    keyboardControls.textFields = [NSArray arrayWithObjects:txtFieldDate,txtFieldPropertyId, nil];
    
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"";
    [keyboardControls hidePrevNextButtons:YES];
    
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] bounds];
    
    CGFloat availableHeight = applicationFrame.size.height - 230;
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    
}
- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([keyboardControls.textFields containsObject:textField])
        keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
-(void)setDate
{
    [txtFieldPropertyId resignFirstResponder];
    pickerType = @"Date";
    fromTime.hidden = YES;
    ToTime.hidden = YES;
    lblPickerTitle.text = @"Select Date:";
    datePicker.datePickerMode = UIDatePickerModeDate;
    datePicker.hidden = NO;
    datePicker.date = [NSDate date];
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    dateView.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
    [UIView commitAnimations];
    [self.view addSubview:dateView];
    [dateView bringSubviewToFront:self.view];
}

-(IBAction)cancelDatePicker:(id)sender
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    dateView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
    [UIView commitAnimations];
}
-(IBAction)doneDatePicker:(id)sender
{
    if ([pickerType isEqualToString:@"Date"])
    {
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        df.dateStyle = NSDateFormatterMediumStyle;
        NSLog(@"my date---%@",[df stringFromDate:datePicker.date]);
        txtFieldDate.text = [NSString stringWithFormat:@"%@",[df stringFromDate:datePicker.date]];
    }
    else
    {
        NSDateFormatter *df = [[NSDateFormatter alloc] init];
        df.dateStyle = NSDateFormatterMediumStyle;
        NSLog(@"my time 1---%@",[df stringFromDate:fromTime.date]);
        NSLog(@"my time 2---%@",[df stringFromDate:ToTime.date]);
        NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
        [outputFormatter setDateFormat:@"HH:mm"];
        NSString *fromTim = [outputFormatter stringFromDate:fromTime.date];
        NSString *toTime = [outputFormatter stringFromDate:ToTime.date];
        NSLog(@"%@ and %@",fromTim,toTime);
        txtFieldTime.text = [NSString stringWithFormat:@"%@ to %@",fromTim,toTime];
    }
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    dateView.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
    [UIView commitAnimations];
}

-(void)checkPropertyIdExistInDb
{
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:txtFieldPropertyId.text forKey:@"property_id"];
    [REWebService checkPropertyIdExistInDb:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
        if (!error){
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]){
                count++;
                [imgBackground setFrame:CGRectMake(0, 0, 320, 157+(190*count))];
                [btnAddMore setFrame:CGRectMake(70, 170+(190*count), 177, 40)];
                imgView1 = [[UIImageView alloc] init];
                imgView1.backgroundColor = [UIColor clearColor];
                imgView1.frame = CGRectMake(10, 14+(190*count), 297, 40);
                imgView1.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
                imgView1.layer.borderWidth=0.75;
                imgView1.image = [UIImage imageNamed:@"drop_dwn.png"];
                [scrlView addSubview:imgView1];
                if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
                {
                    txtFieldDate = [[UITextField alloc] initWithFrame:CGRectMake(19, 19+(190*count), 280, 30)];
                    selectDate = [[UIButton alloc] initWithFrame:CGRectMake(19, 19+(190*count), 280, 30)];
                }
                else
                {
                    txtFieldDate = [[UITextField alloc] initWithFrame:CGRectMake(19, 22+(190*count), 280, 30)];
                    selectDate   = [[UIButton alloc] initWithFrame:CGRectMake(19, 22+(190*count), 280, 30)];
                }
                [selectDate addTarget:self action:@selector(setDate) forControlEvents:UIControlEventTouchUpInside];
                [scrlView bringSubviewToFront:selectDate];
                [scrlView addSubview:selectDate];
                
                txtFieldDate.tag = 100;
                txtFieldDate.userInteractionEnabled = NO;
                txtFieldDate.backgroundColor = [UIColor clearColor];
                txtFieldDate.font = [UIFont fontWithName:@"Helvetica" size:16.0];
                txtFieldDate.placeholder=@"Select Showing Date";
                [txtFieldDate setValue:[UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
                txtFieldDate.delegate =self;
                txtFieldDate.textColor = [UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0];
                [scrlView addSubview:txtFieldDate];
                imgView2 = [[UIImageView alloc] init];
                imgView2.backgroundColor = [UIColor clearColor];
                imgView2.frame = CGRectMake(10, 62+(190*count), 297, 40);
                imgView2.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
                imgView2.layer.borderWidth=0.75;
                imgView2.image = [UIImage imageNamed:@"input.png"];
                [scrlView addSubview:imgView2];
                
                if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
                {
                    txtFieldTime = [[UITextField alloc] initWithFrame:CGRectMake(19, 115+(190*count), 280, 30)];
                    selectTime = [[UIButton alloc] initWithFrame:CGRectMake(19, 115+(190*count), 280, 30)];
                }
                else
                {
                    txtFieldTime = [[UITextField alloc] initWithFrame:CGRectMake(19, 118+(190*count), 280, 30)];
                    selectTime   = [[UIButton alloc] initWithFrame:CGRectMake(19, 118+(190*count), 280, 30)];
                }
                
                [selectTime addTarget:self action:@selector(setTime) forControlEvents:UIControlEventTouchUpInside];
                [scrlView bringSubviewToFront:selectTime];
                [scrlView addSubview:selectTime];
                
                txtFieldTime.tag = 300;
                txtFieldTime.userInteractionEnabled = NO;
                txtFieldTime.backgroundColor = [UIColor clearColor];
                txtFieldTime.font = [UIFont fontWithName:@"Helvetica" size:16.0];
                txtFieldTime.placeholder=@"Select Time";
                [txtFieldTime setValue:[UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
                txtFieldTime.delegate =self;
                txtFieldTime.textColor = [UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0];
                
                imgView3 = [[UIImageView alloc] init];
                imgView3.backgroundColor = [UIColor clearColor];
                imgView3.frame = CGRectMake(10, 110+(190*count), 297, 40);
                imgView3.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
                imgView3.layer.borderWidth=0.75;
                imgView3.image = [UIImage imageNamed:@"input.png"];
                [scrlView addSubview:imgView3];
                [scrlView addSubview:txtFieldTime];
                
                
                
                if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
                    txtFieldPropertyId = [[UITextField alloc] initWithFrame:CGRectMake(19, 68+(190*count), 280, 30)];
                else
                    txtFieldPropertyId = [[UITextField alloc] initWithFrame:CGRectMake(19, 71+(190*count), 280, 30)];
                
                txtFieldPropertyId.tag = 200;
                txtFieldPropertyId.backgroundColor = [UIColor clearColor];
                txtFieldDate.font = [UIFont fontWithName:@"Helvetica" size:16.0];
                txtFieldPropertyId.placeholder = @"Enter Property Id";
                [txtFieldPropertyId setValue:[UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
                txtFieldPropertyId.delegate=self;
                txtFieldPropertyId.textColor = [UIColor colorWithRed:140/255.0 green:140/255.0 blue:140/255.0 alpha:1.0];
                [scrlView addSubview:txtFieldPropertyId];
                
                imgSep = [[UIImageView alloc] init];
                imgSep.backgroundColor = [UIColor clearColor];
                imgSep.frame = CGRectMake(0, 157+(190*count), 320, 1);
                imgSep.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
                imgSep.layer.borderWidth=0.75;
                imgSep.image = [UIImage imageNamed:@"sep.png"];
                [scrlView addSubview:imgSep];
                
                if(count==1)
                    [scrlView setContentSize:CGSizeMake(320, 383+50)];
                
                if(count>=2)
                 [scrlView setContentSize:CGSizeMake(320, 383+190*(count))];
                [self addKeyboardControls];
                
//                9905040
//                9905036
//                80206413
//                80204091
                
            }
            else
            {
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
            
            }
            
        }else{
            
            
        }
        
        
    }];
    
    
    
}
@end
