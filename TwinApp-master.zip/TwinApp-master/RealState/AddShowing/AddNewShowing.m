//  AddNewShowing.m
//  RealEstate_App
//  Created by Octal on 11/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import "AddNewShowing.h"
#import "Utils.h"
#import "MBProgressHUD.h"
#import "REWebService.h"

@interface AddNewShowing ()

@end

@implementation AddNewShowing

- (void)viewDidLoad {
    [super viewDidLoad];
    [myPicker setDelegate:self];
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    viewSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
    [self.view addSubview:viewSelect];
    strCheck = @"manager";
    
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:@"1" forKey:@"role_id"];
    [dataDict setValue:@"1" forKey:@"admin_id"];
    [self getUserRelatedData:dataDict];
    [self selectDate:nil];
    dateSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, 260);
    [self.view addSubview:dateSelect];
}

-(void)viewWillAppear:(BOOL)animated
{
   [myScroll setContentSize:CGSizeMake(MIN([[UIScreen mainScreen] bounds].size.width, myScroll.frame.size.width), myScroll.contentSize.height+120)];
    [myScroll setContentSize:CGSizeMake(320, 1200)];

}


- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
    
}
-(IBAction)backButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)fillDetails:(id)sender
{
   
    if ([sender tag]==100) {
        strCheck = @"manager";
        NSLog(@"manager");
        
    }
    else if([sender tag]==200)
    {
        NSLog(@"agent");
        strCheck = @"agent";
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setValue:@"2" forKey:@"role_id"];
        [dict setValue:mangerId forKey:@"manager_id"];
        [self getUserRelatedData:dict];
    }
    else if([sender tag]==300)
    {
        NSLog(@"agent");
        strCheck = @"client";

    }
    
    lblPickerTitle.text = @"Square Feet";
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
    [UIView commitAnimations];
    myPicker.tag=1;
    [myPicker reloadInputViews];
    [myPicker reloadAllComponents];
    [myPicker selectRow:0 inComponent:0 animated:YES];
    [self.view addSubview:viewSelect];
    [viewSelect bringSubviewToFront:self.view];

}


#pragma mark UIPicker view
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView;
{
  return 1;
}


- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
    
    return self.view.frame.size.width;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;
{
    if ([strCheck isEqualToString:@"manager"])
    {
       return managerData.count;
    }
    else if([strCheck isEqualToString:@"agent"])
    {
        return agentData.count;
    }
    else
    {
        return clientData.count;
    }
    return 1;
    
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if ([strCheck isEqualToString:@"manager"])
    {
        strSelectedManger = [[managerData objectAtIndex:row]valueForKey:@"user_name"];
        mangerId = [[managerData objectAtIndex:row]valueForKey:@"user_id"];
        
    }
    else if ([strCheck isEqualToString:@"agent"])
    {
        strSelectedAgent = [[agentData objectAtIndex:row]valueForKey:@"user_name"];
        agentId = [[agentData objectAtIndex:row]valueForKey:@"user_id"];
    }
    else
    {
        strSelectedClient = [[clientData objectAtIndex:row]valueForKey:@"user_name"];
        clientId = [[clientData objectAtIndex:row]valueForKey:@"user_id"];
    
    }
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component;
{
   
    if ([strCheck isEqualToString:@"manager"])
    {
        return [[managerData objectAtIndex:row] valueForKey:@"user_name"];
        
        
    }
    else if ([strCheck isEqualToString:@"agent"])
    {
        return [[agentData objectAtIndex:row] valueForKey:@"user_name"];
    }
    else
    {
         return [[clientData objectAtIndex:row] valueForKey:@"user_name"];
    
    }
    
    
}

-(IBAction)btnPickerDoneClicked:(id)sender
{
    if ([strCheck isEqualToString:@"manager"])
    {
        
       txtManager.text = strSelectedManger;
        
    }
    else if ([strCheck isEqualToString:@"agent"])
    {
        NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
        [param setValue:@"3" forKey:@"role_id"];
        [param setValue:agentId forKey:@"agent_id"];
        txtAgent.text = strSelectedAgent;
        strCheck = @"client";
        [self getUserRelatedData:param];
    }
    else
    {
        txtClient.text = strSelectedClient;
    }
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
    [UIView commitAnimations];
   
    
}

-(IBAction)btnCancelClicked:(id)sender
{
    if ([sender tag]==1)
    {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        viewSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
        [UIView commitAnimations];
    }
    else
    {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        viewSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
        [UIView commitAnimations];
    }
}

-(void)getUserRelatedData:(NSMutableDictionary *)dataDict
{
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    [REWebService userRelatedShowingData:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self->appDelegate.window animated:YES];
    if (!error){
        
        if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]) {
            
            NSLog(@"%@",dictResult);
            if ([self->strCheck isEqualToString:@"manager"])
            {
                self->managerData = [[NSMutableArray alloc]init];
                NSArray *temp = [[dictResult valueForKey:@"response"] valueForKey:@"data"];
                [self->managerData addObjectsFromArray:temp];
                
            }
            else if ([self->strCheck isEqualToString:@"agent"])
            {
                self->agentData = [[NSMutableArray alloc]init];
                NSArray *temp = [[dictResult valueForKey:@"response"] valueForKey:@"data"];
                [self->agentData addObjectsFromArray:temp];
            }
            else
            {
                self->clientData = [[NSMutableArray alloc]init];
                NSArray *temp = [[dictResult valueForKey:@"response"] valueForKey:@"data"];
                [self->clientData addObjectsFromArray:temp];
            }
            [self->myPicker reloadInputViews];
            [self->myPicker reloadAllComponents];
            [self->myPicker selectRow:0 inComponent:0 animated:YES];
            
        }
        else
        {
            [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
        }
        
    }
        
    }];
    

}



-(IBAction)selectDate:(id)sender
{
    checkVal = @"date";
    datePicker.datePickerMode = UIDatePickerModeDate;
    datePicker.hidden = NO;
    datePicker.date = [NSDate date];
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    dateSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
    [UIView commitAnimations];
    [self.view addSubview:dateSelect];
    [dateSelect bringSubviewToFront:self.view];
}

-(IBAction)cancelDatePicker:(id)sender
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    dateSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
    [UIView commitAnimations];
}
-(IBAction)doneDatePicker:(id)sender
{
    NSDateFormatter *df = [[NSDateFormatter alloc] init];
    df.dateStyle = NSDateFormatterMediumStyle;
    NSLog(@"my date---%@",[df stringFromDate:datePicker.date]);
    if ([checkVal isEqualToString:@"date"])
    {
        txtDate.text = [NSString stringWithFormat:@"%@",[df stringFromDate:datePicker.date]];
    }
    else if ([checkVal isEqualToString:@"fromTime"])
    {
        
        NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
        [outputFormatter setDateFormat:@"h:mm a"];
        txtFromTime.text= [outputFormatter stringFromDate:datePicker.date];
        
    }
    else if ([checkVal isEqualToString:@"toTime"])
    {
        NSDateFormatter *outputFormatter = [[NSDateFormatter alloc] init];
        [outputFormatter setDateFormat:@"h:mm a"];
         txtToTime.text = [outputFormatter stringFromDate:datePicker.date];
    }
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    dateSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
    [UIView commitAnimations];
}
-(IBAction)selectFromTime:(id)sender
{
    if ([sender tag]==400) {
        checkVal = @"fromTime";
    }
    else if ([sender tag]==500)
    {
      checkVal = @"toTime";
    }
    datePicker.datePickerMode = UIDatePickerModeTime;
    datePicker.hidden = NO;
    datePicker.date = [NSDate date];
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    dateSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
    [UIView commitAnimations];
    [self.view addSubview:dateSelect];
    [dateSelect bringSubviewToFront:self.view];
}

-(IBAction)submitButton:(id)sender
{
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    NSMutableDictionary *data = [[NSMutableDictionary alloc]init];
    [data setValue:clientId forKey:@"client_id"];
    [data setValue:txtDate.text forKey:@"date"];
    [data setValue:txtMls.text forKey:@"property_id"];
    [data setValue:txtFromTime.text forKey:@"time"];
    [data setValue:txtToTime.text forKey:@"to_time"];
    [data setValue:txtNote.text forKey:@"notes"];
    [REWebService addShowingWithData:data withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self->appDelegate.window animated:YES];
        if (!error) {
            
            [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
        }
        
        
        
    }];
    

}
-(IBAction)cancekButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
