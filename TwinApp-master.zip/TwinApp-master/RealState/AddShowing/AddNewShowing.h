//
//  AddNewShowing.h
//  RealEstate_App
//
//  Created by Octal on 11/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface AddNewShowing : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource>
{
    IBOutlet UIScrollView *myScroll;
    __weak IBOutlet UIView *viewSelect;
    __weak IBOutlet UIView *dateSelect;
    IBOutlet UIDatePicker *datePicker;
    IBOutlet UIPickerView *myPicker;
    IBOutlet UILabel *lblPickerTitle;
    AppDelegate *appDelegate;
    NSMutableArray *managerData;
    NSMutableArray *agentData;
    NSMutableArray *clientData;
    NSString *strCheck;
    NSString *mangerId;
    NSString *agentId;
    NSString *clientId;
    NSString *checkVal;
    
    IBOutlet UITextField *txtManager;
    IBOutlet UITextField *txtAgent;
    IBOutlet UITextField *txtClient;
    IBOutlet UITextField *txtDate;
    IBOutlet UITextField *txtFromTime;
    IBOutlet UITextField *txtToTime;
    IBOutlet UITextField *txtMls;
    IBOutlet UITextView  *txtNote;
    
    NSString *strSelectedManger;
    NSString *strSelectedAgent;
    NSString *strSelectedClient;
}

@end
