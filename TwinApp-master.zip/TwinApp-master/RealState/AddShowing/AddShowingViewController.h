//  SavedSearchPropertyViewController.h
//  RealState
//  Created by Kapil Goyal on 14/11/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import <UIKit/UIKit.h>
#import "BSKeyboardControls.h"
#import "AppDelegate.h"


@interface AddShowingViewController : UIViewController<BSKeyboardControlsDelegate,UIScrollViewDelegate,UITextFieldDelegate>
{
    IBOutlet UIScrollView *scrlView;
    IBOutlet UIImageView *imgBackground;
    UIImageView *imgView1;
    UIImageView *imgView2;
    UIImageView *imgView3;
    UITextField *txtFieldDate;
    UITextField *txtFieldPropertyId;
    UITextField *txtFieldTime;
    UIImageView *imgSep;
    UIButton *selectDate;
    UIButton *selectTime;
    int count;
    IBOutlet UIButton *btnAddMore;
    IBOutlet UIImageView *imgSep1;
    IBOutlet UIButton *btnAdd;
    BSKeyboardControls *keyboardControls;
    IBOutlet UIDatePicker *datePicker;
    IBOutlet UIDatePicker *fromTime;
    IBOutlet UIDatePicker *ToTime;
    IBOutlet UILabel *lblPickerTitle;
    AppDelegate *appDelegate;
    IBOutlet UILabel *lblClientName;
    IBOutlet UIView * dateView;
    NSString *pickerType;
    
}

@property (nonatomic,strong)NSString *strClientId;
@property (nonatomic,strong)NSString *strClientName;

-(IBAction)btnAddClicked;
-(IBAction)btnAddMoreClicked;
-(IBAction)btnBackClicked;

@end
