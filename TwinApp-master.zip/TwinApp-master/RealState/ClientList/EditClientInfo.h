//
//  EditClientInfo.h
//  RealEstate_App
//
//  Created by Octal on 29/12/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ClientDetail.h"
#import "AppDelegate.h"
#import "BSKeyboardControls.h"


@interface EditClientInfo : UIViewController<UITextFieldDelegate,BSKeyboardControlsDelegate>
{
  
  IBOutlet UIImageView *imgFName;
  IBOutlet UIImageView *imgLName;
  IBOutlet UIImageView *imgEmail;
  IBOutlet UIImageView *imgContact;
  IBOutlet UITextField *txtFName;
  IBOutlet UITextField *txtLName;
  IBOutlet UITextField *txtEmail;
  IBOutlet UITextField *txtContact;
  IBOutlet UIScrollView *scrlView;
  AppDelegate *appDelegate;
  BSKeyboardControls *keyboardControls;
  
    
}
@property(nonatomic,strong)ClientDetail *ClientDetail;

@end
