//
//  AgentListViewController.h
//  RealState
//
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "JTRevealSidebarV2Delegate.h"
#import "UIViewController+JTRevealSidebarV2.h"
#import "UINavigationItem+JTRevealSidebarV2.h"
#import "AppDelegate.h"
#import "ClientDetail.h"

#import "RealEstateService.h"
#import "AgentListDetailInvocation.h"
#import "AgentTvCellView.h"
#import "AgentDetailViewController.h"
#import "MBProgressHUD.h"
#import "Utils.h"

@interface ClientListViewController : UIViewController<UITableViewDelegate, UITableViewDataSource,JTRevealSidebarV2Delegate,ConnectedClientListDetailInvocationDelegate>
{
    IBOutlet UITableView *tblClientList;
    IBOutlet UIView *viewClientList;
    IBOutlet UIButton *btnNavigation;
    IBOutlet UIButton *btnAdd;
    IBOutlet UIButton *btnEdit;
    IBOutlet UIButton *btnEditClient;
    RealEstateService *service;
    AppDelegate *appDelegate;
    NSMutableArray *arrClientData;
    ClientDetail *clientDetail;
    
    int count;

}
@property (nonatomic, strong) SidebarViewController *leftSidebarViewController;

@end
