//
//  AgentListViewController.m
//  RealState
//
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "ClientListViewController.h"
#import "Config.h"
#import "EditClientInfo.h"


@interface ClientListViewController ()
@end

@implementation ClientListViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    self.navigationItem.revealSidebarDelegate=self;
    [btnNavigation addTarget:self action:@selector(revealLeftSidebar:) forControlEvents:UIControlEventTouchUpInside];
    
    service = [[RealEstateService alloc] init];
    arrClientData = [[NSMutableArray alloc] init];
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    if(IsRunningTallPhone())
    {
        [viewClientList setFrame:CGRectMake(0, 0, 320, 578)];
        //[tblClientList setFrame:CGRectMake(0, 44, 320, 518)];
    }
    else
    {
        [viewClientList setFrame:CGRectMake(0, 0, 320, 490)];
        //[tblClientList setFrame:CGRectMake(0, 44, 320, 428)];
    }
     tblClientList.allowsMultipleSelectionDuringEditing = YES;
}

-(void)viewWillAppear:(BOOL)animated
{
    btnEditClient.alpha=0.5;
    btnEditClient.userInteractionEnabled=FALSE;
    [tblClientList setEditing:NO animated:YES];
    [btnEdit setTitle:@"Edit" forState:UIControlStateNormal];
   
    [AppDelegate sharedDelegate].globalReference = nil;
    [AppDelegate sharedDelegate].globalReference = self.navigationController;
    if(isInternetAvailable())
    {
       [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
        [service ConnectedClientListDetailInvocation:@"1" delegate:self];
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Internet connection is not available"];
    }
}

-(void)ConnectedClientListDetailInvocationDidFinish:(ConnectedClientListDetailInvocation*)invocation
                              withResults:(NSMutableArray*)result
                             withMessages:(NSString*)msg
                                withError:(NSError*)error;
{
    [arrClientData removeAllObjects];
    [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
    if(!error)
    {
        if(result==nil || result==(NSArray*)[NSNull null])
        {
            [Utils showAlertMessage:@"Twin Realty" Message:msg];
        }
        else
        {
            if([result count]>0)
            {
                if([[[result objectAtIndex:0] objectForKey:@"message"] isEqualToString:@"failed"]){
                }
                else
                {
                    for (int i=0; i<[result count]; i++)
                    {
                        clientDetail = [[ClientDetail alloc] init];
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"client_id"]!=[NSNull null])
                            clientDetail.strId = [[result objectAtIndex:i] objectForKey:@"client_id"];
                        
//                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"client_name"]!=[NSNull null])
//                            clientDetail.strName = [[result objectAtIndex:i] objectForKey:@"client_name"];
                        
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"client_name"]!=[NSNull null])
                            clientDetail.strFName = [[result objectAtIndex:i] objectForKey:@"first_name"];
                        
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"client_name"]!=[NSNull null])
                            clientDetail.strLName = [[result objectAtIndex:i] objectForKey:@"last_name"];
                        
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"client_email"]!=[NSNull null])
                            clientDetail.strEmail = [[result objectAtIndex:i] objectForKey:@"client_email"];
                        
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"client_phone"]!=[NSNull null])
                            clientDetail.strPhoneNo = [[result objectAtIndex:i] objectForKey:@"client_phone"];
                        
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"client_address"]!=[NSNull null])
                            clientDetail.strAddress = [[result objectAtIndex:i] objectForKey:@"client_address"];
                        
                        if((NSNull*)[[result objectAtIndex:i] objectForKey:@"client_image"]!=[NSNull null])
                            clientDetail.strImage = [[result objectAtIndex:i] objectForKey:@"client_image"];
                        
                        clientDetail.strName = [NSString stringWithFormat:@"%@ %@",clientDetail.strFName,clientDetail.strLName];
                        
                        [arrClientData addObject:clientDetail];
                    }
                }
                [tblClientList reloadData];
            }
        }
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"error"];
    }
}

-(IBAction)btnEditClicked
{
    if([btnEdit.titleLabel.text isEqualToString:@"Edit"])
    {
        count = 0;
        [tblClientList setEditing:YES animated:YES];
        [btnEdit setTitle:@"Done" forState:UIControlStateNormal];
        btnAdd.hidden=YES;
        btnEditClient.hidden = NO;
        btnEditClient.alpha=0.5;
        btnEditClient.userInteractionEnabled=FALSE;
    }
    else
    {
        [btnEdit setTitle:@"Edit" forState:UIControlStateNormal];
        btnAdd.hidden=NO;
        btnEditClient.alpha=0.5;
        btnEditClient.userInteractionEnabled=FALSE;
        [tblClientList setEditing:NO animated:YES];
    }
}

#pragma mark JTRevealSidebarDelegate
- (void)revealLeftSidebar:(id)sender
{
    [self.navigationController toggleRevealState:JTRevealedStateLeft];
}

- (UIView *)viewForLeftSidebar{
    CGRect viewFrame = self.navigationController.applicationViewFrame;
    UITableViewController *controller = self.leftSidebarViewController;
    if (!controller)
    {
        self.leftSidebarViewController = [[SidebarViewController alloc] init];
        self.leftSidebarViewController.sidebarDelegate = [AppDelegate sharedDelegate];
        controller = self.leftSidebarViewController;
    }
    controller.view.frame = CGRectMake(0, viewFrame.origin.y, 270, viewFrame.size.height);
    controller.view.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
    return controller.view;
}


- (void)didChangeRevealedStateForViewController:(UIViewController *)viewController {
   
    if (viewController.revealedState == JTRevealedStateNo)
        tblClientList.userInteractionEnabled=YES;
    else
        tblClientList.userInteractionEnabled=NO;
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrClientData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    AgentTvCellView *cell = (AgentTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
          view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPhone" bundle:nil];
        } else {
            view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPad" bundle:nil];
        }
        cell = (AgentTvCellView *)view.view;
    }
  
    cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    
    if (IS_IPHONE) {
        cell.imgBackground.layer.borderWidth=0.5;
    } else {
        cell.imgBackground.layer.borderWidth=1.0;
    }
    cell.imgUserPhoto.backgroundColor = [UIColor clearColor];
    cell.imgBackground.layer.masksToBounds = true;
    cell.imgUserPhoto.layer.borderColor = [UIColor grayColor].CGColor;
    cell.imgUserPhoto.placeholderImage = [UIImage imageNamed:@"upload_pic"];
    clientDetail = [arrClientData objectAtIndex:indexPath.row];
    NSString *url = [NSString stringWithFormat:@"%@%@",WebserviceImageUrl,clientDetail.strImage];
    cell.imgUserPhoto.imageURL  = [NSURL URLWithString:url];
    cell.lblUserName.text = [NSString stringWithFormat:@"%@ %@",clientDetail.strFName,clientDetail.strLName];
    cell.lblUserEmailId.text = clientDetail.strEmail;
    cell.lblUserPhone.text = clientDetail.strPhoneNo;
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tblClientList.isEditing){
        count--;
    }
    [self updateSelectionCount];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (tblClientList.isEditing){
        count++;
        [self updateSelectionCount];
        
    }
    else
    {
        [tblClientList deselectRowAtIndexPath:indexPath animated:YES];
        AgentDetailViewController *agent;
        if (IS_IPHONE) {
           agent = [[AgentDetailViewController alloc] initWithNibName:@"AgentDetailViewController_iPhone" bundle:nil];
            
        } else {
            agent = [[AgentDetailViewController alloc] initWithNibName:@"AgentDetailViewController_iPad" bundle:nil];
        }
        
        agent.intType = 1;
        agent.agentDetail = [arrClientData objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:agent animated:YES];
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE) {
        return 100;
    } else {
        
        return 130;
    }
}

-(IBAction)editButtonClicked:(id)sender
{
    if (IS_IPHONE) {
        
        EditClientInfo *add = [[EditClientInfo alloc] initWithNibName:@"EditClientInfo" bundle:nil];
        add.ClientDetail = [arrClientData objectAtIndex:[tblClientList indexPathForSelectedRow].row];
        [self.navigationController pushViewController:add animated:YES];
        
    } else {
        
        EditClientInfo *add = [[EditClientInfo alloc] initWithNibName:@"EditClientInfo_iPad" bundle:nil];
        add.ClientDetail = [arrClientData objectAtIndex:[tblClientList indexPathForSelectedRow].row];
        [self.navigationController pushViewController:add animated:YES];
    }
    
}

-(void)updateSelectionCount
{
    if(count==0)
    {
        btnEditClient.alpha=0.5;
        btnEditClient.userInteractionEnabled=FALSE;
    }
    if(count>0)
    {
        btnEditClient.alpha=1.0;
        if(count==1)
        {
            btnEditClient.alpha=1.0;
            btnEditClient.userInteractionEnabled=TRUE;
        }
        else
        {
            btnEditClient.alpha=0.5;
            btnEditClient.userInteractionEnabled=FALSE;
        }
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
