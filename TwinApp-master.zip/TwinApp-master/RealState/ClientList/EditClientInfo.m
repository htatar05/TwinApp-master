//
//  EditClientInfo.m
//  RealEstate_App
//
//  Created by Octal on 29/12/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import "EditClientInfo.h"
#import "MBProgressHUD.h"
#import "REWebService.h"
#import "Utils.h"
#import "JSON.h"

@interface EditClientInfo ()

@end

@implementation EditClientInfo

- (void)viewDidLoad {
    [super viewDidLoad];
    
    imgFName.layer.borderColor = [UIColor colorWithRed:220/255.0 green:220/255.0 blue:220/255.0 alpha:1].CGColor;
    imgFName.layer.borderWidth=1.0;
    
    imgLName.layer.borderColor = [UIColor colorWithRed:220/255.0 green:220/255.0 blue:220/255.0 alpha:1].CGColor;
    imgLName.layer.borderWidth=1.0;
    
    imgEmail.layer.borderColor = [UIColor colorWithRed:220/255.0 green:220/255.0 blue:220/255.0 alpha:1].CGColor;
    imgEmail.layer.borderWidth=1.0;
    
    imgContact.layer.borderColor = [UIColor colorWithRed:220/255.0 green:220/255.0 blue:220/255.0 alpha:1].CGColor;
    imgContact.layer.borderWidth=1.0;
    NSLog(@"my detail %@",self.ClientDetail);
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    txtFName.text = self.ClientDetail.strFName;
    txtLName.text = self.ClientDetail.strLName;
    txtEmail.text = self.ClientDetail.strEmail;
    txtContact.text = self.ClientDetail.strPhoneNo;
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}

-(void)viewWillAppear:(BOOL)animated
{
//    [tb setEditing:NO animated:YES];
//    [btnEdit setTitle:@"Edit" forState:UIControlStateNormal];
}
-(IBAction)backButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)updateButtonClicked:(id)sender
{
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:txtFName.text forKey:@"first_name"];
    [dataDict setValue:txtLName.text forKey:@"last_name"];
    [dataDict setValue:txtEmail.text forKey:@"email"];
    [dataDict setValue:txtContact.text forKey:@"phone"];
    [dataDict setValue:self.ClientDetail.strId forKey:@"id"];
     NSLog(@"[bodyD JSONRepresentation]:%@",[dataDict JSONRepresentation]);
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    [REWebService editConnectedClient:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
    [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
        
         if (!error) {
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]) {
                
                [self.navigationController popViewControllerAnimated:YES];
                
            } else {
                
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                
            }
            
            
        }
        
    }];
    
    
}

#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    
    keyboardControls.textFields = [NSArray arrayWithObjects:txtFName,txtLName,txtEmail,txtContact,nil];
    
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"";
    [keyboardControls hidePrevNextButtons:YES];
    
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] bounds];
    CGFloat availableHeight = applicationFrame.size.height - 230;
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    
    [controls.activeTextField resignFirstResponder];
    
    
}

- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([keyboardControls.textFields containsObject:textField])
        keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

//-(void)textFieldDidBeginEditing:(UITextField *)textField {
//    //Keyboard becomes visible
//    scrollView.frame = CGRectMake(scrollView.frame.origin.x,
//                                  scrollView.frame.origin.y,
//                                  scrollView.frame.size.width,
//                                  scrollView.frame.size.height - 315 + 50);
//}
//
//-(void)textFieldDidEndEditing:(UITextField *)textField {
//    //keyboard will hide
//    scrollView.frame = CGRectMake(scrollView.frame.origin.x,
//                                  scrollView.frame.origin.y,
//                                  scrollView.frame.size.width,
//                                  scrollView.frame.size.height + 315 - 50);
//}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if([textField isEqual:txtContact])
    {
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init] ;
        if([string length]==0)
        {
            [formatter setGroupingSeparator:@"-"];
            [formatter setGroupingSize:4];
            [formatter setUsesGroupingSeparator:YES];
            [formatter setSecondaryGroupingSize:3];
            NSString *num = textField.text ;
            num= [num stringByReplacingOccurrencesOfString:@"-" withString:@""];
            NSString *str = [formatter stringFromNumber:[NSNumber numberWithDouble:[num doubleValue]]];
            
            textField.text=str;
            NSLog(@"%@",str);
            return YES;
        }
        else {
            [formatter setGroupingSeparator:@"-"];
            [formatter setGroupingSize:3];
            [formatter setUsesGroupingSeparator:YES];
            [formatter setSecondaryGroupingSize:3];
            NSString *num = textField.text ;
            if(![num isEqualToString:@""])
            {
                num= [num stringByReplacingOccurrencesOfString:@"-" withString:@""];
                NSString *str = [formatter stringFromNumber:[NSNumber numberWithDouble:[num doubleValue]]];
                
                textField.text=str;
            }
            
            return YES;
        }
    }
    return YES;
}
@end
