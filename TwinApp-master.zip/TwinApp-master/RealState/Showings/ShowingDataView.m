//  ShowingDataView.m
//  RealEstate_App
//  Created by Octal on 07/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import "ShowingDataView.h"
#import "Config.h"
#import "REWebService.h"
#import "ShowingAgentVC.h"
#import "AllManagersList.h"

@interface ShowingDataView ()
@end

@implementation ShowingDataView

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    self.navigationItem.revealSidebarDelegate=self;
    [btnNavigation addTarget:self action:@selector(revealLeftSidebar:) forControlEvents:UIControlEventTouchUpInside];
    
    service = [[RealEstateService alloc] init];
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    
    if(IsRunningTallPhone())
    {
        [viewClientList setFrame:CGRectMake(0, 0, 320, 578)];
        [tblClientList setFrame:CGRectMake(0, 44, 320, 518)];
    }
    else
    {
        [viewClientList setFrame:CGRectMake(0, 0, 320, 490)];
        [tblClientList setFrame:CGRectMake(0, 44, 320, 428)];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [AppDelegate sharedDelegate].globalReference = nil;
    [AppDelegate sharedDelegate].globalReference = self.navigationController;
    if(isInternetAvailable())
    {
       arrManagerData = [[NSMutableArray alloc] init];
       [self getUsersData];
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Internet connection is not available"];
    }
}



#pragma mark JTRevealSidebarDelegate
- (void)revealLeftSidebar:(id)sender
{
    [self.navigationController toggleRevealState:JTRevealedStateLeft];
}

- (UIView *)viewForLeftSidebar{
    CGRect viewFrame = self.navigationController.applicationViewFrame;
    UITableViewController *controller = self.leftSidebarViewController;
    if (!controller)
    {
        self.leftSidebarViewController = [[SidebarViewController alloc] init];
        self.leftSidebarViewController.sidebarDelegate = [AppDelegate sharedDelegate];
        controller = self.leftSidebarViewController;
    }
    controller.view.frame = CGRectMake(0, viewFrame.origin.y, 270, viewFrame.size.height);
    controller.view.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
    return controller.view;
}

- (void)didChangeRevealedStateForViewController:(UIViewController *)viewController {
    if (viewController.revealedState == JTRevealedStateNo)
        tblClientList.userInteractionEnabled=YES;
    else
        tblClientList.userInteractionEnabled=NO;
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrManagerData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    AgentTvCellView *cell = (AgentTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
            
           view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPhone" bundle:nil];
        } else {
            
            view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPad" bundle:nil];
        }
        
        cell = (AgentTvCellView *)view.view;
    }
    
    cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    if (IS_IPHONE) {
        cell.imgBackground.layer.borderWidth=0.5;
    } else {
        cell.imgBackground.layer.borderWidth=1.5;
    }
    
    cell.imgUserPhoto.backgroundColor = [UIColor clearColor];
    cell.imgUserPhoto.layer.borderColor = [UIColor grayColor].CGColor;
    cell.imgUserPhoto.placeholderImage = [UIImage imageNamed:@"upload_pic"];
    clientDetail = [arrManagerData objectAtIndex:indexPath.row];
    
    NSDictionary *temp = [arrManagerData objectAtIndex:indexPath.row];
    NSString *url = [NSString stringWithFormat:@"%@%@",WebserviceImageUrl,[temp valueForKey:@"user_pic"]];
    cell.imgUserPhoto.imageURL  = [NSURL URLWithString:url];
    cell.lblUserName.text = [NSString stringWithFormat:@"%@",[temp valueForKey:@"user_name"]];
    cell.lblUserEmailId.text = [NSString stringWithFormat:@"%@",[temp valueForKey:@"user_email"]];
    cell.lblUserPhone.text = [NSString stringWithFormat:@"%@",[temp valueForKey:@"user_cellphone"]];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE) {
        return 100.0;
    } else {
        return 130.0;
    }

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    [tblClientList deselectRowAtIndexPath:indexPath animated:YES];
    ShowingAgentVC *agent;
    if (IS_IPHONE) {
        
        agent = [[ShowingAgentVC alloc] initWithNibName:@"ShowingAgentVC" bundle:nil];
    } else {
        
        agent = [[ShowingAgentVC alloc] initWithNibName:@"ShowingAgentVC_iPad" bundle:nil];
    }
    agent.managerId = [[arrManagerData objectAtIndex:indexPath.row] valueForKey:@"user_id"];
    agent.isFromAddShowing = @"NO";
    [self.navigationController pushViewController:agent animated:YES];
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
-(void)getUsersData
{
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"RoleId"] isEqualToString:@"1"])
    {
      //[dataDict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"RoleId"] forKey:@"admin_id"];
        [dataDict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] forKey:@"admin_id"];
    }
    else if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"RoleId"] isEqualToString:@"2"])
    {
     // [dataDict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"RoleId"] forKey:@"manager_id"];
        [dataDict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] forKey:@"manager_id"];
    }
    else if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"RoleId"] isEqualToString:@"3"])
    {
      //[dataDict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"RoleId"] forKey:@"agent_id"];
      [dataDict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] forKey:@"agent_id"];
    }
    [REWebService userRelatedData:dataDict withBlock:^(NSDictionary *dictResult, NSError *error){
        [MBProgressHUD hideAllHUDsForView:self->appDelegate.window animated:YES];
        if (!error) {
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"] isEqualToString:@"success"]) {
                NSLog(@"%@",dictResult);
                
                NSArray *tempArr = [[dictResult valueForKey:@"response"] valueForKey:@"data"];
                
                for (NSInteger i=0; i<tempArr.count; i++)
                {
                    NSDictionary *temp = [[NSDictionary alloc]init];
                    temp = [tempArr objectAtIndex:i];
                    [self->arrManagerData addObject:temp];
                }
                [self->tblClientList reloadData];
                
            }
            else
            {
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
            }
            
        }
        
        
    }];
    

}

-(IBAction)addShowing:(id)sender
{
    if (IS_IPHONE) {
        AllManagersList *allManager = [[AllManagersList alloc] initWithNibName:@"AllManagersList" bundle:nil];
        [self.navigationController pushViewController:allManager animated:YES];
    } else {
        AllManagersList *allManager = [[AllManagersList alloc] initWithNibName:@"AllManagersList_iPad" bundle:nil];
        [self.navigationController pushViewController:allManager animated:YES];
    }
    
}

@end
