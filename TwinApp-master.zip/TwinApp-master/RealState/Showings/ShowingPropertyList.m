//  ShowingPropertyList.m
//  RealEstate_App
//  Created by Octal on 07/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import "ShowingPropertyList.h"
#import "PropertyTvCellView.h"
#import "PropertyDetail.h"
#import "UIImageView+UIActivityIndicatorForSDWebImage.h"
#import "UIImageView+HighlightedWebCache.h"
#import "PropertyDetailViewController.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "ShowingPropertyCell.h"

@interface ShowingPropertyList ()

@end

@implementation ShowingPropertyList

- (void)viewDidLoad {
    [super viewDidLoad];
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
   
    [self getPropertyData];
    
    refreshControl = [[UIRefreshControl alloc]init];
    refreshControl.backgroundColor = [UIColor whiteColor];
    [tblListing addSubview:refreshControl];
    refreshControl.tintColor = [UIColor lightGrayColor];
    [refreshControl addTarget:self action:@selector(getPropertyData) forControlEvents:UIControlEventValueChanged];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

# pragma mark Table View Delegate and datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return propertyDataArr.count;
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    ShowingPropertyCell *cell = (ShowingPropertyCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
            
           view = [[UIViewController alloc]initWithNibName:@"ShowingPropertyCell" bundle:nil];
        } else {
            
           view = [[UIViewController alloc]initWithNibName:@"ShowingPropertyCell_iPad" bundle:nil];
        }
        
        cell = (ShowingPropertyCell *)view.view;
    }
    if (propertyDataArr.count){
        
        PropertyDetail *theProperty = [propertyDataArr objectAtIndex:indexPath.row];
        
        if ([theProperty.status isEqualToString:@"for_sale"])
        {
            cell.lblHomeType.text = @"For Sale";
            cell.lblHomeType.textColor = [UIColor colorWithRed:(38/255.f) green:(133/255.f) blue:(9/255.f) alpha:1.0f];
            cell.imgViewPropertyType.image = [UIImage imageNamed:@"for_sale"];
          //  cell.lblPrice.text = [NSString stringWithFormat:@"$ %@",theProperty.priceSale];
            NSInteger *intPrice = [theProperty.priceSale integerValue];
            NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
            NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                               numberStyle:NSNumberFormatterCurrencyStyle];
            
            NSString *newString;
            if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
            {
                newString = [price substringFromIndex:3];
                newString =  [newString substringToIndex:[newString length]-3];
                
            }
            cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
        }
        else if ([theProperty.status isEqualToString:@"for_rent"])
        {
            cell.lblHomeType.text = @"For Rent";
            cell.lblHomeType.textColor = [UIColor orangeColor];
            cell.imgViewPropertyType.image = [UIImage imageNamed:@"for_rent"];
           // cell.lblPrice.text = [NSString stringWithFormat:@"$ %@",theProperty.priceRented];
            NSInteger *intPrice = [theProperty.priceRented integerValue];
            NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
            NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                               numberStyle:NSNumberFormatterCurrencyStyle];
            
            NSString *newString;
            if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
            {
                newString = [price substringFromIndex:3];
                newString =  [newString substringToIndex:[newString length]-3];
                
            }
            cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
            
        }
        else
        {
            cell.lblHomeType.text = @"Sold";
            cell.imgViewPropertyType.image = [UIImage imageNamed:@"sold"];
            cell.lblHomeType.textColor = [UIColor redColor];
            //cell.lblPrice.text = [NSString stringWithFormat:@"$ %@",theProperty.PriceSold];
            NSInteger *intPrice = [theProperty.PriceSold integerValue];
            NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
            NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                               numberStyle:NSNumberFormatterCurrencyStyle];
            
            NSString *newString;
            if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
            {
                newString = [price substringFromIndex:3];
                newString =  [newString substringToIndex:[newString length]-3];
                
            }
            cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
        }
        
        cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
        
        cell.imgBackground.layer.borderWidth=0.75;
        cell.lblSaleType.text = [NSString stringWithFormat:@"%@",theProperty.Id];
        cell.lblBedBath.text = [NSString stringWithFormat:@"%@bd-%@ba %@ sq ft",theProperty.numbedrooms,theProperty.totalfullbaths,theProperty.totalfloorareasqft];
        cell.lblPhotoCount.text = [NSString stringWithFormat:@"%@ Photos",theProperty.availableImages];
        
        cell.lblAddress.text = [NSString stringWithFormat:@"%@",theProperty.fulladdress];
        cell.lblAddress1.text = [NSString stringWithFormat:@"%@",theProperty.fullAddress1];
        
        [cell.imgViewProperty setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",theProperty.imgProperty]] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        
        cell.lblListingCourtesy.text = [NSString stringWithFormat:@"%@",theProperty.listingCourtesy];
        cell.lblOpenHouse.text = [NSString stringWithFormat:@"Showing from %@ to %@",theProperty.fromTime,theProperty.toTime];
        cell.lblAgentName.text = [NSString stringWithFormat:@"Agent name: %@",theProperty.agentName];
        cell.lblAgentCell.text = [NSString stringWithFormat:@"Agent Cell: %@",theProperty.agentCell];
        
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE) {
        return 150;
    } else {
        return 170;
    }
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    PropertyDetailViewController*detail;
    if (IS_IPHONE) {
        detail = [[PropertyDetailViewController alloc]initWithNibName:@"PropertyDetailViewController_iPhone" bundle:nil];
    } else {
        detail = [[PropertyDetailViewController alloc]initWithNibName:@"PropertyDetailViewController_iPad" bundle:nil];
    }
    PropertyDetail *theProperty = [propertyDataArr objectAtIndex:indexPath.row];
    detail.PropertyId = theProperty.Id;
    detail.totalPropertyArr = propertyDataArr;
    detail.selectedIndex = indexPath.row;
    [self.navigationController pushViewController:detail animated:YES];
}
-(void)getPropertyData
{
     NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:self.clientId forKey:@"client_id"];
    [dataDict setValue:self.date forKey:@"date"];
    [dataDict setValue:self.fromTime forKey:@"from_time"];
    [dataDict setValue:self.toTime forKey:@"to_time"];
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    [REWebService showingProperty:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self->appDelegate.window animated:YES];
    NSLog(@"%@",dictResult);
        [self->refreshControl endRefreshing];
        
    if (!error) {
            
             if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]) {
                 self->propertyDataArr = [[NSMutableArray alloc]init];
                NSArray *propertyTempArr = [[dictResult objectForKey:@"response"]objectForKey:@"data"] ;
                for(NSDictionary *tempDict in propertyTempArr)
                {
                    PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                    [self->propertyDataArr addObject:datamodel];
                }
                 for(UILabel *lbl in [self->tblListing subviews])
                {
                    if(lbl.tag == 50)
                    {
                        [lbl removeFromSuperview];
                    }
                    
                }
                 [self->tblListing reloadData];
            }else
            {
              
                [self->tblListing reloadData];
            }
            
        }
        
    }];
    
    
}
-(IBAction)backButtonTaped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
