//
//  ShowingsViewController.h
//  RealState
//
//  Created by Kapil Goyal on 23/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JTRevealSidebarV2Delegate.h"
#import "UIViewController+JTRevealSidebarV2.h"
#import "UINavigationItem+JTRevealSidebarV2.h"
#import "AppDelegate.h" 

@class SidebarViewController;
@interface ShowingsViewController : UIViewController<UITableViewDelegate, UITableViewDataSource,JTRevealSidebarV2Delegate>
{
    IBOutlet UITableView *tblShowings;
    IBOutlet UIView *viewSHowings;
    IBOutlet UIButton *btnNavigation;
    NSMutableArray *dataArr;
    AppDelegate *appdelegate;
   
}
@property (nonatomic, strong) SidebarViewController *leftSidebarViewController;
@property (nonatomic,strong)NSString *clientId;
@end
