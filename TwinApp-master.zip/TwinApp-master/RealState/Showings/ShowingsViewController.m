//  ShowingsViewController.m
//  RealState
//  Created by Kapil Goyal on 23/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "ShowingsViewController.h"
#import "ShowingTvCellView.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "AddShowingViewController.h"
#import "ShowingPropertyList.h"

@interface ShowingsViewController ()
@end

@implementation ShowingsViewController
@synthesize leftSidebarViewController;

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    self.navigationItem.revealSidebarDelegate=self;
    [btnNavigation addTarget:self action:@selector(revealLeftSidebar:) forControlEvents:UIControlEventTouchUpInside];
    appdelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
   
    
    
    
    
    if(IsRunningTallPhone())
    {
        [viewSHowings setFrame:CGRectMake(0, 0, 320, 578)];
        [tblShowings setFrame:CGRectMake(0, 44, 320, 518)];
    }
    else
    {
        [viewSHowings setFrame:CGRectMake(0, 0, 320, 490)];
        [tblShowings setFrame:CGRectMake(0, 44, 320, 428)];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [AppDelegate sharedDelegate].globalReference = nil;
    [AppDelegate sharedDelegate].globalReference = self.navigationController;
    [self getShowingDataFromServer];
}

#pragma mark JTRevealSidebarDelegate
- (void)revealLeftSidebar:(id)sender
{
    [self.navigationController toggleRevealState:JTRevealedStateLeft];
}

- (UIView *)viewForLeftSidebar{
    // Use applicationViewFrame to get the correctly calculated view's frame
    // for use as a reference to our sidebar's view
    CGRect viewFrame = self.navigationController.applicationViewFrame;
    UITableViewController *controller = self.leftSidebarViewController;
    if (!controller)
    {
        self.leftSidebarViewController = [[SidebarViewController alloc] init];
        self.leftSidebarViewController.sidebarDelegate = [AppDelegate sharedDelegate];
        controller = self.leftSidebarViewController;
    }
    controller.view.frame = CGRectMake(0, viewFrame.origin.y, 270, viewFrame.size.height);
    controller.view.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
    return controller.view;
}

//Optional delegate methods for additional configuration after reveal state changed
- (void)didChangeRevealedStateForViewController:(UIViewController *)viewController {
    // Example to disable userInteraction on content view while sidebar is revealing
    if (viewController.revealedState == JTRevealedStateNo)
        tblShowings.scrollEnabled=YES;
    else
        tblShowings.scrollEnabled=NO;
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    ShowingTvCellView *cell = (ShowingTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
            view = [[UIViewController alloc]initWithNibName:@"ShowingTvCellView_iPhone" bundle:nil];
        } else {
            view = [[UIViewController alloc]initWithNibName:@"ShowingTvCellView_iPad" bundle:nil];
        }
        
        cell = (ShowingTvCellView *)view.view;
    }
    
    NSDictionary *dic = [dataArr objectAtIndex:indexPath.row];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSDate *date = [formatter dateFromString:[NSString stringWithFormat:@"%@", [dic valueForKey:@"date"]]];
    [formatter setDateFormat:@"dd MMMM, yyyy"];
    NSString *newDate = [formatter stringFromDate:date];
    
    cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    cell.imgBackground.layer.borderWidth=0.75;
    cell.lblDate.text = newDate;
    cell.lblProperties.text =[NSString stringWithFormat:@"%@", [dic valueForKey:@"no_of_properties"]]  ;
    cell.lblTime.text =[NSString stringWithFormat:@"%@ to %@", [dic valueForKey:@"from_time"],[dic valueForKey:@"to_time"]]  ;

    
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
 
    [tblShowings deselectRowAtIndexPath:indexPath animated:YES];
    NSLog(@"my index%ld",(long)indexPath.row);
    ShowingPropertyList *showing;
    if (IS_IPHONE) {
        
       showing = [[ShowingPropertyList alloc]initWithNibName:@"ShowingPropertyList" bundle:nil];
    } else {
       showing = [[ShowingPropertyList alloc]initWithNibName:@"ShowingPropertyList_iPad" bundle:nil];
    }
    showing.clientId = self.clientId;
    showing.fromTime = [[dataArr objectAtIndex:indexPath.row]valueForKey:@"from_time"];
    showing.toTime = [[dataArr objectAtIndex:indexPath.row]valueForKey:@"to_time"];
    showing.date = [[dataArr objectAtIndex:indexPath.row]valueForKey:@"date"];
    [self.navigationController pushViewController:showing animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE) {
        return 92.0;
    } else {
        return 100.0;
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
-(void)getShowingDataFromServer
{
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:self.clientId forKey:@"client_id"];
    [MBProgressHUD showHUDAddedTo:appdelegate.window animated:YES];
    [REWebService CallGetShowingDetail:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
    [MBProgressHUD hideAllHUDsForView:appdelegate.window animated:YES];
        if (!error) {
            dataArr = [[NSMutableArray alloc]init];
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]) {
                
               NSArray*arr = [[dictResult valueForKey:@"response"] valueForKey:@"data"];
                
                for (NSInteger i  = 0; i<arr.count; i++) {
                    
                    NSDictionary *dict = [arr objectAtIndex:i];
                    [dataArr addObject:dict];
                    
                }
                
                [tblShowings reloadData];
                
                int newCount = [[[dictResult valueForKey:@"response"] valueForKey:@"menu_showing_property_count"] intValue];
                NSString *str = [NSString stringWithFormat:@"%d",newCount];
                [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"showingCount"];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"ReloadSideMenu" object:nil];
                
            }
            
            
        }
        NSLog(@"%@",dictResult);
        
        
    }];
}

-(IBAction)backButtonTaped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];

}
@end
