//
//  AllClientList.h
//  RealEstate_App
//
//  Created by Octal on 18/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface AllClientList : UIViewController
{
    IBOutlet UITableView *myTable;
    NSMutableArray *dataArray;
    AppDelegate *appDelegate;
}
@property (nonatomic,strong)NSString *agentId;
@end
