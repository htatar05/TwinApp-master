//
//  ShowingAgentVC.h
//  RealEstate_App
//
//  Created by Octal on 07/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface ShowingAgentVC : UIViewController
{
    IBOutlet UITableView *tblClientList;
    IBOutlet UIView *viewClientList;
    IBOutlet UIButton *btnNavigation;
    AppDelegate *appDelegate;
    NSMutableArray *arrAgentData;
    IBOutlet UIButton *btnAddShowing;
}

@property (nonatomic,strong)NSString *managerId;
@property (nonatomic,strong)NSString *isFromAddShowing;
@end
