//
//  ShowingClientVC.h
//  RealEstate_App
//
//  Created by Octal on 07/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface ShowingClientVC : UIViewController
{
    IBOutlet UITableView *tblClientList;
    IBOutlet UIView *viewClientList;
    IBOutlet UIButton *btnNavigation;
    IBOutlet UIButton *btnAddShowing;
    
    AppDelegate *appDelegate;
    NSMutableArray *arrClientData;

}
@property (nonatomic,strong)NSString *agentId;
@property (nonatomic,strong)NSString *isFromAddShowing;
@end
