//
//  ShowingDataView.h
//  RealEstate_App
//
//  Created by Octal on 07/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "JTRevealSidebarV2Delegate.h"
#import "UIViewController+JTRevealSidebarV2.h"
#import "UINavigationItem+JTRevealSidebarV2.h"
#import "AppDelegate.h"
#import "ClientDetail.h"
#import "RealEstateService.h"
#import "AgentListDetailInvocation.h"
#import "AgentTvCellView.h"
#import "AgentDetailViewController.h"
#import "MBProgressHUD.h"
#import "Utils.h"

@interface ShowingDataView : UIViewController<UITableViewDelegate, UITableViewDataSource,JTRevealSidebarV2Delegate,ConnectedClientListDetailInvocationDelegate>
{
    IBOutlet UITableView *tblClientList;
    IBOutlet UIView *viewClientList;
    IBOutlet UIButton *btnNavigation;
    IBOutlet UIButton *btnAddShowing;
    
    RealEstateService *service;
    AppDelegate *appDelegate;
    NSMutableArray *arrManagerData;
    ClientDetail *clientDetail;
    
}
@property (nonatomic, strong) SidebarViewController *leftSidebarViewController;
@end