//
//  ShowingPropertyList.h
//  RealEstate_App
//
//  Created by Octal on 07/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface ShowingPropertyList : UIViewController
{
    NSMutableArray *propertyDataArr;
    IBOutlet UITableView *tblListing;
    AppDelegate *appDelegate;
    UIRefreshControl *refreshControl;
    
}
@property (nonatomic,strong)NSString *clientId;
@property (nonatomic,strong)NSString *date;
@property (nonatomic,strong)NSString *fromTime;
@property (nonatomic,strong)NSString *toTime;
@end
