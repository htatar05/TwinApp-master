//  AllClientList.m
//  RealEstate_App
//  Created by Octal on 18/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import "AllClientList.h"
#import "AgentTvCellView.h"
#import "Config.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "Utils.h"
#import "AllAgentList.h"
#import "AddShowingViewController.h"

@interface AllClientList ()

@end

@implementation AllClientList

- (void)viewDidLoad {
    [super viewDidLoad];
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    [self getUsersData];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

-(IBAction)backButtonTaped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [dataArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    AgentTvCellView *cell = (AgentTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
           view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPhone" bundle:nil];
        } else {
           view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPad" bundle:nil];
        }
        cell = (AgentTvCellView *)view.view;
    }
    
    cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    if (IS_IPHONE) {
        cell.imgBackground.layer.borderWidth=0.5;
    } else {
        cell.imgBackground.layer.borderWidth=1.5;
    }
    cell.imgUserPhoto.backgroundColor = [UIColor clearColor];
    cell.imgUserPhoto.layer.borderColor = [UIColor grayColor].CGColor;
    cell.imgUserPhoto.placeholderImage = [UIImage imageNamed:@"upload_pic"];
    NSDictionary *temp = [dataArray objectAtIndex:indexPath.row];
    NSString *url = [NSString stringWithFormat:@"%@%@",WebserviceImageUrl,[temp valueForKey:@"user_pic"]];
    cell.imgUserPhoto.imageURL  = [NSURL URLWithString:url];
    cell.lblUserName.text = [NSString stringWithFormat:@"%@",[temp valueForKey:@"user_name"]];
    cell.lblUserEmailId.text = [NSString stringWithFormat:@"%@",[temp valueForKey:@"user_email"]];
    cell.lblUserPhone.text = [NSString stringWithFormat:@"%@",[temp valueForKey:@"user_cellphone"]];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE) {
        return 100.0;
    }
    else
    {
        return 130.0;
    }
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [myTable deselectRowAtIndexPath:indexPath animated:YES];
    AddShowingViewController *client;
    if (IS_IPHONE) {
        client = [[AddShowingViewController alloc] initWithNibName:@"AddShowingViewController_iPhone" bundle:nil];
    } else {
        client = [[AddShowingViewController alloc] initWithNibName:@"AddShowingViewController_iPad" bundle:nil];
    }
    
    client.strClientId = [[dataArray objectAtIndex:indexPath.row] valueForKey:@"user_id"];
    client.strClientName = [[dataArray objectAtIndex:indexPath.row] valueForKey:@"user_name"];
    [self.navigationController pushViewController:client animated:YES];
    
}
-(void)getUsersData
{
    dataArray = [[NSMutableArray alloc]init];
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:self.agentId forKey:@"agent_id"];
    [REWebService showingDataAccordingToLoginUser:dataDict withBlock:^(NSDictionary *dictResult, NSError *error){
        [MBProgressHUD hideAllHUDsForView:self->appDelegate.window animated:YES];
        
        if (!error){
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"] isEqualToString:@"success"]) {
                NSLog(@"%@",dictResult);
                NSArray *tempArr = [[dictResult valueForKey:@"response"] valueForKey:@"data"];
                for (NSInteger i=0; i<tempArr.count; i++)
                {
                    NSDictionary *temp = [[NSDictionary alloc]init];
                    temp = [tempArr objectAtIndex:i];
                    [self->dataArray addObject:temp];
                }
                [self->myTable reloadData];
                
            }
            else
            {
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
            }
            
        }
        
        
    }];
    
}


@end
