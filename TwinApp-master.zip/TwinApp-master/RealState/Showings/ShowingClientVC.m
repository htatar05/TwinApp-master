//
//  ShowingClientVC.m
//  RealEstate_App
//
//  Created by Octal on 07/11/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import "ShowingClientVC.h"
#import "AgentTvCellView.h"
#import "Config.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "Utils.h"
#import "ShowingsViewController.h"
#import "AllClientList.h"

@interface ShowingClientVC ()

@end

@implementation ShowingClientVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    [self getUsersData];
    if ([self.isFromAddShowing isEqualToString:@"No"]) {
        btnAddShowing.hidden  = YES;
    } else {
        btnAddShowing.hidden  = NO;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)backButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrClientData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    AgentTvCellView *cell = (AgentTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
            view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPhone" bundle:nil];
        } else {
            view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPad" bundle:nil];
        }
        cell = (AgentTvCellView *)view.view;
    }
    
    cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    
    if (IS_IPHONE) {
        cell.imgBackground.layer.borderWidth=0.5;
    } else {
        cell.imgBackground.layer.borderWidth=1.5;
    }
    cell.imgUserPhoto.backgroundColor = [UIColor clearColor];
    cell.imgUserPhoto.layer.borderColor = [UIColor grayColor].CGColor;
    cell.imgUserPhoto.placeholderImage = [UIImage imageNamed:@"upload_pic"];
    
    NSDictionary *temp = [arrClientData objectAtIndex:indexPath.row];
    NSString *url = [NSString stringWithFormat:@"%@%@",WebserviceImageUrl,[temp valueForKey:@"user_pic"]];
    cell.imgUserPhoto.imageURL  = [NSURL URLWithString:url];
    cell.lblUserName.text = [NSString stringWithFormat:@"%@",[temp valueForKey:@"user_name"]];
    cell.lblUserEmailId.text = [NSString stringWithFormat:@"%@",[temp valueForKey:@"user_email"]];
    cell.lblUserPhone.text = [NSString stringWithFormat:@"%@",[temp valueForKey:@"user_cellphone"]];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE) {
        return 100.0;
    } else {
        return 130.0;
    }
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tblClientList deselectRowAtIndexPath:indexPath animated:YES];
    ShowingsViewController *client;
    if (IS_IPHONE) {
        client = [[ShowingsViewController alloc] initWithNibName:@"ShowingsViewController_iPhone" bundle:nil];
    } else {
        client = [[ShowingsViewController alloc] initWithNibName:@"ShowingsViewController_iPad" bundle:nil];
    }
    
    client.clientId  = [[arrClientData objectAtIndex:indexPath.row]valueForKey:@"user_id"];
    [self.navigationController pushViewController:client animated:YES];
    
}
-(void)getUsersData
{
    arrClientData = [[NSMutableArray alloc]init];
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    
    [dataDict setValue:self.agentId forKey:@"agent_id"];
    [REWebService userRelatedData:dataDict withBlock:^(NSDictionary *dictResult, NSError *error){
        [MBProgressHUD hideAllHUDsForView:self->appDelegate.window animated:YES];
        if (!error) {
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"] isEqualToString:@"success"]) {
                NSLog(@"%@",dictResult);
                
                NSArray *tempArr = [[dictResult valueForKey:@"response"] valueForKey:@"data"];
                
                for (NSInteger i=0; i<tempArr.count; i++)
                {
                    NSDictionary *temp = [[NSDictionary alloc]init];
                    temp = [tempArr objectAtIndex:i];
                    [self->arrClientData addObject:temp];
                }
                [self->tblClientList reloadData];
                
            }
            else
            {
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
            }
            
        }
        
        
    }];
}
-(IBAction)addShowingTaped:(id)sender
{
    AllClientList *allClient;
    if (IS_IPHONE) {
        allClient = [[AllClientList alloc] initWithNibName:@"AllClientList" bundle:nil];
    } else {
        allClient = [[AllClientList alloc] initWithNibName:@"AllClientList_iPad" bundle:nil];
    }
    allClient.agentId = [[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"];
    [self.navigationController pushViewController:allClient animated:YES];

}

@end
