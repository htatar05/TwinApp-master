//
//  SavedSearchPropertyViewController.h
//  RealState
//
//  Created by Kapil Goyal on 14/11/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "JTRevealSidebarV2Delegate.h"
#import "UIViewController+JTRevealSidebarV2.h"
#import "UINavigationItem+JTRevealSidebarV2.h"
#import "SidebarViewController.h"

@interface SavedSearchPropertyViewController : UIViewController<UITableViewDelegate,UITableViewDataSource,JTRevealSidebarV2Delegate>
{
    IBOutlet UIScrollView *scrlView;
    IBOutlet UITableView *tblSavedSearch;
    IBOutlet UIImageView *imgSep;
    IBOutlet UIButton *btnMarkRead;
    IBOutlet UIButton *btnNavigation;
    CGFloat height;
    CGRect rect;

    NSMutableArray *arrText;
    NSMutableArray *arrData;
    NSMutableArray *arrtxtViewHeight;
    
    int count;
    IBOutlet UIButton *btnEditSearch;
    IBOutlet UIButton *btnDeleteSearch;
    IBOutlet UIButton *btnEdit;
    AppDelegate *appdelegate;
    NSMutableArray *deleteIdArr;
    NSMutableIndexSet *indexes;
}
@property(nonatomic,strong)SidebarViewController *leftSidebarViewController;

-(IBAction)btnEditClicked;
-(IBAction)btnDeleteClicked;
@end
