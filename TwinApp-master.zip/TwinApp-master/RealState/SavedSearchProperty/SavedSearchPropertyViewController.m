//
//  SavedSearchPropertyViewController.m
//  RealState
//
//  Created by Kapil Goyal on 14/11/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "SavedSearchPropertyViewController.h"
#import "PropertySavedSearchTvCellView.h"
#import "NSAttributedString+Attributes.h"
#import "REWebService.h"
#import "Utils.h"
#import "MainViewController.h"
#import "MBProgressHUD.h"
#import "UIImageView+UIActivityIndicatorForSDWebImage.h"
#import "UIImageView+HighlightedWebCache.h"
#import "Config.h"

@interface SavedSearchPropertyViewController ()
@end

@implementation SavedSearchPropertyViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    appdelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    self.navigationItem.revealSidebarDelegate=self;
    [btnNavigation addTarget:self action:@selector(revealLeftSidebar:) forControlEvents:UIControlEventTouchUpInside];
    deleteIdArr = [[NSMutableArray alloc]init];
    indexes = [NSMutableIndexSet new];
    arrText = [[NSMutableArray alloc] initWithObjects:@"210, s sdfsa sdfsdf sdfsdfsdfsad fPl",
               @"sdf sdf sd",
               @"dfsdfs fsdf sdfsf",
               @"dfsdf sfsds sdfsa sdfs dsdf fd",
               @"sdf sdf sd",
               @"dfsdfs fsdf sdfsf",
               @"dfsdf sfsdsdf sf sfsdfd",
               @"sd fsd sdfsdfs sdfsdf sdf sd",
               @"dfsdfs fsdf ssdfsfsdfdfsf",
               @"dfsdf sfssd sdfs sdfs sdfsd dsdf fd" ,nil];
    
    /***********Dynamic View***********/
    arrtxtViewHeight = [[NSMutableArray alloc] init];

    for(int i=0;i<[arrText count];i++)
    {
        CGFloat ht = [self txtViewHeight:i];
        [arrtxtViewHeight addObject:[NSNumber numberWithFloat:ht]];
    }
    
    if(IsRunningTallPhone())
    {
        [self.view setFrame:CGRectMake(0, 0, 320, 568)];
        [tblSavedSearch setFrame:CGRectMake(0, 44, 320, 466)];
        [imgSep setFrame:CGRectMake(0, 510, 320, 2)];
        [btnMarkRead setFrame:CGRectMake(77, 527, 166, 27)];
    }
    else
    {
        [self.view setFrame:CGRectMake(0, 0, 320, 480)];
        [tblSavedSearch setFrame:CGRectMake(0, 44, 320, 377)];
        [imgSep setFrame:CGRectMake(0, 421, 320, 2)];
        [btnMarkRead setFrame:CGRectMake(77, 438, 166, 27)];
    }
    tblSavedSearch.allowsMultipleSelectionDuringEditing = YES;
    btnEditSearch.hidden = YES;
    btnDeleteSearch.hidden=YES;
    btnMarkRead.hidden=NO;
    
    
}

-(void)viewWillAppear:(BOOL)animated
{
    count = 0;
    [AppDelegate sharedDelegate].globalReference = nil;
    [AppDelegate sharedDelegate].globalReference = self.navigationController;
    [self getSavedSearchList];
}

#pragma mark JTRevealSidebarDelegate
- (void)revealLeftSidebar:(id)sender
{
    [self.navigationController toggleRevealState:JTRevealedStateLeft];
}

- (UIView *)viewForLeftSidebar{
    // Use applicationViewFrame to get the correctly calculated view's frame
    // for use as a reference to our sidebar's view
    CGRect viewFrame = self.navigationController.applicationViewFrame;
    UITableViewController *controller = self.leftSidebarViewController;
    if (!controller)
    {
        self.leftSidebarViewController = [[SidebarViewController alloc] init];
        self.leftSidebarViewController.sidebarDelegate = [AppDelegate sharedDelegate];
        controller = self.leftSidebarViewController;
    }
    controller.view.frame = CGRectMake(0, viewFrame.origin.y, 270, viewFrame.size.height);
    controller.view.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
    return controller.view;
}

//Optional delegate methods for additional configuration after reveal state changed
- (void)didChangeRevealedStateForViewController:(UIViewController *)viewController {
    // Example to disable userInteraction on content view while sidebar is revealing
    if (viewController.revealedState == JTRevealedStateNo)
        tblSavedSearch.userInteractionEnabled=YES;
    else
        tblSavedSearch.userInteractionEnabled=NO;
}

-(CGFloat)txtViewHeight:(int)index
{
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[arrText objectAtIndex:index]];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:14.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        height=0.0;
        if(height1>24)
        {
            height=height1-24;
        }
    }
    else
    {
        UITextView *txtViewHeight = [[UITextView alloc] init];
        txtViewHeight.font = [UIFont fontWithName:@"Helvetica" size:14.0];
        txtViewHeight.text = [arrText objectAtIndex:index];
        txtViewHeight.frame = CGRectMake(0, 0, 177, 24);
        [self.view addSubview:txtViewHeight];
        rect = txtViewHeight.frame;
        rect.size = txtViewHeight.contentSize;
        txtViewHeight.frame = rect;
        [txtViewHeight removeFromSuperview];
        if(rect.size.height>24)
            height=rect.size.height-24;
    }
    return height;
}

- (CGFloat)textViewHeightForAttributedText:(NSMutableAttributedString*)text
{
    UITextView *txtSavedSearch = [[UITextView alloc] init];
    [txtSavedSearch setAttributedText:text];
    CGSize size = [txtSavedSearch sizeThatFits:CGSizeMake(177, 24)];
    NSLog(@"height111=%f",size.height);
    return size.height;
}

-(IBAction)btnEditClicked
{
    if([btnEdit.titleLabel.text isEqualToString:@"Edit"])
    {
        count = 0;
        [tblSavedSearch setEditing:YES animated:YES];
        [btnEdit setTitle:@"Done" forState:UIControlStateNormal];
        btnMarkRead.hidden=YES;
        btnEditSearch.hidden = NO;
        btnDeleteSearch.hidden=NO;
        btnEditSearch.alpha=0.5;
        btnDeleteSearch.alpha=0.5;
        btnEditSearch.userInteractionEnabled=FALSE;
        btnDeleteSearch.userInteractionEnabled=FALSE;
    }
    else
    {
        [btnEdit setTitle:@"Edit" forState:UIControlStateNormal];
        [btnDeleteSearch setTitle:@"Delete" forState:UIControlStateNormal];
        btnMarkRead.hidden=NO;
        btnEditSearch.hidden = YES;
        btnDeleteSearch.hidden=YES;
        [tblSavedSearch setEditing:NO animated:YES];
    }
}

-(void)updateSelectionCount
{
    if (arrData.count) {
        if(count==0)
        {
            [btnDeleteSearch setTitle:@"Delete" forState:UIControlStateNormal];
            btnDeleteSearch.alpha=0.5;
            btnEditSearch.alpha=0.5;
            btnDeleteSearch.userInteractionEnabled=FALSE;
            btnEditSearch.userInteractionEnabled=FALSE;
        }
        if(count>0)
        {
            btnDeleteSearch.userInteractionEnabled=TRUE;
            [btnDeleteSearch setTitle:[NSString stringWithFormat:@"Delete (%d)", count] forState:UIControlStateNormal];
            btnDeleteSearch.alpha=1.0;
            btnEditSearch.alpha=1.0;
            if(count==1)
            {
                btnEditSearch.alpha=1.0;
                btnEditSearch.userInteractionEnabled=TRUE;
            }
            else
            {
                btnEditSearch.alpha=0.5;
                btnEditSearch.userInteractionEnabled=FALSE;
            }
        }
    }
    
}

-(IBAction)btnDeleteClicked
{
    NSMutableDictionary *dataDict  = [[NSMutableDictionary alloc]init];
    [dataDict setValue:deleteIdArr forKey:@"ids"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"user_id"];
    [MBProgressHUD showHUDAddedTo:appdelegate.window animated:YES];
    [REWebService deleteSaveSeraches:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:appdelegate.window animated:YES];
        
        if (!error) {
            
            if ([[[dictResult valueForKey:@"response"]valueForKey:@"message"]isEqualToString:@"success"])
            {
                 count = 0;
                [arrData removeObjectsAtIndexes:indexes];
                if (arrData.count)
                {
                   
                }
                else
                {
                    
                    
                }
                [tblSavedSearch reloadData];
            }
            
        } else {
            
        }
        
    }];
    /*
    NSMutableIndexSet *indexes = [[NSMutableIndexSet alloc ]init];
    NSMutableArray *arrTmp = [[NSMutableArray alloc] init];
    
    NSArray *selectedRows = [tblSavedSearch indexPathsForSelectedRows];
    for (int i=0; i<[selectedRows count]; i++)
    {
        NSIndexPath *indexPath = [selectedRows objectAtIndex:i];
        [arrTmp addObject:indexPath];
        [indexes addIndex:indexPath.row];
    }
    
    [arrData removeObjectsAtIndexes:indexes];
    [tblSavedSearch beginUpdates];
    [tblSavedSearch deleteRowsAtIndexPaths:arrTmp withRowAnimation:UITableViewRowAnimationFade];
    [tblSavedSearch endUpdates];
    
    count = 0;
    [btnDeleteSearch setTitle:@"Delete" forState:UIControlStateNormal];
    btnDeleteSearch.alpha = 0.5;
    btnDeleteSearch.userInteractionEnabled=FALSE;
     */
}


#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrData count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    if (IS_IPHONE) {
         return 105;
    } else {
         return 125;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    PropertySavedSearchTvCellView *cell = (PropertySavedSearchTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE){
            
            view = [[UIViewController alloc]initWithNibName:@"PropertySavedSearchTvCellView_iPhone" bundle:nil];
            
        } else {
            
            view = [[UIViewController alloc]initWithNibName:@"PropertySavedSearchTvCellView_iPad" bundle:nil];
        }
        
        cell = (PropertySavedSearchTvCellView *)view.view;
    }

    NSDictionary *temp = [arrData objectAtIndex:indexPath.row];
    cell.lblName.text = [NSString stringWithFormat:@"%@",[temp valueForKey:@"name"]];
    cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    cell.imgBackground.layer.borderWidth=0.75;
    if ([[temp valueForKey:@"status"] isEqualToString:@"for_sale"])
    {
        cell.lblFilter.text = [NSString stringWithFormat:@"For Sale,%@+ Beds,%@+ Baths",[temp valueForKey:@"bedroom"],[temp valueForKey:@"bathroom"]];
    }
    else if ([[temp valueForKey:@"status"] isEqualToString:@"for_rent"])
    {
        cell.lblFilter.text = [NSString stringWithFormat:@"For Rent,%@+ Beds,%@+ Baths",[temp valueForKey:@"bedroom"],[temp valueForKey:@"bathroom"]];
    }
    else if ([[temp valueForKey:@"status"] isEqualToString:@"sold"])
    {
        cell.lblFilter.text = [NSString stringWithFormat:@"Sold,%@+ Beds,%@+ Baths",[temp valueForKey:@"bedroom"],[temp valueForKey:@"bathroom"]];
    }
    else{
         cell.lblFilter.text = [NSString stringWithFormat:@"All Properties,%@+ Beds,%@+ Baths",[temp valueForKey:@"bedroom"],[temp valueForKey:@"bathroom"]];
    }
    
    NSString *str = [NSString stringWithFormat:@"%@%@",WebserviceSaveSearch,[temp valueForKey:@"image"]];
    [cell.imgPropertyPhoto setImageWithURL:[NSURL URLWithString:str] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    
    if (![[temp valueForKey:@"update_count"] integerValue]==0)
    {
         cell.lblUpdatedProperties.text = [NSString stringWithFormat:@"%@ Updated Properties",[temp valueForKey:@"update_count"]];
    }
    else
    {
        cell.lblUpdatedProperties.text = [NSString stringWithFormat:@"No Updated Properties"];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
   
    return cell;
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tblSavedSearch.isEditing){
        count--;
    }
    NSDictionary *temp = [arrData objectAtIndex:indexPath.row];
    [deleteIdArr removeObject:[temp valueForKey:@"save_search_id"]];
     [indexes removeIndex:indexPath.row];
    [self updateSelectionCount];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tblSavedSearch.isEditing)
    {
         count++;
         [self updateSelectionCount];
          NSDictionary *temp = [arrData objectAtIndex:indexPath.row];
         [deleteIdArr addObject:[temp valueForKey:@"save_search_id"]];
         [indexes addIndex:indexPath.row];
    }
    else
    {
        [tblSavedSearch deselectRowAtIndexPath:indexPath animated:YES];
        MainViewController *mapView;
        if (IS_IPHONE) {
            mapView = [[MainViewController alloc] initWithNibName:@"MainViewController_iPhone" bundle:nil];
        } else {
             mapView = [[MainViewController alloc] initWithNibName:@"MainViewController_iPad" bundle:nil];
        }
        mapView.isFromSavedSearch = @"Yes";
        mapView.propertyId = [[arrData objectAtIndex:indexPath.row] valueForKey:@"save_search_id"];
        [self.navigationController pushViewController:mapView animated:YES];
    }
    
}

-(void)getSavedSearchList
{
   [MBProgressHUD showHUDAddedTo:appdelegate.window animated:YES];
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"user_id"];
    [REWebService GetsavedSearchList:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
    [MBProgressHUD hideAllHUDsForView:appdelegate.window animated:YES];
        if (!error){
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]) {
                
                 NSArray *temp=[[dictResult valueForKey:@"response"] valueForKey:@"data"];
                 arrData = [[NSMutableArray alloc]initWithArray:temp];
                [tblSavedSearch reloadData];
                
            }else{
                
             [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                
            }
            
        }
        
    }];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(IBAction)deleteSaveSearches:(id)sender
{

}
@end
