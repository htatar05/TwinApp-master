//
//  SettingsViewController.h
//  RealState
//
//  Created by Kapil Goyal on 16/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JTRevealSidebarV2Delegate.h"
#import "UIViewController+JTRevealSidebarV2.h"
#import "UINavigationItem+JTRevealSidebarV2.h"
#import "AppDelegate.h"
#import "User.h"
#import <MessageUI/MessageUI.h>
#import "SidebarViewController.h"
@interface SettingsViewController : UIViewController<JTRevealSidebarV2Delegate,UITableViewDelegate,UITableViewDataSource,MFMailComposeViewControllerDelegate>
{
    IBOutlet UIButton *btnNavigation;
    IBOutlet UIScrollView *scrlView;
    IBOutlet UIView *viewSettings;
    IBOutlet UIButton *btnLogout;
    User *user;
    AppDelegate *appDelegate;
    IBOutlet UIView *view1;
    IBOutlet UIView *view2;
    IBOutlet UIView *view3;
    NSMutableArray *arrSetting;
    IBOutlet UITableView *tblSetting;
    IBOutlet UISwitch *switchNotification;
    IBOutlet UISwitch *switchEmails;
}

@property (nonatomic,strong) SidebarViewController *leftSidebarViewController;
-(IBAction)btnLogoutClicked;
-(IBAction)btnLoginClicked;
-(IBAction)btnRegisterClicked;

@end
