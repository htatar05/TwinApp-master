//  ProfileVC.m
//  RealEstate_App
//  Created by Octal on 05/12/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.


#import "ProfileVC.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "UIImageView+UIActivityIndicatorForSDWebImage.h"
#import "UIImageView+HighlightedWebCache.h"
#import "Config.h"
#import "Utils.h"
#import "JSON.h"
#import "NSDictionary+NullReplacement.h"
#import "NSArray+NullReplacement.h"
#import "AGPushNoteView.h"

@interface ProfileVC ()

@end

@implementation ProfileVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    delegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    [self addKeyboardControls];
    txtEmail.enabled = NO;
    [self getUserProfile];
    [scrollView setContentSize:CGSizeMake(320, 510)];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


-(IBAction)backButtonTaped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)getUserProfile
{
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"id"];
    [MBProgressHUD showHUDAddedTo:delegate.window animated:YES];
    [REWebService getUserProfile:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self->delegate.window animated:YES];
    if (!error){
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"])
            {
                NSArray *temp =[[dictResult valueForKey:@"response"] valueForKey:@"data"];
                NSMutableDictionary *dict = [[NSMutableDictionary alloc]initWithDictionary:[temp objectAtIndex:0]];
                self->txtFirstName.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"first_name"]];
                self->txtLastName.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"last_name"]];
                self->txtEmail.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"email"]];
                self->txtContactNum.text = [NSString stringWithFormat:@"%@",[dict valueForKey:@"phone"]];
                self->txtPassWord.text =   [NSString stringWithFormat:@"%@",[dict valueForKey:@"password"]];
                self->txtAddress1.text =   [NSString stringWithFormat:@"%@",[dict valueForKey:@"address"]];
                self->txtAddress2.text =   [NSString stringWithFormat:@"%@",[dict valueForKey:@"address2"]];
                self->txtZipcode.text =    [NSString stringWithFormat:@"%@",[dict valueForKey:@"zip_code"]];
                self->txtCity.text =       [NSString stringWithFormat:@"%@",[dict valueForKey:@"city"]];
                self->txtState.text =      [NSString stringWithFormat:@"%@",[dict valueForKey:@"state"]];
                NSString *strTemp = [NSString stringWithFormat:@"%@%@",profileImage,[dict valueForKey:@"image"]];
                [self->userImage setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",strTemp]] placeholderImage:[UIImage imageNamed:@"upload_pic.png"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                self->userImage.layer.masksToBounds=YES;
                if (IS_IPHONE) {
                    self->userImage.layer.cornerRadius  = 35.0;
                } else {
                    self->userImage.layer.cornerRadius  = 50.0;
                }
                
            }
        }
        
    }];

}

-(IBAction)selectUserPic:(id)sender
{
    UIAlertController* alert = [UIAlertController
                                alertControllerWithTitle:nil
                                message:nil
                                preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction* button0 = [UIAlertAction
                              actionWithTitle:@"Cancel"
                              style:UIAlertActionStyleCancel
                              handler:^(UIAlertAction * action)
                              {
                                  
                              }];
    
    UIAlertAction* button1 = [UIAlertAction
                              actionWithTitle:@"Camera"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  
                                  UIImagePickerController *imagePickerController= [[UIImagePickerController alloc] init];
                                  imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
                                  imagePickerController.delegate = self;
                                  [self presentViewController:imagePickerController animated:YES completion:^{}];
                              }];
    
    UIAlertAction* button2 = [UIAlertAction
                              actionWithTitle:@"Choose Existing"
                              style:UIAlertActionStyleDefault
                              handler:^(UIAlertAction * action)
                              {
                                  
                                  UIImagePickerController *imagePickerController= [[UIImagePickerController alloc] init];
                                  imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                                  imagePickerController.delegate = self;
                                  [self presentViewController:imagePickerController animated:YES completion:^{}];
                              }];
    
    [alert addAction:button0];
    [alert addAction:button1];
    [alert addAction:button2];
    
    
    
    [alert setModalPresentationStyle:UIModalPresentationPopover];
    
    UIPopoverPresentationController *popPresenter = [alert
                                                     popoverPresentationController];
    popPresenter.sourceView = scrollView;
    popPresenter.sourceRect = scrollView.bounds;
    [self presentViewController:alert animated:YES completion:nil];

}



#pragma mark -
#pragma mark UIImagePickerControllerDelegate

- (void) imagePickerController:(UIImagePickerController *)picker
         didFinishPickingImage:(UIImage *)image
                   editingInfo:(NSDictionary *)editingInfo
{
    userImage.image = [self fixOrientationForImage:image];
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(IBAction)updateProfile:(id)sender
{
    
    if (txtFirstName.text.length==0)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter first name"];
    }
    else if (txtLastName.text.length==0)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter last name"];
    }
    else if (txtContactNum.text.length==0)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter phone number"];
    }
    else if (txtPassWord.text.length==0)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter a password"];
    }
    else
    {
        [MBProgressHUD showHUDAddedTo:delegate.window animated:YES];
        NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
        [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"id"];
        [dataDict setValue:txtFirstName.text forKey:@"first_name"];
        [dataDict setValue:txtLastName.text forKey:@"last_name"];
        [dataDict setValue:txtContactNum.text forKey:@"phone"];
        [dataDict setValue:txtAddress1.text forKey:@"address"];
        [dataDict setValue:txtAddress2.text forKey:@"address2"];
        [dataDict setValue:txtZipcode.text forKey:@"post_code"];
        [dataDict setValue:txtPassWord.text forKey:@"password"];
        [dataDict setValue:txtCity.text forKey:@"city"];
        [dataDict setValue:txtState.text forKey:@"state"];
        NSLog(@"%@",[dataDict JSONRepresentation]);
        
        [REWebService UpdateUserProfile:dataDict image:userImage.image withBlock:^(NSDictionary *dictResult, NSError *error) {
            
            [MBProgressHUD hideAllHUDsForView:self->delegate.window animated:YES];
            
            if (!error) {
                
                if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"])
                {
                    
                    NSDictionary *rerg = [dictResult valueForKey:@"response"];
                    
                    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"])
                    {
                        NSLog(@"auto login");
                        [[NSUserDefaults standardUserDefaults] setObject:[rerg dictionaryByReplacingNullsWithBlanks] forKey:@"userData"];
                        [[NSUserDefaults standardUserDefaults] setObject:[rerg objectForKey:@"user_id"] forKey:@"user_id"];
                    }
                    else if ([AppDelegate sharedDelegate].loginUser)
                    {
                        NSLog(@"only login");
                        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"userData"];
                        User *temp = [[User alloc]init];
                        temp.strUserName = [rerg valueForKey:@"username"];
                        temp.strFName = [rerg valueForKey:@"first_name"];
                        temp.strLName = [rerg valueForKey:@"last_name"];
                        temp.strEmail = [rerg valueForKey:@"email"];
                        temp.strRoleId = [rerg valueForKey:@"role_id"];
                        temp.strUserImage = [rerg valueForKey:@"userimage"];
                        self->delegate.user = temp;
                    }
                    self->delegate.loginUser = TRUE;
                    [[NSUserDefaults standardUserDefaults] setObject:[rerg objectForKey:@"user_id"] forKey:@"user_id"];
                    [[NSUserDefaults standardUserDefaults] setObject:[rerg objectForKey:@"role_id"] forKey:@"role_id"];
                    [[NSUserDefaults standardUserDefaults] setObject:[rerg objectForKey:@"role_id"] forKey:@"RoleId"];
                    [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:@"ReloadSideMenu" object:nil];
                    
                } else
                {
                    [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                }
                
            }
            
        }];
    }
     
     
}

#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    
      keyboardControls.textFields = [NSArray arrayWithObjects:txtFirstName,txtLastName,txtEmail,txtContactNum,txtPassWord,txtAddress1,txtAddress2,txtZipcode,nil];
    
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"";
    [keyboardControls hidePrevNextButtons:YES];
    
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] bounds];
    CGFloat availableHeight = applicationFrame.size.height - 230;
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
   
    [controls.activeTextField resignFirstResponder];
   
    
}

- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([keyboardControls.textFields containsObject:textField])
        keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField {
    //Keyboard becomes visible
    scrollView.frame = CGRectMake(scrollView.frame.origin.x,
                                     scrollView.frame.origin.y,
                                     scrollView.frame.size.width,
                                     scrollView.frame.size.height - 315 + 50);
}

-(void)textFieldDidEndEditing:(UITextField *)textField {
    //keyboard will hide
    scrollView.frame = CGRectMake(scrollView.frame.origin.x,
                                     scrollView.frame.origin.y,
                                     scrollView.frame.size.width,
                                     scrollView.frame.size.height + 315 - 50);
}

- (UIImage *)fixOrientationForImage:(UIImage*)neededImage {
    
    // No-op if the orientation is already correct
    if (neededImage.imageOrientation == UIImageOrientationUp) return neededImage;
    
    // We need to calculate the proper transformation to make the image upright.
    // We do it in 2 steps: Rotate if Left/Right/Down, and then flip if Mirrored.
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    switch (neededImage.imageOrientation) {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, neededImage.size.width, neededImage.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, neededImage.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, neededImage.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationUpMirrored:
            break;
    }
    
    switch (neededImage.imageOrientation) {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, neededImage.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, neededImage.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationDown:
        case UIImageOrientationLeft:
        case UIImageOrientationRight:
            break;
    }
    
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, neededImage.size.width, neededImage.size.height,
                                             CGImageGetBitsPerComponent(neededImage.CGImage), 0,
                                             CGImageGetColorSpace(neededImage.CGImage),
                                             CGImageGetBitmapInfo(neededImage.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (neededImage.imageOrientation) {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,neededImage.size.height,neededImage.size.width), neededImage.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,neededImage.size.width,neededImage.size.height), neededImage.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if([textField isEqual:txtContactNum])
    {
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init] ;
        if([string length]==0)
        {
            [formatter setGroupingSeparator:@"-"];
            [formatter setGroupingSize:4];
            [formatter setUsesGroupingSeparator:YES];
            [formatter setSecondaryGroupingSize:3];
            NSString *num = textField.text ;
            num= [num stringByReplacingOccurrencesOfString:@"-" withString:@""];
            NSString *str = [formatter stringFromNumber:[NSNumber numberWithDouble:[num doubleValue]]];
            
            textField.text=str;
            NSLog(@"%@",str);
            return YES;
        }
        else {
            [formatter setGroupingSeparator:@"-"];
            [formatter setGroupingSize:3];
            [formatter setUsesGroupingSeparator:YES];
            [formatter setSecondaryGroupingSize:3];
            NSString *num = textField.text ;
            if(![num isEqualToString:@""])
            {
                num= [num stringByReplacingOccurrencesOfString:@"-" withString:@""];
                NSString *str = [formatter stringFromNumber:[NSNumber numberWithDouble:[num doubleValue]]];
                
                textField.text=str;
            }
            
            return YES;
        }
    }
    return YES;
}
@end
