//  SettingsViewController.m
//  RealState
//  Created by Kapil Goyal on 16/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "SettingsViewController.h"
#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "REWebService.h"
#import "AskForLoginViewController.h"
#import "FeedbackVC.h"
#import "Utils.h"
#import "PrivacyPolicyVC.h"
#import <Social/Social.h>
#import <MessageUI/MessageUI.h>

@interface SettingsViewController ()
@end

@implementation SettingsViewController
@synthesize leftSidebarViewController;

- (void)viewDidLoad
{
    [super viewDidLoad];
    view1.layer.borderWidth=0.5;
    view1.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    
    view2.layer.borderWidth=0.5;
    view2.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    
    view3.layer.borderWidth=0.5;
    view3.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    
    arrSetting = [[NSMutableArray alloc] initWithObjects:@"Privacy Policy",@"Terms of Use",@"Rate This App",@"Send Feedback",@"Share with a Friend",@"Share on Facebook and Twitter",nil];
    
    user = [[User alloc] init];
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    self.navigationItem.revealSidebarDelegate=self;
    [btnNavigation addTarget:self action:@selector(revealLeftSidebar:) forControlEvents:UIControlEventTouchUpInside];
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
       
        [switchNotification setFrame:CGRectMake(257, 87, 51, 31)];
        
        [switchEmails setFrame:CGRectMake(257, 170, 51, 31)];
    }
    else
    {
        [switchNotification setFrame:CGRectMake(237, 87, 51, 31)];
        [switchEmails setFrame:CGRectMake(237, 170, 51, 31)];
    }
    
    
    if (IS_IPHONE) {
        
    } else {
        [switchNotification setFrame:CGRectMake(677, 93, 51, 31)];
        [switchEmails setFrame:CGRectMake(677, 176, 51, 31)];
        
    }
    
    if(IsRunningTallPhone())
    {
        [viewSettings setFrame:CGRectMake(0, 0, 320, 568)];
        [scrlView setFrame:CGRectMake(0, 44, 320, 524)];
        //[tblSetting setFrame:CGRectMake(0, 286, 320, 216)];
        [scrlView setContentSize:CGSizeMake(320, 580)];
    }
    else{
        
        [viewSettings setFrame:CGRectMake(0, 0, 320, 480)];
        [scrlView setFrame:CGRectMake(0, 44, 320, 436)];
        [scrlView setContentSize:CGSizeMake(320, 580)];
        //[tblSetting setFrame:CGRectMake(0, 286, 320, 216)];
    }
    
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| appDelegate.loginUser)
    {
        [btnLogout setTitle:@"Logout" forState:UIControlStateNormal];
        [btnLogout setImage:[UIImage imageNamed:@"logout1"] forState:UIControlStateNormal];
    }
    else
    {
        [btnLogout setTitle:@"Login" forState:UIControlStateNormal];
        [btnLogout setImage:[UIImage imageNamed:@"login_btn21"] forState:UIControlStateNormal];
    }
   
}

-(void)viewWillAppear:(BOOL)animated
{
    [AppDelegate sharedDelegate].globalReference = nil;
    [AppDelegate sharedDelegate].globalReference = self.navigationController;
    [AppDelegate sharedDelegate].boolLogin = TRUE;
    user.strRoleId= [[NSUserDefaults standardUserDefaults] objectForKey:@"role_id"];
    if(![user.strRoleId isEqualToString:@"0"])
    {
        btnLogout.hidden=NO;
    }
    else if([user.strRoleId isEqualToString:@"0"])
    {
        btnLogout.hidden=NO;
    }
    
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"NotificationSwitch"]isEqualToString:@"True"])
    {
        [switchNotification setOn:YES animated:YES];
    }
    else
    {
       [switchNotification setOn:NO animated:YES];
    }
    if ([[[NSUserDefaults standardUserDefaults]objectForKey:@"EmailSwitch"]isEqualToString:@"True"])
    {
        [switchEmails setOn:YES];
    }
    else
    {
       [switchNotification setOn:NO];
    }
    
}

-(IBAction)btnLogoutClicked
{
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| appDelegate.loginUser)
    {
        NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] forKey:@"user_id"];
        [REWebService CallLogout:dict withBlock:^(NSDictionary *dictResult, NSError *error) {
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]){
                
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"userData"];
                [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"user_id"];
                self->appDelegate.loginUser = NO;
                [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"loginstatus"];
                AskForLoginViewController *pVC = [[AskForLoginViewController alloc] initWithNibName:@"AskForLoginViewController_iPhone" bundle:nil];
                self->appDelegate.navigationController = [[UINavigationController alloc] initWithRootViewController:pVC] ;
                self->appDelegate.window.rootViewController = appDelegate.navigationController;
                
            }
            else{
                
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"message"]];
            }
            
            NSLog(@"%@",dictResult);
            
        }];
    }
    else
    {
        appDelegate.boolLoginPresent=TRUE;
        appDelegate.boolLogin=FALSE;
        appDelegate.boolLoginNotNow=FALSE;
        LoginViewController *login;
        if (IS_IPHONE) {
            login = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPhone" bundle:nil];
        } else {
            login = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPad" bundle:nil];
        }
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:login];
        [self presentViewController:nav animated:YES completion:nil];
    }
    
    
}
/*
-(IBAction)btnLoginClicked
{
    appDelegate.boolLoginPresent=TRUE;
    appDelegate.boolLogin=FALSE;
    appDelegate.boolLoginNotNow=FALSE;
    LoginViewController *login = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPhone" bundle:nil];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:login];
    [self presentViewController:nav animated:YES completion:nil];
}

-(IBAction)btnRegisterClicked
{
    appDelegate.boolLoginPresent=TRUE;
    appDelegate.boolLogin=FALSE;
    appDelegate.boolLoginNotNow=FALSE;
    RegisterViewController *registerView = [[RegisterViewController alloc] initWithNibName:@"RegisterViewController_iPhone" bundle:nil];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:registerView];
    [self presentViewController:nav animated:YES completion:nil];
}
*/
- (IBAction)notificationSwitch:(id)sender {
    if (switchNotification.on )
    {
        [self CallEnableDisablePush:@"1"];
        [[NSUserDefaults standardUserDefaults]setValue:@"True" forKey:@"NotificationSwitch"];
        NSLog(@"true");
    }
    else
    {
        NSLog(@"false");
        [self CallEnableDisablePush:@"2"];
        [[NSUserDefaults standardUserDefaults]setValue:@"False" forKey:@"NotificationSwitch"];
    }
    
}

- (IBAction)homeEmailsSwitch:(id)sender {
    if (switchEmails.on )
    {
        NSLog(@"true");
        [self CallFavouriteHomeEmails:@"1"];
        [[NSUserDefaults standardUserDefaults]setValue:@"True" forKey:@"EmailSwitch"];
    }
    else
    {
        NSLog(@"false");
        [self CallFavouriteHomeEmails:@"2"];
        [[NSUserDefaults standardUserDefaults]setValue:@"False" forKey:@"EmailSwitch"];
    }
}

#pragma mark JTRevealSidebarDelegate
- (void)revealLeftSidebar:(id)sender
{
    [self.navigationController toggleRevealState:JTRevealedStateLeft];
}

- (UIView *)viewForLeftSidebar{
   
    CGRect viewFrame = self.navigationController.applicationViewFrame;
    UITableViewController *controller = self.leftSidebarViewController;
    if (!controller)
    {
        self.leftSidebarViewController = [[SidebarViewController alloc] init];
        self.leftSidebarViewController.sidebarDelegate = [AppDelegate sharedDelegate];
        controller = self.leftSidebarViewController;
    }
    controller.view.frame = CGRectMake(0, viewFrame.origin.y, 270, viewFrame.size.height);
    controller.view.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
    return controller.view;
}

//Optional delegate methods for additional configuration after reveal state changed
- (void)didChangeRevealedStateForViewController:(UIViewController *)viewController
{
    // Example to disable userInteraction on content view while sidebar is revealing
    if (viewController.revealedState == JTRevealedStateNo)
        scrlView.userInteractionEnabled=YES;
    else
        scrlView.userInteractionEnabled=NO;
}

#pragma mark UITableView Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell=nil;
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    UILabel *lblSetting = [[UILabel alloc] initWithFrame:CGRectMake(10, 2, 292, 31)];
    lblSetting.text=[arrSetting objectAtIndex:indexPath.row];
    lblSetting.font =[UIFont fontWithName:@"Helvetica" size:16.0];
    lblSetting.textColor = [UIColor colorWithRed:88/255.0 green:88/255.0 blue:88/255.0 alpha:1];
    [cell.contentView addSubview:lblSetting];
    UIImageView *imgArrow;
    if (IS_IPHONE) {
        
        imgArrow = [[UIImageView alloc] initWithFrame:CGRectMake(293, 12, 12, 16)];
        imgArrow.image = [UIImage imageNamed:@"gray_arrow.png"];
        [cell.contentView addSubview:imgArrow];
    } else {
        imgArrow = [[UIImageView alloc] initWithFrame:CGRectMake(700, 12, 12, 16)];
        imgArrow.image = [UIImage imageNamed:@"gray_arrow.png"];
        [cell.contentView addSubview:imgArrow];
    }
    

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tblSetting deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0:
              {
                  
                  if (IS_IPHONE) {
                      
                      PrivacyPolicyVC *fvc = [[PrivacyPolicyVC alloc] initWithNibName:@"PrivacyPolicyVC" bundle:nil];
                      fvc.isPrivacyPolicy = @"YES";
                      [self.navigationController pushViewController:fvc animated:YES];
                  } else {
                      PrivacyPolicyVC *fvc = [[PrivacyPolicyVC alloc] initWithNibName:@"PrivacyPolicyVC_ipad" bundle:nil];
                      fvc.isPrivacyPolicy = @"YES";
                      [self.navigationController pushViewController:fvc animated:YES];
                  }
                
              }
            break;
        case 1:
              {
                  if (IS_IPHONE) {
                      
                      PrivacyPolicyVC *fvc = [[PrivacyPolicyVC alloc] initWithNibName:@"PrivacyPolicyVC" bundle:nil];
                      fvc.isPrivacyPolicy = @"NO";
                      [self.navigationController pushViewController:fvc animated:YES];
                  } else {
                      
                      PrivacyPolicyVC *fvc = [[PrivacyPolicyVC alloc] initWithNibName:@"PrivacyPolicyVC_ipad" bundle:nil];
                      fvc.isPrivacyPolicy = @"NO";
                      [self.navigationController pushViewController:fvc animated:YES];
                  }
                
             }
            break;
        case 2:
             NSLog(@"%ld",(long)indexPath.row);
            break;
        case 3:
              {
                  
                  if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| appDelegate.loginUser)
                  {
                      
                      if (IS_IPHONE) {
                          
                          FeedbackVC *fvc = [[FeedbackVC alloc] initWithNibName:@"FeedbackVC" bundle:nil];
                          [self.navigationController pushViewController:fvc animated:YES];
                      } else {
                          FeedbackVC *fvc = [[FeedbackVC alloc] initWithNibName:@"Feedback_ipad" bundle:nil];
                          [self.navigationController pushViewController:fvc animated:YES];
                      }
                     
                      
                  }
                  else
                  {
                      appDelegate.boolLoginPresent=TRUE;
                      appDelegate.boolLogin=FALSE;
                      appDelegate.boolLoginNotNow=FALSE;
                      LoginViewController *login;
                      if (IS_IPHONE) {
                          login = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPhone" bundle:nil];
                      } else {
                          login = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPad" bundle:nil];
                      }
                      UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:login];
                      [self presentViewController:nav animated:YES completion:nil];
                  }
                  
              }
            break;
        case 4:
              {
                  [self ShareViaMail];
              }
            break;
        case 5:
             {
                 UIAlertController* alert = [UIAlertController
                                             alertControllerWithTitle:nil
                                             message:nil
                                             preferredStyle:UIAlertControllerStyleActionSheet];
                 
                 UIAlertAction* button0 = [UIAlertAction
                                           actionWithTitle:@"Cancel"
                                           style:UIAlertActionStyleCancel
                                           handler:^(UIAlertAction * action)
                                           {
                                               
                                           }];
                 
                 UIAlertAction* button1 = [UIAlertAction
                                           actionWithTitle:@"Share on facebook"
                                           style:UIAlertActionStyleDefault
                                           handler:^(UIAlertAction * action)
                                           {
                                               [self ShareOnFacebook];
                                           }];
                 
                 UIAlertAction* button2 = [UIAlertAction
                                           actionWithTitle:@"Share on twitter"
                                           style:UIAlertActionStyleDefault
                                           handler:^(UIAlertAction * action)
                                           {
                                               [self shareOnTwitter];
                                           }];
                 
                 [alert addAction:button0];
                 [alert addAction:button1];
                 [alert addAction:button2];
                 [self presentViewController:alert animated:YES completion:nil];
             }
            break;
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)CallEnableDisablePush:(NSString *)withString
{
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:withString forKey:@"value"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] forKey:@"user_id"];
    [REWebService CallEnableDisablePush:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        
        if ([[[dictResult valueForKey:@"response"]valueForKey:@"message"]isEqualToString:@"success"]) {
            
           
        }
        NSLog(@"%@",dictResult);
        
    }];
    
}

-(void)CallFavouriteHomeEmails:(NSString *)withString
{
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:withString forKey:@"value"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] forKey:@"user_id"];
    [REWebService CallFavouriteHomeEmails:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
     if ([[[dictResult valueForKey:@"response"]valueForKey:@"message"]isEqualToString:@"success"]) {
            
           
        }
    }];
    
}

- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }
    [self dismissViewControllerAnimated:YES completion:NULL];
}

-(void)ShareOnFacebook
{
    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook]) {
        
        SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
        
        if (controller != nil)
        {
            [controller setInitialText:@"I am a very happy user of the Twin Realty app.It is effective and so convenient! Give it a try too! Check out www.twinrealty.com to get started."];
            [controller addURL:[NSURL URLWithString:@""]];
            [controller addImage:[UIImage imageNamed:@"logo1"]];
            [self presentViewController:controller animated:YES completion:Nil];
        }
        else{
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Twin Realty" message:@"Sorry, cannot load facebook. Please try again latter." preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            [self presentViewController:alertController animated:YES completion:nil];
        }
        
    }
    else
    {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"No Facebook Account" message:@"There are no Facebook accounts configured. You can add or create a Facebook account in Settings." preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:ok];
            [self presentViewController:alertController animated:YES completion:nil];
    }
}


- (void)shareOnTwitter{
    
    if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeTwitter])
    {
        SLComposeViewController *tweetSheet = [SLComposeViewController
                                               composeViewControllerForServiceType:SLServiceTypeTwitter];
        [tweetSheet setInitialText:@"I am a very happy user of the Twin Realty app.It is effective and so convenient! Give it a try too!"];
        [tweetSheet addImage:[UIImage imageNamed:@"logo1"]];
        [self presentViewController:tweetSheet animated:YES completion:nil];
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please configure twitter"];
    }
}
-(void)ShareViaMail
{
    if ([MFMailComposeViewController canSendMail]) {
        
        NSString *emailTitle = @"I am a fan of the Twin Realty app";
        NSString *messageBody = @"I am a very happy user of the Twin Realty app.It is effective and so convenient! Give it a try too! Check out www.twinrealty.com to get started.";
        MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
        mc.mailComposeDelegate = self;
        [mc setSubject:emailTitle];
        [mc setMessageBody:messageBody isHTML:NO];
        [self presentViewController:mc animated:YES completion:NULL];
    }
    else
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Twin Realty" message:@"You must have your Mail account configured in Device Settings" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        [self presentViewController:alertController animated:YES completion:nil];
        
    }
    
}

- (void)messageComposeViewController:
(MFMessageComposeViewController *)controller
                 didFinishWithResult:(MessageComposeResult)result
{
    switch (result)
    {
        case MessageComposeResultCancelled:
            NSLog(@"Cancelled");
            break;
        case MessageComposeResultFailed:
            NSLog(@"Failed");
            break;
        case MessageComposeResultSent:
            break;
        default:
            break;
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
