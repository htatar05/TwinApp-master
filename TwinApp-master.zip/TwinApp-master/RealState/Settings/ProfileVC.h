//  ProfileVC.h
//  RealEstate_App
//  Created by Octal on 05/12/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "BSKeyboardControls.h"
#import "TPKeyboardAvoidingScrollView.h"
@interface ProfileVC : UIViewController<UIImagePickerControllerDelegate,
UINavigationControllerDelegate,BSKeyboardControlsDelegate>

{
    IBOutlet UIImageView *userImage;

    IBOutlet TPKeyboardAvoidingScrollView *scrollView;
    IBOutlet UITextField *txtFirstName;
    IBOutlet UITextField *txtLastName;
    IBOutlet UITextField *txtEmail;
    IBOutlet UITextField *txtContactNum;
    IBOutlet UITextField *txtPassWord;
    IBOutlet UITextField *txtAddress1;
    IBOutlet UITextField *txtAddress2;
    IBOutlet UITextField *txtZipcode;
    IBOutlet UITextField *txtCity;
    IBOutlet UITextField *txtState;
    
    IBOutlet UIButton *selectImage;
  //  IBOutlet UIScrollView *scrollView;
    AppDelegate *delegate;
    BSKeyboardControls *keyboardControls;
}

@end
