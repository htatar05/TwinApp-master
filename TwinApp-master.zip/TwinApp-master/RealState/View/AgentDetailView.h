//  AgentDetailView.h
//  RealState
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "AppDelegate.h"

@protocol AgentDetailViewDelegate <NSObject>
-(void)btnBackClicked;
@end

@class AgentDetail;
@interface AgentDetailView : UIView
{
    
}

@property(nonatomic,strong)id<AgentDetailViewDelegate> delegate;
@end
