//
//  AgentDetailView.m
//  RealState
//
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "AgentDetailView.h"

@implementation AgentDetailView
@synthesize delegate;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.backgroundColor = [UIColor whiteColor];
        UIView *viewAgent = [[UIView alloc] init];
        viewAgent.backgroundColor = [UIColor clearColor];
        viewAgent.frame = CGRectMake(0,0,320,436);
        [self addSubview:viewAgent];
        
        UIImageView *img = [[UIImageView alloc] init];
        img.backgroundColor = [UIColor clearColor];
        img.frame = CGRectMake(0, 0, 320, 44);
        img.image = [UIImage imageNamed:@"top_blue.png"];
        [viewAgent addSubview:img];
        
        UIButton *btnNavigation = [UIButton buttonWithType:UIButtonTypeCustom];
        btnNavigation.backgroundColor=[UIColor clearColor];
        btnNavigation.frame=CGRectMake(1,7,79,29);
        [btnNavigation setImage:[UIImage imageNamed:@"slider_left_arrow.png"] forState:UIControlStateNormal];
        [btnNavigation setTitle:@" Back" forState:UIControlStateNormal];
        [btnNavigation addTarget:self action:@selector(popToView) forControlEvents:UIControlEventTouchUpInside];
        [viewAgent addSubview:btnNavigation];
        
        UILabel *lbl = [[UILabel alloc] init];
        lbl.frame = CGRectMake(53, 8, 230, 27);
        lbl.backgroundColor = [UIColor clearColor];
        lbl.text = @"Addison Amon";
        lbl.textAlignment = NSTextAlignmentCenter;
        lbl.textColor = [UIColor whiteColor];
        lbl.font = [UIFont fontWithName:@"Helvetica-Bold" size:22.0];
        [viewAgent addSubview:lbl];
        
        UIScrollView *scrlView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 44, 320, 416)];
        scrlView.backgroundColor = [UIColor clearColor];
        [viewAgent addSubview:scrlView];

        UIImageView *imgViewSmall = [[UIImageView alloc] initWithFrame:CGRectMake(8, 8, 304, 112)];
        imgViewSmall.backgroundColor = [UIColor whiteColor];
        imgViewSmall.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
        imgViewSmall.layer.borderWidth=0.75;
        imgViewSmall.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
        [scrlView addSubview:imgViewSmall];

        UIImageView *imgViewUser = [[UIImageView alloc] initWithFrame:CGRectMake(17, 17, 96, 93)];
        imgViewUser.backgroundColor = [UIColor clearColor];
        imgViewUser.image = [UIImage imageNamed:@"user.png"];
        [scrlView addSubview:imgViewUser];

        UILabel *lblUserName = [[UILabel alloc] initWithFrame:CGRectMake(115, 20, 170, 21)];
        lblUserName.backgroundColor = [UIColor clearColor];
        lblUserName.text = @"Addison Amon";
        lblUserName.textAlignment = NSTextAlignmentLeft;
        lblUserName.textColor = [UIColor colorWithRed:57/255.0 green:94/255.0 blue:254/255.0 alpha:1.0];
        lblUserName.font = [UIFont fontWithName:@"Helvetica" size:16.0];
        [scrlView addSubview:lblUserName];
        
        UIButton *btnEmail = [UIButton buttonWithType:UIButtonTypeCustom];
        btnEmail.frame=CGRectMake(115,44,186,29);
        btnEmail.backgroundColor=[UIColor clearColor];
        [btnEmail setTitle:@"addison@yahoo.com" forState:UIControlStateNormal];
        btnEmail.titleLabel.textColor = [UIColor colorWithRed:31/255.0 green:31/255.0 blue:31/255.0 alpha:1.0];
        [scrlView addSubview:btnEmail];
        
        UIButton *btnPhone = [UIButton buttonWithType:UIButtonTypeCustom];
        btnPhone.frame=CGRectMake(120,76,186,29);
        btnPhone.backgroundColor=[UIColor whiteColor];
        [btnPhone setTitle:@" 0000 000 0000" forState:UIControlStateNormal];
        btnPhone.titleLabel.textColor = [UIColor colorWithRed:144/255.0 green:144/255.0 blue:136/255.0 alpha:1];
        [scrlView addSubview:btnPhone];
        
        UIImageView *imgViewBig = [[UIImageView alloc] initWithFrame:CGRectMake(8, 134, 304, 254)];
        imgViewBig.backgroundColor = [UIColor whiteColor];
        imgViewBig.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
        imgViewBig.layer.borderWidth=0.75;
        [scrlView addSubview:imgViewBig];
        
        UILabel *lblUserCity = [[UILabel alloc] initWithFrame:CGRectMake(20, 151, 273, 23)];
        lblUserCity.backgroundColor = [UIColor clearColor];
        lblUserCity.text = @"New York";
        lblUserCity.textAlignment = NSTextAlignmentLeft;
        lblUserCity.textColor = [UIColor colorWithRed:144/255.0 green:144/255.0 blue:136/255.0 alpha:1];
        lblUserCity.font = [UIFont fontWithName:@"Helvetica" size:17.0];
        [scrlView addSubview:lblUserCity];

        UIImageView *imgViewGreyLine1 = [[UIImageView alloc] initWithFrame:CGRectMake(8, 182, 304, 2)];
        imgViewGreyLine1.backgroundColor = [UIColor clearColor];
        imgViewGreyLine1.image = [UIImage imageNamed:@"grey_line.png"];
        [scrlView addSubview:imgViewGreyLine1];
        
        UILabel *lblUserState = [[UILabel alloc] initWithFrame:CGRectMake(20, 192, 273, 23)];
        lblUserState.backgroundColor = [UIColor clearColor];
        lblUserState.text = @"United States";
        lblUserState.textAlignment = NSTextAlignmentLeft;
        lblUserState.textColor = [UIColor colorWithRed:144/255.0 green:144/255.0 blue:136/255.0 alpha:1];
        lblUserState.font = [UIFont fontWithName:@"Helvetica" size:17.0];
        [scrlView addSubview:lblUserState];
        
        UIImageView *imgViewGreyLine2 = [[UIImageView alloc] initWithFrame:CGRectMake(8, 224, 304, 2)];
        imgViewGreyLine2.backgroundColor = [UIColor clearColor];
        imgViewGreyLine2.image = [UIImage imageNamed:@"grey_line.png"];
        [scrlView addSubview:imgViewGreyLine2];

        UILabel *lblUserAddress = [[UILabel alloc] initWithFrame:CGRectMake(20, 235, 273, 23)];
        lblUserAddress.backgroundColor = [UIColor clearColor];
        lblUserAddress.text = @"350 Fifth Avenue, 34th floor";
        lblUserAddress.textAlignment = NSTextAlignmentLeft;
        lblUserAddress.textColor = [UIColor colorWithRed:144/255.0 green:144/255.0 blue:136/255.0 alpha:1];
        lblUserAddress.font = [UIFont fontWithName:@"Helvetica" size:17.0];
        [scrlView addSubview:lblUserAddress];
        
        UIImageView *imgViewGreyLine3 = [[UIImageView alloc] initWithFrame:CGRectMake(8, 269, 304, 2)];
        imgViewGreyLine3.backgroundColor = [UIColor clearColor];
        imgViewGreyLine3.image = [UIImage imageNamed:@"grey_line.png"];
        [scrlView addSubview:imgViewGreyLine3];

        UILabel *lblUserZipCode = [[UILabel alloc] initWithFrame:CGRectMake(20, 281, 273, 23)];
        lblUserZipCode.backgroundColor = [UIColor clearColor];
        lblUserZipCode.text = @"12580-2568";
        lblUserZipCode.textAlignment = NSTextAlignmentLeft;
        lblUserZipCode.textColor = [UIColor colorWithRed:144/255.0 green:144/255.0 blue:136/255.0 alpha:1];
        lblUserZipCode.font = [UIFont fontWithName:@"Helvetica" size:17.0];
        [scrlView addSubview:lblUserZipCode];
        
        UIImageView *imgViewGreyLine4 = [[UIImageView alloc] initWithFrame:CGRectMake(8, 314, 304, 2)];
        imgViewGreyLine4.backgroundColor = [UIColor clearColor];
        imgViewGreyLine4.image = [UIImage imageNamed:@"grey_line.png"];
        [scrlView addSubview:imgViewGreyLine4];

        UIButton *btnContact = [UIButton buttonWithType:UIButtonTypeCustom];
        btnContact.frame=CGRectMake(92,328,128,44);
        btnContact.backgroundColor=[UIColor whiteColor];
        [btnContact setBackgroundImage:[UIImage imageNamed:@"login_btn_sc.png"] forState:UIControlStateNormal];
        btnContact.titleLabel.font = [UIFont fontWithName:@"Helvetica" size:13.0];
        [btnContact setTitle:[AppDelegate sharedDelegate].strTitle forState:UIControlStateNormal];
        btnContact.titleLabel.textColor = [UIColor whiteColor];
        [scrlView addSubview:btnContact];
    }
    return self;
}

-(void)popToView
{
    if([self.delegate respondsToSelector:@selector(btnBackClicked)])
    {
        [self.delegate btnBackClicked];
    }
}

@end
