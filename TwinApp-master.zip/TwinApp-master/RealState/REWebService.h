//  OpenInstagramController
//  Created by Octal on 28/03/16.


#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface REWebService : NSObject
{
    
}

+ (void)CallRegistrationWithImage:(NSMutableDictionary *)dict image:(UIImage *)image withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)CallLogout:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)CallEnableDisablePush:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)CallFavouriteHomeEmails:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)CallSendFeedback:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)CallGetTermsAndCondition:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)CallGetPrivacyPolicy:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)CallGetPropertDataFromServer:(NSMutableDictionary *)dict :(UIViewController *)view :(UIView *)subview withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;


+ (void)CallGetPropertCountFromServer:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)CallGetParticularPropertyDetail:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)CallGetShowingDetail:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)CallGetFavouriteProperties:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)addFavouriteProperties:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)deleteFavouriteProperties:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)propertyListingWithPaging:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)savedSearch:(NSMutableDictionary *)dict image:(UIImage *)image withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;


+ (void)GetsavedSearchList:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)GetParticularSavedSearch:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)CallDrawServiceFromServer:(NSMutableDictionary *)dict :(UIViewController *)view :(UIView *)subview withBlock:(void (^)(NSDictionary * dictResult, NSError *error))block;


+ (void)CallSearchWithTextWithPaging:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)userRelatedData:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)showingProperty:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)disclaimerDetailFromServer:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)userRelatedShowingData:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;


+ (void)showingDataAccordingToLoginUser:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)addShowingWithData:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)addNoteProperty:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)addImageProperty:(NSMutableDictionary *)dict image:(UIImage *)image withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)checkPropertyIdExistInDb:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)myAgentList:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)AssignedAgentList:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)sendMailToUsers:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)getUserProfile:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)UpdateUserProfile:(NSMutableDictionary *)dict image:(UIImage *)image withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)developmentOnOff:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)deleteSaveSeraches:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)showFavoriteOnMap:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

+ (void)editConnectedClient:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;







@end
