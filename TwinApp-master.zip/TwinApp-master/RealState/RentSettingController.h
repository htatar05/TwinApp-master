//
//  RentSettingController.h
//  RealEstate_App
//
//  Created by Octal on 06/09/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "BSKeyboardControls.h"

@interface RentSettingController : UIViewController<BSKeyboardControlsDelegate,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate>
{
    AppDelegate * _delegate;
    IBOutlet UILabel *lblTotalCount;
    IBOutlet UISegmentedControl *bedSegment;
    IBOutlet UISegmentedControl *bathroomSegment;
    IBOutlet UITextField *txtLocation;
    IBOutlet UITextField *txtSearchByKeywords;
    IBOutlet UISwitch *recentlyRentSwitch;
    BSKeyboardControls *keyboardControls;
    NSString *strPickerType;
    NSString *PickerSubType;
    
    __weak IBOutlet UIPickerView *Picker;
    __weak IBOutlet UIView *viewSelect;
    
    IBOutlet UILabel *lblPropertyType;
    IBOutlet UILabel *lblSquareFeet;
    IBOutlet UILabel *lblPetPolicy;
    IBOutlet UILabel *lblLotSize;
    IBOutlet UILabel *lblYearBuild;
    IBOutlet UILabel *lblDaysOnMarket;
    IBOutlet UILabel *lblPickerTitle;
    IBOutlet UISegmentedControl *acresSegment;
    
    IBOutlet UIView *txtSearchKeywordsView;
    IBOutlet UIButton *btnSearchKeyDelete;
    
    IBOutlet UIView *txtLocationView;
    IBOutlet UIButton *btnLocationDelete;
    
}
@property (nonatomic, strong) DBManager *dbManager;
@property (nonatomic, strong) NSArray *propertyDetail;
@property (nonatomic, strong) NSString *strLat1;
@property (nonatomic, strong) NSString *strLat2;
@property (nonatomic, strong) NSString *strLat3;
@property (nonatomic, strong) NSString *strLat4;

@property (weak, nonatomic) IBOutlet UIScrollView *myScrollView;
@end
