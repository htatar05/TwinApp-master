//
//  AllPropertySetting.h
//  RealEstate_App
//
//  Created by Octal on 25/08/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "BSKeyboardControls.h"

@interface AllPropertySetting : UIViewController<BSKeyboardControlsDelegate,UITextFieldDelegate,UIPickerViewDataSource,UIPickerViewDelegate>
{
    BOOL isListPrice;
    IBOutlet UILabel *lblTotalCount;
    IBOutlet UISegmentedControl *bedSegment;
    IBOutlet UISegmentedControl *bathroomSegment;
    AppDelegate *appDelegate;
    BSKeyboardControls *keyboardControls;
    IBOutlet UITextField *txtLocation;
    __weak IBOutlet UIPickerView *Picker;
    __weak IBOutlet UIView *viewSelect;
    NSString *strPickerType;
     NSString *PickerSubType;
    IBOutlet UILabel *lblPickerTitle;
    IBOutlet UILabel *lblPropertyType;
    IBOutlet UILabel *lblSquareFeet;
    IBOutlet UILabel *lblLotSize;
    IBOutlet UILabel *lblYearBuild;
    IBOutlet UILabel *lblDaysOnMarket;
    IBOutlet UISegmentedControl *acresSegment;
    IBOutlet UITextField *txtSearchByKeywords;
    IBOutlet UISwitch *switchForeclosures;
    IBOutlet UISwitch *switchForSale;
    IBOutlet UISwitch *switchRecentlySold;
    
    IBOutlet UIView *txtSearchKeywordsView;
    IBOutlet UIButton *btnSearchKeyDelete;
    
    IBOutlet UIView *txtLocationView;
    IBOutlet UIButton *btnLocationDelete;
   
    
}

@property (weak, nonatomic) IBOutlet UIScrollView *myScrollView;
@property (nonatomic, strong) NSString *strLat1;
@property (nonatomic, strong) NSString *strLat2;
@property (nonatomic, strong) NSString *strLat3;
@property (nonatomic, strong) NSString *strLat4;
@end
