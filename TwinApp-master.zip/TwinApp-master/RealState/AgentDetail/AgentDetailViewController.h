//
//  AgentDetailViewController.h
//  RealState
//
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AgentDetail.h"
#import "AgentDetailView.h"
#import <QuartzCore/QuartzCore.h>
#import "BSKeyboardControls.h"
#import "EGOImageView.h"
#import <MessageUI/MessageUI.h>
#import "AppDelegate.h"

@interface AgentDetailViewController : UIViewController<AgentDetailViewDelegate,UITextViewDelegate,BSKeyboardControlsDelegate,UITextFieldDelegate,MFMailComposeViewControllerDelegate>
{
    AgentDetailView *agentDetailView;
    BSKeyboardControls *keyboardControls;
    AppDelegate *delegate;
    CGFloat height;
    CGFloat ht;

    IBOutlet UIScrollView *scrlView;
    
    IBOutlet EGOImageView *imgAgent;
    IBOutlet UIImageView *imgBackground;
    IBOutlet UIImageView *imgBack1;

    IBOutlet UIImageView *imgSep1;
    IBOutlet UIImageView *imgSep2;
    IBOutlet UIImageView *imgSep3;
    IBOutlet UIImageView *imgSep4;
    IBOutlet UIImageView *imgSep5;
    IBOutlet UIImageView *imgSep6;

    IBOutlet UILabel *lblAgentName;
    IBOutlet UILabel *lblAgentEmail;
    IBOutlet UILabel *lblAgentPhone;
    IBOutlet UILabel *lblGetApproved;
    
    IBOutlet UIButton *btnHome;
    IBOutlet UIButton *btnPhone;
    IBOutlet UIButton *btnEmail;
    IBOutlet UIButton *btnSend;
    IBOutlet UIButton *btnCheck;
    IBOutlet UIButton *btnContactAgent;

    IBOutlet UILabel *lblAgetnType;
    IBOutlet UITextField *txtFieldEmail;
    IBOutlet UITextField *txtFieldPhone;
    IBOutlet UITextView *txtViewMessage;
    IBOutlet UITextView *txtViewAddress;
    AgentDetail *agentDetailTmp;
    BOOL boolKeepmeApproved;

}
@property(nonatomic,strong)AgentDetail *agentDetail;
@property(nonatomic,assign)int intType;

-(IBAction)btnBackClicked;
-(IBAction)btnApprovedClicked:(id)sender;

@end
