//  AgentDetailViewController.m
//  RealState
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "AgentDetailViewController.h"
#import "AgentListViewController.h"
#import "NSAttributedString+Attributes.h"
#import "Config.h"
#import <MessageUI/MessageUI.h>
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "Utils.h"

@interface AgentDetailViewController ()
@end

@implementation AgentDetailViewController
@synthesize agentDetail;
@synthesize intType;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    agentDetailTmp = [[AgentDetail alloc] init];
    imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    imgBackground.layer.borderWidth=0.75;
    delegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    
    
    [txtFieldEmail setValue:[UIColor colorWithRed:130/255.0 green:130/255.0 blue:130/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    [txtFieldPhone setValue:[UIColor colorWithRed:130/255.0 green:130/255.0 blue:130/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    txtViewMessage.text = @"Message";
    txtViewMessage.textColor = [UIColor colorWithRed:130/255.0 green:130/255.0 blue:130/255.0 alpha:1.0];
    
    agentDetailTmp = self.agentDetail;
    txtFieldEmail.text = [NSString stringWithFormat:@"%@",agentDetailTmp.strEmail];
    txtFieldPhone.text = [NSString stringWithFormat:@"%@",agentDetailTmp.strPhoneNo];

    
    imgAgent.placeholderImage = [UIImage imageNamed:@"upload_pic"];
    NSString *url = [NSString stringWithFormat:@"%@%@",WebserviceImageUrl, agentDetailTmp.strImage];
    imgAgent.imageURL  = [NSURL URLWithString:url];
    lblAgetnType.text = [NSString stringWithFormat:@"%@",agentDetailTmp.strName];
    
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:agentDetailTmp.strAddress];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:15.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        height=0.0;
        if(height1>30)
        {
            height=height1-30;
        }
    }
    else
    {
        UITextView *txtSavedSearch = [[UITextView alloc] init];
        txtSavedSearch.frame = CGRectMake(0, 0, 173, 30);
        txtSavedSearch.font = [UIFont fontWithName:@"Helvetica" size:15.0];
        txtSavedSearch.text = agentDetailTmp.strAddress;
        [self.view addSubview:txtSavedSearch];
        CGRect rect = txtSavedSearch.frame;
        rect.size = txtSavedSearch.contentSize;
        txtSavedSearch.frame = rect;
        height=0.0;
        if(rect.size.height>30)
            height=rect.size.height-30;
        [txtSavedSearch removeFromSuperview];
    }
    lblAgentName.text = agentDetailTmp.strName;
    lblAgentEmail.text=agentDetailTmp.strEmail;
    lblAgentPhone.text = agentDetailTmp.strPhoneNo;
    txtViewAddress.text = agentDetailTmp.strAddress;

    CGFloat yPoint1=0;
    CGFloat yPoint2=0;
    
    if(agentDetailTmp.strPhoneNo!=nil && [agentDetailTmp.strPhoneNo isEqualToString:@""])
    {
        yPoint1 = 16;
        yPoint2 = 11;
        
        if (IS_IPHONE) {
            [btnContactAgent setFrame:CGRectMake(85, 184+height-15, 154, 37)];
        }
        
        if(intType==1)
        {
            [btnContactAgent setTitle:@"Contact Client" forState:UIControlStateNormal];
            if (IS_IPHONE) {
                [btnContactAgent setFrame:CGRectMake(85, 184+height-yPoint2, 154, 37)];
            }
            
        }
        else
        {
            [btnContactAgent setTitle:@"Contact Agent" forState:UIControlStateNormal];
            if (IS_IPHONE) {
                [btnContactAgent setFrame:CGRectMake(85, 184+height-yPoint2, 154, 37)];
            }
            
        }
    }
    
    else
    {
        yPoint1 = 0;
        yPoint2 = 5;
        if(intType==1)
        {
            
            [btnContactAgent setTitle:@"Contact Client" forState:UIControlStateNormal];
            if (IS_IPHONE) {
                [btnContactAgent setFrame:CGRectMake(85, 184+height-yPoint2, 154, 37)];
            }
            
        }
        else
        {
            [btnContactAgent setTitle:@"Contact Agent" forState:UIControlStateNormal];
            if (IS_IPHONE) {
                [btnContactAgent setFrame:CGRectMake(85, 184+height-yPoint2, 154, 37)];
            }
            
        }
    }
    
    if (IS_IPHONE) {
        
        [imgAgent setFrame:CGRectMake(17, 21, 109, 121)];
        [txtViewAddress setFrame:CGRectMake(129, 79-yPoint1, 175, 30+height)];
        [imgBackground setFrame:CGRectMake(9, 12, 304, 139+height-yPoint1)];
        [btnHome setFrame:CGRectMake(133, 110+height-yPoint2, 24, 24)];
        [btnPhone setFrame:CGRectMake(162, 110+height-yPoint2, 24, 24)];
        [btnEmail setFrame:CGRectMake(191, 110+height-yPoint2, 24, 24)];
        [imgBack1 setFrame:CGRectMake(0, 246+height-yPoint2, 320, 158+43)];
        [imgSep1 setFrame:CGRectMake(0, 238+height-yPoint2, 320, 8)];
        [imgSep2 setFrame:CGRectMake(0, 282+height-yPoint2, 320, 1)];
        [imgSep3 setFrame:CGRectMake(0, 320+height-yPoint2, 320, 1)];
        [imgSep4 setFrame:CGRectMake(0, 44+381+24+height-yPoint2, 320, 1)];
        [imgSep5 setFrame:CGRectMake(0, 42+419+24+height-yPoint2, 320, 1)];
        [txtFieldEmail setFrame:CGRectMake(17, 246+height-yPoint2, 296, 36)];
        [txtFieldPhone setFrame:CGRectMake(17, 283+height-yPoint2, 296, 36)];
        [txtViewMessage setFrame:CGRectMake(11, 321+height-yPoint2, 309, 150)];
        [lblGetApproved setFrame:CGRectMake(0, 44+382+23+height-yPoint2, 320, 36)];
        [btnCheck setFrame:CGRectMake(14, 44+387+24+height-yPoint2, 24, 24)];
        [btnSend setFrame:CGRectMake(0, 44+424+24+height-yPoint2, 320, 41)];
    }
    
    if(IsRunningTallPhone())
    {
        [self.view setFrame:CGRectMake(0, 0, 320, 568)];
        [scrlView setFrame:CGRectMake(0, 44, 320, 524)];
         scrlView.contentSize=CGSizeMake(320, 550+height);
    }
    else
    {
        [self.view setFrame:CGRectMake(0, 0, 320, 480)];
        [scrlView setFrame:CGRectMake(0, 44, 320, 436)];
        [scrlView setContentSize:CGSizeMake(320, 520+height)];
    }
    
    if (!IS_IPHONE){
        
        [self.view setFrame:CGRectMake(0, 0, 768, 1024)];
        [scrlView setFrame:CGRectMake(0, 60, 768, 964)];
        [scrlView setContentSize:CGSizeMake(768, 520+height)];
    }
  
    
    [self addKeyboardControls];
}

- (CGFloat)textViewHeightForAttributedText:(NSMutableAttributedString*)text
{
    UITextView *txtSavedSearch = [[UITextView alloc] init];
    [txtSavedSearch setAttributedText:text];
    CGSize size = [txtSavedSearch sizeThatFits:CGSizeMake(173, 40)];
    return size.height;
}

#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    
    keyboardControls.textFields = [NSArray arrayWithObjects:txtFieldEmail,txtFieldPhone,txtViewMessage, nil];
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"Previous";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"Next";
    
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
        else if([textField isKindOfClass:[UITextView class]])
        {
            ((UITextView *) textField).inputAccessoryView = keyboardControls;
            ((UITextView *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] applicationFrame];
    CGFloat availableHeight = applicationFrame.size.height - 220; // Remove area covered by keyboard
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
    [scrlView setContentOffset:CGPointMake(0, y) animated:YES];
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    [controls.activeTextField resignFirstResponder];
    [scrlView setContentOffset:CGPointMake(0, 0) animated:YES];
}

- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}

#pragma mark TextField Delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([keyboardControls.textFields containsObject:textField])
        keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    return YES;
}

#pragma mark TextView Delegate
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    const CGFloat *components = CGColorGetComponents(txtViewMessage.textColor.CGColor);
    NSString *red = [NSString stringWithFormat:@"%f", components[0]] ;
    NSString *green = [NSString stringWithFormat:@"%f", components[1]] ;
    NSString *blue = [NSString stringWithFormat:@"%f", components[2]] ;
    NSString *alpha = [NSString stringWithFormat:@"%f", components[3]] ;

    if ([red isEqualToString:@"0.509804"] && [green isEqualToString:@"0.509804"] && [blue isEqualToString:@"0.509804"] && [alpha isEqualToString:@"1.000000"])
    {
        txtViewMessage.text = @"";
        txtViewMessage.textColor = [UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1.0];
    }
}

-(BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    if ([keyboardControls.textFields containsObject:textView])
        keyboardControls.activeTextField = textView;
    
    [self scrollViewToCenterOfScreen:textView];
    return YES;
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
   
}

-(void) textViewDidChange:(UITextView *)textView
{
    if(txtViewMessage.text.length == 0)
    {
        txtViewMessage.textColor = [UIColor colorWithRed:130/255.0 green:130/255.0 blue:130/255.0 alpha:1.0];
        txtViewMessage.text = @"Message";

    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
   if([textField isEqual:txtFieldPhone])
    {
        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init] ;
        if([string length]==0)
        {
            [formatter setGroupingSeparator:@"-"];
            [formatter setGroupingSize:4];
            [formatter setUsesGroupingSeparator:YES];
            [formatter setSecondaryGroupingSize:3];
            NSString *num = textField.text ;
            num= [num stringByReplacingOccurrencesOfString:@"-" withString:@""];
            NSString *str = [formatter stringFromNumber:[NSNumber numberWithDouble:[num doubleValue]]];
            
            textField.text=str;
            NSLog(@"%@",str);
            return YES;
        }
        else {
            [formatter setGroupingSeparator:@"-"];
            [formatter setGroupingSize:3];
            [formatter setUsesGroupingSeparator:YES];
            [formatter setSecondaryGroupingSize:3];
            NSString *num = textField.text ;
            if(![num isEqualToString:@""])
            {
                num= [num stringByReplacingOccurrencesOfString:@"-" withString:@""];
                NSString *str = [formatter stringFromNumber:[NSNumber numberWithDouble:[num doubleValue]]];
                
                textField.text=str;
            }
            
            return YES;
        }
    }
    return YES;
}

-(IBAction)btnApprovedClicked:(id)sender
{
	if (boolKeepmeApproved)
    {
		boolKeepmeApproved=FALSE;
		[btnCheck setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
	}
	else
	{
        boolKeepmeApproved=TRUE;
		[btnCheck setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
	}
}

-(IBAction)btnBackClicked
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


-(void)ShareViaMail
{
    if ([MFMailComposeViewController canSendMail])
    {
        NSString *emailTitle = @"I am a fan of the Twin Realty app";
        NSString *messageBody = @"I am a very happy user of the Twin Realty app.It is effective and so convenient! Give it a try too! Check out www.twinrealty.com to get started.";
        MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
        mc.mailComposeDelegate = self;
        [mc setSubject:emailTitle];
        [mc setMessageBody:messageBody isHTML:NO];
        [self presentViewController:mc animated:YES completion:NULL];
    }
    else
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Twin Realty" message:@"You must have your Mail account configured in Device Settings" preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:ok];
        [self presentViewController:alertController animated:YES completion:nil];
        
    }
    
}

/*
- (void)messageComposeViewController:
(MFMessageComposeViewController *)controller
                 didFinishWithResult:(MessageComposeResult)result
{
    switch (result)
    {
        case MessageComposeResultCancelled:
            NSLog(@"Cancelled");
            break;
        case MessageComposeResultFailed:
            NSLog(@"Failed");
            break;
        case MessageComposeResultSent:
            break;
        default:
            break;
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}
*/

-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    if (error) {

        [self dismissViewControllerAnimated:YES completion:nil];
    }
    else {
        //[self dismissModalViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

# pragma  mark Actions
-(IBAction)btnHomeClicked:(id)sender
{
    
}
-(IBAction)btnPhoneClicked:(id)sender
{
    NSString *str = [NSString stringWithFormat:@"Call %@ ?",agentDetailTmp.strPhoneNo];
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:str message:@"" preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"Yes" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self makeCall];
    }]];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self closeAlertview];
    }]];
    
    dispatch_async(dispatch_get_main_queue(), ^ {
        [self presentViewController:alertController animated:YES completion:nil];
    });

}
-(IBAction)btnEmailClicked:(id)sender
{
    [self ShareViaMail];
}
-(IBAction)btnSendClicked:(id)sender
{
    [MBProgressHUD showHUDAddedTo:delegate.window animated:YES];
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:agentDetailTmp.strEmail forKey:@"to_email"];
    [dataDict setValue:txtViewMessage.text forKey:@"msg"];
    [dataDict setValue:agentDetailTmp.strId forKey:@"to_id"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults]valueForKey:@"RoleId"] forKey:@"role_id"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"sender_id"];
    [REWebService sendMailToUsers:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        NSLog(@"%@",dictResult);
        [MBProgressHUD hideAllHUDsForView:delegate.window animated:YES];
        if (!error) {
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]) {
                
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
            } else {
                
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                
            }
            
            
        }
        
        
    }];


}

-(void)closeAlertview
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)makeCall
{
    NSString *URLString = [@"tel://" stringByAppendingString:agentDetailTmp.strPhoneNo];
    NSURL *URL = [NSURL URLWithString:URLString];
    [[UIApplication sharedApplication] openURL:URL];
}
@end
