//  AskForLoginViewController.m
//  RealState
//  Created by Kapil Goyal on 27/08/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "AskForLoginViewController.h"
#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "PropertyDetailViewController.h"
#import "AgentDetailViewController.h"
#import "SavedSearchPropertyViewController.h"
#import "AddShowingViewController.h"
#import "DevelopmentDetaillViewController.h"

@interface AskForLoginViewController ()
@end

@implementation AskForLoginViewController

- (void)viewDidLoad
{
    [super viewDidLoad];   
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    [UIApplication sharedApplication].statusBarHidden = YES;
    self.navigationController.navigationBarHidden=YES;
    service = [[RealEstateService alloc] init];
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        [imgHeaderView setFrame:CGRectMake(0, 0, 320, 44)];
        [imgInnerView setFrame:CGRectMake(65, 6, 31, 31)];
        [lblName setFrame:CGRectMake(95, 9, 155, 26)];
    }
    else
    {
        [imgHeaderView setFrame:CGRectMake(0, 0, 320, 44)];
        [imgInnerView setFrame:CGRectMake(65, 6, 31, 31)];
        [lblName setFrame:CGRectMake(95, 9, 155, 26)];
    }
    BOOL loginStatus = [[NSUserDefaults standardUserDefaults] boolForKey:@"loginstatus"];
    if(loginStatus)
    {
        [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
        [service LoginInvocation:[[NSUserDefaults standardUserDefaults] objectForKey:@"email"] password:[[NSUserDefaults standardUserDefaults] objectForKey:@"password"] deviceToken:@"0" deviceType:@"0" delegate:self];
    }
}

-(void)LoginInvocationDidFinish:(LoginInvocation*)invocation withResults:(NSString*)result withError:(NSError*)error
{
	if(!error)
    {
		if([result isEqualToString:@"success"])
        {
          [self navigateToMapView];
        }
        [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
    }
}

-(void)navigateToMapView
{
    if (IS_IPHONE) {
        MainViewController *main = [[MainViewController alloc] initWithNibName:@"MainViewController_iPhone" bundle:nil];
        [self.navigationController pushViewController:main animated:YES];
    } else {
        MainViewController *main = [[MainViewController alloc] initWithNibName:@"MainViewController_iPad" bundle:nil];
        [self.navigationController pushViewController:main animated:YES];
    }
    
}
    
-(IBAction)btnLoginClicked
{
    appDelegate.boolLogin=TRUE;
    appDelegate.boolLoginNotNow=FALSE;
    appDelegate.boolLoginPresent=FALSE;
    
    if (IS_IPHONE) {
        
        LoginViewController *login = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPhone" bundle:nil];
        [self.navigationController pushViewController:login animated:YES];
        
    } else {
        LoginViewController *login = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPad" bundle:nil];
        [self.navigationController pushViewController:login animated:YES];
    }
    
}

-(IBAction)btnNotNowClicked
{
    appDelegate.boolLoginNotNow=TRUE;
    appDelegate.boolLogin=FALSE;
    appDelegate.boolLoginPresent=FALSE;
    [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"RoleId"];
    
    if (IS_IPHONE) {
        
        MainViewController *main = [[MainViewController alloc] initWithNibName:@"MainViewController_iPhone" bundle:nil];
        [self.navigationController pushViewController:main animated:YES];
        
    } else {
        
        MainViewController *main = [[MainViewController alloc] initWithNibName:@"MainViewController_iPad" bundle:nil];
        [self.navigationController pushViewController:main animated:YES];
        
    }
    
}

-(IBAction)btnRegisterClicked
{
    if (IS_IPHONE) {
        
        RegisterViewController *register1 = [[RegisterViewController alloc] initWithNibName:@"RegisterViewController_iPhone" bundle:nil];
        register1.isFromRegister = @"Yes";
        [self.navigationController pushViewController:register1 animated:YES];
        
    } else {
        
        RegisterViewController *register1 = [[RegisterViewController alloc] initWithNibName:@"RegisterViewController_iPad" bundle:nil];
        register1.isFromRegister = @"Yes";
        [self.navigationController pushViewController:register1 animated:YES];
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
