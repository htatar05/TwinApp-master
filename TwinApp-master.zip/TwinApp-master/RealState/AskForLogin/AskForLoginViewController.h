//  AskForLoginViewController.h
//  RealState
//  Created by Kapil Goyal on 27/08/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "MBProgressHUD.h"
#import "LoginInvocation.h"
#import "RealEstateService.h"
#import "MainViewController.h"

@interface AskForLoginViewController : UIViewController<LoginInvocationDelegate>
{
    AppDelegate *appDelegate;
    RealEstateService *service;
    IBOutlet UIImageView *imgHeaderView;
    IBOutlet UIImageView *imgInnerView;
    IBOutlet UILabel *lblName;
}

-(IBAction)btnLoginClicked;
-(IBAction)btnNotNowClicked;
-(IBAction)btnRegisterClicked;

@end
