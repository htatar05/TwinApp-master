//  SoldSettingController.h
//  RealEstate_App
//  Created by Octal on 20/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "BSKeyboardControls.h"
#import "DBManager.h"

@interface SoldSettingController : UIViewController<BSKeyboardControlsDelegate,UITextFieldDelegate,UIActionSheetDelegate,UIPickerViewDataSource,UIPickerViewDelegate>
{
    
    AppDelegate * _delegate;
    IBOutlet UILabel *lblTotalCount;
    IBOutlet UISegmentedControl *bedSegment;
    IBOutlet UISegmentedControl *bathroomSegment;
    BSKeyboardControls *keyboardControls;
    IBOutlet UITextField *txtLocation;
    IBOutlet UIButton *btnForclosures;
    IBOutlet UILabel *lblPropertyType;
    IBOutlet UILabel *lblSquareFeet;
    __weak IBOutlet UIPickerView *Picker;
    __weak IBOutlet UIView *viewSelect;
    IBOutlet UILabel *lblPickerTitle;
    IBOutlet UISegmentedControl *acresSegment;
    NSArray *dataDuplicate;
    IBOutlet UILabel *lblLotSize;
    IBOutlet UILabel *lblYearBuild;
    IBOutlet UILabel *lblDaysOnMarket;
    IBOutlet UITextField *txtSearchByKeywords;
    
    IBOutlet UIView *txtSearchKeywordsView;
    IBOutlet UIButton *btnSearchKeyDelete;
    
    IBOutlet UIView *txtLocationView;
    IBOutlet UIButton *btnLocationDelete;

}

@property (weak, nonatomic) IBOutlet UIScrollView *myScrollView;
@property (nonatomic, strong) NSString *strLat1;
@property (nonatomic, strong) NSString *strLat2;
@property (nonatomic, strong) NSString *strLat3;
@property (nonatomic, strong) NSString *strLat4;
@property (nonatomic, strong) DBManager *dbManager;

@end
