//
//  LayerViewController.h
//  RealState
//
//  Created by Kapil Goyal on 11/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface LayerViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    IBOutlet UIView *viewLayer;
    IBOutlet UIView *viewTmp;

    LayerViewController *layer;
    NSMutableArray *arrMapType;
    IBOutlet UITableView *tblMapType;
    NSMutableDictionary * dictCheck;
    UILabel *lblMapType;
    NSIndexPath *ipath;
    AppDelegate *appdelegate;
    UIImageView *imgCheck;
    NSArray *arrayFav;
    IBOutlet UISwitch *switchLayer;
}

-(IBAction)btnApplyClicked;
-(IBAction)btnDevelopmentClicked:(id)sender;
@end



