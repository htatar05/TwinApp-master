//  LayerViewController.m
//  RealState
//  Created by Kapil Goyal on 11/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "LayerViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "LayerTvCellView.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "Utils.h"

@interface LayerViewController ()

@end

@implementation LayerViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    viewTmp.layer.borderWidth=0.5;
    viewTmp.layer.borderColor = [[UIColor lightGrayColor] CGColor];
    arrMapType = [[NSMutableArray alloc] initWithObjects:@"Earth View",@"Satelite View", @"Hybrid View", nil];
    dictCheck = [[NSMutableDictionary alloc] init];
    appdelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    [self getDevelopmentLayerStatus];
    if (IS_IPHONE) {
        
        if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
        {
            [switchLayer setFrame:CGRectMake(260, 11, 51, 31)];
        }
        else
        {
            [switchLayer setFrame:CGRectMake(238, 11, 51, 31)];
        }
    }
    
    
    for (int j=0;j<[arrMapType count];j++)
    {
        [dictCheck setValue:@"0" forKey:[NSString stringWithFormat:@"%d",j]];
    }
}

-(IBAction)btnApplyClicked
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(IBAction)btnDevelopmentClicked:(id)sender
{
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| appdelegate.loginUser)
    {
         NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
        [dataDict setValue:[[[NSUserDefaults standardUserDefaults]objectForKey:@"userData"] objectForKey:@"user_id"] forKey:@"user_id"];
        if (switchLayer.on){
           [dataDict setValue:@"1" forKey:@"development_on"];
        } else {
             [dataDict setValue:@"2" forKey:@"development_on"];
        }
        [MBProgressHUD showHUDAddedTo:appdelegate.window animated:YES];
        [REWebService developmentOnOff:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self->appdelegate.window animated:YES];
            NSLog(@"%@",dictResult);
            if (!error) {
                
                if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"])
                {
                    if ([[[dictResult valueForKey:@"response"] valueForKey:@"msg"]isEqualToString:@"off."]){
                        self->switchLayer.on = NO;
                    }else{
                        
                        self->switchLayer.on = YES;
                    }
                    
                } else
                {
                    [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"message"]];
                }
            }
        }];
        
        
        
    }
    else{
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please Login First."];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    LayerTvCellView *cell = (LayerTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
            
            view =[[UIViewController alloc] initWithNibName:@"LayerTvCellView_iPhone" bundle:nil];
        } else {
            
             view=[[UIViewController alloc] initWithNibName:@"LayerTvCellView_iPad" bundle:nil];
        }
        cell=(LayerTvCellView *)view.view;
    }
    cell.tag = indexPath.row;
    cell.lblMapType.text = [arrMapType objectAtIndex:indexPath.row];
    int intValue = [[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"c%ld",(long)indexPath.row]] intValue];
    if ([[dictCheck valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] isEqualToString:@"1"] || intValue==1)
    {
        cell.imgCheck.image = [UIImage imageNamed:@"blue_tick.png"];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    LayerTvCellView *cell = (LayerTvCellView*)[tblMapType cellForRowAtIndexPath:indexPath];
    ipath = [tblMapType indexPathForCell:cell];
    
    NSArray *arrKeys = [dictCheck allKeys];
    for (int i=0; i<[arrKeys count]; i++)
    {
        if([[arrKeys objectAtIndex:i] isEqualToString:[NSString stringWithFormat:@"%ld",(long)ipath.row]])
        {
            [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:[NSString stringWithFormat:@"c%d",i]];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [dictCheck setValue:@"1" forKey:[NSString stringWithFormat:@"%d",i]];
        }
        else
        {
            [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:[NSString stringWithFormat:@"c%d",i]];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [dictCheck setValue:@"0" forKey:[NSString stringWithFormat:@"%d",i]];
        }
    }
    [[NSUserDefaults standardUserDefaults]setValue:[arrMapType objectAtIndex:indexPath.row] forKey:@"MapType"];
    [tblMapType deselectRowAtIndexPath:indexPath animated:YES];
    [self performSelector:@selector(LoadData) withObject:nil afterDelay:0.2];
}

-(void)LoadData
{
    [tblMapType reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)getDevelopmentLayerStatus
{
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| appdelegate.loginUser)
    {
       [MBProgressHUD showHUDAddedTo:appdelegate.window animated:YES];
       NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
       [dataDict setValue:[[[NSUserDefaults standardUserDefaults]objectForKey:@"userData"] objectForKey:@"user_id"] forKey:@"user_id"];
       [REWebService developmentOnOff:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
           [MBProgressHUD hideAllHUDsForView:self->appdelegate.window animated:YES];
        NSLog(@"%@",dictResult);
           
            if (!error) {
                
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"])
            {
                if ([[[dictResult valueForKey:@"response"] valueForKey:@"msg"]isEqualToString:@"off."]){
                    
                    self->switchLayer.on = NO;
                    
                }else{
                    self->switchLayer.on = YES;
                }
                
            } else
            {
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"message"]];
            }
                
                
                
            }
            
            
            
        }];
        
    }
    else
    {
        switchLayer.on = NO;
        switchLayer.userInteractionEnabled = NO;
    }
    
    

}

@end
