//  PropertyListingVC.m
//  RealEstate_App
//  Created by Octal on 13/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.


#import "PropertyListingVC.h"
#import "PropertyTvCellView.h"
#import "PropertyDetail.h"
#import "UIImageView+UIActivityIndicatorForSDWebImage.h"
#import "UIImageView+HighlightedWebCache.h"
#import "PropertyDetailViewController.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "Utils.h"
#import "JSON.h"
#import "SortViewController.h"
#import "SavedSearchViewController.h"
#import "LoginViewController.h"
#import "MainViewController.h"
#import "AllPropertySetting.h"
#import "SaleSettingController.h"
#import "RentSettingController.h"
#import "SoldSettingController.h"
#import "DisclaimerVC.h"
#import "SRRefreshView.h"


@interface PropertyListingVC ()<SRRefreshDelegate>

@end

@implementation PropertyListingVC
{
    SRRefreshView   *_slimeView;
    NSString *strStatus;
    NSArray *dataDuplicate;
    NSString *salePriceMin;
    NSString *salePriceMax;
    NSString *rentPriceMin;
    NSString *rentPriceMax;
    NSString *fullAddress;
    NSString *totalBaths;
    NSString *totalBeds;
    NSString *propertyType;
    NSString *squareFeetMin;
    NSString *squareFeetMax;
    NSString *foreclosedyn;
    NSString *shortSale;
    NSString *strPetPolicy;
    NSString *lotSquareMin;
    NSString *lotSquareMax;
    NSString *lotAcreMin;
    NSString *lotAcreMax;
    NSString *yearBuiltMin;
    NSString *yearBuiltMax;
    NSString *daysOnMarket;
    NSString *strProprtyCount;
    NSString *SearchByKeyword;
    NSMutableString *typeOfProperty;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    countAvail = 0;
    [self addKeyboardControls];
    UILabel * leftView = [[UILabel alloc] initWithFrame:CGRectMake(10,0,7,26)];
    leftView.backgroundColor = [UIColor clearColor];
    txtSearch.leftView = leftView;
    txtSearch.leftViewMode = UITextFieldViewModeAlways;
    txtSearch.delegate = self;
    txtSearch.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"RealEstate.sqlite"];
    
    
    refreshControl = [[UIRefreshControl alloc]init];
    refreshControl.backgroundColor = [UIColor whiteColor];
    [tblListing addSubview:refreshControl];
    refreshControl.tintColor = [UIColor lightGrayColor];
    [refreshControl addTarget:self action:@selector(pullToRefresh) forControlEvents:UIControlEventValueChanged];
    propertyDataArr = [[NSMutableArray alloc]init];
    
   /*
    _slimeView = [[SRRefreshView alloc] init];
    _slimeView.delegate = self;
    _slimeView.slimeMissWhenGoingBack = YES;
    _slimeView.slime.bodyColor = [UIColor lightGrayColor];
    _slimeView.slime.skinColor = [UIColor whiteColor];
    _slimeView.slime.lineWith = 1;
    _slimeView.slime.shadowBlur = 4;
    _slimeView.slime.shadowColor = [UIColor blackColor];
    
    CGRect bounds = self.view.bounds;
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, bounds.size.width, 40)];
    headerView.backgroundColor = [UIColor redColor];
    tblListing.tableHeaderView = headerView;
    tblListing.autoresizingMask = UIViewAutoresizingFlexibleWidth| UIViewAutoresizingFlexibleHeight;
    [tblListing addSubview:_slimeView];
    tblListing.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    [_slimeView update:64];
    */
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}
-(void)viewWillAppear:(BOOL)animated
{
    [tblListing reloadData];
    strPagingId = @"0";
    [self getSavedValueFromDatabase];

}

#pragma mark Actions

-(IBAction)sortOrderSelected:(id)sender
{
    if (IS_IPHONE) {
        SortViewController*sort = [[SortViewController alloc]initWithNibName:@"SortViewController_iPhone" bundle:nil];
        sort.selectedOrder = [[NSUserDefaults standardUserDefaults]valueForKey:@"SortOrder"];
        [self.navigationController presentViewController:sort animated:YES completion:nil];
    } else {
        SortViewController*sort = [[SortViewController alloc]initWithNibName:@"SortViewController_iPad" bundle:nil];
        sort.selectedOrder = [[NSUserDefaults standardUserDefaults]valueForKey:@"SortOrder"];
        [self.navigationController presentViewController:sort animated:YES completion:nil];
    }
    
}

-(IBAction)saveSearchSelected:(id)sender
{
    [Utils showAlertMessage:@"Twin Realty" Message:@"Under Development"];
    
    
    
    /*
    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| appDelegate.loginUser)
    {
        SavedSearchViewController *savedSearchVc = [[SavedSearchViewController alloc] initWithNibName:@"SavedSearchViewController_iPhone" bundle:nil];
        savedSearchVc.strPnCount = self.propertyAvail;
        savedSearchVc.parameterDict = self.param;
        [self.navigationController pushViewController:savedSearchVc animated:YES];
        
    } else
    {
        LoginViewController* loginVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPhone" bundle:nil];
        [self.navigationController presentViewController:loginVC animated:YES completion:nil];
    }
     */
    
}
-(IBAction)mapButtonSelected:(id)sender
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

-(IBAction)backButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)buttonFilterTaped:(id)sender
{
    NSLog(@"filter");
    if ([self.selectedType isEqualToString:@"All_Property"])
    {
        
        if (IS_IPHONE) {
            AllPropertySetting *allPropertyDetail = [[AllPropertySetting alloc] initWithNibName:@"AllPropertySetting" bundle:nil];
            [self.navigationController pushViewController:allPropertyDetail animated:YES];
        } else {
            AllPropertySetting *allPropertyDetail = [[AllPropertySetting alloc] initWithNibName:@"AllPropertySetting_iPad" bundle:nil];
            [self.navigationController pushViewController:allPropertyDetail animated:YES];
        }
        
    }
    else if ([self.selectedType isEqualToString:@"For_Rent"])
    {
        
        if (IS_IPHONE) {
            RentSettingController *rentSetting = [[RentSettingController alloc] initWithNibName:@"RentSettingController" bundle:nil];
            [self.navigationController pushViewController:rentSetting animated:YES];
        } else {
            RentSettingController *rentSetting = [[RentSettingController alloc] initWithNibName:@"RentSettingController_iPad" bundle:nil];
            [self.navigationController pushViewController:rentSetting animated:YES];
        }
        
    }
    else if ([self.selectedType isEqualToString:@"For_Sold"])
    {
        if (IS_IPHONE) {
            SoldSettingController *soldSettings = [[SoldSettingController alloc]initWithNibName:@"SoldSettingController" bundle:nil];
            [self.navigationController pushViewController:soldSettings animated:YES];
        } else {
            SoldSettingController *soldSettings = [[SoldSettingController alloc]initWithNibName:@"SoldSettingController_iPad" bundle:nil];
            [self.navigationController pushViewController:soldSettings animated:YES];
        }
        
    }
    else
    {
        if (IS_IPHONE) {
            SaleSettingController *saleSetting = [[SaleSettingController alloc] initWithNibName:@"SaleSettingController" bundle:nil];
            [self.navigationController pushViewController:saleSetting animated:YES];
        } else {
            SaleSettingController *saleSetting = [[SaleSettingController alloc] initWithNibName:@"SaleSettingController_iPad" bundle:nil];
            [self.navigationController pushViewController:saleSetting animated:YES];
        }
        
    }
    
    
}
# pragma mark Table View Delegate and datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return propertyDataArr.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
        static NSString *CellIdentifier = @"Cell";
        PropertyTvCellView *cell = (PropertyTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            UIViewController *view;
            if (IS_IPHONE) {
                
                view = [[UIViewController alloc]initWithNibName:@"PropertyTvCellView_iPhone" bundle:nil];
            } else {
                
               view = [[UIViewController alloc]initWithNibName:@"PropertyTvCellView_iPad" bundle:nil];
            }
            
            cell = (PropertyTvCellView *)view.view;
        }
        if (propertyDataArr.count){
            
            PropertyDetail *theProperty = [propertyDataArr objectAtIndex:indexPath.row];
            
            if ([theProperty.status isEqualToString:@"for_sale"])
            {
                cell.lblHomeType.text = @"For Sale";
                cell.lblHomeType.textColor = [UIColor colorWithRed:(38/255.f) green:(133/255.f) blue:(9/255.f) alpha:1.0f];
                cell.imgViewPropertyType.image = [UIImage imageNamed:@"for_sale"];
                NSInteger *intPrice = [theProperty.priceSale integerValue];
                NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                     numberStyle:NSNumberFormatterCurrencyStyle];
                
                NSString *newString;
                if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
                {
                    newString = [price substringFromIndex:3];
                    newString =  [newString substringToIndex:[newString length]-3];
                    
                }
                cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
                NSLog(@"Roop new %@",newString);
                
                if ([theProperty.openHouse isEqualToString:@""]) {
                    cell.lblOpenHouse.text = [NSString stringWithFormat:@"Open House Not Available"];
                } else{
                    cell.lblOpenHouse.text = [NSString stringWithFormat:@"%@",theProperty.openHouse];
                }
                
            }
            else if ([theProperty.status isEqualToString:@"for_rent"])
            {
                cell.lblHomeType.text = @"For Rent";
                cell.lblHomeType.textColor = [UIColor orangeColor];
                cell.imgViewPropertyType.image = [UIImage imageNamed:@"for_rent"];
                NSInteger *intPrice = [theProperty.priceRented integerValue];
                NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                   numberStyle:NSNumberFormatterCurrencyStyle];
                
                NSString *newString;
                if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
                {
                    newString = [price substringFromIndex:3];
                    newString =  [newString substringToIndex:[newString length]-3];
                    
                }
                cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
                
                if ([theProperty.openHouse isEqualToString:@""]) {
                    cell.lblOpenHouse.text = [NSString stringWithFormat:@"Open House Not Available"];
                } else {
                    cell.lblOpenHouse.text = [NSString stringWithFormat:@"%@",theProperty.openHouse];
                }
                
            }
            else
            {
                cell.lblHomeType.text = @"Sold";
                cell.imgViewPropertyType.image = [UIImage imageNamed:@"sold"];
                cell.lblHomeType.textColor = [UIColor redColor];
                NSInteger *intPrice = [theProperty.PriceSold integerValue];
                NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                     numberStyle:NSNumberFormatterCurrencyStyle];
                
                NSString *newString;
                if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
                {
                    newString = [price substringFromIndex:3];
                    newString =  [newString substringToIndex:[newString length]-3];
                    
                }
                cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
                
                NSString *finalDate = theProperty.dateSold;
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                NSDate *reciveDate = [dateFormatter dateFromString:finalDate];
                [dateFormatter setDateFormat:@"MMM dd, yyyy"];
                NSString *dateStr = [dateFormatter stringFromDate:reciveDate];
                cell.lblOpenHouse.text = [NSString stringWithFormat:@"Date Sold: %@",dateStr];
               
            }
            
            cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
            
            cell.imgBackground.layer.borderWidth=0.75;
            
            cell.lblSaleType.text = [NSString stringWithFormat:@"%@",theProperty.Id];
            cell.lblPhotoCount.text = [NSString stringWithFormat:@"%@ Photos",theProperty.availableImages];
            cell.lblAddress.text = [NSString stringWithFormat:@"%@",theProperty.fulladdress];
            cell.lblAddress1.text = [NSString stringWithFormat:@"%@",theProperty.fullAddress1];
            [cell.imgViewProperty setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",theProperty.imgProperty]] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            
            cell.lblListingCourtesy.text = [NSString stringWithFormat:@"%@",theProperty.listingCourtesy];
            
            if([theProperty.propClass isEqualToString:@"DOCK"]||[theProperty.propClass isEqualToString:@"LOT"]) {
                
                cell.lblBedBath.text = [NSString stringWithFormat:@"Acres  :%@ acres",theProperty.acres];
            }else
            {
                cell.lblBedBath.text = [NSString stringWithFormat:@"%@bd-%@ba %@ sq ft",theProperty.numbedrooms,theProperty.totalfullbaths,theProperty.totalfloorareasqft];
            }
            if ((indexPath.row == [propertyDataArr count]-1) && ([propertyDataArr count]<countAvail)) {
                tblListing.tableFooterView = footerView;
                lblCountShowing.text = [NSString stringWithFormat:@"%lu of %ld",(unsigned long)[propertyDataArr count],(long)countAvail];
                [self getPropertyData];

            }
        }
        return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE) {
        return 150;
    } else {
        return 170;
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 38;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    PropertyDetailViewController*detail;
    if (IS_IPHONE) {
        detail = [[PropertyDetailViewController alloc]initWithNibName:@"PropertyDetailViewController_iPhone" bundle:nil];
    } else {
        detail = [[PropertyDetailViewController alloc]initWithNibName:@"PropertyDetailViewController_iPad" bundle:nil];
    }
        PropertyDetail *theProperty = [propertyDataArr objectAtIndex:indexPath.row];
        detail.PropertyId = theProperty.Id;
        detail.totalPropertyArr = propertyDataArr;
        detail.selectedIndex = indexPath.row;
        [self.navigationController pushViewController:detail animated:YES];
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat sectionHeaderHeight = 38;
    if (scrollView.contentOffset.y<=sectionHeaderHeight&&scrollView.contentOffset.y>=0) {
        scrollView.contentInset = UIEdgeInsetsMake(-scrollView.contentOffset.y, 0, 0, 0);
    } else if (scrollView.contentOffset.y>=sectionHeaderHeight) {
        scrollView.contentInset = UIEdgeInsetsMake(-sectionHeaderHeight, 0, 0, 0);
    }
}


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 18)];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, tableView.frame.size.width, 18)];
    label.textColor = [UIColor whiteColor];
    [label setFont:[UIFont boldSystemFontOfSize:16]];
    NSString *string =[[NSUserDefaults standardUserDefaults] valueForKey:@"SortOrder"];
    [label setText:string];
    [view addSubview:label];
    
    UIButton *btnInfo = [[UIButton alloc]initWithFrame:CGRectMake(tableView.frame.size.width-40, 10, 20, 20)];
    [btnInfo setTitle:@"i" forState:UIControlStateNormal];
     btnInfo.backgroundColor = [UIColor colorWithRed:0/255.0 green:132/255.0 blue:249/255.0 alpha:1.0];
     btnInfo.layer.cornerRadius  = 10;
    [[btnInfo layer] setBorderWidth:1.0f];
     btnInfo.titleLabel.font = [UIFont systemFontOfSize:14];
    [[btnInfo layer] setBorderColor:[UIColor whiteColor].CGColor];
    [btnInfo addTarget:self action:@selector(disclaimerScreen) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:btnInfo];
    [view setBackgroundColor:[UIColor colorWithRed:0/255.0 green:132/255.0 blue:249/255.0 alpha:1.0]];
    return view;
    
}

-(void)disclaimerScreen
{
    DisclaimerVC *disclaimer;
    if (IS_IPHONE) {
        disclaimer = [[DisclaimerVC alloc] initWithNibName:@"DisclaimerVC" bundle:nil];
    } else {
        disclaimer = [[DisclaimerVC alloc] initWithNibName:@"DisclaimerVC_iPad" bundle:nil];
    }
    
    if (self.infoArray.count)
    {
        disclaimer.isCountAvail = @"Yes";
    }
    else
    {
        disclaimer.isCountAvail = @"No";
    }
    disclaimer.feedArray = self.infoArray;
    [self.navigationController pushViewController:disclaimer animated:YES];

}
-(void)getPropertyData
{
    NSString *strLat1 = [self.param valueForKey:@"latitude1"];
    NSString *strLat2 = [self.param valueForKey:@"longitude1"];
    NSString *strLat3 = [self.param valueForKey:@"latitude2"];
    NSString *strLat4 = [self.param valueForKey:@"longitude2"];
    
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    if ([self.selectedType isEqualToString:@"All_Property"])
    {
        [dataDict setValue:salePriceMin forKey:@"price_for_sale1"];
        [dataDict setValue:salePriceMax forKey:@"price_for_sale2"];
        [dataDict setValue:rentPriceMin forKey:@"pricerented1"];
        [dataDict setValue:rentPriceMax forKey:@"pricerented2"];
        [dataDict setValue:fullAddress forKey:@"fulladdress"];
        [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
        [dataDict setValue:totalBeds forKey:@"numbedrooms"];
        [dataDict setValue:propertyType forKey:@"propertytype"];
        [dataDict setValue:@"0" forKey:@"pet_policy"];
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"AllPropertyLotType"]isEqualToString:@"SQFT"]) {
            
            [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
            [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
            
        }else
        {
            [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
            [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
        }
        [dataDict setValue:strLat1 forKey:@"latitude1"];
        [dataDict setValue:strLat2 forKey:@"longitude1"];
        [dataDict setValue:strLat3 forKey:@"latitude2"];
        [dataDict setValue:strLat4 forKey:@"longitude2"];
        [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
        [dataDict setValue:@"0" forKey:@"recently_rented"];
        [dataDict setValue:@"0" forKey:@"recently_sold"];
        [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
        [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
        [dataDict setValue:squareFeetMin forKey:@"sqft1"];
        [dataDict setValue:squareFeetMax forKey:@"sqft2"];
        [dataDict setValue:foreclosedyn forKey:@"foreclosedyn"];
        [dataDict setValue:@"0" forKey:@"shortsaleyn"];
        [dataDict setValue:SearchByKeyword forKey:@"search_by_keyword"];
        [dataDict setValue:@"all_property" forKey:@"status"];
    }
    
    else if ([self.selectedType isEqualToString:@"For_Rent"])
    {
        [dataDict setValue:rentPriceMin forKey:@"pricerented1"];
        [dataDict setValue:rentPriceMax forKey:@"pricerented2"];
        [dataDict setValue:fullAddress forKey:@"fulladdress"];
        [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
        [dataDict setValue:totalBeds forKey:@"numbedrooms"];
        [dataDict setValue:propertyType forKey:@"propertytype"];
        [dataDict setValue:squareFeetMin forKey:@"sqft1"];
        [dataDict setValue:squareFeetMax forKey:@"sqft2"];
        [dataDict setValue:strPetPolicy forKey:@"pet_policy"];
        
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"RentPropertyLotType"]isEqualToString:@"SQFT"])
        {
            [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
            [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
        }
        else
        {
            [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
            [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
        }
        [dataDict setValue:strLat1 forKey:@"latitude1"];
        [dataDict setValue:strLat2 forKey:@"longitude1"];
        [dataDict setValue:strLat3 forKey:@"latitude2"];
        [dataDict setValue:strLat4 forKey:@"longitude2"];
        [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
        [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
        [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
        [dataDict setValue:SearchByKeyword forKey:@"search_by_keyword"];
        [dataDict setValue:@"for_rent" forKey:@"status"];
    }
    
    else if ([self.selectedType isEqualToString:@"For_Sold"])
    {
        [dataDict setValue:strLat1 forKey:@"latitude1"];
        [dataDict setValue:strLat2 forKey:@"longitude1"];
        [dataDict setValue:strLat3 forKey:@"latitude2"];
        [dataDict setValue:strLat4 forKey:@"longitude2"];
        [dataDict setValue:salePriceMin forKey:@"pricesold1"];
        [dataDict setValue:salePriceMax forKey:@"pricesold2"];
        [dataDict setValue:fullAddress forKey:@"fulladdress"];
        [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
        [dataDict setValue:totalBeds forKey:@"numbedrooms"];
        [dataDict setValue:propertyType forKey:@"propertytype"];
        [dataDict setValue:squareFeetMin forKey:@"sqft1"];
        [dataDict setValue:squareFeetMax forKey:@"sqft2"];
        [dataDict setValue:foreclosedyn forKey:@"foreclosedyn"];
        [dataDict setValue:shortSale forKey:@"shortsaleyn"];
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"SoldPropertyLotType"]isEqualToString:@"SQFT"]) {
            
            [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
            [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
        }else{
            [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
            [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
        }
        
        [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
        [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
        [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
        [dataDict setValue:SearchByKeyword forKey:@"search_by_keyword"];
        [dataDict setValue:@"sold" forKey:@"status"];
    }
    
    else
    {
        [dataDict setValue:strLat1 forKey:@"latitude1"];
        [dataDict setValue:strLat2 forKey:@"longitude1"];
        [dataDict setValue:strLat3 forKey:@"latitude2"];
        [dataDict setValue:strLat4 forKey:@"longitude2"];
        [dataDict setValue:salePriceMin forKey:@"price_for_sale1"];
        [dataDict setValue:salePriceMax forKey:@"price_for_sale2"];
        [dataDict setValue:fullAddress forKey:@"fulladdress"];
        [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
        [dataDict setValue:totalBeds forKey:@"numbedrooms"];
        [dataDict setValue:propertyType forKey:@"propertytype"];
        [dataDict setValue:squareFeetMin forKey:@"sqft1"];
        [dataDict setValue:squareFeetMax forKey:@"sqft2"];
        [dataDict setValue:foreclosedyn forKey:@"foreclosedyn"];
        [dataDict setValue:shortSale forKey:@"shortsaleyn"];
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"SalePropertyLotType"]isEqualToString:@"SQFT"]) {
            
            [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
            [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
        }else{
            [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
            [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
        }
        
        [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
        [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
        [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
        [dataDict setValue:SearchByKeyword forKey:@"search_by_keyword"];
        [dataDict setValue:@"for_sale" forKey:@"status"];
    }
    
    [dataDict setValue:strPagingId forKey:@"property_paging_id"];
    [dataDict setValue:txtSearch.text forKey:@"searchh"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"SortOrder"] forKey:@"sortt"];
     NSLog(@"%@",[dataDict JSONRepresentation]);
   // [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    [REWebService propertyListingWithPaging:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
    //[MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
     NSLog(@"%@",dictResult);
        
        if (!error) {
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]) {
                self->tblListing.hidden = NO;
                self->tblListing.tableFooterView = nil;
                NSArray *propertyTempArr = [[dictResult objectForKey:@"response"]objectForKey:@"data"] ;
                self->countAvail = [[[dictResult valueForKey:@"response"] valueForKey:@"count_available"] integerValue];
                // propertyDataArr = [[NSMutableArray alloc]init];
                for(NSDictionary *tempDict in propertyTempArr)
                {
                    PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                    [self->propertyDataArr addObject:datamodel];
                }
                self.infoArray = [propertyTempArr valueForKeyPath:@"@distinctUnionOfObjects.feed_name"];
                self->strPagingId = [[dictResult valueForKey:@"response"] valueForKey:@"paging_id"];
                
                for(UILabel *lbl in [self.view subviews])
                {
                    if(lbl.tag == 50)
                    {
                        [lbl removeFromSuperview];
                    } 
                    
                }
                [self->tblListing reloadData];
            }else
            {
                for(UILabel *lbl in [self.view subviews])
                {
                    if(lbl.tag == 50)
                    {
                        [lbl removeFromSuperview];
                    }
                    
                }
                [self noRecordFoundLabel];
                [self->tblListing reloadData];
                self->tblListing.hidden = YES;
            }
            
        }
        
    }];

}

-(void)pullToRefresh
{
    
//    strPagingId = @"0";
//    [propertyDataArr removeAllObjects];
//    [self.param setValue:strPagingId forKey:@"property_paging_id"];
//    [self.param setValue:txtSearch.text forKey:@"searchh"];
//    [self.param setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"SortOrder"] forKey:@"sortt"];
//     NSLog(@"%@",[_param JSONRepresentation]);
    
    strPagingId = @"0";
    [propertyDataArr removeAllObjects];
    NSString *strLat1 = [self.param valueForKey:@"latitude1"];
    NSString *strLat2 = [self.param valueForKey:@"longitude1"];
    NSString *strLat3 = [self.param valueForKey:@"latitude2"];
    NSString *strLat4 = [self.param valueForKey:@"longitude2"];
    
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    if ([self.selectedType isEqualToString:@"All_Property"])
    {
        [dataDict setValue:salePriceMin forKey:@"price_for_sale1"];
        [dataDict setValue:salePriceMax forKey:@"price_for_sale2"];
        [dataDict setValue:rentPriceMin forKey:@"pricerented1"];
        [dataDict setValue:rentPriceMax forKey:@"pricerented2"];
        [dataDict setValue:fullAddress forKey:@"fulladdress"];
        [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
        [dataDict setValue:totalBeds forKey:@"numbedrooms"];
        [dataDict setValue:propertyType forKey:@"propertytype"];
        [dataDict setValue:@"0" forKey:@"pet_policy"];
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"AllPropertyLotType"]isEqualToString:@"SQFT"]) {
            
            [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
            [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
            
        }else
        {
            [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
            [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
        }
        [dataDict setValue:strLat1 forKey:@"latitude1"];
        [dataDict setValue:strLat2 forKey:@"longitude1"];
        [dataDict setValue:strLat3 forKey:@"latitude2"];
        [dataDict setValue:strLat4 forKey:@"longitude2"];
        [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
        [dataDict setValue:@"0" forKey:@"recently_rented"];
        [dataDict setValue:@"0" forKey:@"recently_sold"];
        [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
        [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
        [dataDict setValue:squareFeetMin forKey:@"sqft1"];
        [dataDict setValue:squareFeetMax forKey:@"sqft2"];
        [dataDict setValue:foreclosedyn forKey:@"foreclosedyn"];
        [dataDict setValue:@"0" forKey:@"shortsaleyn"];
        [dataDict setValue:@"all_property" forKey:@"status"];
    }
    
    else if ([self.selectedType isEqualToString:@"For_Rent"])
    {
        [dataDict setValue:rentPriceMin forKey:@"pricerented1"];
        [dataDict setValue:rentPriceMax forKey:@"pricerented2"];
        [dataDict setValue:fullAddress forKey:@"fulladdress"];
        [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
        [dataDict setValue:totalBeds forKey:@"numbedrooms"];
        [dataDict setValue:propertyType forKey:@"propertytype"];
        [dataDict setValue:squareFeetMin forKey:@"sqft1"];
        [dataDict setValue:squareFeetMax forKey:@"sqft2"];
        [dataDict setValue:strPetPolicy forKey:@"pet_policy"];
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"RentPropertyLotType"]isEqualToString:@"SQFT"])
        {
            [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
            [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
        }
        else
        {
            [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
            [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
        }
        [dataDict setValue:strLat1 forKey:@"latitude1"];
        [dataDict setValue:strLat2 forKey:@"longitude1"];
        [dataDict setValue:strLat3 forKey:@"latitude2"];
        [dataDict setValue:strLat4 forKey:@"longitude2"];
        [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
        [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
        [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
        [dataDict setValue:@"for_rent" forKey:@"status"];
    }
    
    else if ([self.selectedType isEqualToString:@"For_Sold"])
    {
        [dataDict setValue:strLat1 forKey:@"latitude1"];
        [dataDict setValue:strLat2 forKey:@"longitude1"];
        [dataDict setValue:strLat3 forKey:@"latitude2"];
        [dataDict setValue:strLat4 forKey:@"longitude2"];
        [dataDict setValue:salePriceMin forKey:@"pricesold1"];
        [dataDict setValue:salePriceMax forKey:@"pricesold2"];
        [dataDict setValue:fullAddress forKey:@"fulladdress"];
        [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
        [dataDict setValue:totalBeds forKey:@"numbedrooms"];
        [dataDict setValue:propertyType forKey:@"propertytype"];
        [dataDict setValue:squareFeetMin forKey:@"sqft1"];
        [dataDict setValue:squareFeetMax forKey:@"sqft2"];
        [dataDict setValue:foreclosedyn forKey:@"foreclosedyn"];
        [dataDict setValue:shortSale forKey:@"shortsaleyn"];
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"SoldPropertyLotType"]isEqualToString:@"SQFT"]) {
            
            [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
            [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
        }else{
            [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
            [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
        }
        
        [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
        [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
        [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
        [dataDict setValue:@"sold" forKey:@"status"];
    }
    
    else
    {
        [dataDict setValue:strLat1 forKey:@"latitude1"];
        [dataDict setValue:strLat2 forKey:@"longitude1"];
        [dataDict setValue:strLat3 forKey:@"latitude2"];
        [dataDict setValue:strLat4 forKey:@"longitude2"];
        [dataDict setValue:salePriceMin forKey:@"price_for_sale1"];
        [dataDict setValue:salePriceMax forKey:@"price_for_sale2"];
        [dataDict setValue:fullAddress forKey:@"fulladdress"];
        [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
        [dataDict setValue:totalBeds forKey:@"numbedrooms"];
        [dataDict setValue:propertyType forKey:@"propertytype"];
        [dataDict setValue:squareFeetMin forKey:@"sqft1"];
        [dataDict setValue:squareFeetMax forKey:@"sqft2"];
        [dataDict setValue:foreclosedyn forKey:@"foreclosedyn"];
        [dataDict setValue:shortSale forKey:@"shortsaleyn"];
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"SalePropertyLotType"]isEqualToString:@"SQFT"]) {
            
            [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
            [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
        }else{
            [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
            [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
        }
        
        [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
        [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
        [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
        [dataDict setValue:@"for_sale" forKey:@"status"];
    }
    
    [dataDict setValue:strPagingId forKey:@"property_paging_id"];
    [dataDict setValue:txtSearch.text forKey:@"searchh"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"SortOrder"] forKey:@"sortt"];
     NSLog(@"%@",[dataDict JSONRepresentation]);
    [REWebService propertyListingWithPaging:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [self->refreshControl endRefreshing];
        [self->_slimeView performSelector:@selector(endRefresh)
                         withObject:nil afterDelay:0
                            inModes:[NSArray arrayWithObject:NSRunLoopCommonModes]];
      
        NSLog(@"%@",dictResult);
        if (!error) {
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]) {
                self->tblListing.tableFooterView = nil;
                NSArray *propertyTempArr = [[dictResult objectForKey:@"response"]objectForKey:@"data"] ;
                self->countAvail = [[[dictResult valueForKey:@"response"] valueForKey:@"count_available"] integerValue];
                for(NSDictionary *tempDict in propertyTempArr)
                {
                    PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                    [self->propertyDataArr addObject:datamodel];
                }
               self.infoArray = [propertyTempArr valueForKeyPath:@"@distinctUnionOfObjects.feed_name"];
                self->strPagingId = [[dictResult valueForKey:@"response"] valueForKey:@"paging_id"];
                
                for(UILabel *lbl in [self->tblListing subviews])
                {
                    if(lbl.tag == 50)
                    {
                        [lbl removeFromSuperview];
                    }
                    
                }
                [self->tblListing reloadData];
                self->tblListing.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
            }else
            {
                [self noRecordFoundLabel];
                [self->tblListing reloadData];
                self->tblListing.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
            }
            
        }
        
    }];
}

#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    keyboardControls.textFields = [NSArray arrayWithObjects:txtSearch, nil];
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"";
    [keyboardControls hidePrevNextButtons:YES];
    
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] bounds];
    
    CGFloat availableHeight = applicationFrame.size.height - 230;
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    if (txtSearch.text.length == 0)
    {
        strPagingId = @"0";
        [propertyDataArr removeAllObjects];
        [self getPropertyData];
    }
    else
    {
        strPagingId = @"0";
        [propertyDataArr removeAllObjects];
        [self getPropertyData];
    }
}

- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([keyboardControls.textFields containsObject:textField])
        keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

/*
-(void)callSearchwithTextfield:(NSString*)strText
{
    [propertyDataArr removeAllObjects];
    NSMutableDictionary *data = [[NSMutableDictionary alloc]init];
    [data setValue:strPagingId forKey:@"property_paging_id"];
    [data setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"SortOrder"] forKey:@"sortt"];
    [data setValue:strText forKey:@"searchh"];
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    [REWebService CallSearchWithTextWithPaging:data withBlock:^(NSDictionary *dictResult, NSError *error) {
    [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
        NSLog(@"%@",dictResult);
        
        if (!error) {
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]) {
                tblListing.tableFooterView = nil;
                NSArray *propertyTempArr = [[dictResult objectForKey:@"response"]objectForKey:@"data"] ;
                countAvail = [[[dictResult valueForKey:@"response"] valueForKey:@"count_available"] integerValue];
                for(NSDictionary *tempDict in propertyTempArr)
                {
                    PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                    [propertyDataArr addObject:datamodel];
                }
                strPagingId = [[dictResult valueForKey:@"response"] valueForKey:@"paging_id"];
                [tblListing reloadData];
            }else {
                
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                
            }
            
        }
        
    }];

}
 */

-(void)noRecordFoundLabel
{
    lblNoRecord = [[UILabel alloc]init];
    [lblNoRecord setFrame:CGRectMake(tblListing.frame.size.width / 2-100, tblListing.frame.size.height / 2-10, 200, 20)];
    lblNoRecord.text = @"Zoom In To See Listings";
    lblNoRecord.numberOfLines = 1;
    lblNoRecord.tag = 50;
    lblNoRecord.font = [UIFont systemFontOfSize:20];
    lblNoRecord.baselineAdjustment = UIBaselineAdjustmentAlignBaselines;
    lblNoRecord.adjustsFontSizeToFitWidth = YES;
    lblNoRecord.minimumScaleFactor = 10.0f/12.0f;
    lblNoRecord.clipsToBounds = YES;
    lblNoRecord.backgroundColor = [UIColor clearColor];
    lblNoRecord.textColor = [UIColor lightGrayColor];
    lblNoRecord.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:lblNoRecord];
    //lblNoRecord2
    
    lblNoRecord2 = [[UILabel alloc]init];
    [lblNoRecord2 setFrame:CGRectMake(tblListing.frame.size.width / 2-100, tblListing.frame.size.height / 2+20, 200, 40)];
    lblNoRecord2.text = @"You’re zoomed too far out for us to show result.";
    lblNoRecord2.numberOfLines = 2;
    lblNoRecord2.tag = 50;
    lblNoRecord2.font = [UIFont systemFontOfSize:12];
    lblNoRecord2.baselineAdjustment = UIBaselineAdjustmentAlignBaselines;
    lblNoRecord2.adjustsFontSizeToFitWidth = YES;
    lblNoRecord2.minimumScaleFactor = 10.0f/12.0f;
    lblNoRecord2.clipsToBounds = YES;
    lblNoRecord2.backgroundColor = [UIColor clearColor];
    lblNoRecord2.textColor = [UIColor lightGrayColor];
    lblNoRecord2.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:lblNoRecord2];
}



-(void)getSavedValueFromDatabase
{
    NSString *existData;
    if ([self.selectedType isEqualToString:@"All_Property"])
    {
        strStatus =  @"all_property";
        existData = @"select * from AllProperties";
        
    }
    else if ([self.selectedType isEqualToString:@"For_Rent"])
    {
        strStatus =  @"for_rent";
        existData = @"select * from RentProperties";
    }
    else if ([self.selectedType isEqualToString:@"For_Sold"])
    {
        strStatus =  @"sold";
        existData = @"select * from SoldProperties";
        
    }
    else
    {
        strStatus =  @"for_sale";
        existData = @"select * from SaleProperties";
    }
    
    if (self.propertyDetail != nil)
    {
        self.propertyDetail = nil;
    }
    self.propertyDetail = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:existData]];
    NSLog(@"DATA---%@",_propertyDetail);
    NSLog(@"Count---%lu",(unsigned long)self.propertyDetail.count);
    if (self.propertyDetail.count)
    {
        dataDuplicate = [self.propertyDetail objectAtIndex:0];
        if ([self.selectedType isEqualToString:@"All_Property"])
        {
            salePriceMin  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:0]];
            salePriceMax  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:1]];
            rentPriceMin  =[NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
            rentPriceMax  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:3]];
            if (![[dataDuplicate objectAtIndex:4] isEqualToString:@"0"]) {
                fullAddress = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:4]];
            }
            else
            {
                fullAddress = @"0";
            }
            totalBeds    = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:5] integerValue]];
            totalBaths   = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
            propertyType = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:7]];
            
            NSArray *selectedItems = [propertyType componentsSeparatedByString:@"/"];
            typeOfProperty = [[NSMutableString alloc]init];
            for (NSInteger i = 0; i<selectedItems.count; i++) {
                [typeOfProperty appendString:[NSString stringWithFormat:@"%@,",[selectedItems objectAtIndex:i]]];
            }
            propertyType = [typeOfProperty substringToIndex:[typeOfProperty length]-1];
            
            
            
            
            // set square feet
            if ([[dataDuplicate objectAtIndex:8] integerValue] ==0&&[[dataDuplicate objectAtIndex:9] integerValue] ==0)
            {
                squareFeetMin = @"1";
                squareFeetMax = @"500000";
            }
            else if ([[dataDuplicate objectAtIndex:8] integerValue] ==0)
            {
                squareFeetMin = @"1";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:9] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:9] integerValue] ==0)
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:8] integerValue]];
                squareFeetMax = @"500000";
            }
            else
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:8] integerValue]];
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:9] integerValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:18] isEqualToString:@"Yes"]){
                foreclosedyn = @"Yes";
            }
            if ([[dataDuplicate objectAtIndex:18] isEqualToString:@"No"]){
                foreclosedyn = @"No";
            }
            shortSale = @"0";
            
            if ([[dataDuplicate objectAtIndex:10] floatValue] ==0&&[[dataDuplicate objectAtIndex:11] integerValue] ==0)
            {
                lotSquareMin = @"1";
                lotSquareMax = @"500000000000";
            }
            else if ([[dataDuplicate objectAtIndex:10] floatValue] ==0)
            {
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotSquareMin = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:11] floatValue] ==0)
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:10] integerValue]];
                lotSquareMax = @"500000000000";
            }
            else
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:10] integerValue]];
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:12] floatValue] ==0&&[[dataDuplicate objectAtIndex:13] floatValue] ==0)
            {
                
                lotAcreMin= @"0";
                lotAcreMax  = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:12] floatValue] ==0)
            {
                lotAcreMin = @"0";
                lotAcreMax = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:13] floatValue]];
            }
            else if ([[dataDuplicate objectAtIndex:13] floatValue] ==0)
            {
                lotAcreMin = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:12] floatValue]];
                lotAcreMax = @"500000000";
            }
            else
            {
                lotAcreMin =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:12] floatValue]];
                lotAcreMax =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:13] floatValue]];
            }
            
            
            if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"]&&[[dataDuplicate objectAtIndex:15] isEqualToString:@"0"]) {
                yearBuiltMin = @"0";
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
            {
                yearBuiltMin= @"0";
                yearBuiltMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:15] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:15] isEqualToString:@"0"])
            {
                yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else
            {
                yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
                yearBuiltMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:15] integerValue]];
            }
            if ([[dataDuplicate objectAtIndex:16]isEqualToString:@"Any"]) {
                
                daysOnMarket =@"0";
            } else {
                daysOnMarket =[NSString stringWithFormat:@"-%@",[dataDuplicate objectAtIndex:16]];
            }
            if (![[dataDuplicate objectAtIndex:17] isEqualToString:@"0"]) {
                SearchByKeyword = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:17]];
            }
            else
            {
                SearchByKeyword = @"";
            }
            
            
        }
        else if ([self.selectedType isEqualToString:@"For_Rent"])
        {
            rentPriceMin  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:0]];
            rentPriceMax  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:1]];
            
            if (![[dataDuplicate objectAtIndex:2] isEqualToString:@"0"]) {
                fullAddress   = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
            }
            else{
                fullAddress = @"0";
            }
            totalBeds     = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:3] integerValue]];
            totalBaths    = [NSString stringWithFormat:@"%ld",[[dataDuplicate objectAtIndex:4] integerValue]];
            if (![[dataDuplicate objectAtIndex:5]isEqualToString:@"0"]) {
                propertyType = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:5]];
            }
            NSArray *selectedItems = [propertyType componentsSeparatedByString:@"/"];
            typeOfProperty = [[NSMutableString alloc]init];
            for (NSInteger i = 0; i<selectedItems.count; i++) {
                [typeOfProperty appendString:[NSString stringWithFormat:@"%@,",[selectedItems objectAtIndex:i]]];
            }
            propertyType = [typeOfProperty substringToIndex:[typeOfProperty length]-1];
            
            
            if ([[dataDuplicate objectAtIndex:6] integerValue] ==0 && [[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = @"0";
                squareFeetMax = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:6] integerValue] ==0)
            {
                squareFeetMin = @"1";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
                squareFeetMax = @"500000";
            }
            else
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:8] floatValue] ==0&&[[dataDuplicate objectAtIndex:9] integerValue] ==0)
            {
                lotSquareMin = @"0";
                lotSquareMax = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:8] floatValue] ==0)
            {
                lotSquareMin = @"1";
                lotSquareMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:9] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:9] floatValue] ==0)
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:8] integerValue]];
                lotSquareMax = @"500000000000";
            }
            else
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:8] integerValue]];
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:9] integerValue]];
            }
            strPetPolicy = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:10]];
            foreclosedyn  = @"Yes";
            shortSale     = @"No";
            
            if ([[dataDuplicate objectAtIndex:11] floatValue] ==0 &&[[dataDuplicate objectAtIndex:12] floatValue] ==0)
            {
                lotAcreMin = @"0";
                lotAcreMax = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:11] floatValue] ==0)
            {
                lotAcreMin = @"0";
                lotAcreMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:12] floatValue] ==0)
            {
                lotAcreMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotAcreMax = @"500000";
            }
            else
            {
                lotAcreMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotAcreMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"]&&[[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
            {
                yearBuiltMin= @"0";
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"])
            {
                yearBuiltMin= @"0";
                yearBuiltMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
            {
                yearBuiltMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else
            {
                yearBuiltMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
                yearBuiltMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
            }
            if ([[dataDuplicate objectAtIndex:15] isEqualToString:@"Any"]) {
                
                daysOnMarket = @"0";
            } else {
                daysOnMarket = [NSString stringWithFormat:@"-%@",[dataDuplicate objectAtIndex:15]];
            }
            
            if (![[dataDuplicate objectAtIndex:16] isEqualToString:@"0"]) {
                SearchByKeyword = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:16]];
            }
            else
            {
                SearchByKeyword = @"";
            }
            
        }
        else if ([self.selectedType isEqualToString:@"For_Sold"])
        {
            salePriceMin = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:0]];
            salePriceMax = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:1]];
            fullAddress  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
            totalBeds    = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:3] integerValue]];
            totalBaths   = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:4] integerValue]];
            propertyType = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:5]];
            
            
            NSArray *selectedItems = [propertyType componentsSeparatedByString:@"/"];
            typeOfProperty = [[NSMutableString alloc]init];
            for (NSInteger i = 0; i<selectedItems.count; i++) {
                [typeOfProperty appendString:[NSString stringWithFormat:@"%@,",[selectedItems objectAtIndex:i]]];
            }
            propertyType = [typeOfProperty substringToIndex:[typeOfProperty length]-1];
            
            /*
             Set Square feet
             */
            
            if ([[dataDuplicate objectAtIndex:6] integerValue] ==0&&[[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = @"0";
                squareFeetMax = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:6] integerValue] ==0)
            {
                
                squareFeetMin = @"1";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
                
            }
            else if ([[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = @"500000";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
            }
            else
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
            }
            
            // update lot square
            
            if ([[dataDuplicate objectAtIndex:11] floatValue] ==0&&[[dataDuplicate objectAtIndex:12] integerValue] ==0)
            {
                lotSquareMin = @"1";
                lotSquareMax = @"500000000000";
            }
            else if ([[dataDuplicate objectAtIndex:11] floatValue] ==0)
            {
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
                lotSquareMin = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:12] floatValue] ==0)
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotSquareMax = @"500000000000";
            }
            else
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:9] floatValue] ==0&&[[dataDuplicate objectAtIndex:10] floatValue] ==0)
            {
                
                lotAcreMin= @"0";
                lotAcreMax  = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:9] floatValue] ==0)
            {
                lotAcreMin = @"0";
                lotAcreMax = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:10] floatValue]];
            }
            else if ([[dataDuplicate objectAtIndex:10] floatValue] ==0)
            {
                lotAcreMin = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:9] floatValue]];
                lotAcreMax = @"500000000";
            }
            else
            {
                lotAcreMin =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:9] floatValue]];
                lotAcreMax =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:10] floatValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"]&&[[dataDuplicate objectAtIndex:14] isEqualToString:@"0"]) {
                yearBuiltMin = @"0";
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"])
            {
                yearBuiltMin= @"0";
                yearBuiltMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
            {
                yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else
            {
                yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
                yearBuiltMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
            }
            if ([[dataDuplicate objectAtIndex:15]isEqualToString:@"Any"]) {
                
                daysOnMarket =@"0";
            } else {
                daysOnMarket =[NSString stringWithFormat:@"-%@",[dataDuplicate objectAtIndex:15]];
            }
            
            if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Foreclosures only"]){
                foreclosedyn = @"Yes";
                shortSale = @"No";
            }
            else if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Short sale only"]){
                foreclosedyn = @"No";
                shortSale = @"Yes";
                
            }
            else if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Both"]){
                foreclosedyn = @"Yes";
                shortSale = @"Yes";
            }
            else
            {
                foreclosedyn = @"No";
                shortSale = @"No";
            }
            
            if (![[dataDuplicate objectAtIndex:16] isEqualToString:@"0"]) {
                SearchByKeyword = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:16]];
            }
            else
            {
                SearchByKeyword = @"";
            }
            
        }
        else
        {
            salePriceMin = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:0]];
            salePriceMax = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:1]];
            fullAddress  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
            totalBeds    = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:3] integerValue]];
            totalBaths   = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:4] integerValue]];
            propertyType = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:5]];
            
            
            NSArray *selectedItems = [propertyType componentsSeparatedByString:@"/"];
            typeOfProperty = [[NSMutableString alloc]init];
            for (NSInteger i = 0; i<selectedItems.count; i++) {
                [typeOfProperty appendString:[NSString stringWithFormat:@"%@,",[selectedItems objectAtIndex:i]]];
            }
            propertyType = [typeOfProperty substringToIndex:[typeOfProperty length]-1];
            
            /*
             Set Square feet
             */
            
            if ([[dataDuplicate objectAtIndex:6] integerValue] ==0&&[[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = @"0";
                squareFeetMax = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:6] integerValue] ==0)
            {
                
                squareFeetMin = @"1";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
                
            }
            else if ([[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = @"500000";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
            }
            else
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
            }
            
            // update lot square
            
            if ([[dataDuplicate objectAtIndex:11] floatValue] ==0&&[[dataDuplicate objectAtIndex:12] integerValue] ==0)
            {
                lotSquareMin = @"1";
                lotSquareMax = @"500000000000";
            }
            else if ([[dataDuplicate objectAtIndex:11] floatValue] ==0)
            {
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
                lotSquareMin = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:12] floatValue] ==0)
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotSquareMax = @"500000000000";
            }
            else
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:9] floatValue] ==0&&[[dataDuplicate objectAtIndex:10] floatValue] ==0)
            {
                
                lotAcreMin= @"0";
                lotAcreMax  = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:9] floatValue] ==0)
            {
                lotAcreMin = @"0";
                lotAcreMax = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:10] floatValue]];
            }
            else if ([[dataDuplicate objectAtIndex:10] floatValue] ==0)
            {
                lotAcreMin = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:9] floatValue]];
                lotAcreMax = @"500000000";
            }
            else
            {
                lotAcreMin =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:9] floatValue]];
                lotAcreMax =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:10] floatValue]];
            }
            
            if (![[dataDuplicate objectAtIndex:16] isEqualToString:@"0"]) {
                SearchByKeyword = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:16]];
            }
            else
            {
                SearchByKeyword = @"";
            }
            
            if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"]&&[[dataDuplicate objectAtIndex:14] isEqualToString:@"0"]) {
                yearBuiltMin = @"0";
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"])
            {
                yearBuiltMin= @"0";
                yearBuiltMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
            {
                yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else
            {
                yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
                yearBuiltMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
            }
            if ([[dataDuplicate objectAtIndex:15]isEqualToString:@"Any"]) {
                
                daysOnMarket =@"0";
            } else {
                daysOnMarket =[NSString stringWithFormat:@"-%@",[dataDuplicate objectAtIndex:15]];
            }
            
            if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Foreclosures only"]){
                foreclosedyn = @"Yes";
                shortSale = @"No";
            }
            else if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Short sale only"]){
                foreclosedyn = @"No";
                shortSale = @"Yes";
                
            }
            else if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Both"]){
                foreclosedyn = @"Yes";
                shortSale = @"Yes";
            }
            else
            {
                foreclosedyn = @"No";
                shortSale = @"No";
            }
        }
    }
    [self getPropertyData];
    
}

#pragma mark - slimeRefresh delegate
/*
- (void)slimeRefreshStartRefresh:(SRRefreshView *)refreshView
{
    [self pullToRefresh];
    
//    [_slimeView performSelector:@selector(pullToRefresh)
//                     withObject:nil afterDelay:0
//                        inModes:[NSArray arrayWithObject:NSRunLoopCommonModes]];
}
*/
@end
