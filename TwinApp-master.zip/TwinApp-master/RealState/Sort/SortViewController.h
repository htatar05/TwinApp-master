//
//  SortViewController.h
//  RealState
//
//  Created by Kapil Goyal on 12/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SortViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet UIView *viewSortOrder;
    IBOutlet UITableView *tblViewSortOrder;
    NSMutableArray *arrSortOrder;
    IBOutlet UIScrollView *scrlViewSort;
    NSInteger selectedIndex;
    NSIndexPath *ipath;
    NSMutableDictionary * dictCheck;
}

@property  (nonatomic,strong)NSString * selectedOrder;
-(IBAction)btnApply;
@end
