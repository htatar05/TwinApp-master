//
//  SortViewController.m
//  RealState
//
//  Created by Kapil Goyal on 12/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "SortViewController.h"
#import "SortTvCellView.h"

@interface SortViewController ()
@end

@implementation SortViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    selectedIndex = 0;
    
    arrSortOrder = [[NSMutableArray alloc] initWithObjects:@"Recently Changed",@"Square Feet: High to Low",@"Lot Size", @"Price: Low to High", @"Price: High to Low", @"Year Built", @"Bedrooms", @"Bathrooms", nil];
    
    if(IsRunningTallPhone())
    {
        [viewSortOrder setFrame:CGRectMake(0, 0, 320, 568)];
        [scrlViewSort setContentSize:CGSizeMake(320, 500)];
    }
    else
    {
        [viewSortOrder setFrame:CGRectMake(0, 0, 320, 480)];
        [scrlViewSort setContentSize:CGSizeMake(320, 490)];
    }
    
    if (!IS_IPHONE) {
        
        [viewSortOrder setFrame:CGRectMake(0, 0, 768, 1024)];
        [scrlViewSort setContentSize:CGSizeMake(768, 800)];
        
    }

    dictCheck = [[NSMutableDictionary alloc] init];
    for (int j=0;j<[arrSortOrder count];j++)
    {
        [dictCheck setValue:@"0" forKey:[NSString stringWithFormat:@"%d",j]];
        if ([self.selectedOrder isEqualToString:[arrSortOrder objectAtIndex:j]]) {
            selectedIndex = j;
            
        }
    }
}

-(IBAction)btnApply
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrSortOrder count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    SortTvCellView *cell = (SortTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
            
            view = [[UIViewController alloc]initWithNibName:@"SortTvCellView_iPhone" bundle:nil];
        } else {
            view = [[UIViewController alloc]initWithNibName:@"SortTvCellView_iPad" bundle:nil];
        }
        
        cell = (SortTvCellView *)view.view;
    }
    cell.tag = indexPath.row;
    cell.lblSortType.text = [arrSortOrder objectAtIndex:indexPath.row];
    
    if ([[dictCheck valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] isEqualToString:@"1"]|| selectedIndex==indexPath.row) {
        
        cell.imgCheck.image = [UIImage imageNamed:@"blue_tick.png"];
    }
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SortTvCellView *cell = (SortTvCellView*)[tblViewSortOrder cellForRowAtIndexPath:indexPath];
    ipath = [tblViewSortOrder indexPathForCell:cell];
    NSArray *arrKeys = [dictCheck allKeys];
    NSArray *arr = [arrKeys sortedArrayUsingSelector:@selector(compare:)];
    
    for (int i=0; i<[arr count]; i++)
    {
        if([[arr objectAtIndex:i] isEqualToString:[NSString stringWithFormat:@"%ld",(long)ipath.row]])
        {
            [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:[NSString stringWithFormat:@"b%d",i]];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [dictCheck setValue:@"1" forKey:[NSString stringWithFormat:@"%d",i]];
        }
        else
        {
            [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:[NSString stringWithFormat:@"b%d",i]];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [dictCheck setValue:@"0" forKey:[NSString stringWithFormat:@"%d",i]];
        }
    }
    [[NSUserDefaults standardUserDefaults]setValue:[arrSortOrder objectAtIndex:indexPath.row] forKey:@"SortOrder"];
     selectedIndex = indexPath.row;
    [tblViewSortOrder deselectRowAtIndexPath:indexPath animated:YES];
    [self performSelector:@selector(LoadData) withObject:nil afterDelay:0.2];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE) {
        return 40;
    } else {
        return 60;
    }
}

-(void)LoadData
{
    [tblViewSortOrder reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
