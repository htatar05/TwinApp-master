//  DisclaimerVC.m
//  RealEstate_App
//  Created by Octal on 13/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import "DisclaimerVC.h"
#import "DisclaimerTvCellView.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "Utils.h"


@interface DisclaimerVC ()

@end

@implementation DisclaimerVC

- (void)viewDidLoad
{
     [super viewDidLoad];
     self.dataArray = [[NSMutableArray alloc]init];
     appdelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
     defaultText.text = @"";
     defaultText.backgroundColor = [UIColor whiteColor];
     [self getDisclaimerDetail];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark Actions

-(IBAction)backButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    DisclaimerTvCellView *cell = (DisclaimerTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view = [[UIViewController alloc]initWithNibName:@"DisclaimerTvCellView" bundle:nil];
        cell = (DisclaimerTvCellView *)view.view;
    }
    
    NSDictionary *dic = [self.dataArray objectAtIndex:indexPath.row];
    cell.lblProperties.text =[NSString stringWithFormat:@"%@", [dic valueForKey:@"feed"]]  ;
    cell.txtDisclaimer.text =[NSString stringWithFormat:@"%@", [dic valueForKey:@"disclaimer"]]  ;
    cell.txtDisclaimer.textColor = [UIColor lightGrayColor];
    cell.lblProperties.textColor = [UIColor blackColor];
    cell.txtDisclaimer.editable = NO;
    myTable.backgroundColor = [UIColor whiteColor];
    if (indexPath.row ==self.dataArray.count-1) {
        cell.seprateLine.hidden = YES;
    }
    else
    {
        cell.seprateLine.hidden = NO;
    }
    return cell;
   
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 90;
}
-(void)getDisclaimerDetail
{
    [MBProgressHUD showHUDAddedTo:appdelegate.window animated:YES];
    [REWebService disclaimerDetailFromServer:nil withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self->appdelegate.window animated:YES];
        NSLog(@"%@",dictResult);
        
        if (!error)
        {
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"])
            {
                
                if ([self.isCountAvail isEqualToString:@"Yes"]) {
                    
                    NSArray *temp = [[dictResult valueForKey:@"response"] valueForKey:@"data"];
                    NSMutableString* mutString = [[NSMutableString alloc] init];
                    [mutString appendString:[[dictResult valueForKey:@"response"] valueForKey:@"default_disclaimer"]];
                    for (NSInteger i = 0; i<self.feedArray.count; i++) {
                        for (NSInteger j= 0; j<temp.count; j++){
                            if ([[self.feedArray objectAtIndex:i] isEqualToString:[[temp objectAtIndex:j] valueForKey:@"feed"]]){
                                
                                [mutString appendString:[NSString stringWithFormat:@"\n\n%@\n",[[temp objectAtIndex:j] valueForKey:@"disclaimer"]]];
                            }
                        }
                        
                    }
                    self->defaultText.text = mutString;
                    
                }
                else
                {
                    self->defaultText.text = [[dictResult valueForKey:@"response"] valueForKey:@"default_disclaimer"];
                }
                self->defaultText.textColor = [UIColor lightGrayColor];
                if (IS_IPHONE) {
                    self->defaultText.font = [UIFont systemFontOfSize:17.0];
                } else {
                    self->defaultText.font = [UIFont systemFontOfSize:19.0];
                }
                
                

             }
            
            else
            {
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
            
            }
            
            
        }
        
        
        
    }];
    
    
}
@end
