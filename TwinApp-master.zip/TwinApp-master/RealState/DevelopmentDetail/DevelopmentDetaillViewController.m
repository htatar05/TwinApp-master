//  AgentDetailViewController.m
//  RealState
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "DevelopmentDetaillViewController.h"
#import "AgentListViewController.h"
#import "NSAttributedString+Attributes.h"
#import "UIImageView+UIActivityIndicatorForSDWebImage.h"
#import "UIImageView+HighlightedWebCache.h"

@interface DevelopmentDetaillViewController ()
@end

@implementation DevelopmentDetaillViewController

- (void)viewDidLoad
{
    [super viewDidLoad];

    
    imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    imgBackground.layer.borderWidth=0.75;
    
    [txtFieldEmail setValue:[UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    [txtFieldPhone setValue:[UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
    txtViewMessage.text = @"Message";
    txtViewMessage.textColor = [UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1.0];
    
     NSString *str = @"64, Roop V64, Roop Vihar Colony,  uuuuu64, Roop Vihar Colony,  uuuuu64, Roop Vihar Colony,  uuuuu64, Roop Vihar Colony,  uuuuu64, Roop Vihar Colony,  uuuuu64, Roop Vihar Colony,  uuuuu64, Roop Vihar kkkk k kkkkk";
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:str];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:15.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        height=0.0;
        if(height1>40)
        {
            height=height1-40;
        }
    }
    else
    {
        UITextView *txtSavedSearch = [[UITextView alloc] init];
        txtSavedSearch.frame = CGRectMake(0, 0, 173, 40);
        txtSavedSearch.font = [UIFont fontWithName:@"Helvetica" size:15.0];
        txtSavedSearch.text = str;
        [self.view addSubview:txtSavedSearch];
        CGRect rect = txtSavedSearch.frame;
        rect.size = txtSavedSearch.contentSize;
        txtSavedSearch.frame = rect;
        height=0.0;
        if(rect.size.height>40)
            height=rect.size.height-40;
        [txtSavedSearch removeFromSuperview];
    }
    
    [txtViewAddress setFrame:CGRectMake(129, 82, 173, 40+height)];
    txtViewAddress.text = str;
    [imgBackground setFrame:CGRectMake(9, 12, 304, 155+height)];
    [btnHome setFrame:CGRectMake(133, 131+height, 24, 24)];
    [btnPhone setFrame:CGRectMake(162, 131+height, 24, 24)];
    [btnEmail setFrame:CGRectMake(191, 131+height, 24, 24)];
    [btnContactAgent setFrame:CGRectMake(85, 184+height, 154, 37)];
    
    [imgBack1 setFrame:CGRectMake(0, 246+height, 320, 158)];
    [imgSep1 setFrame:CGRectMake(0, 238+height, 320, 8)];
    [imgSep2 setFrame:CGRectMake(0, 282+height, 320, 1)];
    [imgSep3 setFrame:CGRectMake(0, 320+height, 320, 1)];
    [imgSep4 setFrame:CGRectMake(0, 381+24+height, 320, 1)];
    [imgSep5 setFrame:CGRectMake(0, 419+24+height, 320, 1)];
    [imgSep6 setFrame:CGRectMake(0, 465+24+height, 320, 1)];
    
    [txtFieldEmail setFrame:CGRectMake(17, 246+height, 296, 36)];
    [txtFieldPhone setFrame:CGRectMake(17, 283+height, 296, 36)];
    [txtViewMessage setFrame:CGRectMake(8, 321+height, 309, 86)];
    [lblGetApproved setFrame:CGRectMake(0, 382+24+height, 320, 36)];
    
    [btnCheck setFrame:CGRectMake(14, 389+24+height, 24, 24)];
    [btnSend setFrame:CGRectMake(0, 424+24+height, 320, 41)];
    
    NSLog(@"height=%f",height);
    if(IsRunningTallPhone())
    {
        [self.view setFrame:CGRectMake(0, 0, 320, 568)];
        [scrlView setFrame:CGRectMake(0, 44, 320, 524)];
         scrlView.contentSize=CGSizeMake(320, 550);
    }
    else
    {
        [self.view setFrame:CGRectMake(0, 0, 320, 480)];
        [scrlView setFrame:CGRectMake(0, 44, 320, 436)];
         scrlView.contentSize=CGSizeMake(320, 520);
    }
    
    scrlViewImage = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 320, 200)];
    
    if (!IS_IPHONE) {
        
        [self.view setFrame:CGRectMake(0, 0, 768, 1024)];
        [scrlView setFrame:CGRectMake(0, 60, 768, 900)];
       // scrlView.contentSize=CGSizeMake(320, 550);
        scrlViewImage = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 768, 300)];
    }
    
    scrlViewImage.backgroundColor = [UIColor clearColor];
    scrlViewImage.showsHorizontalScrollIndicator=FALSE;
    [scrlViewImage setCanCancelContentTouches:NO];
    scrlViewImage.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    scrlViewImage.scrollEnabled = YES;
    scrlViewImage.pagingEnabled = YES;
    scrlViewImage.scrollsToTop = NO;
    [scrlView addSubview:scrlViewImage];
   
    scrlViewImage.delegate=self;
    CGRect frame = scrlViewImage.frame;
    frame.origin.x = frame.size.width * num;
    frame.origin.y = 0;
    [scrlViewImage scrollRectToVisible:frame animated:NO];
    pageControlUsed = YES;
    UIImageView *imgNextBack = [[UIImageView alloc] init];
    imgNextBack.backgroundColor = [UIColor blackColor];
    if (IS_IPHONE) {
        imgNextBack.frame = CGRectMake(0, 156, 320, 44);
    } else {
        imgNextBack.frame = CGRectMake(0, 220, 768, 44);
    }
    imgNextBack.alpha = 0.5f;
    [scrlView addSubview:imgNextBack];
    num = 0;
    imageArr = self.developmentInfo.developmentImageArr;
    pageControl.numberOfPages = [imageArr count];
    pageControl.currentPage = num;
    
    for(int i=0;i<[imageArr count];i++)
    {
        if (IS_IPHONE) {
             xPosition = 320*i;
        } else {
             xPosition = 768*i;
        }
       
        
        if (IS_IPHONE) {
            imgProperty = [[UIImageView alloc] initWithFrame:CGRectMake(xPosition, -20, 320, 220)];
        } else {
            imgProperty = [[UIImageView alloc] initWithFrame:CGRectMake(xPosition, -20, 768, 300)];
        }
        
        NSString *imageName = [NSString stringWithFormat:@"%@",[imageArr objectAtIndex:i]];
        imgProperty.image = [UIImage imageNamed:imageName];
        
        
        
        [imgProperty setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[imageArr objectAtIndex:i]]] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        
        
        [scrlViewImage addSubview:imgProperty];
        if (IS_IPHONE) {
            [scrlViewImage setContentSize:CGSizeMake(320+xPosition, 0)];
        }
        else
        {
            [scrlViewImage setContentSize:CGSizeMake(768+xPosition, 0)];
        }
        
    }
    
    
    btnPrevious = [UIButton buttonWithType:UIButtonTypeCustom];
    btnPrevious.backgroundColor=[UIColor clearColor];
   
    if (IS_IPHONE) {
         btnPrevious.frame=CGRectMake(11,164,29,29);
    } else {
         btnPrevious.frame=CGRectMake(11,226,29,29);
    }
    [btnPrevious setImage:[UIImage imageNamed:@"slider_left_arrow"] forState:UIControlStateNormal];
    [btnPrevious addTarget:self action:@selector(btnPreviousClicked) forControlEvents:UIControlEventTouchUpInside];
    [scrlView addSubview:btnPrevious];
    btnPrevious.userInteractionEnabled=FALSE;
    
    btnNext = [UIButton buttonWithType:UIButtonTypeCustom];
    btnNext.backgroundColor=[UIColor clearColor];
    if (IS_IPHONE) {
        btnNext.frame=CGRectMake(281,164,29,29);
    }
    else
    {
        btnNext.frame=CGRectMake(728,226,29,29);
    }
    
    [btnNext setImage:[UIImage imageNamed:@"slider_right_arrow"] forState:UIControlStateNormal];
    [btnNext addTarget:self action:@selector(btnNextClicked) forControlEvents:UIControlEventTouchUpInside];
    [scrlView addSubview:btnNext];
    
    
    
    if (IS_IPHONE){
        
        lblCounter2 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-65,164,130,30)];
        lblCounter2.text = [NSString stringWithFormat:@"%d of %lu Photos",num+1,(unsigned long)imageArr.count];
        lblCounter2.textColor = [UIColor whiteColor];
        
    }
    else{
        
        lblCounter2 = [[UILabel alloc]initWithFrame:CGRectMake(self.view.frame.size.width/2-65,225,130,30)];
        lblCounter2.text = [NSString stringWithFormat:@"%d of %lu Photos",num+1,(unsigned long)imageArr.count];
        lblCounter2.textColor = [UIColor whiteColor];
    }
    [scrlView addSubview:lblCounter2];
    
    lblLocation.text = [NSString stringWithFormat:@"Location:%@",self.developmentInfo.fulladdress];
    lblYearBuild.text = [NSString stringWithFormat:@"Development:%@",self.developmentInfo.yearBuilt];
    
    
    [self addKeyboardControls];

}

- (CGFloat)textViewHeightForAttributedText:(NSMutableAttributedString*)text
{
    UITextView *txtSavedSearch = [[UITextView alloc] init];
    [txtSavedSearch setAttributedText:text];
    CGSize size = [txtSavedSearch sizeThatFits:CGSizeMake(173, 40)];
    NSLog(@"height111=%f",size.height);
    return size.height;
}

#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    
    keyboardControls.textFields = [NSArray arrayWithObjects:txtFieldEmail,txtFieldPhone,txtViewMessage, nil];
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"Previous";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"Next";
    
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
        else if([textField isKindOfClass:[UITextView class]])
        {
            ((UITextView *) textField).inputAccessoryView = keyboardControls;
            ((UITextView *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] applicationFrame];
    CGFloat availableHeight = applicationFrame.size.height - 220;
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
    [scrlView setContentOffset:CGPointMake(0, y) animated:YES];
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    [controls.activeTextField resignFirstResponder];
    [scrlView setContentOffset:CGPointMake(0, 0) animated:YES];
}

- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}

#pragma mark TextField Delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([keyboardControls.textFields containsObject:textField])
        keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    return YES;
}

#pragma mark TextView Delegate
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    const CGFloat *components = CGColorGetComponents(txtViewMessage.textColor.CGColor);
    NSString *red = [NSString stringWithFormat:@"%f", components[0]] ;
    NSString *green = [NSString stringWithFormat:@"%f", components[1]] ;
    NSString *blue = [NSString stringWithFormat:@"%f", components[2]] ;
    NSString *alpha = [NSString stringWithFormat:@"%f", components[3]] ;
    
    if ([red isEqualToString:@"0.376471"] && [green isEqualToString:@"0.376471"] && [blue isEqualToString:@"0.376471"] && [alpha isEqualToString:@"1.000000"])
    {
        txtViewMessage.text = @"";
        txtViewMessage.textColor = [UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1.0];
    }
}

-(BOOL)textViewShouldBeginEditing:(UITextView *)textView
{
    if ([keyboardControls.textFields containsObject:textView])
        keyboardControls.activeTextField = textView;
    
    [self scrollViewToCenterOfScreen:textView];
    return YES;
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    NSLog(@"kapil");
}

-(void) textViewDidChange:(UITextView *)textView
{
    if(txtViewMessage.text.length == 0){
        txtViewMessage.textColor = [UIColor colorWithRed:96/255.0 green:96/255.0 blue:96/255.0 alpha:1.0];
        txtViewMessage.text = @"Message";
        [txtViewMessage resignFirstResponder];
        [scrlView setContentOffset:CGPointMake(0, 0) animated:YES];
    }
}


-(IBAction)btnBackClicked
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


#pragma mark UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)sender
{
    if (pageControlUsed)
    {
        return;
    }
    CGFloat pageWidth = scrlViewImage.frame.size.width;
    int page = floor((scrlViewImage.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    pageControl.currentPage = page;
    num=page;
    
    if((int)scrlViewImage.contentOffset.x==0)
        btnPrevious.userInteractionEnabled=FALSE;
    else
        btnPrevious.userInteractionEnabled=TRUE;
    
    if((int)scrlViewImage.contentOffset.x == (320*([imageArr count]-1)))
        btnNext.userInteractionEnabled=FALSE;
    else
        btnNext.userInteractionEnabled=TRUE;
    
    
    
    lblCounter2.text = [NSString stringWithFormat:@"%d of %lu Photos",num+1,(unsigned long)imageArr.count];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    pageControlUsed = NO;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    pageControlUsed = NO;
}

#pragma mark Next Previous button
-(void)btnNextClicked
{
    num = num+1;
    if(num == [imageArr count]-1)
    {
        if (IS_IPHONE) {
            [scrlViewImage setContentOffset:CGPointMake(320*num, 0) animated:YES];
        } else {
            [scrlViewImage setContentOffset:CGPointMake(768*num, 0) animated:YES];
        }
        
        btnNext.userInteractionEnabled=FALSE;
        btnPrevious.userInteractionEnabled=TRUE;
        
    }
    else
    {
        if (IS_IPHONE) {
            [scrlViewImage setContentOffset:CGPointMake(320*num, 0) animated:YES];
        } else {
            [scrlViewImage setContentOffset:CGPointMake(768*num, 0) animated:YES];
        }
         btnNext.userInteractionEnabled=TRUE;
         btnPrevious.userInteractionEnabled=TRUE;
        
    }
    
    lblCounter2.text = [NSString stringWithFormat:@"%d of %lu Photos",num+1,(unsigned long)imageArr.count];
    pageControlUsed=YES;
}

-(void)btnPreviousClicked
{
    num = num-1;
    if(num == 0 || num == -1)
    {
        [scrlViewImage setContentOffset:CGPointMake(320*num, 0) animated:YES];
        btnNext.userInteractionEnabled=TRUE;
        btnPrevious.userInteractionEnabled=FALSE;
        
    }
    else
    {
        [scrlViewImage setContentOffset:CGPointMake(320*num, 0) animated:YES];
        btnNext.userInteractionEnabled=TRUE;
        btnPrevious.userInteractionEnabled=TRUE;
        
    }
    lblCounter2.text = [NSString stringWithFormat:@"%d of %lu Photos",num+1,(unsigned long)imageArr.count];
    pageControlUsed=YES;
}
@end
