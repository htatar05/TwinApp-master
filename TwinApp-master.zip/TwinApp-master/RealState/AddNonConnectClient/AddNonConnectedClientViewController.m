//  LoginViewController.m
//  RealState
//  Created by Kapil Goyal on 27/08/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.


#import "AddNonConnectedClientViewController.h"
#import "MainViewController.h"
#import "SettingsViewController.h"
#import <QuartzCore/QuartzCore.h>

@interface AddNonConnectedClientViewController ()
@end

@implementation AddNonConnectedClientViewController
@synthesize intType;
@synthesize nonConnectedClientDetailTmp;

- (void)viewDidLoad
{
    [super viewDidLoad];
    service = [[RealEstateService alloc] init];
    _delegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    nonConnectedClientDetail = [[NonConnectedClientDetail alloc] init];
    arrNonConnectedClientsId = [[NSMutableArray alloc]init];
    
    self.navigationController.navigationBarHidden = YES;
    [self addKeyboardControls];
    imgUName.layer.borderColor = [UIColor colorWithRed:220/255.0 green:220/255.0 blue:220/255.0 alpha:1].CGColor;
    imgUName.layer.borderWidth=1.0;
    
    imgFName.layer.borderColor = [UIColor colorWithRed:220/255.0 green:220/255.0 blue:220/255.0 alpha:1].CGColor;
    imgFName.layer.borderWidth=1.0;
    
    imgLName.layer.borderColor = [UIColor colorWithRed:220/255.0 green:220/255.0 blue:220/255.0 alpha:1].CGColor;
    imgLName.layer.borderWidth=1.0;
    
    imgEmail.layer.borderColor = [UIColor colorWithRed:220/255.0 green:220/255.0 blue:220/255.0 alpha:1].CGColor;
    imgEmail.layer.borderWidth=1.0;
    
    imgPassword.layer.borderColor = [UIColor colorWithRed:220/255.0 green:220/255.0 blue:220/255.0 alpha:1].CGColor;
    imgPassword.layer.borderWidth=1.0;
    
    imgCPassword.layer.borderColor = [UIColor colorWithRed:220/255.0 green:220/255.0 blue:220/255.0 alpha:1].CGColor;
    imgCPassword.layer.borderWidth=1.0;
    [scrlView setContentSize:CGSizeMake(self.view.frame.size.width, self.view.frame.size.height)];
    
    if(intType==0)
    {
        btnAdd.hidden=NO;
        btnUpdate.hidden=YES;
        btnRemove.hidden=YES;
        lblType.text=@"Add Non-Connected Clients";
    }
    else
    {
        btnAdd.hidden=YES;
        btnUpdate.hidden=NO;
        btnRemove.hidden=NO;
        lblType.text=@"Edit Non-Connected Clients";
        nonConnectedClientDetail = self.nonConnectedClientDetailTmp;
        [arrNonConnectedClientsId addObject:nonConnectedClientDetail.strId];
        txtFieldUName.text = nonConnectedClientDetail.strUserName;
        txtFieldFName.text = nonConnectedClientDetail.strFirstName;
        txtFieldLName.text = nonConnectedClientDetail.strLastName;
        txtFieldEmail.text = nonConnectedClientDetail.strEmail;
        txtFieldPassword.text = nonConnectedClientDetail.strPassword;
        txtFieldConfirmPassword.text = nonConnectedClientDetail.strPassword;
    }
}

-(IBAction)btnBackCliked
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex==0)
        [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnAddCliked
{
    nonConnectedClientDetail.strUserName = [txtFieldUName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	nonConnectedClientDetail.strFirstName = [txtFieldFName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
	nonConnectedClientDetail.strLastName = [txtFieldLName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    nonConnectedClientDetail.strEmail = [txtFieldEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	nonConnectedClientDetail.strPassword = [txtFieldPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	nonConnectedClientDetail.strCPassword = [txtFieldConfirmPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    BOOL flag = (validateEmail(nonConnectedClientDetail.strEmail));
    BOOL boolFirstName = [self userNameValidate:txtFieldFName.text];
    BOOL boolLastName = [self userNameValidate:txtFieldLName.text];
    if(nonConnectedClientDetail.strUserName == NULL || [nonConnectedClientDetail.strUserName length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter user name!"];
		[txtFieldUName becomeFirstResponder];
        return;
	}
    else if (!boolFirstName)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter valid first name!"];
		[txtFieldFName becomeFirstResponder];
        return;
    }
    
    else if(nonConnectedClientDetail.strFirstName == NULL || [nonConnectedClientDetail.strFirstName length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter first name!"];
		[txtFieldFName becomeFirstResponder];
        return;
	}
    else if (!boolLastName)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter valid last name!"];
		[txtFieldLName becomeFirstResponder];
        return;
    }
    else if(nonConnectedClientDetail.strLastName == NULL || [nonConnectedClientDetail.strLastName length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter last name!"];
		[txtFieldLName becomeFirstResponder];
	}
    else if(nonConnectedClientDetail.strEmail == NULL || [nonConnectedClientDetail.strEmail length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter email ID!"];
		[txtFieldEmail becomeFirstResponder];
        return;
	}
	else if (!flag) {
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter valid email ID!"];
		[txtFieldEmail becomeFirstResponder];
        return;
	}
    else if(nonConnectedClientDetail.strPassword == NULL || [nonConnectedClientDetail.strPassword length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter password!"];
		[txtFieldPassword becomeFirstResponder];
        return;
	}
	else if(nonConnectedClientDetail.strCPassword == NULL || [nonConnectedClientDetail.strCPassword length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter confrim password!"];
		[txtFieldConfirmPassword becomeFirstResponder];
        return;
	}
    else if(nonConnectedClientDetail.strPassword.length<6 ) {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter password at least 6 characters!"];
		[txtFieldPassword becomeFirstResponder];
        return;
    }
    else if(nonConnectedClientDetail.strPassword.length>15)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter password 6 to 15 characters!"];
		[txtFieldPassword becomeFirstResponder];
        return;
    }
    else if(nonConnectedClientDetail.strCPassword.length<6) {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter confirm password at least 6 characters!"];
		[txtFieldConfirmPassword becomeFirstResponder];
        return;
    }
    else if(nonConnectedClientDetail.strCPassword.length>15)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter confirm password 6 to 15 characters!"];
		[txtFieldConfirmPassword becomeFirstResponder];
        return;
    }
	else if (![nonConnectedClientDetail.strCPassword isEqualToString:nonConnectedClientDetail.strPassword])
	{
		[Utils showAlertMessage:@"Twin Realty" Message:@"Password and confirm password doesn’t match!"];
		[txtFieldConfirmPassword becomeFirstResponder];
        return;
	}
    else
    {
        if(isInternetAvailable())
        {
            [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
            [service AddNonConnectedClientDetailInvocation:[[[NSUserDefaults standardUserDefaults] valueForKey:@"userData"] valueForKey:@"user_id"] strUserName:nonConnectedClientDetail.strUserName strEmail:nonConnectedClientDetail.strEmail strFirstName:nonConnectedClientDetail.strFirstName strLastName:nonConnectedClientDetail.strLastName strPassword:nonConnectedClientDetail.strPassword delegate:self];
        }
        else
        {
            [Utils showAlertMessage:@"Twin Realty" Message:@"Internet connection is not available"];
        }
    }
}

-(void)AddNonConnectedClientDetailInvocationDidFinish:(AddNonConnectedClientDetailInvocation*)invocation
                                          withResults:(NSMutableDictionary*)result
                                         withMessages:(NSString*)result1
                                            withError:(NSError*)error;
{
    
    [MBProgressHUD hideAllHUDsForView:_delegate.window animated:YES];
    if(!error)
    {
        if(result==nil || result==(NSMutableDictionary*)[NSNull null])
        {
            [Utils showAlertMessage:@"Twin Realty" Message:result1];
        }
        else if([[result objectForKey:@"message"] isEqualToString:@"success"])
        {
            alertAdd = [[UIAlertView alloc] initWithTitle:@"RealEstate" message:result1 delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alertAdd show];
        }
        else
        {
             [Utils showAlertMessage:@"Twin Realty" Message:result1];
        }
    }
    else{
        [Utils showAlertMessage:@"Twin Realty" Message:@"error"];
    }
}


-(IBAction)btnUpdateCliked
{
    nonConnectedClientDetail.strUserName = [txtFieldUName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	nonConnectedClientDetail.strFirstName = [txtFieldFName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
	nonConnectedClientDetail.strLastName = [txtFieldLName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    nonConnectedClientDetail.strEmail = [txtFieldEmail.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	nonConnectedClientDetail.strPassword = [txtFieldPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
	nonConnectedClientDetail.strCPassword = [txtFieldConfirmPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    BOOL flag = (validateEmail(nonConnectedClientDetail.strEmail));
    BOOL boolFirstName = [self userNameValidate:txtFieldFName.text];
    BOOL boolLastName = [self userNameValidate:txtFieldLName.text];
    if(nonConnectedClientDetail.strUserName == NULL || [nonConnectedClientDetail.strUserName length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter user name!"];
		[txtFieldUName becomeFirstResponder];
        return;
	}
    else if (!boolFirstName)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter valid first name!"];
		[txtFieldFName becomeFirstResponder];
        return;
    }
    
    else if(nonConnectedClientDetail.strFirstName == NULL || [nonConnectedClientDetail.strFirstName length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter first name!"];
		[txtFieldFName becomeFirstResponder];
        return;
	}
    else if (!boolLastName)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter valid last name!"];
		[txtFieldLName becomeFirstResponder];
        return;
    }
    else if(nonConnectedClientDetail.strLastName == NULL || [nonConnectedClientDetail.strLastName length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter last name!"];
		[txtFieldLName becomeFirstResponder];
	}
    else if(nonConnectedClientDetail.strEmail == NULL || [nonConnectedClientDetail.strEmail length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter email ID!"];
		[txtFieldEmail becomeFirstResponder];
        return;
	}
	else if (!flag) {
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter valid email ID!"];
		[txtFieldEmail becomeFirstResponder];
        return;
	}
    else if(nonConnectedClientDetail.strPassword == NULL || [nonConnectedClientDetail.strPassword length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter password!"];
		[txtFieldPassword becomeFirstResponder];
        return;
	}
	else if(nonConnectedClientDetail.strCPassword == NULL || [nonConnectedClientDetail.strCPassword length] == 0){
		[Utils showAlertMessage:@"Twin Realty" Message:@"Please enter confrim password!"];
		[txtFieldConfirmPassword becomeFirstResponder];
        return;
	}
    else if(nonConnectedClientDetail.strPassword.length<6 ) {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter password at least 6 characters!"];
		[txtFieldPassword becomeFirstResponder];
        return;
    }
    else if(nonConnectedClientDetail.strPassword.length>15)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter password 6 to 15 characters!"];
		[txtFieldPassword becomeFirstResponder];
        return;
    }
    else if(nonConnectedClientDetail.strCPassword.length<6) {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter confirm password at least 6 characters!"];
		[txtFieldConfirmPassword becomeFirstResponder];
        return;
    }
    else if(nonConnectedClientDetail.strCPassword.length>15)
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter confirm password 6 to 15 characters!"];
		[txtFieldConfirmPassword becomeFirstResponder];
        return;
    }
	else if (![nonConnectedClientDetail.strCPassword isEqualToString:nonConnectedClientDetail.strPassword])
	{
		[Utils showAlertMessage:@"Twin Realty" Message:@"Password and confirm password doesn’t match!"];
		[txtFieldConfirmPassword becomeFirstResponder];
        return;
	}
    else
    {
        if(isInternetAvailable())
        {
            [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
            [service UpdateNonConnectedClientDetailInvocation:nonConnectedClientDetail.strId strUserName:nonConnectedClientDetail.strUserName strEmail:nonConnectedClientDetail.strEmail strFirstName:nonConnectedClientDetail.strFirstName strLastName:nonConnectedClientDetail.strLastName strPassword:nonConnectedClientDetail.strPassword delegate:self];
        }
        else
        {
            [Utils showAlertMessage:@"Twin Realty" Message:@"Internet connection is not available"];
        }
    }
}

-(void)UpdateNonConnectedClientDetailInvocationDidFinish:(UpdateNonConnectedClientDetailInvocation*)invocation
                                             withResults:(NSMutableDictionary*)result
                                            withMessages:(NSString*)result1
                                               withError:(NSError*)error;
{
    [MBProgressHUD hideAllHUDsForView:_delegate.window animated:YES];
    if(!error)
    {
        if(result==nil || result==(NSMutableDictionary*)[NSNull null]){
            [Utils showAlertMessage:@"Twin Realty" Message:result1];
        }
        else if([[result objectForKey:@"message"] isEqualToString:@"success"])
        {
            alertUpdated = [[UIAlertView alloc] initWithTitle:@"Twin Realty" message:result1 delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alertUpdated show];
        }
        else
        {
            [Utils showAlertMessage:@"Twin Realty" Message:result1];
        }
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"error"];
    }
}

-(IBAction)btnDeleteCliked
{
   
    [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
    [service DeleteNonConnectedClientDetailInvocation:arrNonConnectedClientsId delegate:self];
    
    
}

-(void)DeleteNonConnectedClientDetailInvocationDidFinish:(DeleteNonConnectedClientDetailInvocation*)invocation
                                             withResults:(NSMutableDictionary*)result
                                            withMessages:(NSString*)result1
                                               withError:(NSError*)error;
{
   [MBProgressHUD hideAllHUDsForView:_delegate.window animated:YES];
    if(!error)
    {
        if(result==nil || result==(NSMutableDictionary*)[NSNull null]){
            [Utils showAlertMessage:@"Twin Realty" Message:result1];
        }
        else if([[result objectForKey:@"message"] isEqualToString:@"success"])
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
        else
        {
            [Utils showAlertMessage:@"Twin Realty" Message:result1];
        }
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"error"];
    }
}

#pragma mark Registration method
- (BOOL)userNameValidate:(NSString *)strName;
{
    NSCharacterSet *s = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890_ "];
    s = [s invertedSet];
    NSRange r = [strName rangeOfCharacterFromSet:s];
    if (r.location != NSNotFound)
        return NO;
    return YES;
}

#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    
    keyboardControls.textFields = [NSArray arrayWithObjects:txtFieldUName,txtFieldFName,txtFieldLName,txtFieldEmail,txtFieldPassword,txtFieldConfirmPassword, nil];
    
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"Previous";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"Next";
    
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] applicationFrame];
    
    CGFloat availableHeight = applicationFrame.size.height - 200; // Remove area covered by keyboard
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
    [scrlView setContentOffset:CGPointMake(0, y) animated:YES];
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    [controls.activeTextField resignFirstResponder];
    [scrlView setContentOffset:CGPointMake(0, 0) animated:YES];
}

- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}

#pragma UITextField Delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([keyboardControls.textFields containsObject:textField])
        keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
