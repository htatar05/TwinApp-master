//
//  LoginViewController.h
//  RealState
//
//  Created by Kapil Goyal on 27/08/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BSKeyboardControls.h"
#import "NonConnectedClientDetail.h"
#import "Utils.h"
#import "MBProgressHUD.h"
#import "RealEstateService.h"
#import "UpdateNonConnectedClientDetailInvocation.h"
#import "AddNonConnectedClientDetailInvocation.h"
#import "DeleteNonConnectedClientDetailInvocation.h"

@interface AddNonConnectedClientViewController:UIViewController<BSKeyboardControlsDelegate,UITextFieldDelegate,UIAlertViewDelegate,UpdateNonConnectedClientDetailInvocationDelegate,AddNonConnectedClientDetailInvocationDelegate,DeleteNonConnectedClientDetailInvocationDelegate>
{
    BSKeyboardControls *keyboardControls;
    AppDelegate * _delegate;
    IBOutlet UIImageView *imgUName;
    IBOutlet UIImageView *imgFName;
    IBOutlet UIImageView *imgLName;
    IBOutlet UIImageView *imgEmail;
    IBOutlet UIImageView *imgPassword;
    IBOutlet UIImageView *imgCPassword;

    IBOutlet UITextField *txtFieldUName;
    IBOutlet UITextField *txtFieldFName;
    IBOutlet UITextField *txtFieldLName;
    IBOutlet UITextField *txtFieldEmail;
    IBOutlet UITextField *txtFieldPassword;
    IBOutlet UITextField *txtFieldConfirmPassword;
    IBOutlet UIButton *btnBack;
    
    IBOutlet UIScrollView *scrlView;
    IBOutlet UIButton *btnAdd;
    IBOutlet UIButton *btnUpdate;
    IBOutlet UIButton *btnRemove;
    IBOutlet UILabel *lblType;
    
    NonConnectedClientDetail *nonConnectedClientDetail;
    RealEstateService *service;
    
    UIAlertControllerStyle *alertAdd;
    //UIAlertView *alertAdd;
    UIAlertControllerStyle *alertUpdated;
    //UIAlertView *alertUpdate;
    NSMutableArray *arrNonConnectedClientsId;
    
}
@property(nonatomic,strong)NonConnectedClientDetail *nonConnectedClientDetailTmp;

-(IBAction)btnBackCliked;
-(IBAction)btnAddCliked;
-(IBAction)btnUpdateCliked;
-(IBAction)btnDeleteCliked;

@property(nonatomic,assign)int intType;
@end

