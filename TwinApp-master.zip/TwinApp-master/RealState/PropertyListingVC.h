//  PropertyListingVC.h
//  RealEstate_App
//  Created by Octal on 13/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "BSKeyboardControls.h"
#import "DBManager.h"

@interface PropertyListingVC : UIViewController<BSKeyboardControlsDelegate,UITextFieldDelegate>
{
    IBOutlet UITableView *tblListing;
    NSMutableArray *propertyDataArr;
    AppDelegate *appDelegate;
    NSInteger countAvail;
    IBOutlet UIView *footerView;
    NSString *strPagingId;
    IBOutlet UILabel *lblCountShowing;
    IBOutlet UITextField *txtSearch;
    BSKeyboardControls *keyboardControls;
    UILabel *lblNoRecord;
    UILabel *lblNoRecord2;
    UIRefreshControl* refreshControl;
    UIView *refreshLoadingView;
}
@property (nonatomic,strong) NSMutableDictionary *param ;
@property (nonatomic,strong) NSString *propertyAvail ;
@property (nonatomic,strong) NSString *selectedType;
@property (nonatomic, strong) NSArray *propertyDetail;
@property (nonatomic, strong) NSArray *infoArray;
@property (nonatomic, strong) DBManager *dbManager;


@end
