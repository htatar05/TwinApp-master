//
//  MainViewController.h
//  RealState
//  Created by Kapil Goyal on 09/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "AppDelegate.h"
#import "SavedSearchViewController.h"
#import "BSKeyboardControls.h"
#import "JTRevealSidebarV2Delegate.h"
#import "UIViewController+JTRevealSidebarV2.h"
#import "UINavigationItem+JTRevealSidebarV2.h"
#import "MapIndex.h"
#import "DBManager.h"




@class SPGooglePlacesAutocompleteQuery;
@class SidebarViewController;

@interface MainViewController : UIViewController<UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource,JTRevealSidebarV2Delegate,UIGestureRecognizerDelegate,CLLocationManagerDelegate,BSKeyboardControlsDelegate,UITextFieldDelegate>
{
    UITapGestureRecognizer *tapGestureOnMap;
    UITapGestureRecognizer *tapGestureOnBtnNavigation;
    UITapGestureRecognizer *tapGestureOnBtnLayer;
    UITapGestureRecognizer *tapGestureOnBtnNearBy;
    AppDelegate * _delegate;
    BSKeyboardControls *keyboardControls;
    IBOutlet UIImageView *imgHeaderView;
    IBOutlet UIView *viewBottom;
    IBOutlet UIButton *btnBack;
    IBOutlet UITextField *txtSearch;
    IBOutlet UIButton *btnNavigation;
    IBOutlet UIButton *btnFilter;
    IBOutlet UIButton *btnNearBy;
    IBOutlet UIButton *btnDraw;
    IBOutlet UIButton *btnInfo;
    IBOutlet UIButton *btnLayer;
    IBOutlet UIButton *btnList;
    IBOutlet UIButton *btnSavedSearch;
    IBOutlet UIView *viewDraw;
    IBOutlet UIButton *btnClear;
    IBOutlet UITableView *myTable;
    IBOutlet UIView *clusterTbl;
    IBOutlet UIView *loadingView;
    bool isDrawing;
    
    NSArray *searchResultPlaces;
    SPGooglePlacesAutocompleteQuery *searchQuery;
    BOOL shouldBeginEditing;
    UITableView *addressTable;
    NSArray *infoArray;
    NSMutableDictionary *passDict;
    NSString *strDefaultText;
    NSMutableArray *arrAllCordinatesArray;
   // NSMutableArray *developmentArr;
}

@property (nonatomic, strong) SidebarViewController *leftSidebarViewController;
@property (nonatomic, strong) IBOutlet MIMapView *mapView;
@property (nonatomic, strong) NSString* selectedValue;
@property (nonatomic, strong) NSString*isFromSavedSearch;
@property (nonatomic, strong) NSString*isFromFavourite;
@property (nonatomic, strong) NSString*propertyId;
@property (nonatomic, strong)NSMutableString *AppendString;
@property (nonatomic, strong) DBManager *dbManager;
@property (nonatomic, strong) NSArray *propertyDetail;


-(IBAction)btnDrawClicked;
-(IBAction)btnCancelClicked;
-(IBAction)btnApplyClicked;
-(IBAction)btnLayerClicked;
-(IBAction)btnListClicked;
-(IBAction)btnSaveSearchedClicked;
-(IBAction)btnFilterClicked;
-(IBAction)btnInfoClicked;

- (void)touchesBegan:(UITouch*)touch;
- (void)touchesMoved:(UITouch*)touch;
- (void)touchesEnded:(UITouch*)touch;






@end
