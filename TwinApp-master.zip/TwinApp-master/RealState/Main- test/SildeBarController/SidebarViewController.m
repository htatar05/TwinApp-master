//  LeftSidebarViewController.m
//  JTRevealSidebarDemo
//  Created by James Apple Tang on 12/12/11.


#import "SidebarViewController.h"
#import "RenameSavedSearchViewController.h"
#import "AppDelegate.h"
#import "LoginViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "Config.h"
#import "UIImageView+UIActivityIndicatorForSDWebImage.h"
#import "UIImageView+HighlightedWebCache.h"
#import "AGPushNoteView.h"


@implementation SidebarViewController
@synthesize sidebarDelegate;

UIView *headerView;

-(id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self)
    {
        
    }
    return self;
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    
    [super viewDidLoad];
    user = [[User alloc] init];
    headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 600, 98)];
    UIImageView *img = [[UIImageView alloc] initWithFrame:CGRectMake(55, 10, 154, 78)];
    img.image = [UIImage imageNamed:@"logo.png"];
    headerView.backgroundColor = [UIColor redColor];
    [headerView addSubview:img];
    headerView.layer.zPosition = 1;
    [self.view addSubview:headerView];
    
    UIView *viewTop  = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 600, 98)];
    headerView.backgroundColor = [UIColor whiteColor];
    self.tableView.tableHeaderView = viewTop;
    self.tableView.showsVerticalScrollIndicator=NO;
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
        [self.tableView setSeparatorInset:UIEdgeInsetsZero];
   
    [self loadData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ReloadSideMenu) name:@"ReloadSideMenu" object:nil];
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
}

-(void)ReloadSideMenu {
    [self loadData];
}

-(void)loadData
{
    dataArrayItem =  [[NSMutableArray alloc] init];
    dataArrayImage = [[NSMutableArray alloc] init];
    arrSectionName = [[NSMutableArray alloc] initWithObjects:@"Home Search",@"My Real Estate Center",@"Account", nil];

    user.strRoleId = [[NSUserDefaults standardUserDefaults]objectForKey:@"RoleId"];
    
    if((NSNull *)user.strRoleId!=[NSNull null] && user.strRoleId!= nil && ![user.strRoleId isEqualToString:@"0"])
    {
        if([user.strRoleId isEqualToString:@"1"] || [user.strRoleId isEqualToString:@"2"] || [user.strRoleId isEqualToString:@"3"])
            [arrSectionName insertObject:@"My Clients" atIndex:2];
        else if([user.strRoleId isEqualToString:@"4"])
            [arrSectionName insertObject:@"Agent" atIndex:2];
    }
    
    [AppDelegate sharedDelegate].arrSectionCount = arrSectionName;
    
    NSArray *firstItemsArray = [[NSArray alloc] initWithObjects:@" For Sale", @" For Rent", @" Sold",@" All Properties", nil];
    
    NSDictionary *firstItemsArrayDict = [NSDictionary dictionaryWithObject:firstItemsArray forKey:@"data"];
    [dataArrayItem addObject:firstItemsArrayDict];
    
    NSMutableArray *secondItemsArray = [[NSMutableArray alloc] initWithObjects:@" Saved Searches", @" Favorite Homes", nil];
    
    NSMutableArray *secondItemsImageArray = [[NSMutableArray alloc] initWithObjects:[UIImage imageNamed:@"saved_srch.png"], [UIImage imageNamed:@"fav_home.png"], nil];
    
    if((NSNull*)user.strRoleId!=[NSNull null] && user.strRoleId!= nil && ![user.strRoleId isEqualToString:@"0"])
    {
        if([user.strRoleId isEqualToString:@"1"] || [user.strRoleId isEqualToString:@"2"] || [user.strRoleId isEqualToString:@"3"] || [user.strRoleId isEqualToString:@"4"])
        {
            [secondItemsArray addObject:@" Showings"];
            [secondItemsImageArray addObject:[UIImage imageNamed:@"showings_icon.png"]];
        }
    }
    
    NSDictionary *secondItemsArrayDict = [NSDictionary dictionaryWithObject:secondItemsArray forKey:@"data"];
    [dataArrayItem addObject:secondItemsArrayDict];
    
    if((NSNull*)user.strRoleId!=[NSNull null] && user.strRoleId!= nil && ![user.strRoleId isEqualToString:@"0"])
    {
        if ([user.strRoleId isEqualToString:@"1"] || [user.strRoleId isEqualToString:@"2"]) {
            
            NSMutableArray *thirdItemsArray = [[NSMutableArray alloc] initWithObjects:@" Connected-Clients",@" Non-Connected Clients",@" My Agents", nil];
            
            NSDictionary *thirdItemArrayDict = [NSDictionary dictionaryWithObject:thirdItemsArray forKey:@"data"];
            [dataArrayItem addObject:thirdItemArrayDict];
        }
        
        else if([user.strRoleId isEqualToString:@"3"])
        {
            NSMutableArray *thirdItemsArray = [[NSMutableArray alloc] initWithObjects:@" Connected-Clients",@" Non-Connected Clients",nil];
            NSDictionary *thirdItemArrayDict = [NSDictionary dictionaryWithObject:thirdItemsArray forKey:@"data"];
            [dataArrayItem addObject:thirdItemArrayDict];
        }
        
        else if([user.strRoleId isEqualToString:@"4"])
        {
            NSMutableArray *thirdItemsArray  = [[NSMutableArray alloc] initWithObjects:@" Assigned Agent",nil];
            NSDictionary *thirdItemArrayDict = [NSDictionary dictionaryWithObject:thirdItemsArray forKey:@"data"];
            [dataArrayItem addObject:thirdItemArrayDict];
        }
    }
    
    if(![user.strRoleId isEqualToString:@"0"])
    {
        if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| [AppDelegate sharedDelegate].loginUser) {
            NSString *strUserName =[NSString stringWithFormat:@" %@ %@",[[[NSUserDefaults standardUserDefaults]objectForKey:@"userData"] valueForKey:@"first_name"],[[[NSUserDefaults standardUserDefaults]objectForKey:@"userData"] valueForKey:@"last_name"]];
            if ([strUserName isEqualToString:@" (null) (null)"]){
                strUserName = [AppDelegate sharedDelegate].user.strFName;
                
                strUserName = [NSString stringWithFormat:@" %@ %@",[AppDelegate sharedDelegate].user.strFName,[AppDelegate sharedDelegate].user.strLName];
            }
            NSArray *fourthItemsArray = [[NSArray alloc] initWithObjects:strUserName,@" Logout", @" Settings", nil];
            
            NSDictionary *fourthItemsArrayDict = [NSDictionary dictionaryWithObject:fourthItemsArray forKey:@"data"];
            [dataArrayItem addObject:fourthItemsArrayDict];
            
        }
        else
        {
            
            NSArray *fourthItemsArray = [[NSArray alloc] initWithObjects:@" Login/Register", @" Settings", nil];
            NSDictionary *fourthItemsArrayDict = [NSDictionary dictionaryWithObject:fourthItemsArray forKey:@"data"];
            [dataArrayItem addObject:fourthItemsArrayDict];
            
        }
    }
    else
    {
        NSArray *fourthItemsArray = [[NSArray alloc] initWithObjects:@" Login/Register", @" Settings", nil];
        NSDictionary *fourthItemsArrayDict = [NSDictionary dictionaryWithObject:fourthItemsArray forKey:@"data"];
        [dataArrayItem addObject:fourthItemsArrayDict];
    }
    
    NSArray *firstItemsImageArray = [[NSArray alloc] initWithObjects:[UIImage imageNamed:@"for_sale.png"], [UIImage imageNamed:@"for_rent.png"], [UIImage imageNamed:@"sold.png"], [UIImage imageNamed:@"all_properties.png"], nil];
    
    NSDictionary *firstImageArrayDict = [NSDictionary dictionaryWithObject:firstItemsImageArray forKey:@"data"];
    [dataArrayImage addObject:firstImageArrayDict];
    
    NSDictionary *secondImageArrayDict = [NSDictionary dictionaryWithObject:secondItemsImageArray forKey:@"data"];
    [dataArrayImage addObject:secondImageArrayDict];
    
    if((NSNull*)user.strRoleId!=[NSNull null] && user.strRoleId!= nil && ![user.strRoleId isEqualToString:@"0"])
    {
        if ([user.strRoleId isEqualToString:@"1"] || [user.strRoleId isEqualToString:@"2"])
        {
            NSMutableArray *thirdItemsImageArray = [[NSMutableArray alloc] initWithObjects:[UIImage imageNamed:@"connected_clients.png"], [UIImage imageNamed:@"non_connected_clients.png"],[UIImage imageNamed:@"agent_icon.png"], nil];
            NSDictionary *thirdImageArrayDict = [NSDictionary dictionaryWithObject:thirdItemsImageArray forKey:@"data"];
            [dataArrayImage addObject:thirdImageArrayDict];
        }
        
        else if([user.strRoleId isEqualToString:@"3"])
        {
            NSMutableArray *thirdItemsImageArray = [[NSMutableArray alloc] initWithObjects:[UIImage imageNamed:@"connected_clients.png"], [UIImage imageNamed:@"non_connected_clients.png"],nil];
            NSDictionary *thirdImageArrayDict = [NSDictionary dictionaryWithObject:thirdItemsImageArray forKey:@"data"];
            [dataArrayImage addObject:thirdImageArrayDict];
        }
        else if([user.strRoleId isEqualToString:@"4"])
        {
            NSMutableArray *thirdItemsImageArray = [[NSMutableArray alloc] initWithObjects:[UIImage imageNamed:@"agent_icon.png"],nil];
            NSDictionary *thirdImageArrayDict = [NSDictionary dictionaryWithObject:thirdItemsImageArray forKey:@"data"];
            [dataArrayImage addObject:thirdImageArrayDict];
        }
    }
    if(![user.strRoleId isEqualToString:@"0"])
    {
        NSString *userImage =[NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults]objectForKey:@"userData"] valueForKey:@"userimage"]];
        if ([userImage isEqualToString:@" (null)"]) {
            userImage = [AppDelegate sharedDelegate].user.strUserImage;
        }
        else if ([userImage isEqualToString:@""])
        {
          userImage = @"upload_pic.png";
        }
       
        NSString *strTemp = [NSString stringWithFormat:@"%@%@",profileImage,userImage];
        NSData * imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:strTemp]];
        UIImage *image = [[UIImage alloc] initWithData:imageData];
        
        if (image==nil) {
            image = [UIImage imageNamed:@"upload_pic.png"];
        }
       
        NSArray *fourthItemsImageArray = [[NSArray alloc] initWithObjects:image,[UIImage imageNamed:@"logout.png"], [UIImage imageNamed:@"setting.png"], nil];
        NSDictionary *fourthImageArrayDict = [NSDictionary dictionaryWithObject:fourthItemsImageArray forKey:@"data"];
        [dataArrayImage addObject:fourthImageArrayDict];
        
        
        /*
        NSArray *fourthItemsImageArray = [[NSArray alloc] initWithObjects:[UIImage imageNamed:@"user_img.png"],[UIImage imageNamed:@"logout.png"], [UIImage imageNamed:@"setting.png"], nil];
        NSDictionary *fourthImageArrayDict = [NSDictionary dictionaryWithObject:fourthItemsImageArray forKey:@"data"];
        [dataArrayImage addObject:fourthImageArrayDict];
         */
    }
    else
    {
        NSArray *fourthItemsImageArray = [[NSArray alloc] initWithObjects:[UIImage imageNamed:@"login_icon.png"], [UIImage imageNamed:@"setting.png"], nil];
        NSDictionary *fourthImageArrayDict = [NSDictionary dictionaryWithObject:fourthItemsImageArray forKey:@"data"];
        [dataArrayImage addObject:fourthImageArrayDict];
    }
    [self.tableView reloadData];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [arrSectionName count];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *viewHeader = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 275, 37)];
    [viewHeader setBackgroundColor:[UIColor clearColor]];
    
    UIImage *myImage = [UIImage imageNamed:@"top_blue.png"];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:myImage];
    imageView.frame = CGRectMake(0,0,270,37);
    [viewHeader addSubview:imageView];
    
    UILabel *lbl = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, 200, 37)];
    lbl.backgroundColor = [UIColor clearColor];
    lbl.text = [arrSectionName objectAtIndex:section];
    lbl.textColor = [UIColor whiteColor];
    lbl.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
    [viewHeader addSubview:lbl];
    return viewHeader;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 37;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    int count;
    NSDictionary *dictionary = [dataArrayItem objectAtIndex:section];
    NSArray *array = [dictionary objectForKey:@"data"];
    return  [array count];
    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell=nil;
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    NSDictionary *dictionary = [dataArrayImage objectAtIndex:indexPath.section];
    NSArray *array = [dictionary objectForKey:@"data"];
    
    NSDictionary *dictionaryItem = [dataArrayItem objectAtIndex:indexPath.section];
    NSArray *arrayItem = [dictionaryItem objectForKey:@"data"];

    if(indexPath.section==2 && [arrSectionName count]==3)
    {
        if(![user.strRoleId isEqualToString:@"0"])
        {
            if(indexPath.row==0)
            {
                imgViewIcon = [[UIImageView alloc] initWithFrame:CGRectMake(14, 13, 18, 18)];
           
                [cell.contentView addSubview:imgViewIcon];
                imgViewIcon.layer.masksToBounds=YES;
                
                NSString *userImage =[NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults]objectForKey:@"userData"] valueForKey:@"userimage"]];
                if ([userImage isEqualToString:@"(null)"]) {
                    userImage = [AppDelegate sharedDelegate].user.strUserImage;
                }
                
                NSString *strTemp = [NSString stringWithFormat:@"%@%@",profileImage,userImage];
                
                [imgViewIcon setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",strTemp]] placeholderImage:[UIImage imageNamed:@"non_connected_clients"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                
               
                imgViewIcon.layer.cornerRadius=9;
                lblHomeType = [[UILabel alloc] initWithFrame:CGRectMake(33, 5, 200, 35)];
            }
            else
            {
                imgViewIcon = [[UIImageView alloc] initWithFrame:CGRectMake(14, 13, 18, 18)];
                imgViewIcon.image = [array objectAtIndex:indexPath.row];
                [cell.contentView addSubview:imgViewIcon];
                lblHomeType = [[UILabel alloc] initWithFrame:CGRectMake(33, 5, 200, 35)];
            }
        }
        else
        {
            imgViewIcon = [[UIImageView alloc] initWithFrame:CGRectMake(14, 13, 18, 18)];
            imgViewIcon.image = [array objectAtIndex:indexPath.row];
            [cell.contentView addSubview:imgViewIcon];
            lblHomeType = [[UILabel alloc] initWithFrame:CGRectMake(33, 5, 200, 35)];
        }
    }
  
    else if(indexPath.section==3 && [arrSectionName count]==4)
    {
        if(![user.strRoleId isEqualToString:@"0"])
        {
            if(indexPath.row==0)
            {
                imgViewIcon = [[UIImageView alloc] initWithFrame:CGRectMake(14, 13, 18, 18)];
                [cell.contentView addSubview:imgViewIcon];
             
                NSString *userImage =[NSString stringWithFormat:@"%@",[[[NSUserDefaults standardUserDefaults]objectForKey:@"userData"] valueForKey:@"userimage"]];
                if ([userImage isEqualToString:@"(null)"]) {
                    userImage = [AppDelegate sharedDelegate].user.strUserImage;
                }
                else if ([userImage isEqualToString:@""])
                {
                    userImage = @"upload_pic.png";
                }
                
                NSString *strTemp = [NSString stringWithFormat:@"%@%@",profileImage,userImage];
                [imgViewIcon setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",strTemp]] placeholderImage:[UIImage imageNamed:@"non_connected_clients"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            
                imgViewIcon.layer.masksToBounds=YES;
                imgViewIcon.layer.cornerRadius=9;
                lblHomeType = [[UILabel alloc] initWithFrame:CGRectMake(33, 5, 200, 35)];
            }
            else
            {
                imgViewIcon = [[UIImageView alloc] initWithFrame:CGRectMake(14, 13, 18, 18)];
                imgViewIcon.image = [array objectAtIndex:indexPath.row];
                [cell.contentView addSubview:imgViewIcon];
                lblHomeType = [[UILabel alloc] initWithFrame:CGRectMake(33, 5, 200, 35)];
            }
        }
        else
        {
            imgViewIcon = [[UIImageView alloc] initWithFrame:CGRectMake(14, 13, 18, 18)];
            imgViewIcon.image = [array objectAtIndex:indexPath.row];
            [cell.contentView addSubview:imgViewIcon];
            lblHomeType = [[UILabel alloc] initWithFrame:CGRectMake(33, 5, 200, 35)];
        }
    }
    
    else if(indexPath.section==2 && [arrSectionName count]==4)
    {
        if([user.strRoleId isEqualToString:@"1"]||[user.strRoleId isEqualToString:@"2"]||[user.strRoleId isEqualToString:@"3"])
        {
            if(indexPath.row==0 || indexPath.row==1)
            {
                imgViewIcon = [[UIImageView alloc] initWithFrame:CGRectMake(8, 15, 27, 14)];
               // imgViewIcon.image = [array objectAtIndex:indexPath.row];
                [cell.contentView addSubview:imgViewIcon];
                lblHomeType = [[UILabel alloc] initWithFrame:CGRectMake(33, 5, 200, 35)];
            }
            else
            {
                imgViewIcon = [[UIImageView alloc] initWithFrame:CGRectMake(14, 13, 18, 18)];
               // imgViewIcon.image = [array objectAtIndex:indexPath.row];
                [cell.contentView addSubview:imgViewIcon];
                lblHomeType = [[UILabel alloc] initWithFrame:CGRectMake(33, 5, 200, 35)];
            }
        }
        
        else if([user.strRoleId isEqualToString:@"4"])
        {
            imgViewIcon = [[UIImageView alloc] initWithFrame:CGRectMake(14, 13, 18, 18)];
           // imgViewIcon.image = [array objectAtIndex:indexPath.row];
            [cell.contentView addSubview:imgViewIcon];
            lblHomeType = [[UILabel alloc] initWithFrame:CGRectMake(33, 5, 200, 35)];
        }
    }
    else
    {
        imgViewIcon = [[UIImageView alloc] initWithFrame:CGRectMake(14, 13, 18, 18)];
      //  imgViewIcon.image = [array objectAtIndex:indexPath.row];
        [cell.contentView addSubview:imgViewIcon];
        lblHomeType = [[UILabel alloc] initWithFrame:CGRectMake(33, 5, 200, 35)];
    }
    
    lblHomeType.text = [arrayItem objectAtIndex:indexPath.row];
    [lblHomeType setMinimumScaleFactor:8.0/[UIFont labelFontSize]];
    lblHomeType.adjustsFontSizeToFitWidth = YES;
    [cell.contentView addSubview:lblHomeType];
    imgArrow = [[UIImageView alloc] initWithFrame:CGRectMake(245, 15, 12, 16)];
    imgArrow.image = [UIImage imageNamed:@"arrow.png"];
    [cell.contentView addSubview:imgArrow];
    int tagValue = (indexPath.section*100)+(indexPath.row);
    cell.tag=tagValue;
    lblHomeType.textColor = [UIColor colorWithRed:83/255.0 green:83/255.0 blue:83/255.0 alpha:1];
    if(indexPath.section==1 && [arrSectionName count]==4)
    {
        if (indexPath.row==0) {
            
            UILabel *lblCount = [[UILabel alloc]initWithFrame:CGRectMake(185, 15, 25, 15)];
            lblCount.layer.cornerRadius = 2.0;
            lblCount.font = [UIFont systemFontOfSize:10];
            lblCount.layer.masksToBounds = YES;
            lblCount.textColor = [UIColor whiteColor];
            lblCount.textAlignment = NSTextAlignmentCenter;
            lblCount.backgroundColor = [UIColor redColor];
            if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"SavedSearchCount"] isEqualToString:@"0"]|| [[NSUserDefaults standardUserDefaults]valueForKey:@"SavedSearchCount"]==nil) {
                lblCount.backgroundColor = [UIColor clearColor];
                lblCount.text = @"";
                
            } else {
                
                lblCount.backgroundColor = [UIColor redColor];
                lblCount.text = [[NSUserDefaults standardUserDefaults]valueForKey:@"SavedSearchCount"];
                
            }
             [cell.contentView addSubview:lblCount];
            
            
        }
        else if (indexPath.row==1)
        {
            UILabel *lblCount = [[UILabel alloc]initWithFrame:CGRectMake(185, 15, 25, 15)];
            lblCount.font = [UIFont systemFontOfSize:10];
            lblCount.layer.cornerRadius = 2.0;
            lblCount.layer.masksToBounds = YES;
            lblCount.textColor = [UIColor whiteColor];
            lblCount.textAlignment = NSTextAlignmentCenter;
            if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"FavouriteCount"] isEqualToString:@"0"]|| [[NSUserDefaults standardUserDefaults]valueForKey:@"FavouriteCount"]==nil) {
                lblCount.backgroundColor = [UIColor clearColor];
                lblCount.text = @"";
                
            } else {
                
                lblCount.backgroundColor = [UIColor redColor];
                lblCount.text = [[NSUserDefaults standardUserDefaults]valueForKey:@"FavouriteCount"];
                
            }
            [cell.contentView addSubview:lblCount];
            
            
        }
        else{
            
            UILabel *lblCount = [[UILabel alloc]initWithFrame:CGRectMake(185, 15, 25, 15)];
            lblCount.font = [UIFont systemFontOfSize:10];
            lblCount.layer.cornerRadius = 2.0;
            lblCount.layer.masksToBounds = YES;
            lblCount.textColor = [UIColor whiteColor];
            lblCount.textAlignment = NSTextAlignmentCenter;
            if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"showingCount"] isEqualToString:@"0"]|| [[NSUserDefaults standardUserDefaults]valueForKey:@"showingCount"]==nil) {
                lblCount.backgroundColor = [UIColor clearColor];
                lblCount.text = @"";
                
            } else {
                
                lblCount.backgroundColor = [UIColor redColor];
                lblCount.text = [[NSUserDefaults standardUserDefaults]valueForKey:@"showingCount"];
                
            }
             [cell.contentView addSubview:lblCount];
        }
        
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (self.sidebarDelegate)
    {
        if([user.strRoleId isEqualToString:@"0"] && indexPath.section==2 && indexPath.row==0)
        {
            [AppDelegate sharedDelegate].boolLoginNotNow = TRUE;
            [AppDelegate sharedDelegate].boolLogin = FALSE;
            [AppDelegate sharedDelegate].boolLoginPresent=FALSE;
            
            LoginViewController *login;
            if (IS_IPHONE) {
                 login= [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPhone" bundle:nil];
            } else {
                 login= [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPad" bundle:nil];
            }
           
            if (IS_IPHONE) {
                if(IsRunningTallPhone())
                    login.view.frame=CGRectMake(0, 568, 320, 568);
                else
                    login.view.frame=CGRectMake(0, 480, 320, 480);
            } else {
                
                login.view.frame=CGRectMake(0, 1024, 768, 1024);
            }
            

            [[AppDelegate sharedDelegate].window addSubview:login.view];
            [UIView animateWithDuration:0.5
                                  delay:0.0
                                options:1
                             animations:^{
                                 
                                 if (IS_IPHONE) {
                                     
                                     if(IsRunningTallPhone())
                                         login.view.frame=CGRectMake(0, 0, 320, 568);
                                     else
                                         login.view.frame=CGRectMake(0, 0, 320, 480);
                                 } else {
                                     
                                     login.view.frame=CGRectMake(0, 0, 768, 1024);
                                 }
                                 
                             }
                             completion:^(BOOL finished){}];
         
        }
        
        else if([user.strRoleId isEqualToString:@"1"] || [user.strRoleId isEqualToString:@"2"] || [user.strRoleId isEqualToString:@"3"] ||  [user.strRoleId isEqualToString:@"4"])
        {
            if((indexPath.section==3) && (indexPath.row==1))
            {
               // [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"role_id"];
               // [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"RoleId"];
                
                {
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
                    [dict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] forKey:@"user_id"];
                    [REWebService CallLogout:dict withBlock:^(NSDictionary *dictResult, NSError *error) {
                        if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]){
                            
                            [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                            
                            [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"userData"];
                            [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"user_id"];
                            [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"RoleId"];
                            [AppDelegate sharedDelegate].loginUser = NO;
                            [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"loginstatus"];
                            AskForLoginViewController *pVC ;
                            
                            if (IS_IPHONE) { 
                               pVC = [[AskForLoginViewController alloc] initWithNibName:@"AskForLoginViewController_iPhone" bundle:nil];
                            } else {
                                pVC = [[AskForLoginViewController alloc] initWithNibName:@"AskForLoginViewController_iPad" bundle:nil];
                            }
                            
                            [AppDelegate sharedDelegate].navigationController = [[UINavigationController alloc] initWithRootViewController:pVC] ;
                            [AppDelegate sharedDelegate].window.rootViewController = [AppDelegate sharedDelegate].navigationController;
                            
                        }
                        else{
                            
                            [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"message"]];
                        }
                        
                        NSLog(@"%@",dictResult);
                        
                    }];
                
                }
               // [self loadData];
                
            }
            else
            {
                NSObject *object = [NSString stringWithFormat:@"%@", @"MainViewController_iPhone"];
                [self.sidebarDelegate sidebarViewController:self didSelectObject:object atIndexPath:indexPath];
            }
        }
        else
        {
            NSObject *object = [NSString stringWithFormat:@"%@", @"MainViewController_iPhone"];
            [self.sidebarDelegate sidebarViewController:self didSelectObject:object atIndexPath:indexPath];
        }
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView {
    CGRect newFrame = headerView.frame;
    newFrame.origin.x = 0;
    newFrame.origin.y = self.tableView.contentOffset.y;
    headerView.frame = newFrame;
}
@end
