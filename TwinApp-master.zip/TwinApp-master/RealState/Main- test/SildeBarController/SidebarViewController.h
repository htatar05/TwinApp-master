//
//  LeftSidebarViewController.h
//  JTRevealSidebarDemo
//
//  Created by James Apple Tang on 12/12/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "User.h"


@protocol SidebarViewControllerDelegate;

@interface SidebarViewController : UITableViewController
{
    NSMutableArray *arrSectionName;
    NSMutableArray *dataArrayItem;
    NSMutableArray *dataArrayImage;

    NSString *strUserId;
    UIImageView *imgViewIcon;
    UILabel *lblHomeType;
    UIImageView *imgArrow;
    BOOL boolLoginStatus;
    User *user;
   
}

@property (nonatomic, assign) id <SidebarViewControllerDelegate> sidebarDelegate;
-(void)loadData;
@end

@protocol SidebarViewControllerDelegate <NSObject>
- (void)sidebarViewController:(SidebarViewController *)sidebarViewController didSelectObject:(NSObject *)object atIndexPath:(NSIndexPath *)indexPath;

@optional
- (NSIndexPath *)lastSelectedIndexPathForSidebarViewController:(SidebarViewController *)sidebarViewController;

@end
//http://learningiphonesdk.blogspot.in