//  MainViewController.m
//  RealState
//  Created by Kapil Goyal on 09/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited.All rights reserved.


#import "MainViewController.h"
#import "SortViewController.h"
#import "LayerViewController.h"
#import "SavedSearchViewController.h"
#import "PropertyDetailViewController.h"
#import "RenameSavedSearchViewController.h"
#import "PropertyTypeViewController.h"
#import "DisclaimerViewController.h"
#import "AllPropertySetting.h"
#import "MBProgressHUD.h"
#import "REWebService.h"
#import "Utils.h"
#import "PropertyDetail.h"
#import "Airport.h"
#import "PropertyTvCellView.h"
#import "UIImageView+UIActivityIndicatorForSDWebImage.h"
#import "UIImageView+HighlightedWebCache.h"
#import "SaleSettingController.h"
#import "RentSettingController.h"
#import "PropertyDetailViewController.h"
#import "CanvasView.h"
#import "JSON.h"
#import "SBAPIManager.h"
#import "SPGooglePlacesAutocompleteQuery.h"
#import "SPGooglePlacesAutocompletePlace.h"
#import "DisclaimerVC.h"
#import "LoginViewController.h"
#import "NSDictionary+NullReplacement.h"
#import "NSArray+NullReplacement.h"
#import "PropertyListingVC.h"
#import "SoldSettingController.h"
#import "AddNewShowing.h"
#import "DevelopmentInfoCell.h"
#import "DevelopmentDetaillViewController.h"



#define MERCATOR_RADIUS 85445659.44705395


@interface MainViewController ()

@property (nonatomic, strong) NSMutableArray *coordinates;
@property (nonatomic, strong) NSMutableArray *polygonPoints;
@property (weak, nonatomic) IBOutlet UIButton *drawPolygonButton;
@property (nonatomic) BOOL isDrawingPolygon;
@property (nonatomic, strong) CanvasView *canvasView;

@end

@implementation MainViewController
{
    NSMutableArray *propertyDataArr;
    NSString *strStatus;
    CGPoint touchlocation;
    NSString *salePriceMin;
    NSString *salePriceMax;
    NSString *rentPriceMin;
    NSString *rentPriceMax;
    NSString *fullAddress;
    NSString *SearchByKeyword;
    NSString *totalBaths;
    NSString *totalBeds;
    NSString *propertyType;
    NSString *squareFeetMin;
    NSString *squareFeetMax;
    NSString *foreclosedyn;
    NSString *shortSale;
    NSString *strPetPolicy;
    NSArray *dataDuplicate;
    NSString *lotSquareMin;
    NSString *lotSquareMax;
    NSString *lotAcreMin;
    NSString *lotAcreMax;
    NSString *yearBuiltMin;
    NSString *yearBuiltMax;
    NSString *daysOnMarket;
    NSString *strProprtyCount;
    NSMutableDictionary *savedParam;
    double zoomLavel;
    NSMutableString *typeOfProperty;
    NSString *mapAddress;
    __block NSData *imageData;
}
@synthesize leftSidebarViewController;
@synthesize coordinates = _coordinates;
@synthesize canvasView = _canvasView;


- (NSMutableArray*)coordinates
{
    if(_coordinates == nil) _coordinates = [[NSMutableArray alloc] init];
    return _coordinates;
}


- (CanvasView*)canvasView
{
    if(_canvasView == nil){
        CGRect frame = CGRectMake(0, 45, self.view.frame.size.width, self.view.frame.size.height-100);
        _canvasView = [[CanvasView alloc] initWithFrame:frame];
        _canvasView.userInteractionEnabled = YES;
        _canvasView.delegate = self;
    }
    return _canvasView;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        searchQuery = [[SPGooglePlacesAutocompleteQuery alloc] init];
        searchQuery.radius = 100.0;
        shouldBeginEditing = YES;
    }
    return self;
}
- (void)viewDidLoad
{
    
    if ([[UIScreen mainScreen] respondsToSelector:@selector(displayLinkWithTarget:selector:)] &&
        ([UIScreen mainScreen].scale == 2.0)) {
        
        NSLog(@"Retina display");
        // Retina display
    } else {
        
        NSLog(@"non-Retina display");
        
        // non-Retina display
    }
    
    
    
    [super viewDidLoad];
    arrAllCordinatesArray = [[NSMutableArray alloc] init];
    if (IS_IPHONE) {
        addressTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 44, self.view.frame.size.width, 100)];
    } else {
        addressTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 58, self.view.frame.size.width, 200)];
    }
    addressTable.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    addressTable.delegate = self;
    addressTable.dataSource = self;
    addressTable.tag = 500;
    passDict = [[NSMutableDictionary alloc]init];
    [self.view addSubview:addressTable];
    addressTable.hidden = YES;
    self.navigationController.navigationBarHidden = YES;
    self.navigationItem.revealSidebarDelegate=self;
    [self performSelector:@selector(showUserLocationOn) withObject:nil afterDelay:0.5];
    [self addKeyboardControls];
    [_mapView setDelegate:self];
    txtSearch.delegate = self;
    myTable.delegate = self;
    btnClear.hidden = YES;
    isDrawing = false;
    [btnClear setTitle:@"Clear" forState:UIControlStateNormal];
    [btnClear addTarget:self action:@selector(clearButtonTaped:) forControlEvents:UIControlEventTouchUpInside];
    if (IS_IPHONE) {
        [viewDraw setFrame:CGRectMake(0, -44, 320, 44)];
    } else {
        [viewDraw setFrame:CGRectMake(0, -60, 768, 60)];
    }
    [self.view addSubview:viewDraw];
     _delegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"RealEstate.sqlite"];
    _mapView.showsCompass = NO;
   [txtSearch addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    
    propertyDataArr = [[NSMutableArray alloc]init];
    tapGestureOnBtnNavigation = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(revealLeftSidebar:)];
    tapGestureOnBtnNavigation.numberOfTapsRequired = 1;
    [btnNavigation addGestureRecognizer:tapGestureOnBtnNavigation];
    
    if (IS_IPHONE) {
        
        if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
        {
            [imgHeaderView setFrame:CGRectMake(0, 0, 320, 45)];
            [btnNavigation setFrame:CGRectMake(7, 6, 31, 30)];
            [btnFilter setFrame:CGRectMake(280, 6, 31, 30)];
            [_mapView setFrame:CGRectMake(0, 44, 320, 381)];
            [btnNearBy setFrame:CGRectMake(9, 53, 61, 28)];
            [btnDraw setFrame:CGRectMake(246, 53, 32, 28)];
            [btnInfo setFrame:CGRectMake(282, 53, 27, 28)];
            [viewBottom setFrame:CGRectMake(0, 425, 320, 56)];
            [btnClear setFrame:CGRectMake(0, 0, 320, 56)];
            if(IsRunningTallPhone())
            {
                [_mapView setFrame:CGRectMake(0, 44, 320, 468)];
                [viewBottom setFrame:CGRectMake(0, 512, 320, 56)];
                [btnClear setFrame:CGRectMake(0, 0, 320, 56)];
            }
        }
        else
        {
            [imgHeaderView setFrame:CGRectMake(0, 0, 320, 45)];
            [btnNavigation setFrame:CGRectMake(7, 6, 31, 30)];
            [btnFilter setFrame:CGRectMake(280, 6, 31, 30)];
            [_mapView setFrame:CGRectMake(0, 44, 320, 381)];
            [btnNearBy setFrame:CGRectMake(9, 53, 61, 28)];
            [btnDraw setFrame:CGRectMake(246, 53, 32, 28)];
            [btnInfo setFrame:CGRectMake(282, 53, 27, 28)];
            [viewBottom setFrame:CGRectMake(0, 425, 320, 56)];
            [btnClear setFrame:CGRectMake(0, 0, 320, 56)];
            if(IsRunningTallPhone())
            {
                [_mapView setFrame:CGRectMake(0, 44, 320, 468)];
                [viewBottom setFrame:CGRectMake(0, 512, 320, 56)];
                [btnClear setFrame:CGRectMake(0, 0, 320, 56)];
            }
        }
    }
}

-(IBAction)clearButtonTaped:(id)sender
{
    
    [arrAllCordinatesArray removeAllObjects];
    //[viewDraw setFrame:CGRectMake(0, -44, 320, 44)];
    btnClear.hidden=YES;
    imgHeaderView.hidden=NO;
    btnNavigation.hidden=NO;
    btnFilter.hidden=NO;
    btnNearBy.hidden=NO;
    btnDraw.hidden=NO;
    btnInfo.hidden=NO;
    btnLayer.hidden=NO;
    btnSavedSearch.hidden=NO;
    btnList.hidden=NO;
    self.mapView.scrollEnabled=YES;
    self.mapView.zoomEnabled=YES;
    NSArray *pointsArray = [self.mapView overlays];
    [self.coordinates removeAllObjects];
    [self.mapView removeOverlays:pointsArray];
    [self btnDrawClicked];

}
-(void)viewWillAppear:(BOOL)animated
{
    if ([self.isFromSavedSearch isEqualToString:@"Yes"])
    {
        NSLog(@"from saved search");
        [self getSavedSearch:self.propertyId];
    }
    else if ([self.isFromFavourite isEqualToString:@"Yes"])
    {
        [self showFavouriteOnMap];
      
    }
    if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"MapType"]isEqualToString:@"Satelite View"])
    {
        _mapView.mapType = MKMapTypeSatellite;
    }
    else if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"MapType"]isEqualToString:@"Hybrid View"])
    {
        _mapView.mapType = MKMapTypeHybrid;
    }
    else
    {
       _mapView.mapType =MKMapTypeStandard ;
    }
    [AppDelegate sharedDelegate].globalReference = nil;
    [AppDelegate sharedDelegate].globalReference = self.navigationController;
    [clusterTbl removeFromSuperview];
    UILabel * leftView = [[UILabel alloc] initWithFrame:CGRectMake(10,0,7,26)];
    leftView.backgroundColor = [UIColor clearColor];
    txtSearch.leftView = leftView;
    txtSearch.leftViewMode = UITextFieldViewModeAlways;
    txtSearch.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [self getSavedValueFromDatabase];
}

-(void)showUserLocationOn
{
    if (_delegate.currentLocation != nil)
    {
        MKCoordinateRegion region;
        MKCoordinateSpan span;
        span.latitudeDelta =  0.005;
        span.longitudeDelta = 0.005;
        CLLocationCoordinate2D location;
        location.latitude = _delegate.currentLocation.coordinate.latitude;
        location.longitude = _delegate.currentLocation.coordinate.longitude;
        region.span = span;
        region.center = location;
        [self.mapView setRegion:region animated:YES];
    }
}
#pragma mark JTRevealSidebarDelegate
- (void)revealLeftSidebar:(id)sender
{
    [self.navigationController toggleRevealState:JTRevealedStateLeft];
}

- (UIView *)viewForLeftSidebar
{
    CGRect viewFrame = self.navigationController.applicationViewFrame;
    UITableViewController *controller = self.leftSidebarViewController;
    if (!controller)
    {
        self.leftSidebarViewController = [[SidebarViewController alloc] init];
        self.leftSidebarViewController.sidebarDelegate = [AppDelegate sharedDelegate];
        [AppDelegate sharedDelegate].sideBar=self.leftSidebarViewController;
        controller = self.leftSidebarViewController; 
    }
    controller.view.frame = CGRectMake(0, viewFrame.origin.y, 270, viewFrame.size.height);
    controller.view.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
    return controller.view;
}


- (void)didChangeRevealedStateForViewController:(UIViewController *)viewController {
    if (viewController.revealedState == JTRevealedStateNo)
    {
        [self.mapView removeGestureRecognizer:tapGestureOnMap];
        [btnList removeGestureRecognizer:tapGestureOnBtnLayer];
        [btnNearBy removeGestureRecognizer:tapGestureOnBtnNearBy];
      
    }
    else
    {
        tapGestureOnMap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(revealLeftSidebar:)];
        tapGestureOnMap.numberOfTouchesRequired = 1;
        [self.mapView addGestureRecognizer:tapGestureOnMap];
        
        tapGestureOnBtnLayer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(revealLeftSidebar:)];
        
        tapGestureOnBtnNearBy = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(revealLeftSidebar:)];
        [btnNearBy addGestureRecognizer:tapGestureOnBtnNearBy];
      
    }
}

#pragma mark Actions
-(IBAction)nearByHomeClicked:(id)sender
{
    MKCoordinateRegion region;
    MKCoordinateSpan span;
    span.latitudeDelta =  0.005;
    span.longitudeDelta = 0.005;
    CLLocationCoordinate2D location;
    location.latitude = _delegate.currentLocation.coordinate.latitude;
    location.longitude = _delegate.currentLocation.coordinate.longitude;
    region.span = span;
    region.center = location;
    [self.mapView setRegion:region animated:YES];
  
}

#pragma mark View Draw Function
-(IBAction)btnDrawClicked
{
    
    if (isDrawing == false)
    {
        NSMutableArray * annotationsToRemove = [ _mapView.annotations mutableCopy ] ;
        [ _mapView removeAnnotations:annotationsToRemove] ;
        [_mapView removeAnnotations:_mapView.annotations];
        
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.1];
        
        if (IS_IPHONE) {
            if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
               // [viewDraw setFrame:CGRectMake(<#CGFloat x#>, <#CGFloat y#>, <#CGFloat width#>, <#CGFloat height#>)]
                [viewDraw setFrame:CGRectMake(0, 623, 375, 60)];
            else
                [viewDraw setFrame:CGRectMake(0, 0, 320, 44)];
        } else {
            [viewDraw setFrame:CGRectMake(0, 0, 768, 60)];
            
        }
        
        
        [UIView commitAnimations];
        btnNavigation.hidden=YES;
        btnFilter.hidden=YES;
        imgHeaderView.hidden=YES;
        btnNearBy.hidden=YES;
        btnDraw.hidden=YES;
        btnInfo.hidden=YES;
        btnClear.hidden = NO;
        btnLayer.hidden=YES;
        btnSavedSearch.hidden=YES;
        btnList.hidden=YES;
        self.mapView.scrollEnabled=NO;
        self.mapView.zoomEnabled=NO;
        if(self.isDrawingPolygon == NO)
        {
            self.isDrawingPolygon = YES;
            [self.coordinates removeAllObjects];
            [self.view addSubview:self.canvasView];
        }
        else
        {
            NSInteger numberOfPoints = [self.coordinates count];
            self.AppendString=[[NSMutableString alloc] init];
            if (numberOfPoints > 2)
            {
                CLLocationCoordinate2D points[numberOfPoints];
                for (NSInteger i = 0; i < numberOfPoints; i++){
                    points[i] = [self.coordinates[i] MKCoordinateValue];
                    [self.AppendString appendString:[NSString stringWithFormat:@"%f %f, ",points[i].latitude,points[i].longitude ]];
                }
                
                if (zoomLavel>=6)
                {
                    [arrAllCordinatesArray addObject:self.AppendString];
                    [self.mapView addOverlay:[MKPolygon polygonWithCoordinates:points count:numberOfPoints]];
                }
                else
                {
                    if (IS_IPHONE) {
                        [viewDraw setFrame:CGRectMake(0, -44, 320, 44)];
                    } else {
                        [viewDraw setFrame:CGRectMake(0, -60, 768, 60)];
                    }
                   // [viewDraw setFrame:CGRectMake(0, -44, 320, 44)];
                    btnClear.hidden=YES;
                    imgHeaderView.hidden=NO;
                    btnNavigation.hidden=NO;
                    btnFilter.hidden=NO;
                    btnNearBy.hidden=NO;
                    btnDraw.hidden=NO;
                    btnInfo.hidden=NO;
                    btnLayer.hidden=NO;
                    btnSavedSearch.hidden=NO;
                    btnList.hidden=NO;
                    self.mapView.scrollEnabled=YES;
                    self.mapView.zoomEnabled=YES;
                    NSArray *pointsArray = [self.mapView overlays];
                    [self.mapView removeOverlays:pointsArray];
                    [arrAllCordinatesArray removeAllObjects];
                    [self.coordinates removeAllObjects];
                    NSString *zoomStr=[NSString stringWithFormat:@"You are currently on zoom level %0.1f please zoom more to zoom level 6.0 for drawing on map",zoomLavel];
                    [Utils showAlertMessage:nil Message:zoomStr];
                }
            }
            NSArray *pointsArray = [self.mapView overlays];
            if (pointsArray.count<=4)
            {
                self.isDrawingPolygon = NO;
                self.canvasView.image = nil;
                [self.canvasView removeFromSuperview];
                [self btnDrawClicked];
                
            }else
            {
                self.isDrawingPolygon = YES;
                self.canvasView.image = nil;
                [self.canvasView removeFromSuperview];
            }
        }
        
    } else
    {
        [btnDraw setImage:[UIImage imageNamed:@"draw"] forState:UIControlStateNormal];
        isDrawing = false;
        [self.canvasView removeFromSuperview];
        [arrAllCordinatesArray removeAllObjects];
        [self.coordinates removeAllObjects];
        if (IS_IPHONE) {
            [viewDraw setFrame:CGRectMake(0, -44, 320, 44)];
        } else {
            [viewDraw setFrame:CGRectMake(0, -60, 768, 60)];
        }
        //[viewDraw setFrame:CGRectMake(0, -44, 320, 44)];
        btnClear.hidden=YES;
        imgHeaderView.hidden=NO;
        btnNavigation.hidden=NO;
        btnFilter.hidden=NO;
        btnNearBy.hidden=NO;
        btnDraw.hidden=NO;
        btnInfo.hidden=NO;
        btnLayer.hidden=NO;
        btnSavedSearch.hidden=NO;
        btnList.hidden=NO;
        NSArray *pointsArray = [self.mapView overlays];
        [self.mapView removeOverlays:pointsArray];
        self.mapView.scrollEnabled=YES;
        self.mapView.zoomEnabled=YES;
    }
}

- (void)touchesBegan:(UITouch*)touch
{
        CGPoint location = [touch locationInView:self.mapView];
        CLLocationCoordinate2D coordinate = [self.mapView convertPoint:location toCoordinateFromView:self.mapView];
        [self.coordinates addObject:[NSValue valueWithMKCoordinate:coordinate]];
}

- (void)touchesMoved:(UITouch*)touch
{
        CGPoint location = [touch locationInView:self.mapView];
        CLLocationCoordinate2D coordinate = [self.mapView convertPoint:location toCoordinateFromView:self.mapView];
        [self.coordinates addObject:[NSValue valueWithMKCoordinate:coordinate]];
}

- (void)touchesEnded:(UITouch*)touch
{
        CGPoint location = [touch locationInView:self.mapView];
        CLLocationCoordinate2D coordinate = [self.mapView convertPoint:location toCoordinateFromView:self.mapView];
        [self.coordinates addObject:[NSValue valueWithMKCoordinate:coordinate]];
        NSLog(@"self.coordinates - %@",self.coordinates);
        [self btnDrawClicked];
}


#pragma mark - MKMapViewDelegate

- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id <MKOverlay>)overlay
{
    MKOverlayPathView *overlayPathView;
    if ([overlay isKindOfClass:[MKPolygon class]])
    {
        overlayPathView = [[MKPolygonView alloc] initWithPolygon:(MKPolygon*)overlay];
        overlayPathView.fillColor = [[UIColor cyanColor] colorWithAlphaComponent:0.2];
        overlayPathView.strokeColor = [[UIColor blueColor] colorWithAlphaComponent:0.7];
        overlayPathView.lineWidth = 2;
        return overlayPathView;
    }
    else if ([overlay isKindOfClass:[MKPolyline class]])
    {
        overlayPathView = [[MKPolylineView alloc] initWithPolyline:(MKPolyline *)overlay];
        overlayPathView.strokeColor = [[UIColor blueColor] colorWithAlphaComponent:0.7];
        overlayPathView.lineWidth = 2;
        return overlayPathView;
    }
    
    return nil;
}

-(IBAction)btnCancelClicked
{
    [self.canvasView removeFromSuperview];
    [arrAllCordinatesArray removeAllObjects];
    [self.coordinates removeAllObjects];
    if (IS_IPHONE) {
        [viewDraw setFrame:CGRectMake(0, -44, 320, 44)];
    } else {
        [viewDraw setFrame:CGRectMake(0, -60, 768, 60)];
    }
   // [viewDraw setFrame:CGRectMake(0, -44, 320, 44)];
    btnClear.hidden=YES;
    imgHeaderView.hidden=NO;
    btnNavigation.hidden=NO;
    btnFilter.hidden=NO;
    btnNearBy.hidden=NO;
    btnDraw.hidden=NO;
    btnInfo.hidden=NO;
    btnLayer.hidden=NO;
    btnSavedSearch.hidden=NO;
    btnList.hidden=NO;
    NSArray *pointsArray = [self.mapView overlays];
    [self.mapView removeOverlays:pointsArray];
    self.mapView.scrollEnabled=YES;
    self.mapView.zoomEnabled=YES;
}

-(IBAction)btnApplyClicked
{
    if (!(self.AppendString==nil))
    {
         [self DrawPointsInMap];
          isDrawing = true;
        [btnDraw setImage:[UIImage imageNamed:@"draw_active"] forState:UIControlStateNormal];
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please select a region"];
    }
    [self.canvasView removeFromSuperview];
    [arrAllCordinatesArray removeAllObjects];
    [self.coordinates removeAllObjects];
    if (IS_IPHONE) {
        [viewDraw setFrame:CGRectMake(0, -44, 320, 44)];
    } else {
        [viewDraw setFrame:CGRectMake(0, -60, 768, 60)];
    }
   // [viewDraw setFrame:CGRectMake(0, -44, 320, 44)];
    
    btnClear.hidden=YES;
    imgHeaderView.hidden=NO;
    btnNavigation.hidden=NO;
    btnFilter.hidden=NO;
    btnNearBy.hidden=NO;
    btnDraw.hidden=NO;
    btnInfo.hidden=NO;
    btnLayer.hidden=NO;
    btnSavedSearch.hidden=NO;
    btnList.hidden=NO;
    self.mapView.scrollEnabled=YES;
    self.mapView.zoomEnabled=YES;
   
}

-(IBAction)btnInfoClicked
{
    DisclaimerVC *disclaimer;
    if (IS_IPHONE) {
       disclaimer = [[DisclaimerVC alloc] initWithNibName:@"DisclaimerVC" bundle:nil];
    } else {
       disclaimer = [[DisclaimerVC alloc] initWithNibName:@"DisclaimerVC_iPad" bundle:nil];
    }
    if (infoArray.count) {
        disclaimer.isCountAvail = @"Yes";
        disclaimer.feedArray = infoArray;
    }
    else{
        disclaimer.isCountAvail = @"No";
    }
    [self.navigationController pushViewController:disclaimer animated:YES];
}

-(IBAction)btnFilterClicked
{
   if ([self.isFromSavedSearch isEqualToString:@"Yes"])
   {
       [Utils showAlertMessage:nil Message:@"Filters are already saved"];
       
    } else {
        
        if ([self.selectedValue isEqualToString:@"All_Property"])
        {
            
            AllPropertySetting *allPropertyDetail;
            if (IS_IPHONE) {
                
               allPropertyDetail = [[AllPropertySetting alloc] initWithNibName:@"AllPropertySetting" bundle:nil];
            } else {
                
               allPropertyDetail = [[AllPropertySetting alloc] initWithNibName:@"AllPropertySetting_ipad" bundle:nil];
            }
            
            allPropertyDetail.strLat1 = [passDict valueForKey:@"latitude1"];
            allPropertyDetail.strLat2 = [passDict valueForKey:@"longitude1"];
            allPropertyDetail.strLat3 = [passDict valueForKey:@"latitude2"];
            allPropertyDetail.strLat4 = [passDict valueForKey:@"longitude2"];
            [self.navigationController pushViewController:allPropertyDetail animated:YES];
        }
        else if ([self.selectedValue isEqualToString:@"For_Rent"])
        {
            RentSettingController *rentSetting;
            if (IS_IPHONE) {
                rentSetting = [[RentSettingController alloc] initWithNibName:@"RentSettingController" bundle:nil];
            } else {
                rentSetting = [[RentSettingController alloc] initWithNibName:@"RentSettingController_ipad" bundle:nil];
            }
            rentSetting.strLat1 = [passDict valueForKey:@"latitude1"];
            rentSetting.strLat2 = [passDict valueForKey:@"longitude1"];
            rentSetting.strLat3 = [passDict valueForKey:@"latitude2"];
            rentSetting.strLat4 = [passDict valueForKey:@"longitude2"];
            [self.navigationController pushViewController:rentSetting animated:YES];
            
        }
        else if ([self.selectedValue isEqualToString:@"For_Sold"])
        {
            SoldSettingController *soldSettings;
            if (IS_IPHONE) {
               soldSettings = [[SoldSettingController alloc]initWithNibName:@"SoldSettingController" bundle:nil];
            } else {
                soldSettings = [[SoldSettingController alloc]initWithNibName:@"SoldSettingController_ipad" bundle:nil];
            }
            
            soldSettings.strLat1 = [passDict valueForKey:@"latitude1"];
            soldSettings.strLat2 = [passDict valueForKey:@"longitude1"];
            soldSettings.strLat3 = [passDict valueForKey:@"latitude2"];
            soldSettings.strLat4 = [passDict valueForKey:@"longitude2"];
            [self.navigationController pushViewController:soldSettings animated:YES];
        }
        else
        {
            SaleSettingController *saleSetting;
            if (IS_IPHONE) {
                saleSetting = [[SaleSettingController alloc] initWithNibName:@"SaleSettingController" bundle:nil];
            } else {
                saleSetting = [[SaleSettingController alloc] initWithNibName:@"SaleSettingController_ipad" bundle:nil];
            }
            saleSetting.strLat1 = [passDict valueForKey:@"latitude1"];
            saleSetting.strLat2 = [passDict valueForKey:@"longitude1"];
            saleSetting.strLat3 = [passDict valueForKey:@"latitude2"];
            saleSetting.strLat4 = [passDict valueForKey:@"longitude2"];
            [self.navigationController pushViewController:saleSetting animated:YES];
        }
    }
}

#pragma mark Layer View Function
-(IBAction)btnLayerClicked
{
    if (IS_IPHONE) {
        
        LayerViewController *layer = [[LayerViewController alloc] initWithNibName:@"LayerViewController_iPhone" bundle:nil];
        [self.navigationController presentViewController:layer animated:YES completion:nil];
        
    } else {
        
        LayerViewController *layer = [[LayerViewController alloc] initWithNibName:@"LayerViewController_iPad" bundle:nil];
        [self.navigationController presentViewController:layer animated:YES completion:nil];
    }
   
    
    
}

#pragma mark Saved Search View Function

-(IBAction)btnSaveSearchedClicked
{
    if ([self.isFromSavedSearch isEqualToString:@"Yes"]) {
        
        [Utils showAlertMessage:nil Message:@"These are already in saved search"];
    } else {
        
        if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| _delegate.loginUser)
        {
            CLLocationCoordinate2D centre = [self.mapView centerCoordinate];
            CLLocation *centreLoc = [[CLLocation alloc]initWithLatitude:centre.latitude longitude:centre.longitude];
            mapAddress = [self getAddressFromLocation:centreLoc];
            [self screenshot];
        } else
        {
            
            if (IS_IPHONE) {
                LoginViewController* loginVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPhone" bundle:nil];
                [self.navigationController presentViewController:loginVC animated:YES completion:nil];
                
            } else {
                LoginViewController* loginVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPad" bundle:nil];
                [self.navigationController presentViewController:loginVC animated:YES completion:nil];
            }
            
        }
    }    
}

-(IBAction)btnListClicked
{
    PropertyListingVC *list;
    if (IS_IPHONE) {
       list = [[PropertyListingVC alloc] initWithNibName:@"PropertyListingVC" bundle:nil];
    } else {
       list = [[PropertyListingVC alloc] initWithNibName:@"PropertyListingVC_iPad" bundle:nil];
    }
    list.param = passDict;
    list.propertyAvail = strProprtyCount;
    list.selectedType = self.selectedValue;
    [self.navigationController pushViewController:list animated:YES];
}

-(void)hidePresentViewController
{
    RenameSavedSearchViewController *renameSavedSearch = [[RenameSavedSearchViewController alloc] initWithNibName:@"RenameSavedSearchViewController_iPhone" bundle:nil];
    [self.navigationController pushViewController:renameSavedSearch animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

/*
    New Work Start
*/

- (void)mapView:(MKMapView *)aMapView regionDidChangeAnimated:(BOOL)animated
{
    zoomLavel =[self Mapzoomlevel];
    NSLog(@"My Zoom is--->%f",zoomLavel);
    
    if ([self.isFromSavedSearch isEqualToString:@"Yes"])
    {
        NSLog(@"from saved search");
        
    }
    else if ([self.isFromFavourite isEqualToString:@"Yes"])
    {
          NSLog(@"from Favourite");
    }
    else
    {
     if (_delegate.currentLocation != nil && isDrawing !=true){
         
         if (dataDuplicate.count){
             
             MKCoordinateRegion visibleRegion = self.mapView.region;
             CLLocationCoordinate2D center = visibleRegion.center;
             CLLocationCoordinate2D northWestCorner, southEastCorner;
             northWestCorner.latitude  = center.latitude  + (visibleRegion.span.latitudeDelta  / 2.0);
             northWestCorner.longitude = center.longitude - (visibleRegion.span.longitudeDelta / 2.0);
             southEastCorner.latitude  = center.latitude  - (visibleRegion.span.latitudeDelta  / 2.0);
             southEastCorner.longitude = center.longitude + (visibleRegion.span.longitudeDelta / 2.0);
             NSLog(@"1-- >%f",northWestCorner.latitude);
             NSLog(@"2-- >%f",northWestCorner.longitude);
             NSLog(@"3-- >%f",southEastCorner.latitude);
             NSLog(@"4-- >%f",southEastCorner.longitude);
             
             NSString *strLat1 = [NSString stringWithFormat:@"%.06f",[[NSNumber numberWithDouble:northWestCorner.latitude] floatValue]];
             NSString *strLat2 = [NSString stringWithFormat:@"%.06f",[[NSNumber numberWithDouble:northWestCorner.longitude] floatValue]];
             NSString *strLat3 = [NSString stringWithFormat:@"%.06f",[[NSNumber numberWithDouble:southEastCorner.latitude] floatValue]];
             NSString *strLat4 = [NSString stringWithFormat:@"%.06f",[[NSNumber numberWithDouble:southEastCorner.longitude] floatValue]];
             
             [loadingView setFrame:CGRectMake((self.view.frame.size.width/2)-65, self.view.frame.size.height-96, 130, 40)];
             NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
             if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| _delegate.loginUser)
             {
                [dataDict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] forKey:@"user_id"];
             }
             
            
             if ([self.selectedValue isEqualToString:@"All_Property"])
             {
                 [dataDict setValue:salePriceMin forKey:@"price_for_sale1"];
                 [dataDict setValue:salePriceMax forKey:@"price_for_sale2"];
                 [dataDict setValue:rentPriceMin forKey:@"pricerented1"];
                 [dataDict setValue:rentPriceMax forKey:@"pricerented2"];
                 [dataDict setValue:fullAddress forKey:@"fulladdress"];
                 [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
                 [dataDict setValue:totalBeds forKey:@"numbedrooms"];
                 [dataDict setValue:propertyType forKey:@"propertytype"];
                 [dataDict setValue:@"0" forKey:@"pet_policy"];
                 if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"AllPropertyLotType"]isEqualToString:@"SQFT"]) {
                     
                     [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
                     [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
                     
                 }else
                 {
                     [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
                     [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
                 }
                 [dataDict setValue:strLat1 forKey:@"latitude1"];
                 [dataDict setValue:strLat2 forKey:@"longitude1"];
                 [dataDict setValue:strLat3 forKey:@"latitude2"];
                 [dataDict setValue:strLat4 forKey:@"longitude2"];
                 [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
                 [dataDict setValue:@"0" forKey:@"recently_rented"];
                 [dataDict setValue:@"0" forKey:@"recently_sold"];
                 [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
                 [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
                 [dataDict setValue:squareFeetMin forKey:@"sqft1"];
                 [dataDict setValue:squareFeetMax forKey:@"sqft2"];
                 [dataDict setValue:foreclosedyn forKey:@"foreclosedyn"];
                 [dataDict setValue:@"0" forKey:@"shortsaleyn"];
                 [dataDict setValue:SearchByKeyword forKey:@"search_by_keyword"];
                 [dataDict setValue:@"all_property" forKey:@"status"];
                 passDict = dataDict;
                 
             }
             else if ([self.selectedValue isEqualToString:@"For_Rent"])
             {
                 [dataDict setValue:rentPriceMin forKey:@"pricerented1"];
                 [dataDict setValue:rentPriceMax forKey:@"pricerented2"];
                 [dataDict setValue:fullAddress forKey:@"fulladdress"];
                 [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
                 [dataDict setValue:totalBeds forKey:@"numbedrooms"];
                 [dataDict setValue:propertyType forKey:@"propertytype"];
                 [dataDict setValue:squareFeetMin forKey:@"sqft1"];
                 [dataDict setValue:squareFeetMax forKey:@"sqft2"];
                 [dataDict setValue:strPetPolicy forKey:@"pet_policy"];
                 if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"RentPropertyLotType"]isEqualToString:@"SQFT"])
                 {
                     [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
                     [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
                 }
                 else
                 {
                     [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
                     [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
                 }
                 [dataDict setValue:strLat1 forKey:@"latitude1"];
                 [dataDict setValue:strLat2 forKey:@"longitude1"];
                 [dataDict setValue:strLat3 forKey:@"latitude2"];
                 [dataDict setValue:strLat4 forKey:@"longitude2"];
                 [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
                 [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
                 [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
                 [dataDict setValue:SearchByKeyword forKey:@"search_by_keyword"];
                 [dataDict setValue:@"for_rent" forKey:@"status"];
                 passDict = dataDict;
             }
             else if ([self.selectedValue isEqualToString:@"For_Sold"])
             {
                 [dataDict setValue:strLat1 forKey:@"latitude1"];
                 [dataDict setValue:strLat2 forKey:@"longitude1"];
                 [dataDict setValue:strLat3 forKey:@"latitude2"];
                 [dataDict setValue:strLat4 forKey:@"longitude2"];
                 [dataDict setValue:salePriceMin forKey:@"pricesold1"];
                 [dataDict setValue:salePriceMax forKey:@"pricesold2"];
                 [dataDict setValue:fullAddress forKey:@"fulladdress"];
                 [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
                 [dataDict setValue:totalBeds forKey:@"numbedrooms"];
                 [dataDict setValue:propertyType forKey:@"propertytype"];
                 [dataDict setValue:squareFeetMin forKey:@"sqft1"];
                 [dataDict setValue:squareFeetMax forKey:@"sqft2"];
                 [dataDict setValue:foreclosedyn forKey:@"foreclosedyn"];
                 [dataDict setValue:shortSale forKey:@"shortsaleyn"];
                 if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"SoldPropertyLotType"]isEqualToString:@"SQFT"]) {
                     
                     [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
                     [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
                 }else{
                     [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
                     [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
                 }
                 [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
                 [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
                 [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
                 [dataDict setValue:SearchByKeyword forKey:@"search_by_keyword"];
                 [dataDict setValue:@"sold" forKey:@"status"];
                 passDict = dataDict;
                
             }
             else
             {
                 [dataDict setValue:strLat1 forKey:@"latitude1"];
                 [dataDict setValue:strLat2 forKey:@"longitude1"];
                 [dataDict setValue:strLat3 forKey:@"latitude2"];
                 [dataDict setValue:strLat4 forKey:@"longitude2"];
                 [dataDict setValue:salePriceMin forKey:@"price_for_sale1"];
                 [dataDict setValue:salePriceMax forKey:@"price_for_sale2"];
                 [dataDict setValue:fullAddress forKey:@"fulladdress"];
                 [dataDict setValue:totalBaths forKey:@"totalfullbaths"];
                 [dataDict setValue:totalBeds forKey:@"numbedrooms"];
                 [dataDict setValue:propertyType forKey:@"propertytype"];
                 [dataDict setValue:squareFeetMin forKey:@"sqft1"];
                 [dataDict setValue:squareFeetMax forKey:@"sqft2"];
                 [dataDict setValue:foreclosedyn forKey:@"foreclosedyn"];
                 [dataDict setValue:shortSale forKey:@"shortsaleyn"];
                 if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"SalePropertyLotType"]isEqualToString:@"SQFT"]) {
                     
                     [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
                     [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
                 }else{
                     [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
                     [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
                 }
                 
                 [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
                 [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
                 [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
                 [dataDict setValue:SearchByKeyword forKey:@"search_by_keyword"];
                 [dataDict setValue:@"for_sale" forKey:@"status"];
                 passDict = dataDict;
             }
              NSLog(@"%@",[dataDict JSONRepresentation]);
             [REWebService CallGetPropertDataFromServer:dataDict:self:loadingView withBlock:^(NSDictionary *dictResult, NSError *error) {
                 if (!error) {
                     
                     if ([[[dictResult objectForKey:@"response"] objectForKey:@"message"] isEqualToString:@"success"]) {
                      
                         if (self->propertyDataArr)
                         {
                             [self->propertyDataArr removeAllObjects];
                         }
                         
                         NSMutableArray * annotationsToRemove = [ self->_mapView.annotations mutableCopy ] ;
                         [ self->_mapView removeAnnotations:annotationsToRemove] ;
                         [self->_mapView removeAnnotations:self->_mapView.annotations];
                         
                         NSArray *propertyTempArr = [[dictResult objectForKey:@"response"]objectForKey:@"data"] ;
                         for(NSDictionary *tempDict in propertyTempArr)
                         {
                             PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                             [self->propertyDataArr addObject:datamodel];
                         }
                         
                         [self->myTable reloadData];
                         [self->_mapView removeAnnotations:self->_mapView.annotations];
                         dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^
                                        {
                                            NSArray *propertyData = [Airport allPropertyData:propertyTempArr];
                                            dispatch_async(dispatch_get_main_queue(), ^
                                                           {
                                                               if (self->_mapView.annotations.count) {
                                                                   [self->_mapView removeAnnotations:self->_mapView.annotations];
                                                               } else {
                                                                   
                                                                   [self->_mapView addAnnotations:propertyData];
                                                               }
                                                               
                                                               [self->myTable reloadData];
                                                               
                                                           });
                                        });
                         
                         self->infoArray = [propertyTempArr valueForKeyPath:@"@distinctUnionOfObjects.feed_name"];
                     }
                     else
                     {
                         self->infoArray = nil;
                     }
                     
                     self->strProprtyCount = [NSString stringWithFormat:@"%@",[[dictResult objectForKey:@"response"] objectForKey:@"pcount"]];
                     self->strDefaultText  = [NSString stringWithFormat:@"%@",[[dictResult objectForKey:@"response"] objectForKey:@"default_disclaimer"]];
                     
                 }
                 else
                 {
                     NSLog(@"No result available");
                     
                    
                     
                 }
                
             }];
             
           }
         
        }
    }
}


-(void)DrawPointsInMap
{
    if (dataDuplicate.count){
        NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
        [loadingView setFrame:CGRectMake((self.view.frame.size.width/2)-65, self.view.frame.size.height-96, 130, 40)];
        for (NSInteger i=0; i<arrAllCordinatesArray.count; i++)
        {
            [dataDict setValue:[arrAllCordinatesArray objectAtIndex:i] forKey:[NSString stringWithFormat:@"lat_long_data_%ld",(long)i+1]];
        }
        [dataDict addEntriesFromDictionary:passDict];
        [dataDict removeObjectForKey:@"latitude1"];
        [dataDict removeObjectForKey:@"longitude1"];
        [dataDict removeObjectForKey:@"latitude2"];
        [dataDict removeObjectForKey:@"longitude2"];
        [dataDict removeObjectForKey:@"fulladdress"];
        [arrAllCordinatesArray removeAllObjects];
        NSLog(@"my json%@",[dataDict JSONRepresentation]);
        [REWebService CallDrawServiceFromServer:dataDict :self :loadingView withBlock:^(NSDictionary *dictResult, NSError *error){
            if (!error){
                
                if ([[[dictResult objectForKey:@"response"] objectForKey:@"message"] isEqualToString:@"success"]) {
                    
                    if (self->propertyDataArr){
                        [self->propertyDataArr removeAllObjects];
                        
                    }
                    NSMutableArray * annotationsToRemove = [ self->_mapView.annotations mutableCopy ] ;
                    [ self->_mapView removeAnnotations:annotationsToRemove];
                    [self->_mapView removeAnnotations:self->_mapView.annotations];
                    NSArray *propertyTempArr1 = [[dictResult objectForKey:@"response"]objectForKey:@"data_1"] ;
                    NSArray *propertyTempArr2 = [[dictResult objectForKey:@"response"]objectForKey:@"data_2"] ;
                    NSArray *propertyTempArr3 = [[dictResult objectForKey:@"response"]objectForKey:@"data_3"] ;
                    NSArray *propertyTempArr4 = [[dictResult objectForKey:@"response"]objectForKey:@"data_4"] ;
                    NSArray *propertyTempArr5 = [[dictResult objectForKey:@"response"]objectForKey:@"data_5"] ;
                    for(NSDictionary *tempDict in propertyTempArr1)
                    {
                        PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                        [self->propertyDataArr addObject:datamodel];
                    }
                    
                    for(NSDictionary *tempDict in propertyTempArr2)
                    {
                        PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                        [self->propertyDataArr addObject:datamodel];
                    }
                    
                    for(NSDictionary *tempDict in propertyTempArr3)
                    {
                        PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                        [self->propertyDataArr addObject:datamodel];

                    }
                    
                    for(NSDictionary *tempDict in propertyTempArr4)
                    {
                        PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                        [self->propertyDataArr addObject:datamodel];

                    }
                    
                    for(NSDictionary *tempDict in propertyTempArr5)
                    {
                        PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                        [self->propertyDataArr addObject:datamodel];

                    }
                    [self->myTable reloadData];
                    [self->_mapView removeAnnotations:self->_mapView.annotations];
                    
                    //First
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^
                                   {
                                       NSArray *propertyData = [Airport allPropertyData:propertyTempArr1];
                                       dispatch_async(dispatch_get_main_queue(), ^
                                                      {
                                                          [self->_mapView addAnnotations:propertyData];
                                                          [self->myTable reloadData];
                                                          
                                                      });
                                   });
                    
                    
                    
                    
                    //Second
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^
                                   {
                                       NSArray *propertyData = [Airport allPropertyData:propertyTempArr2];
                                       dispatch_async(dispatch_get_main_queue(), ^
                                                      {
                                                        
                                                          [self->_mapView addAnnotations:propertyData];
                                                          [self->myTable reloadData];
                                                          
                                                      });
                                   });
                    
                    
                    //third
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^
                                   {
                                       NSArray *propertyData = [Airport allPropertyData:propertyTempArr3];
                                       dispatch_async(dispatch_get_main_queue(), ^
                                                      {
                                                          [self->_mapView addAnnotations:propertyData];
                                                          [self->myTable reloadData];
                                                          
                                                      });
                                   });
                    
                    
                    //fourth
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^
                                   {
                                       NSArray *propertyData = [Airport allPropertyData:propertyTempArr4];
                                       dispatch_async(dispatch_get_main_queue(), ^
                                                      {
                                                          [self->_mapView addAnnotations:propertyData];
                                                          [self->myTable reloadData];
                                                          
                                                      });
                                   });
                    
                    //fifth
                    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^
                                   {
                                       NSArray *propertyData = [Airport allPropertyData:propertyTempArr5];
                                       dispatch_async(dispatch_get_main_queue(), ^
                                                      {
                                                          [self->_mapView addAnnotations:propertyData];
                                                          [self->myTable reloadData];
                                                          
                                                      });
                                   });
                    
                }
            }
            else
            {
                NSLog(@"data not foundddd");
            }
            
            
        }];
        
    }
    
    
    
}


- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    MIAnnotation *annotation = (MIAnnotation *)view.annotation;
    if ([annotation class] == [MIAnnotation class])
    {
        NSArray *arr = [annotation.allAnnotations allObjects];
        [propertyDataArr removeAllObjects];
        for (int i =0; i < arr.count; i++)
        {
            Airport *point = [arr objectAtIndex:i];
            NSLog(@"info %@",point.detailDict);
            PropertyDetail *detail =  [[PropertyDetail alloc]initWithDict:point.detailDict];
            
//            if (![detail.PropertyKind isEqualToString:@"Development"]) {
//                [propertyDataArr addObject:detail];
//            }
            [propertyDataArr addObject:detail];
        }
       // if (propertyDataArr.count) {
            [clusterTbl setFrame:CGRectMake(0, 160, self.view.frame.size.width, 170)];
            [self.mapView addSubview:clusterTbl];
            [myTable reloadData];
//        }
//        else
//        {
//            [Utils showAlertMessage:@"Twin Realty" Message:@"All Properties are from development"];
//        }
        
    }
    else if ([annotation class]==[Airport class])
    {
            [propertyDataArr removeAllObjects];
            Airport *point = (Airport *)view.annotation;
            NSLog(@"info %@",point.detailDict);
        if ([[point.detailDict valueForKey:@"Property_kind"]isEqualToString:@"Development"]) {
            
            PropertyDetail *detail =  [[PropertyDetail alloc]initWithDict:point.detailDict];
            [propertyDataArr addObject:detail];
            [clusterTbl setFrame:CGRectMake(0, 160, self.view.frame.size.width, 170)];
            [self.mapView addSubview:clusterTbl];
            [myTable reloadData];
            
        }
        else
        {
            PropertyDetail *detail =  [[PropertyDetail alloc]initWithDict:point.detailDict];
            [propertyDataArr addObject:detail];
            [clusterTbl setFrame:CGRectMake(0, 160, self.view.frame.size.width, 170)];
            [self.mapView addSubview:clusterTbl];
            [myTable reloadData];
        
        }
        
    }
    
    
}


- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
    NSLog(@"tap event");
}

# pragma mark Table View Delegate and datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag==500) {
        return searchResultPlaces.count;
    }
    else
    {
        if (propertyDataArr.count)
        {
            return propertyDataArr.count;
        }
    }
    return nil;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (SPGooglePlacesAutocompletePlace *)placeAtIndexPath:(NSIndexPath *)indexPath {
    return [searchResultPlaces objectAtIndex:indexPath.row];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag==500)
    {
        static NSString *cellIdentifier = @"SPGooglePlacesAutocompleteCell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        }
        
        cell.textLabel.font = [UIFont fontWithName:@"GillSans" size:16.0];
        cell.textLabel.text = [self placeAtIndexPath:indexPath].name;
        return cell;
        
    } else
        
    {
         PropertyDetail *theProperty = [propertyDataArr objectAtIndex:indexPath.row];
        if ([theProperty.PropertyKind isEqualToString:@"Non Development"]) {
            
            static NSString *CellIdentifier = @"Cell";
            PropertyTvCellView *cell = (PropertyTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil)
            {
                UIViewController *view;
                if (IS_IPHONE) {
                   view = [[UIViewController alloc]initWithNibName:@"PropertyTvCellView_iPhone" bundle:nil];
                } else {
                   view = [[UIViewController alloc]initWithNibName:@"PropertyTvCellView_iPad" bundle:nil];
                }
                
                cell = (PropertyTvCellView *)view.view;
            }
            if (propertyDataArr.count){
                
                if ([theProperty.status isEqualToString:@"for_sale"])
                {
                    cell.lblHomeType.text = @"For Sale";
                    cell.lblHomeType.textColor = [UIColor colorWithRed:(38/255.f) green:(133/255.f) blue:(9/255.f) alpha:1.0f];
                    cell.imgViewPropertyType.image = [UIImage imageNamed:@"for_sale"];
                    NSInteger *intPrice = [theProperty.priceSale integerValue];
                    NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                    NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                       numberStyle:kCFNumberFormatterCurrencyStyle];
                    
                    
                    NSString *newString;
                    if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
                    {
                        newString = [price substringFromIndex:3];
                        newString =  [newString substringToIndex:[newString length]-3];
                        
                    }
                    cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
                    
                }
                else if ([theProperty.status isEqualToString:@"for_rent"])
                {
                    cell.lblHomeType.text = @"For Rent";
                    cell.lblHomeType.textColor = [UIColor orangeColor];
                    cell.imgViewPropertyType.image = [UIImage imageNamed:@"for_rent"];
                    
                    NSInteger *intPrice = [theProperty.priceRented integerValue];
                    NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                    NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                       numberStyle:kCFNumberFormatterCurrencyStyle];
                    
                    NSString *newString;
                    if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
                    {
                        newString = [price substringFromIndex:3];
                        newString =  [newString substringToIndex:[newString length]-3];
                        
                    }
                    cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
                    
                }
                else
                {
                    cell.lblHomeType.text = @"Sold";
                    cell.imgViewPropertyType.image = [UIImage imageNamed:@""];
                    NSInteger *intPrice = [theProperty.PriceSold integerValue];
                    NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
                    NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                                       numberStyle:kCFNumberFormatterCurrencyStyle];
                    
                    NSString *newString;
                    if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
                    {
                        newString = [price substringFromIndex:3];
                        newString =  [newString substringToIndex:[newString length]-3];
                        
                    }
                    cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
                }
                
                cell.lblSaleType.text = [NSString stringWithFormat:@"%@",theProperty.Id];
                cell.lblBedBath.text = [NSString stringWithFormat:@"%@bd-%@ba %@ sq ft",theProperty.numbedrooms,theProperty.totalfullbaths,theProperty.totalfloorareasqft];
                cell.lblPhotoCount.text = [NSString stringWithFormat:@"%@ Photos",theProperty.availableImages];
                cell.lblAddress.text = [NSString stringWithFormat:@"%@",theProperty.fulladdress];
                cell.lblAddress1.text = [NSString stringWithFormat:@"%@",theProperty.fullAddress1];
                cell.lblListingCourtesy.text = [NSString stringWithFormat:@"%@",theProperty.listingCourtesy];
                cell.sepLine.hidden = NO;
                
                if ([theProperty.openHouse isEqualToString:@""]) {
                    cell.lblOpenHouse.text = [NSString stringWithFormat:@"Open House Not Available"];
                } else {
                    cell.lblOpenHouse.text = [NSString stringWithFormat:@"%@",theProperty.openHouse];
                }
                [cell.imgViewProperty setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",theProperty.imgProperty]] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            }
            
            return cell;
            
        } else {
            
            static NSString *CellIdentifier = @"Cell";
            DevelopmentInfoCell *cell = (DevelopmentInfoCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil)
            {
                UIViewController *view = [[UIViewController alloc]initWithNibName:@"DevelopmentInfoCell" bundle:nil];
                cell = (DevelopmentInfoCell *)view.view;
            }
            cell.lblLocation.text = [NSString stringWithFormat:@"Location:%@",theProperty.fulladdress];
            if (![theProperty.yearBuilt isKindOfClass:[NSNull class]]) {
                
                cell.lblDevelopedIn.text = [NSString stringWithFormat:@"Developed in:%@",theProperty.yearBuilt];
            }
            else
            {
                cell.lblDevelopedIn.text = [NSString stringWithFormat:@"Developed in:"];
            }
            
            if (theProperty.developmentImageArr.count)
            {
                [cell.img setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[theProperty.developmentImageArr objectAtIndex:0]]] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            }
            else{
                
                [cell.img setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@""]] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            
            }
            
            return cell;
        }
      
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag==500) {
        return 44;
    }
    else
    {
        PropertyDetail *temp = [propertyDataArr objectAtIndex:indexPath.row];
        if ([temp.PropertyKind isEqualToString:@"Non Development"]) {
            
            return 150;
            
        } else{
            
            return 100;
        }
        
        
    }
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag==500) {
        
        txtSearch.text = [self placeAtIndexPath:indexPath].name;
        addressTable.hidden = YES;
        [txtSearch resignFirstResponder];
        CLGeocoder *geocoder = [[CLGeocoder alloc] init];
        [geocoder geocodeAddressString:txtSearch.text completionHandler:^(NSArray *placemarks, NSError *error) {
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            MKCoordinateRegion region;
            region.center.latitude = placemark.location.coordinate.latitude;
            region.center.longitude = placemark.location.coordinate.longitude;
            MKCoordinateSpan span;
             double radius =  [(CLCircularRegion*)placemark.region radius]/1000;
            span.latitudeDelta = radius / 112.0;
            region.span = span;
            [self->_mapView setRegion:region animated:YES];
        }];
    } else{
        
         PropertyDetail *theProperty = [propertyDataArr objectAtIndex:indexPath.row];
        if ([theProperty.PropertyKind isEqualToString:@"Non Development"])
        {
            PropertyDetailViewController*detail;
            if (IS_IPHONE) {
                 detail = [[PropertyDetailViewController alloc]initWithNibName:@"PropertyDetailViewController_iPhone" bundle:nil];
            } else {
                 detail = [[PropertyDetailViewController alloc]initWithNibName:@"PropertyDetailViewController_iPad" bundle:nil];
            }
            detail.PropertyId = theProperty.Id;
            detail.totalPropertyArr = propertyDataArr;
            detail.selectedIndex = indexPath.row;
            [self.navigationController pushViewController:detail animated:YES];
            
        }
        else
        {
            DevelopmentDetaillViewController*development;
            if (IS_IPHONE) {
                development = [[DevelopmentDetaillViewController alloc]initWithNibName:@"DevelopmentDetaillViewController_iPhone" bundle:nil];
            } else {
               // DevelopmentDetaillViewController_iPad
                development = [[DevelopmentDetaillViewController alloc]initWithNibName:@"DevelopmentDetaillViewController_iPad" bundle:nil];
            }
            
            development.developmentInfo = theProperty;
            [self.navigationController pushViewController:development animated:YES];
        
        }
        
        
    }
    
}

-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [clusterTbl removeFromSuperview];
    UITouch *touch = [[event allTouches] anyObject];
    touchlocation = [touch locationInView:touch.view];
}

#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    
    keyboardControls.textFields = [NSArray arrayWithObjects:@[], nil];
    
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"";
    [keyboardControls hidePrevNextButtons:YES];
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] bounds];
    
    CGFloat availableHeight = applicationFrame.size.height - 230;
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    
    if (!(txtSearch.text.length==0)) {
        addressTable.hidden = YES;
        CLGeocoder *geocoder = [[CLGeocoder alloc] init];
        [geocoder geocodeAddressString:txtSearch.text completionHandler:^(NSArray *placemarks, NSError *error) {
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            MKCoordinateRegion region;
            region.center.latitude = placemark.location.coordinate.latitude;
            region.center.longitude = placemark.location.coordinate.longitude;
            MKCoordinateSpan span;
            double radius =  [(CLCircularRegion*)placemark.region radius]/1000;
            span.latitudeDelta = radius / 112.0;
            region.span = span;
            [self->_mapView setRegion:region animated:YES];
        }];
    }
    
    [txtSearch resignFirstResponder];
    [controls.activeTextField resignFirstResponder];
    
}

- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (shouldBeginEditing) {
        
        NSTimeInterval animationDuration = 0.3;
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:animationDuration];
        [UIView commitAnimations];
    }
    BOOL boolToReturn = shouldBeginEditing;
    shouldBeginEditing = YES;
    return boolToReturn;
    
    if ([keyboardControls.textFields containsObject:textField])
        keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if ((!txtSearch.text.length)==0) {
        addressTable.hidden = YES;
        CLGeocoder *geocoder = [[CLGeocoder alloc] init];
        [geocoder geocodeAddressString:txtSearch.text completionHandler:^(NSArray *placemarks, NSError *error) {
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            MKCoordinateRegion region;
            region.center.latitude = placemark.location.coordinate.latitude;
            region.center.longitude = placemark.location.coordinate.longitude;
            MKCoordinateSpan span;
            double radius =  [(CLCircularRegion*)placemark.region radius]/1000;
            span.latitudeDelta = radius / 112.0;
            region.span = span;
            [self->_mapView setRegion:region animated:YES];
        }];
    }
    [textField resignFirstResponder];
    return YES;
}

-(void)textFieldDidChange :(UITextField *)theTextField{
    NSLog( @"text changed: %@", theTextField.text);
   [self handleSearchForSearchString:theTextField.text];
    [addressTable reloadData];
}
- (void)handleSearchForSearchString:(NSString *)searchString {
    searchQuery.location = self.mapView.userLocation.coordinate;
    searchQuery.input = searchString;
    [searchQuery fetchPlaces:^(NSArray *places, NSError *error) {
        if (error) {
            SPPresentAlertViewWithErrorAndTitle(error, @"Could not fetch Places");
        } else {
            self->searchResultPlaces = places;
            if (places.count) {
                
                if (places.count<5) {
                    
                    self->addressTable.hidden = YES;
                  //  [addressTable reloadData];
                    
                } else {
                    self->addressTable.hidden = NO;
                    [self->addressTable reloadData];
                }
                
            }
            else{
                self->addressTable.hidden = YES;
            }
           
        }
    }];
}

-(void)getSavedValueFromDatabase
{
    NSString *existData;
    if ([self.selectedValue isEqualToString:@"All_Property"])
    {
        strStatus =  @"all_property";
        existData = @"select * from AllProperties";
        
    }
    else if ([self.selectedValue isEqualToString:@"For_Rent"])
    {
        strStatus =  @"for_rent";
        existData = @"select * from RentProperties";
    }
    else if ([self.selectedValue isEqualToString:@"For_Sold"])
    {
        strStatus =  @"sold";
        existData = @"select * from SoldProperties";
        
    }
    else
    {
        strStatus =  @"for_sale";
        existData = @"select * from SaleProperties";
    }
    
    if (self.propertyDetail != nil)
    {
        self.propertyDetail = nil;
    }
    self.propertyDetail = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:existData]];
    NSLog(@"DATA---%@",_propertyDetail);
    NSLog(@"Count---%lu",(unsigned long)self.propertyDetail.count);
    if (self.propertyDetail.count)
    {
        dataDuplicate = [self.propertyDetail objectAtIndex:0];
        if ([self.selectedValue isEqualToString:@"All_Property"])
        {
            salePriceMin  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:0]];
            salePriceMax  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:1]];
            rentPriceMin  =[NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
            rentPriceMax  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:3]];
            if (![[dataDuplicate objectAtIndex:4] isEqualToString:@"0"]){
                
                fullAddress = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:4]];
            }
            else
            {
              fullAddress = @"0";
            }
            totalBeds    = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:5] integerValue]];
            totalBaths   = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
            propertyType = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:7]];
            
            NSArray *selectedItems = [propertyType componentsSeparatedByString:@"/"];
            typeOfProperty = [[NSMutableString alloc]init];
            for (NSInteger i = 0; i<selectedItems.count; i++) {
                [typeOfProperty appendString:[NSString stringWithFormat:@"%@,",[selectedItems objectAtIndex:i]]];
            }
            propertyType = [typeOfProperty substringToIndex:[typeOfProperty length]-1];
            // set square feet
            if ([[dataDuplicate objectAtIndex:8] integerValue] ==0&&[[dataDuplicate objectAtIndex:9] integerValue] ==0)
            {
                squareFeetMin = @"1";
                squareFeetMax = @"500000";
            }
            else if ([[dataDuplicate objectAtIndex:8] integerValue] ==0)
            {
                squareFeetMin = @"1";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:9] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:9] integerValue] ==0)
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:8] integerValue]];
                squareFeetMax = @"500000";
            }
            else
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:8] integerValue]];
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:9] integerValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:18] isEqualToString:@"Yes"]){
                foreclosedyn = @"Yes";
            }
            if ([[dataDuplicate objectAtIndex:18] isEqualToString:@"No"]){
                foreclosedyn = @"No";
            }
            shortSale = @"0";
            
            if ([[dataDuplicate objectAtIndex:10] floatValue] ==0&&[[dataDuplicate objectAtIndex:11] integerValue] ==0)
            {
                lotSquareMin = @"1";
                lotSquareMax = @"500000000000";
            }
            else if ([[dataDuplicate objectAtIndex:10] floatValue] ==0)
            {
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotSquareMin = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:11] floatValue] ==0)
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:10] integerValue]];
                lotSquareMax = @"500000000000";
            }
            else
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:10] integerValue]];
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:12] floatValue] ==0&&[[dataDuplicate objectAtIndex:13] floatValue] ==0)
            {
               
                lotAcreMin= @"0";
                lotAcreMax  = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:12] floatValue] ==0)
            {
                lotAcreMin = @"0";
                lotAcreMax = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:13] floatValue]];
            }
            else if ([[dataDuplicate objectAtIndex:13] floatValue] ==0)
            {
                lotAcreMin = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:12] floatValue]];
                lotAcreMax = @"500000000";
            }
            else
            {
                lotAcreMin =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:12] floatValue]];
                lotAcreMax =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:13] floatValue]];
            }
            
            
            if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"]&&[[dataDuplicate objectAtIndex:15] isEqualToString:@"0"]) {
                yearBuiltMin = @"0";
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
            {
                yearBuiltMin= @"0";
                yearBuiltMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:15] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:15] isEqualToString:@"0"])
            {
                yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else
            {
                yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
                yearBuiltMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:15] integerValue]];
            }
            if ([[dataDuplicate objectAtIndex:16]isEqualToString:@"Any"]) {
                
                daysOnMarket =@"0";
            } else {
                daysOnMarket =[NSString stringWithFormat:@"-%@",[dataDuplicate objectAtIndex:16]];
            }
            if (![[dataDuplicate objectAtIndex:17] isEqualToString:@"0"]) {
                SearchByKeyword = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:17]];
            }
            else
            {
                SearchByKeyword = @"";
            }
            
            
        }
        else if ([self.selectedValue isEqualToString:@"For_Rent"])
        {
            rentPriceMin  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:0]];
            rentPriceMax  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:1]];
            
            if (![[dataDuplicate objectAtIndex:2] isEqualToString:@"0"]) {
              fullAddress   = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
            }
            else{
                fullAddress = @"0";
            }
            totalBeds     = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:3] integerValue]];
            totalBaths    = [NSString stringWithFormat:@"%ld",[[dataDuplicate objectAtIndex:4] integerValue]];
            if (![[dataDuplicate objectAtIndex:5]isEqualToString:@"0"]) {
                propertyType = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:5]];
            }
            NSArray *selectedItems = [propertyType componentsSeparatedByString:@"/"];
            typeOfProperty = [[NSMutableString alloc]init];
            for (NSInteger i = 0; i<selectedItems.count; i++) {
                [typeOfProperty appendString:[NSString stringWithFormat:@"%@,",[selectedItems objectAtIndex:i]]];
            }
            propertyType = [typeOfProperty substringToIndex:[typeOfProperty length]-1];
            
            
            if ([[dataDuplicate objectAtIndex:6] integerValue] ==0 && [[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = @"0";
                squareFeetMax = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:6] integerValue] ==0)
            {
                squareFeetMin = @"1";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
                squareFeetMax = @"500000";
            }
            else
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:8] floatValue] ==0&&[[dataDuplicate objectAtIndex:9] integerValue] ==0)
            {
                lotSquareMin = @"0";
                lotSquareMax = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:8] floatValue] ==0)
            {
                lotSquareMin = @"1";
                lotSquareMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:9] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:9] floatValue] ==0)
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:8] integerValue]];
                lotSquareMax = @"500000000000";
            }
            else
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:8] integerValue]];
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:9] integerValue]];
            }
            strPetPolicy = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:10]];
            foreclosedyn  = @"Yes";
            shortSale     = @"No";
            
            if ([[dataDuplicate objectAtIndex:11] floatValue] ==0 &&[[dataDuplicate objectAtIndex:12] floatValue] ==0)
            {
                lotAcreMin = @"0";
                lotAcreMax = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:11] floatValue] ==0)
            {
                lotAcreMin = @"0";
                lotAcreMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:12] floatValue] ==0)
            {
                lotAcreMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotAcreMax = @"500000";
            }
            else
            {
                lotAcreMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotAcreMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"]&&[[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
            {
                yearBuiltMin= @"0";
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"])
            {
                yearBuiltMin= @"0";
                yearBuiltMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
            {
                yearBuiltMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else
            {
                yearBuiltMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
                yearBuiltMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
            }
            if ([[dataDuplicate objectAtIndex:15] isEqualToString:@"Any"]) {
                
                daysOnMarket = @"0";
            } else {
                daysOnMarket = [NSString stringWithFormat:@"-%@",[dataDuplicate objectAtIndex:15]];
            }
            
            if (![[dataDuplicate objectAtIndex:16] isEqualToString:@"0"]) {
                SearchByKeyword = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:16]];
            }
            else
            {
                SearchByKeyword = @"";
            }
            
            
            
        }
        else if ([self.selectedValue isEqualToString:@"For_Sold"])
        {
            salePriceMin = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:0]];
            salePriceMax = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:1]];
            fullAddress  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
            totalBeds    = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:3] integerValue]];
            totalBaths   = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:4] integerValue]];
            propertyType = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:5]];
            
            
            NSArray *selectedItems = [propertyType componentsSeparatedByString:@"/"];
            typeOfProperty = [[NSMutableString alloc]init];
            for (NSInteger i = 0; i<selectedItems.count; i++) {
                [typeOfProperty appendString:[NSString stringWithFormat:@"%@,",[selectedItems objectAtIndex:i]]];
            }
            propertyType = [typeOfProperty substringToIndex:[typeOfProperty length]-1];
            
            /*
             Set Square feet
             */
            
            if ([[dataDuplicate objectAtIndex:6] integerValue] ==0&&[[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = @"0";
                squareFeetMax = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:6] integerValue] ==0)
            {
                
                squareFeetMin = @"1";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
                
            }
            else if ([[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = @"500000";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
            }
            else
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
            }
            
            // update lot square
            
            if ([[dataDuplicate objectAtIndex:11] floatValue] ==0&&[[dataDuplicate objectAtIndex:12] integerValue] ==0)
            {
                lotSquareMin = @"1";
                lotSquareMax = @"500000000000";
            }
            else if ([[dataDuplicate objectAtIndex:11] floatValue] ==0)
            {
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
                lotSquareMin = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:12] floatValue] ==0)
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotSquareMax = @"500000000000";
            }
            else
            {
                lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
                lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:9] floatValue] ==0&&[[dataDuplicate objectAtIndex:10] floatValue] ==0)
            {
                
                lotAcreMin= @"0";
                lotAcreMax  = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:9] floatValue] ==0)
            {
                lotAcreMin = @"0";
                lotAcreMax = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:10] floatValue]];
            }
            else if ([[dataDuplicate objectAtIndex:10] floatValue] ==0)
            {
                lotAcreMin = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:9] floatValue]];
                lotAcreMax = @"500000000";
            }
            else
            {
                lotAcreMin =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:9] floatValue]];
                lotAcreMax =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:10] floatValue]];
            }
            
            if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"]&&[[dataDuplicate objectAtIndex:14] isEqualToString:@"0"]) {
                yearBuiltMin = @"0";
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"])
            {
                yearBuiltMin= @"0";
                yearBuiltMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
            }
            else if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
            {
                yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
                NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                [formatter setDateFormat:@"yyyy"];
                yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
            }
            else
            {
                yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
                yearBuiltMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
            }
            if ([[dataDuplicate objectAtIndex:15]isEqualToString:@"Any"]) {
                
                daysOnMarket =@"0";
            } else {
                daysOnMarket =[NSString stringWithFormat:@"-%@",[dataDuplicate objectAtIndex:15]];
            }
            
            if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Foreclosures only"]){
                foreclosedyn = @"Yes";
                shortSale = @"No";
            }
            else if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Short sale only"]){
                foreclosedyn = @"No";
                shortSale = @"Yes";
                
            }
            else if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Both"]){
                foreclosedyn = @"Yes";
                shortSale = @"Yes";
            }
            else
            {
                foreclosedyn = @"No";
                shortSale = @"No";
            }
            
            if (![[dataDuplicate objectAtIndex:16] isEqualToString:@"0"]) {
                SearchByKeyword = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:16]];
            }
            else
            {
                SearchByKeyword = @"";
            }
            
        }
        else
        {
            salePriceMin = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:0]];
            salePriceMax = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:1]];
            fullAddress  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
            totalBeds    = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:3] integerValue]];
            totalBaths   = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:4] integerValue]];
            propertyType = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:5]];
            
            
            NSArray *selectedItems = [propertyType componentsSeparatedByString:@"/"];
            typeOfProperty = [[NSMutableString alloc]init];
            for (NSInteger i = 0; i<selectedItems.count; i++) {
                [typeOfProperty appendString:[NSString stringWithFormat:@"%@,",[selectedItems objectAtIndex:i]]];
            }
            propertyType = [typeOfProperty substringToIndex:[typeOfProperty length]-1];

            /*
              Set Square feet
            */
            
            if ([[dataDuplicate objectAtIndex:6] integerValue] ==0&&[[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = @"0";
                squareFeetMax = @"0";
            }
            else if ([[dataDuplicate objectAtIndex:6] integerValue] ==0)
            {
               
                squareFeetMin = @"1";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
                
            }
            else if ([[dataDuplicate objectAtIndex:7] integerValue] ==0)
            {
                squareFeetMin = @"500000";
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
            }
            else
            {
                squareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
                squareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
            }
            
            // update lot square
             
             if ([[dataDuplicate objectAtIndex:11] floatValue] ==0&&[[dataDuplicate objectAtIndex:12] integerValue] ==0)
             {
             lotSquareMin = @"1";
             lotSquareMax = @"500000000000";
             }
             else if ([[dataDuplicate objectAtIndex:11] floatValue] ==0)
             {
             lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
             lotSquareMin = @"0";
             }
             else if ([[dataDuplicate objectAtIndex:12] floatValue] ==0)
             {
             lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
             lotSquareMax = @"500000000000";
             }
             else
             {
             lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
             lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
             }
             
             if ([[dataDuplicate objectAtIndex:9] floatValue] ==0&&[[dataDuplicate objectAtIndex:10] floatValue] ==0)
             {
             
             lotAcreMin= @"0";
             lotAcreMax  = @"0";
             }
             else if ([[dataDuplicate objectAtIndex:9] floatValue] ==0)
             {
             lotAcreMin = @"0";
             lotAcreMax = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:10] floatValue]];
             }
             else if ([[dataDuplicate objectAtIndex:10] floatValue] ==0)
             {
             lotAcreMin = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:9] floatValue]];
             lotAcreMax = @"500000000";
             }
             else
             {
             lotAcreMin =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:9] floatValue]];
             lotAcreMax =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:10] floatValue]];
             }
            
             if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"]&&[[dataDuplicate objectAtIndex:14] isEqualToString:@"0"]) {
             yearBuiltMin = @"0";
             NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
             [formatter setDateFormat:@"yyyy"];
             yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
             }
             else if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"])
             {
             yearBuiltMin= @"0";
             yearBuiltMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
             }
             else if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
             {
             yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
             NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
             [formatter setDateFormat:@"yyyy"];
             yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
             }
             else
             {
             yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
             yearBuiltMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
             }
             if ([[dataDuplicate objectAtIndex:15]isEqualToString:@"Any"]) {
             
             daysOnMarket =@"0";
             } else {
             daysOnMarket =[NSString stringWithFormat:@"-%@",[dataDuplicate objectAtIndex:15]];
             }
            
            if (![[dataDuplicate objectAtIndex:16] isEqualToString:@"0"]) {
                SearchByKeyword = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:16]];
            }
            else
            {
                SearchByKeyword = @"";
            }
            
            if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Foreclosures only"]){
                foreclosedyn = @"Yes";
                shortSale = @"No";
            }
            else if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Short sale only"]){
                foreclosedyn = @"No";
                shortSale = @"Yes";
                
            }
            else if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Both"]){
                foreclosedyn = @"Yes";
                shortSale = @"Yes";
            }
            else
            {
                foreclosedyn = @"No";
                shortSale = @"No";
            }
        }
    }
    
    [self mapView:self.mapView regionDidChangeAnimated:YES];

}
-(void)getSavedSearch:(NSString*)withId
{
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:withId forKey:@"save_search_id"];
    [REWebService GetParticularSavedSearch:dataDict withBlock:^(NSDictionary *dictResult, NSError *error){
        NSLog(@"%@",dictResult);
       
        if (!error) {
            if ([[[dictResult valueForKey:@"response"]valueForKey:@"message"]isEqualToString:@"success"]) {
                
                int newCount = [[[dictResult valueForKey:@"response"] valueForKey:@"menu_saved_count"] intValue];
                NSString *str = [NSString stringWithFormat:@"%d",newCount];
                [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"SavedSearchCount"];
                NSDictionary *temp=  [[dictResult valueForKey:@"response"] valueForKey:@"data"];
                CLLocationCoordinate2D neCoord;
                neCoord.latitude = [[temp valueForKey:@"latitude1"] doubleValue];
                neCoord.longitude = [[temp valueForKey:@"longitude1"] doubleValue];
                CLLocationCoordinate2D swCoord;
                swCoord.latitude = [[temp valueForKey:@"latitude2"] doubleValue];
                swCoord.longitude = [[temp valueForKey:@"longitude2"] doubleValue];
                MKCoordinateRegion region;
                region.center.latitude = neCoord.latitude - (neCoord.latitude - swCoord.latitude) * 0.5;
                region.center.longitude = neCoord.longitude + (swCoord.longitude - neCoord.longitude) * 0.5;
                region.span.latitudeDelta = fabs(neCoord.latitude - swCoord.latitude);
                region.span.longitudeDelta = fabs(swCoord.longitude - neCoord.longitude);
                region = [self.mapView regionThatFits:region];
                [self.mapView setRegion:region animated:YES];
                [temp dictionaryByReplacingNullsWithBlanks];
                self->savedParam = [temp mutableCopy];
                [self getSavedSearchedOnMap:self->savedParam];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"ReloadSideMenu" object:nil];
                
            }
            else
            {
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"]valueForKey:@"msg"]];
            }
            
            
        }
        
    }];

}
-(void)getSavedSearchedOnMap:(NSMutableDictionary*)param
{
    [loadingView setFrame:CGRectMake((self.view.frame.size.width/2)-65, self.view.frame.size.height-96, 130, 40)];
    [REWebService CallGetPropertDataFromServer:param :self :loadingView withBlock:^(NSDictionary *dictResult, NSError *error) {
        [self->loadingView removeFromSuperview];
        if ([[[dictResult objectForKey:@"response"] objectForKey:@"message"] isEqualToString:@"success"]) {
            
            if (self->propertyDataArr){
                [self->propertyDataArr removeAllObjects];
               
                
            }
            
            NSMutableArray * annotationsToRemove = [ self->_mapView.annotations mutableCopy ] ;
            
            [ self->_mapView removeAnnotations:annotationsToRemove] ;
            [self->_mapView removeAnnotations:self->_mapView.annotations];
            
            
            NSArray *propertyTempArr = [[dictResult objectForKey:@"response"]objectForKey:@"data"] ;
            for(NSDictionary *tempDict in propertyTempArr)
            {
                PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                [self->propertyDataArr addObject:datamodel];

            }
            
            [self->myTable reloadData];
            [self->_mapView removeAnnotations:self->_mapView.annotations];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^
                           {
                               NSArray *propertyData = [Airport allPropertyData:propertyTempArr];
                               dispatch_async(dispatch_get_main_queue(), ^
                                              {
                                                  if (self->_mapView.annotations.count) {
                                                      [self->_mapView removeAnnotations:self->_mapView.annotations];
                                                  } else {
                                                      
                                                      [self->_mapView addAnnotations:propertyData];
                                                  }
                                                  
                                                  [self->myTable reloadData];
                                                  
                                              });
                           });
            
            
        }
        
        
    }];

}
-(double)Mapzoomlevel {
    
return 21- round(log2(_mapView.region.span.longitudeDelta *
                          MERCATOR_RADIUS * M_PI / (180.0 * _mapView.bounds.size.width)));
    
}

-(NSString *)getAddressFromLocation :(CLLocation *)currentLocation
{
    [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
    __block NSString *address;
    CLGeocoder *ceo = [[CLGeocoder alloc]init];
    [ceo reverseGeocodeLocation: currentLocation completionHandler:
     ^(NSArray *placemarks, NSError *error) {
         [MBProgressHUD hideAllHUDsForView:self->_delegate.window animated:YES];
         CLPlacemark *placemark = [placemarks objectAtIndex:0];
         NSLog(@"placemark %@",placemark);
         NSString *cityName    = [placemarks[0] locality];
         NSString *locatedAt = [NSString stringWithFormat:@"%@ %@ %@",cityName,[placemark.addressDictionary valueForKey:@"State"],[placemark.addressDictionary valueForKey:@"ZIP"]];
    
         if ([self.selectedValue isEqualToString:@"All_Property"])
         {
          address = [NSString stringWithFormat:@"All Properties near %@",locatedAt];
         }
         else if ([self.selectedValue isEqualToString:@"For_Rent"])
         {
          address = [NSString stringWithFormat:@"For Rent near %@",locatedAt];
         }
         else if ([self.selectedValue isEqualToString:@"For_Sold"])
         {
          address = [NSString stringWithFormat:@"Sold near %@",locatedAt];
         }
         else
         {
             
          address = [NSString stringWithFormat:@"For Sale near %@",locatedAt];
             
         }
        [self getMapImage:^(UIImage *Resultimage, NSError *error){
            NSLog(@"%@",Resultimage);
            if (!error) {
                
                SavedSearchViewController *savedSearchVc;
                if (IS_IPHONE) {
                    
                   savedSearchVc  = [[SavedSearchViewController alloc] initWithNibName:@"SavedSearchViewController_iPhone" bundle:nil];
                } else {
                    savedSearchVc  = [[SavedSearchViewController alloc] initWithNibName:@"SavedSearchViewController_iPad" bundle:nil];
                }
                savedSearchVc.strPnCount = self->strProprtyCount;
                savedSearchVc.parameterDict = self->passDict;
                savedSearchVc.genratedAddress = address;
                savedSearchVc.imageCapture =Resultimage;
                [self.navigationController pushViewController:savedSearchVc animated:YES];
            }
        }];
         
         
         
         
     }];
    NSLog(@"my address-%@",address);
    return address;
}


- (void)getMapImage:(void (^)(UIImage *captureimage, NSError *error))block
{
    MKMapSnapshotOptions *options = [[MKMapSnapshotOptions alloc] init];
    options.region = self.mapView.region;
    options.scale = [UIScreen mainScreen].scale;
    options.size = self.mapView.frame.size;
   // __block NSData *data;
    MKMapSnapshotter *snapshotter = [[MKMapSnapshotter alloc] initWithOptions:options];
    [snapshotter startWithCompletionHandler:^(MKMapSnapshot *snapshot, NSError *error) {
      
         block(snapshot.image,nil);
        
    }];
}

    
        

-(NSData *)screenshot
{
   MKMapSnapshotOptions *options = [[MKMapSnapshotOptions alloc] init];
   options.region = self.mapView.region;
   options.scale = [UIScreen mainScreen].scale;
   options.size = self.mapView.frame.size;
   __block NSData *data;
   MKMapSnapshotter *snapshotter = [[MKMapSnapshotter alloc] initWithOptions:options];
   [snapshotter startWithCompletionHandler:^(MKMapSnapshot *snapshot, NSError *error) {
   UIImage *image = snapshot.image;
   data = UIImagePNGRepresentation(image);
       
       
       
   }];
   
   return data;
}

-(void)showFavouriteOnMap
{
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] forKey:@"user_id"];
    [REWebService showFavoriteOnMap:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        
        if (!error) {
            
            if ([[[dictResult objectForKey:@"response"] objectForKey:@"message"] isEqualToString:@"success"]) {
                
                if (self->propertyDataArr.count){
                    [self->propertyDataArr removeAllObjects];
                    
                }
                NSMutableArray * annotationsToRemove = [ self->_mapView.annotations mutableCopy ] ;
                [ self->_mapView removeAnnotations:annotationsToRemove] ;
                [self->_mapView removeAnnotations:self->_mapView.annotations];
                
                
                NSArray *propertyTempArr = [[dictResult objectForKey:@"response"]objectForKey:@"data"] ;
                for(NSDictionary *tempDict in propertyTempArr)
                {
                    PropertyDetail *datamodel = [[PropertyDetail alloc]initWithDict:tempDict];
                    [self->propertyDataArr addObject:datamodel];
                    
                }
                
                [self->myTable reloadData];
                [self->_mapView removeAnnotations:self->_mapView.annotations];
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^
                               {
                                   NSArray *propertyData = [Airport allPropertyData:propertyTempArr];
                                   dispatch_async(dispatch_get_main_queue(), ^
                                                  {
                                                      if (self->_mapView.annotations.count) {
                                                          [self->_mapView removeAnnotations:self->_mapView.annotations];
                                                      } else {
                                                          
                                                          [self->_mapView addAnnotations:propertyData];
                                                          
                                                          
                                                          double center_long = 0.0f;
                                                          double center_lat = 0.0f;
                                                          double max_long = 0.0f;
                                                          double min_long = 0.0f;
                                                          double max_lat = 0.0f;
                                                          double min_lat = 0.0f;
                                                           
                                                          for (PropertyDetail *theData in self->propertyDataArr) {
                                                           if ([theData.latitude doubleValue] > max_lat) {max_lat = [theData.latitude doubleValue];}
                                                           if ([theData.latitude doubleValue] < min_lat) {min_lat = [theData.latitude doubleValue];}
                                                           if ([theData.longitude doubleValue] > max_long) {max_long = [theData.longitude doubleValue];}
                                                           if ([theData.longitude doubleValue] < min_long) {min_long = [theData.longitude doubleValue];}
                                                           
                                                           //sum up long and lang to get average later
                                                           center_lat = center_lat + [theData.latitude doubleValue];
                                                           center_long = center_long + [theData.longitude doubleValue];
                                                           }
                                                           
                                                           //calculate average long / lat
                                                          center_lat = center_lat / [self->propertyDataArr count];
                                                          center_long = center_long / [self->propertyDataArr count];
                                                           
                                                           NSLog(@"center long: %f, center lat: %f", center_long, center_lat);
                                                           NSLog(@"max_long: %f, min_long: %f, max_lat: %f, min_lat: %f", max_long, min_long, max_lat, min_lat);
                                                           
                                                           //create new region and set map
                                                           CLLocationCoordinate2D coord = {.latitude =  center_lat, .longitude =  center_long};
                                                           MKCoordinateSpan span = MKCoordinateSpanMake(fabs(max_lat) + fabs(min_lat), fabs(max_long) + fabs(min_long));
                                                           MKCoordinateRegion region = {coord, span};
                                                          [self->_mapView setRegion:region];
                                                    
                                                          
                                                      }
                                                      
                                                      [self->myTable reloadData];
                                                      
                                                  });
                               });
                
                
            }
            else
            {
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"]valueForKey:@"msg"]];
            }
            
            
        }
        
        
    }];
    

}


@end
