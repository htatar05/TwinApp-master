//
//  ScrollingImageViewController.h
//  ScrollingImage
//
//  Created by Chakra on 05/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@class MVPService;

@interface ScrollingImageViewController : UIViewController<UIScrollViewDelegate,UIGestureRecognizerDelegate> {
    
    CGPoint *startPOint;
    MVPService *service;
	IBOutlet UIScrollView *FirstScrollView;	
    IBOutlet UIToolbar *toolbarImg;
    IBOutlet UIBarButtonItem *nextBTn;
    IBOutlet UIBarButtonItem *peviousBtn;
    IBOutlet UIBarButtonItem *space1;
    IBOutlet UIBarButtonItem *space2;
    IBOutlet UIBarButtonItem *space3;
    
    UIButton *btn_share;
    UIBarButtonItem *sharebarbutton;
    UIAlertControllerStyle _MyPhoto;
    //UIActionSheet *actionsheet_MyPhoto;
    NSArray *permissions;
    UIView *loadingView;
    
   IBOutlet UIBarButtonItem *crossBtn;
   BOOL deleteflage;
    UIAlertControllerStyle *Deletealrt;
   //UIAlertView *Deletealert;
    BOOL pageControlUsed;
	NSArray *contentList;
	UIPageControl *pageControl;
   
	
}

@property(nonatomic,retain)NSString *memberidStr;
@property(nonatomic,assign)NSUInteger currentPageIndex;
@property (nonatomic, retain) NSString *isFromRestDetail;
@property (nonatomic, retain) UIView *FirstScrollView;
@property (nonatomic, retain)NSMutableArray *array;
@property (nonatomic, retain) NSMutableArray *viewControllers;


-(IBAction)previousBtnPressed:(id)sender;
-(IBAction)nextBtnPressed:(id)sender;

@end
