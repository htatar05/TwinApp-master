//  ScrollingImageViewController.m
//  ScrollingImage
//  Created by Chakra on 05/09/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.

#import "ScrollingImageViewController.h"
#import "Config.h"
#import "MyViewController.h"


@interface ScrollingImageViewController(Private)

@end


@implementation ScrollingImageViewController

@synthesize FirstScrollView,array,isFromRestDetail;
@synthesize currentPageIndex,memberidStr,viewControllers;

- (void)viewDidLoad
{
    if ([self.navigationController.navigationBar respondsToSelector:@selector( setBackgroundImage:forBarMetrics:)]){
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"t_ttile.png"] forBarMetrics:UIBarMetricsDefault];
    }
    
    FirstScrollView.scrollsToTop=NO;
    FirstScrollView.showsHorizontalScrollIndicator=NO;
    FirstScrollView.delegate=self;
    
    deleteflage=FALSE;
    

	self.view.backgroundColor = [UIColor viewFlipsideBackgroundColor];
	
	[FirstScrollView setBackgroundColor:[UIColor blackColor]];
	[FirstScrollView setCanCancelContentTouches:NO];
	FirstScrollView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
	FirstScrollView.clipsToBounds = YES;
	FirstScrollView.scrollEnabled = YES;
	FirstScrollView.pagingEnabled = YES;
    
    NSMutableArray *controllers = [[NSMutableArray alloc] init];
    for (unsigned i = 0; i < [array count]; i++)
    {
		[controllers addObject:[NSNull null]];
    }
    self.viewControllers = controllers;
    
    
    if (IsRunningTallPhone()) {
       FirstScrollView.contentSize = CGSizeMake(FirstScrollView.frame.size.width * [array count], FirstScrollView.frame.size.height);
    }
    else
    {
        FirstScrollView.contentSize = CGSizeMake(FirstScrollView.frame.size.width * [array count], FirstScrollView.frame.size.height-88);
    }
 
    FirstScrollView.showsHorizontalScrollIndicator = NO;
    FirstScrollView.showsVerticalScrollIndicator = NO;
    FirstScrollView.scrollsToTop = NO;
    FirstScrollView.delegate = self;
    
    pageControl.numberOfPages = [array count];
    pageControl.currentPage = currentPageIndex;
	[self loadScrollViewWithPage:currentPageIndex];
	CGRect frame = FirstScrollView.frame;
    frame.origin.x = frame.size.width * currentPageIndex;
    frame.origin.y = 0;
	[FirstScrollView scrollRectToVisible:frame animated:NO];
    pageControlUsed = YES;
    
}

- (void)loadScrollViewWithPage:(int)page
{
    if (page < 0)
        return;
    if (page >= [array count])
        return;
    MyViewController *controller = [ self.viewControllers objectAtIndex:page];
    if ((NSNull *)controller == [NSNull null])
    {
        controller = [[MyViewController alloc] initWithPageNumber:page];
        [ self.viewControllers replaceObjectAtIndex:page withObject:controller];
    }
	if (controller.view.superview == nil)
    {
        CGRect frame = FirstScrollView.frame;
        frame.origin.x = frame.size.width * page;
        frame.origin.y = 0;
        controller.view.frame = frame;
        [FirstScrollView addSubview:controller.view];
	}
}

- (void)scrollViewDidScroll:(UIScrollView *)sender
{
   	if (pageControlUsed)
    {
        return;
    }
    CGFloat pageWidth = FirstScrollView.frame.size.width;
    int page = floor((FirstScrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    pageControl.currentPage = page;
    currentPageIndex=page;
    [self loadScrollViewWithPage:page];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    pageControlUsed = NO;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    pageControlUsed = NO;
}

- (IBAction)changePage:(id)sender
{
    int page = pageControl.currentPage;
    [self loadScrollViewWithPage:page];
    CGRect frame = FirstScrollView.frame;
    frame.origin.x = frame.size.width * page;
    frame.origin.y = 0;
	[FirstScrollView scrollRectToVisible:frame animated:NO];
    pageControlUsed = YES;
}

#pragma mark - Click events
-(IBAction)previousBtnPressed:(id)sender
{
    if (currentPageIndex>=1) {
        
        currentPageIndex=currentPageIndex-1;
        [self loadScrollViewWithPage:currentPageIndex];
        CGRect frame = FirstScrollView.frame;
        frame.origin.x = frame.size.width * currentPageIndex;
        frame.origin.y = 0;
        [FirstScrollView scrollRectToVisible:frame animated:NO];
        pageControlUsed = YES;
    }
}

-(IBAction)nextBtnPressed:(id)sender
{
    if (currentPageIndex<[array count]-1) {
        currentPageIndex=currentPageIndex+1;
        [self loadScrollViewWithPage:currentPageIndex];
        CGRect frame = FirstScrollView.frame;
        frame.origin.x = frame.size.width * currentPageIndex;
        frame.origin.y = 0;
        [FirstScrollView scrollRectToVisible:frame animated:NO];
        pageControlUsed = YES;
    }
}

- (void)showFirstLoadingView
{
    if (loadingView == nil)
    {
        loadingView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0, 320.0, 480)];
        loadingView.opaque = NO;
        loadingView.backgroundColor = [UIColor blackColor];
        loadingView.alpha = 0.7;
		
        UIActivityIndicatorView *spinningWheel = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(142.0, 173, 37.0, 37.0)];
        [spinningWheel startAnimating];
        spinningWheel.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
        [loadingView addSubview:spinningWheel];
		
		UILabel *lblLoading=[[UILabel alloc] initWithFrame:CGRectMake(120,130,100,30)];
		[lblLoading setText:@"Loading...."];
		[lblLoading setBackgroundColor:[UIColor clearColor]];
		[lblLoading setTextColor:[UIColor whiteColor]];
		[lblLoading setFont:[UIFont fontWithName:@"Arial" size:18]];
		[lblLoading setFont:[UIFont boldSystemFontOfSize:18]];
		[loadingView addSubview:lblLoading];
    }
    
    [self.view addSubview:loadingView];
}


#pragma mark - EGO imageview delegate
//- (void)imageViewFailedToLoadImage:(EGOImageView*)imageView error:(NSError*)error
//{
//    NSLog(@"failed to load images");
//}
//
//-(UIImage*) resizeImage:(UIImage*) image size:(CGSize) size
//{
//	if (image.size.width != size.width || image.size.height != size.height)
//    {
//		UIGraphicsBeginImageContext(size);
//		CGRect imageRect = CGRectMake(0.0, 0.0, size.width, size.height);
//		[image drawInRect:imageRect];
//		image = UIGraphicsGetImageFromCurrentImageContext();
//		UIGraphicsEndImageContext();
//	}
//	return image;
//}

- (void)didReceiveMemoryWarning
{
	[super didReceiveMemoryWarning];
}



@end
