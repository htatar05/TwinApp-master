
#import <UIKit/UIKit.h>


@interface MyViewController : UIViewController
{
    UILabel *pageNumberLabel;
    int pageNumber;
}

@property (nonatomic, retain) IBOutlet UILabel *pageNumberLabel;
@property (nonatomic, retain) IBOutlet UILabel *numberTitle;
@property (nonatomic, retain) IBOutlet UIImageView *numberImage;
- (id)initWithPageNumber:(int)page;

@end
