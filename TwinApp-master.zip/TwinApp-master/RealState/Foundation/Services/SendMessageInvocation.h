//
//  LoginInvocation.h
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"
#import "RealEstateAsyncInvocation.h"

@class SendMessageInvocation;
@protocol SendMessageInvocationDelegate

-(void)SendMessageInvocationDidFinish:(SendMessageInvocation*)invocation
                              withResults:(NSMutableDictionary*)result
                             withMessages:(NSString*)result1
							 withError:(NSError*)error;

@end
@interface SendMessageInvocation : RealEstateAsyncInvocation {
}

@property (nonatomic, strong) NSString *strLoggedInUserId;
@property (nonatomic, strong) NSString *strToUserId;
@property (nonatomic, strong) NSString *strToEamilId;
@property (nonatomic, strong) NSString *strFromEamil;
@property (nonatomic, strong) NSString *strFromPhoneNo;
@property (nonatomic, strong) NSString *strFromMessage;

-(NSString*)body; 

@end