//
//  LoginInvocation.m
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//

#import "DeleteNonConnectedClientDetailInvocation.h"
#import "JSON.h"


@implementation DeleteNonConnectedClientDetailInvocation
@synthesize arrNonConnectedClientsId;

-(void)invoke
{
	NSString *a= @"deleteNotConnectedClient";
	[self post:a body:[self body]];
}

-(NSString*)body
{
	NSMutableDictionary* bodyD = [[NSMutableDictionary alloc] init] ;
	[bodyD setObject:self.arrNonConnectedClientsId forKey:@"nonclinetuser_id"];
    NSLog(@"[bodyD JSONRepresentation]:%@",[bodyD JSONRepresentation]);
	return [bodyD JSONRepresentation];
}

-(BOOL)handleHttpOK:(NSMutableData *)data
{
	NSDictionary* resultsd = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]  JSONValue];
	// response dictionary
	NSError* error = Nil;
	NSMutableDictionary *dictResponse = [resultsd objectForKey:@"response"];
    NSLog(@"arrResponse=%@",dictResponse);
    if((NSNull *)dictResponse!=[NSNull null])
    {
        if([dictResponse count]>0)
        {
            if([[dictResponse objectForKey:@"message"] isEqualToString:@"success"])
                [self.delegate DeleteNonConnectedClientDetailInvocationDidFinish:self withResults:dictResponse withMessages:[dictResponse objectForKey:@"msg"] withError:error];
            else
                [self.delegate DeleteNonConnectedClientDetailInvocationDidFinish:self withResults:dictResponse withMessages:[dictResponse objectForKey:@"msg"] withError:error];
        }
        else{
              [self.delegate DeleteNonConnectedClientDetailInvocationDidFinish:self withResults:dictResponse withMessages:@"error" withError:error];
        }
        return YES;
    }
    else{
        return NO;
    }
}

-(BOOL)handleHttpError:(NSInteger)code
{
	[self.delegate DeleteNonConnectedClientDetailInvocationDidFinish:self
                                          withResults:Nil
                                         withMessages:Nil
                                         withError:[NSError errorWithDomain:@"UserId" 
                                                                       code:[[self response] statusCode]
                                                                   userInfo:[NSDictionary dictionaryWithObject:@"Failed to Add Non-Connected Client Detail. Please try again later" forKey:@"message"]]];
	return YES;
}

@end

