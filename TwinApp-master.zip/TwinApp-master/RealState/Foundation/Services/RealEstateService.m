//
//  HMJService.m
//  HMJ
//
//  Created by ashish sharma on 31/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RealEstateService.h"
#import <SystemConfiguration/SCNetworkReachability.h>
#import "CFNetwork/CFHTTPMessage.h"
#import <SystemConfiguration/SCNetworkReachability.h>
#import "SBJSON.h"
#import "Reachability.h"


@implementation RealEstateService

-(id)retain {	
	return [super retain];
}

-(void)dealloc {	
	[super dealloc];
}

-(void)LoginInvocation:(NSString*)email password:(NSString *)password  deviceToken:(NSString*)deviceToken deviceType:(NSString*)deviceType delegate: (id<LoginInvocationDelegate>)delegate;
{
    LoginInvocation *invocation = [[[LoginInvocation alloc] init] autorelease];
	invocation.email = email;
    invocation.password = password;
	invocation.strDeviceToken = deviceToken;
    invocation.deviceType=deviceType;
    [self invoke:invocation withDelegate:delegate]; 
}

-(void)ForgotPasswordInvocation:(NSString*)email delegate: (id<ForgotPasswordInvocationDelegate>)delegate
{
    ForgotPasswordInvocation *invocation = [[[ForgotPasswordInvocation alloc] init] autorelease];
	invocation.email = email;
    [self invoke:invocation withDelegate:delegate];
}

-(void)AgentListInvocation:(id<AgentListInvocationDelegate>)delegate;
{
    AgentListInvocation *invocation = [[[AgentListInvocation alloc] init] autorelease];
    [self invoke:invocation withDelegate:delegate];
}

-(void)AgentListDetailInvocation:(NSString*)strId delegate:(id<AgentListDetailInvocationDelegate>)delegate
{
    AgentListDetailInvocation *invocation = [[[AgentListDetailInvocation alloc] init] autorelease];
	invocation.strId = strId;
    [self invoke:invocation withDelegate:delegate];
}

-(void)ConnectedClientListDetailInvocation:(NSString*)strId delegate:(id<ConnectedClientListDetailInvocationDelegate>)delegate;
{
    ConnectedClientListDetailInvocation *invocation = [[[ConnectedClientListDetailInvocation alloc] init] autorelease];
	invocation.strId = strId;
    [self invoke:invocation withDelegate:delegate];
}

-(void)NonConnectedClientListDetailInvocation:(NSString*)strId delegate:(id<NonConnectedClientListDetailInvocationDelegate>)delegate
{
    NonConnectedClientListDetailInvocation *invocation = [[[NonConnectedClientListDetailInvocation alloc] init] autorelease];
	invocation.strId = strId;
    [self invoke:invocation withDelegate:delegate];
}

-(void)UpdateNonConnectedClientDetailInvocation:(NSString*)strId strUserName:(NSString*)strUserName strEmail:(NSString*)strEmail strFirstName:(NSString*)strFirstName strLastName:(NSString*)strLastName strPassword:(NSString*)strPassword delegate:(id<UpdateNonConnectedClientDetailInvocationDelegate>)delegate;
{
    UpdateNonConnectedClientDetailInvocation *invocation = [[[UpdateNonConnectedClientDetailInvocation alloc] init] autorelease];
    invocation.strId=strId;
    invocation.strUserName=strUserName;
    invocation.strEmail=strEmail;
    invocation.strFirstName=strFirstName;
    invocation.strLastName=strLastName;
    invocation.strPassword=strPassword;
    [self invoke:invocation withDelegate:delegate];
}

-(void)AddNonConnectedClientDetailInvocation:(NSString*)strLoggedInUserId strUserName:(NSString*)strUserName strEmail:(NSString*)strEmail strFirstName:(NSString*)strFirstName strLastName:(NSString*)strLastName strPassword:(NSString*)strPassword delegate:(id<AddNonConnectedClientDetailInvocationDelegate>)delegate;
{
    AddNonConnectedClientDetailInvocation *invocation = [[[AddNonConnectedClientDetailInvocation alloc] init] autorelease];
    invocation.strLoggedInUserId=strLoggedInUserId;
    invocation.strUserName=strUserName;
    invocation.strEmail=strEmail;
    invocation.strFirstName=strFirstName;
    invocation.strLastName=strLastName;
    invocation.strPassword=strPassword;
    [self invoke:invocation withDelegate:delegate];
}

-(void)DeleteNonConnectedClientDetailInvocation:(NSMutableArray*)arrNonConnectedClientsId delegate:(id<DeleteNonConnectedClientDetailInvocationDelegate>)delegate
{
    DeleteNonConnectedClientDetailInvocation *invocation = [[[DeleteNonConnectedClientDetailInvocation alloc] init] autorelease];
    invocation.arrNonConnectedClientsId=arrNonConnectedClientsId;
    [self invoke:invocation withDelegate:delegate];
}


@end