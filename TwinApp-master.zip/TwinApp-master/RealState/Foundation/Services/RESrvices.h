//
//  RESrvices.h
//  RealEstate_App
//
//  Created by Octal on 10/08/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RESrvices : NSObject


+ (void)Login:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block;

@end
