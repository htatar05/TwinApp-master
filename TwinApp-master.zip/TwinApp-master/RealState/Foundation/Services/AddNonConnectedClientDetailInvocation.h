//
//  LoginInvocation.h
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"
#import "RealEstateAsyncInvocation.h"

@class AddNonConnectedClientDetailInvocation;
@protocol AddNonConnectedClientDetailInvocationDelegate

-(void)AddNonConnectedClientDetailInvocationDidFinish:(AddNonConnectedClientDetailInvocation*)invocation
                              withResults:(NSMutableDictionary*)result
                             withMessages:(NSString*)result1
							 withError:(NSError*)error;

@end
@interface AddNonConnectedClientDetailInvocation : RealEstateAsyncInvocation {
}

@property (nonatomic, strong) NSString *strLoggedInUserId;
@property (nonatomic, strong) NSString *strFirstName;
@property (nonatomic, strong) NSString *strLastName;
@property (nonatomic, strong) NSString *strUserName;
@property (nonatomic, strong) NSString *strEmail;
@property (nonatomic, strong) NSString *strPassword;

-(NSString*)body; 

@end