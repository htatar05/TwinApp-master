//
//  LoginInvocation.h
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"
#import "RealEstateAsyncInvocation.h"

@class AgentListDetailInvocation;
@protocol AgentListDetailInvocationDelegate

-(void)AgentListDetailInvocationDidFinish:(AgentListDetailInvocation*)invocation
                              withResults:(NSMutableArray*)result
                             withMessages:(NSString*)result
							 withError:(NSError*)error;

@end
@interface AgentListDetailInvocation : RealEstateAsyncInvocation {
}

@property (nonatomic,strong)NSString *strId;

-(NSString*)body; 

@end