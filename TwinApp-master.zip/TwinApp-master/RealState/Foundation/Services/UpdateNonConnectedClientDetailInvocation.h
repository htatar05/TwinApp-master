//
//  LoginInvocation.h
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"
#import "RealEstateAsyncInvocation.h"

@class UpdateNonConnectedClientDetailInvocation;
@protocol UpdateNonConnectedClientDetailInvocationDelegate

-(void)UpdateNonConnectedClientDetailInvocationDidFinish:(UpdateNonConnectedClientDetailInvocation*)invocation
                              withResults:(NSMutableDictionary*)result
                             withMessages:(NSString*)result
							 withError:(NSError*)error;

@end
@interface UpdateNonConnectedClientDetailInvocation : RealEstateAsyncInvocation {
}

@property (nonatomic, strong) NSString *strId;
@property (nonatomic, strong) NSString *strFirstName;
@property (nonatomic, strong) NSString *strLastName;
@property (nonatomic, strong) NSString *strUserName;
@property (nonatomic, strong) NSString *strEmail;
@property (nonatomic, strong) NSString *strPassword;


-(NSString*)body; 

@end