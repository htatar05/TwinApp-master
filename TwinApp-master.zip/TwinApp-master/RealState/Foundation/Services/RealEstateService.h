//  HMJService.h
//  HMJ
//  Created by ashish sharma on 31/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.


#import <Foundation/Foundation.h>
#import "SAService.h"
#import "LoginInvocation.h"
#import "ForgotPasswordInvocation.h"
#import "AgentListInvocation.h"
#import "AgentListDetailInvocation.h"
#import "ConnectedClientListDetailInvocation.h"
#import "NonConnectedClientListDetailInvocation.h"
#import "UpdateNonConnectedClientDetailInvocation.h"
#import "AddNonConnectedClientDetailInvocation.h"
#import "DeleteNonConnectedClientDetailInvocation.h"

@interface RealEstateService : SAService
{
    
}

-(void)LoginInvocation:(NSString*)email password:(NSString *)password  deviceToken:(NSString*)deviceToken deviceType:(NSString*)deviceType delegate: (id<LoginInvocationDelegate>)delegate;

-(void)ForgotPasswordInvocation:(NSString*)email delegate: (id<ForgotPasswordInvocationDelegate>)delegate;

-(void)AgentListInvocation:(id<AgentListInvocationDelegate>)delegate;
-(void)AgentListDetailInvocation:(NSString*)strId delegate:(id<AgentListDetailInvocationDelegate>)delegate;
-(void)ConnectedClientListDetailInvocation:(NSString*)strId delegate:(id<ConnectedClientListDetailInvocationDelegate>)delegate;
-(void)NonConnectedClientListDetailInvocation:(NSString*)strId delegate:(id<NonConnectedClientListDetailInvocationDelegate>)delegate;

-(void)UpdateNonConnectedClientDetailInvocation:(NSString*)strId strUserName:(NSString*)strUserName strEmail:(NSString*)strEmail strFirstName:(NSString*)strFirstName strLastName:(NSString*)strLastName strPassword:(NSString*)strPassword delegate:(id<UpdateNonConnectedClientDetailInvocationDelegate>)delegate;

-(void)AddNonConnectedClientDetailInvocation:(NSString*)strLoggedInUserId strUserName:(NSString*)strUserName strEmail:(NSString*)strEmail strFirstName:(NSString*)strFirstName strLastName:(NSString*)strLastName strPassword:(NSString*)strPassword delegate:(id<AddNonConnectedClientDetailInvocationDelegate>)delegate;

-(void)DeleteNonConnectedClientDetailInvocation:(NSMutableArray*)arrNonConnectedClientsId delegate:(id<DeleteNonConnectedClientDetailInvocationDelegate>)delegate;


@end


