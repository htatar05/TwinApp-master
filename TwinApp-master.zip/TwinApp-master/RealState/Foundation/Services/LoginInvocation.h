//
//  LoginInvocation.h
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"
#import "RealEstateAsyncInvocation.h"
#import "AppDelegate.h"

@class LoginInvocation;
@protocol LoginInvocationDelegate 

-(void)LoginInvocationDidFinish:(LoginInvocation*)invocation 
						   withResults:(NSString*)result
							 withError:(NSError*)error;

@end
@interface LoginInvocation : RealEstateAsyncInvocation {
    
     AppDelegate *appdelegate;
}

@property (nonatomic,strong)NSString *email;
@property (nonatomic,strong)NSString *password;
@property (nonatomic,strong)NSString *strDeviceToken;
@property (nonatomic,strong)NSString *deviceType;

-(NSString*)body; 

@end