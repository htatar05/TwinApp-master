//  LoginInvocation.m
//  StormPins
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.

#import "LoginInvocation.h"
#import "JSON.h"
#import "NSDictionary+NullReplacement.h"
#import "NSArray+NullReplacement.h"
#import "Utils.h"


@implementation LoginInvocation
@synthesize email, password,strDeviceToken,deviceType;

-(void)invoke
{
	 NSString *a= @"login";
	[self post:a body:[self body]];
}

-(NSString*)body
{
	NSMutableDictionary* bodyD = [[NSMutableDictionary alloc] init] ;
	[bodyD setObject:self.email forKey:@"email"];
	[bodyD setObject:self.password forKey:@"password"];
    [bodyD setObject:self.strDeviceToken forKey:@"device_token"];
    [bodyD setObject:@"iphone" forKey:@"device_type"];
    NSLog(@"[bodyD JSONRepresentation]:%@",[bodyD JSONRepresentation]);
    return [bodyD JSONRepresentation];
}

-(BOOL)handleHttpOK:(NSMutableData *)data
{
    appdelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
	NSDictionary* resultsd = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]  JSONValue];
	NSError* error = Nil;
	NSDictionary *rerg = [resultsd objectForKey:@"response"];
    if((NSNull *)rerg!=[NSNull null])
    {
        if([[rerg objectForKey:@"message"] isEqualToString:@"success"])
        {
            if (appdelegate.isAutoLogin) {
           
            [[NSUserDefaults standardUserDefaults] setObject:[rerg dictionaryByReplacingNullsWithBlanks] forKey:@"userData"];
            [[NSUserDefaults standardUserDefaults] setObject:[rerg objectForKey:@"user_id"] forKey:@"user_id"];
                
            }
            else{
                
                [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"userData"];
                User *temp = [[User alloc]init];
                temp.strUserName = [rerg valueForKey:@"username"];
                temp.strFName = [rerg valueForKey:@"first_name"];
                temp.strLName = [rerg valueForKey:@"last_name"];
                temp.strEmail = [rerg valueForKey:@"email"];
                temp.strRoleId = [rerg valueForKey:@"role_id"];
                temp.strUserImage = [rerg valueForKey:@"userimage"];
                appdelegate.user = temp;
               
            }
            appdelegate.loginUser = TRUE;
            [[NSUserDefaults standardUserDefaults] setObject:[rerg objectForKey:@"user_id"] forKey:@"user_id"];
            [[NSUserDefaults standardUserDefaults] setObject:[rerg objectForKey:@"role_id"] forKey:@"role_id"];
            [[NSUserDefaults standardUserDefaults] setObject:[rerg objectForKey:@"role_id"] forKey:@"RoleId"];
            [self.delegate LoginInvocationDidFinish:self withResults:@"success" withError:error];
        }
        else
        {
            
            [Utils showAlertMessage:@"Twin Realty" Message:[rerg valueForKey:@"msg"]];
            [self.delegate LoginInvocationDidFinish:self withResults:@"failed" withError:error];
        }
        return YES;
    }
    else
    {
        return NO;
    }
}

-(BOOL)handleHttpError:(NSInteger)code
{
	[self.delegate LoginInvocationDidFinish:self 
                                       withResults:Nil
                                         withError:[NSError errorWithDomain:@"UserId" 
                                                                       code:[[self response] statusCode]
                                                                   userInfo:[NSDictionary dictionaryWithObject:@"Failed to submit Login Detail. Please try again later" forKey:@"message"]]];
	return YES;
}

@end

