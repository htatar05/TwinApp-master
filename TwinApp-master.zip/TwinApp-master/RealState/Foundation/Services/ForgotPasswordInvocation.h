//
//  ForgotPasswordInvocation.h
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"
#import "RealEstateAsyncInvocation.h"

@class ForgotPasswordInvocation;
@protocol ForgotPasswordInvocationDelegate 

-(void)ForgotPasswordInvocationDidFinish:(ForgotPasswordInvocation*)invocation 
                             withResults:(NSString*)result
                            withMessages:(NSString*)msg
                               withError:(NSError*)error;

@end

@interface ForgotPasswordInvocation : RealEstateAsyncInvocation {
}

@property (nonatomic,strong)NSString *email;
-(NSString*)body; 

@end