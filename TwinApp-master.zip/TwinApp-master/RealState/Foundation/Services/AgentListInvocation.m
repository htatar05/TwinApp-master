//
//  ForgotPasswordInvocation.m
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//


#import "AgentListInvocation.h"
#import "JSON.h"
#import "Config.h"
#import "Utils.h"

@implementation AgentListInvocation

-(void)invoke {
	NSString *a= @"agent_list";
    [self get:a];
}

-(BOOL)handleHttpOK:(NSMutableData *)data
{	
	NSDictionary* resultsd = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]  JSONValue];
	// response dictionary
	NSError* error = Nil;
	NSArray *rerg = [resultsd objectForKey:@"response"];
    if((NSNull *)rerg!=[NSNull null])
    {
        if([rerg count]>0)
            [self.delegate AgentListInvocationDidFinish:self withResults:rerg withMessages:@"error" withError:error];
        else
            [self.delegate AgentListInvocationDidFinish:self withResults:rerg withMessages:@"error" withError:error];
    }
	return YES;
}

-(BOOL)handleHttpError:(NSInteger)code {
	[self.delegate AgentListInvocationDidFinish:self 
                                withResults:Nil
                                withMessages:Nil
                                  withError:[NSError errorWithDomain:@"UserId" 
                                                                code:[[self response] statusCode]
                                                            userInfo:[NSDictionary dictionaryWithObject:@"Please try again later" forKey:@"message"]]];
	return YES;
}

@end

