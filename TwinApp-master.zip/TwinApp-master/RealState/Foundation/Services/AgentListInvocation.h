//
//  ForgotPasswordInvocation.h
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"
#import "RealEstateAsyncInvocation.h"

@class AgentListInvocation;
@protocol AgentListInvocationDelegate 

-(void)AgentListInvocationDidFinish:(AgentListInvocation*)invocation 
                             withResults:(NSArray*)result
                            withMessages:(NSString*)msg
                               withError:(NSError*)error;

@end
@interface AgentListInvocation : RealEstateAsyncInvocation {
}
@end