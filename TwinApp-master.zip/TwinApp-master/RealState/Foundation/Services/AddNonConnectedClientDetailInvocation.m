//
//  LoginInvocation.m
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//

#import "AddNonConnectedClientDetailInvocation.h"
#import "JSON.h"


@implementation AddNonConnectedClientDetailInvocation
@synthesize strLoggedInUserId,strFirstName,strLastName,strUserName,strEmail,strPassword;

-(void)invoke
{
	NSString *a= @"registerNotConnectedClient";
	[self post:a body:[self body]];
}

-(NSString*)body
{
	NSMutableDictionary* bodyD = [[NSMutableDictionary alloc] init] ;
	[bodyD setObject:self.strLoggedInUserId forKey:@"id"];
    [bodyD setObject:self.strUserName forKey:@"nonclinetuser_name"];
    [bodyD setObject:self.strEmail forKey:@"nonclient_email"];
    [bodyD setObject:self.strFirstName forKey:@"nonclientfirst_name"];
    [bodyD setObject:self.strLastName forKey:@"nonclientlast_name"];
    [bodyD setObject:self.strPassword forKey:@"password"];
    NSLog(@"[bodyD JSONRepresentation]:%@",[bodyD JSONRepresentation]);
	return [bodyD JSONRepresentation];
}

-(BOOL)handleHttpOK:(NSMutableData *)data
{
	NSDictionary* resultsd = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]  JSONValue];
	// response dictionary
	NSError* error = Nil;
	NSMutableDictionary *dictResponse = [resultsd objectForKey:@"response"];
    NSLog(@"arrResponse=%@",dictResponse);
    if((NSNull *)dictResponse!=[NSNull null])
    {
        if([dictResponse count]>0)
        {
            if([[dictResponse objectForKey:@"message"] isEqualToString:@"success"])
                [self.delegate AddNonConnectedClientDetailInvocationDidFinish:self withResults:dictResponse withMessages:[dictResponse objectForKey:@"msg"] withError:error];
            else
                [self.delegate AddNonConnectedClientDetailInvocationDidFinish:self withResults:dictResponse withMessages:[dictResponse objectForKey:@"msg"] withError:error];
        }
        else{
              [self.delegate AddNonConnectedClientDetailInvocationDidFinish:self withResults:dictResponse withMessages:@"error" withError:error];
        }
        return YES;
    }
    else{
        return NO;
    }
}

-(BOOL)handleHttpError:(NSInteger)code
{
	[self.delegate AddNonConnectedClientDetailInvocationDidFinish:self
                                          withResults:Nil
                                         withMessages:Nil
                                         withError:[NSError errorWithDomain:@"UserId" 
                                                                       code:[[self response] statusCode]
                                                                   userInfo:[NSDictionary dictionaryWithObject:@"Failed to Add Non-Connected Client Detail. Please try again later" forKey:@"message"]]];
	return YES;
}

@end

