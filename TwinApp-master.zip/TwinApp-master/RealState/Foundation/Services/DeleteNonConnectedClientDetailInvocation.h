//
//  LoginInvocation.h
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"
#import "RealEstateAsyncInvocation.h"

@class DeleteNonConnectedClientDetailInvocation;
@protocol DeleteNonConnectedClientDetailInvocationDelegate

-(void)DeleteNonConnectedClientDetailInvocationDidFinish:(DeleteNonConnectedClientDetailInvocation*)invocation
                              withResults:(NSMutableDictionary*)result
                             withMessages:(NSString*)result1
							 withError:(NSError*)error;

@end
@interface DeleteNonConnectedClientDetailInvocation : RealEstateAsyncInvocation {
}

@property (nonatomic, strong) NSMutableArray *arrNonConnectedClientsId;

-(NSString*)body; 

@end