//
//  RESrvices.m
//  RealEstate_App
//
//  Created by Octal on 10/08/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import "RESrvices.h"
#import "NSData+Base64.h"

#import "AFURLSessionManager.h"
#import <SystemConfiguration/SCNetworkReachability.h>

//#import "NSData+AESCrypt.h"
#import "NSString+AESCrypt.h"

#import "CFNetwork/CFHTTPMessage.h"
#import <SystemConfiguration/SCNetworkReachability.h>
#import "SBJSON.h"
#import "AFURLSessionManager.h"



#import "AFHTTPSessionManager.h"
#import "Reachability.h"

@implementation RESrvices



+ (BOOL) IsServerReachable
{
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable) {
        NSLog(@"There IS NO internet connection");
        return FALSE;
    } else {
        NSLog(@"There IS internet connection");
        return TRUE;
    }
}


+ (NSDictionary *)parse_data:(NSString *)datastring {
    
    SBJsonParser* parser = [[SBJsonParser alloc] init];
    NSArray *arrResult=[[NSArray alloc]init];
    id result = [parser objectWithString:datastring];
    if([result isKindOfClass:[NSArray class]]) {
        arrResult = [parser objectWithString: datastring ];
    } else if( [result isKindOfClass:[NSDictionary class]]) {
        arrResult = [NSArray arrayWithObject : [parser objectWithString:datastring ] ];
    } else if([result isKindOfClass:[NSString class]]){
        arrResult = [NSArray arrayWithObject:datastring];
    }
    
    NSDictionary *dict = [[NSDictionary alloc] init];
    
    if([arrResult count]>0)
    {
        dict = [[arrResult objectAtIndex:0] objectForKey:@"response"];
    }
    
    return dict;
}


+ (void)Login:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    //[self IsServerReachable]
    if(dict)
    {
        
        if ([[NSUserDefaults standardUserDefaults] valueForKey:@"devicetoken"]==NULL)
        {
            [[NSUserDefaults standardUserDefaults]setValue:@"0000" forKey:@"devicetoken"];
        }
        
        NSString *strDeviceToken = [[NSUserDefaults standardUserDefaults] valueForKey:@"devicetoken"];
        [dict setObject:strDeviceToken forKey:@"device_id"];
        [dict setObject:@"iPhone" forKey:@"device_name"];
        
        
        NSError *error;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                                           options:0
                                                             error:&error];
        NSString *jsonString;
        
        if (! jsonData) {
            NSLog(@"Got an error: %@", error);
        } else {
            jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        }
        
        NSString *encryptedString = [jsonString AES256EncryptWithKey:@"a16byteslongkey!"];
        NSLog(@"encrypted string %@",encryptedString);
        NSData* sendData = [encryptedString dataUsingEncoding:NSUTF8StringEncoding];
        
        NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
        configuration.timeoutIntervalForRequest = 60.0;
        configuration.timeoutIntervalForResource = 60.0;
        
        AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
        manager.securityPolicy.allowInvalidCertificates = YES;
        manager.securityPolicy.validatesDomainName = NO;
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        
        
        
        NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@login_bari",jsonString]];
        NSMutableURLRequest* request = [[NSMutableURLRequest alloc] initWithURL:URL cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:240.0];
        
        [request setHTTPBody:sendData];
        request.HTTPMethod = @"POST";
        
        NSURLSessionDataTask *dataTask =
        [manager dataTaskWithRequest:request completionHandler:^(NSURLResponse *response, NSData *responseObject, NSError *error) {
            if (error) {
                NSLog(@"Error: %@", error);
                block(nil,error);
            } else {
                NSLog(@"Success: %@ %@", response, responseObject);
                
                NSString *string = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
                NSString *decryptedString  = [string AES256DecryptWithKey:@"a16byteslongkey!"];
                NSDictionary *jsonData = [self parse_data:decryptedString];
                block(jsonData,nil);
                NSLog(@"Success: %@ ", jsonData);
                
            } }];
        [dataTask resume];
    }
    else
    {
        block(nil,nil);
        //        TTAlertView *alert = [[TTAlertView alloc] initWithTitle:@"Network problem" message:@"Network unreachable." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        //        [alert show];
    }
}


@end
