

#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"

@interface RealEstateAsyncInvocation : SAServiceAsyncInvocation {
	
}

@end