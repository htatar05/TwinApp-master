//
//  ForgotPasswordInvocation.m
//  StormPins
//
//  Created by ashish sharma on 01/11/12.
//  Copyright (c) 2012 Octal. All rights reserved.
//


#import "ForgotPasswordInvocation.h"
#import "JSON.h"
#import "Config.h"
#import "Utils.h"

@implementation ForgotPasswordInvocation
@synthesize email;

-(void)invoke {
	NSString *a= @"forgetpassword";
	[self post:a body:[self body]];
}

-(NSString*)body {
	NSMutableDictionary* bodyD = [[NSMutableDictionary alloc] init] ;
	[bodyD setObject:self.email forKey:@"email"];	
	return [bodyD JSONRepresentation];
}

-(BOOL)handleHttpOK:(NSMutableData *)data {
	
	NSDictionary* resultsd = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]  JSONValue];
	NSError* error = Nil;
	NSDictionary *rerg = [resultsd objectForKey:@"response"];
    if((NSNull *)rerg!=[NSNull null])
    {
        [self.delegate ForgotPasswordInvocationDidFinish:self withResults:[rerg objectForKey:@"success"] withMessages:[rerg objectForKey:@"error"] withError:error];
        return YES;
    }
    else
        return NO;
}

-(BOOL)handleHttpError:(NSInteger)code {
	[self.delegate ForgotPasswordInvocationDidFinish:self 
                                withResults:Nil
                                withMessages:Nil
                                  withError:[NSError errorWithDomain:@"UserId" 
                                                                code:[[self response] statusCode]
                                                            userInfo:[NSDictionary dictionaryWithObject:@"Please try again later" forKey:@"message"]]];
	return YES;
}

@end

