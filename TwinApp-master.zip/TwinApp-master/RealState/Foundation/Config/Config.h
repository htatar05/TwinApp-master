//  Config.h
//  StormPins
//  Created by ashish sharma on 29/10/12.
//  Copyright (c) 2012 Octal. All rights reserved.

#import <Foundation/Foundation.h>

@interface Config : NSObject
{
    
}
extern BOOL isSocialMediaLogin;
extern NSString *checkLoginProfile;
extern NSString *GpsCity;
extern NSString *currentLat;
extern NSString *currentLong;
extern NSString *checkNavigatesFrom;
extern BOOL isGPSOn;
extern NSString *GpsCurrentCity;
extern NSString *checkRegisterProfile;
extern int directionRowSelect;
extern NSString *dirStr;


+(UIImage*)imageWithImage:(UIImage*)image
			 scaledToSize:(CGSize)newSize;
extern BOOL imageFlag;extern NSString *weatherKey;
extern NSString *useremailG;
extern BOOL loginSuccess;
extern bool loginflag;
extern NSString *WebserviceUrl;
extern NSString *WebserviceImageUrl;
extern NSString *WebserviceSaveSearch;
extern NSString *profileImage;
extern NSString	*DatabaseName;




//Tanuj
extern float lat;
extern float longi;
extern UIImage *flagImage;
extern BOOL pinDrop;

//tanuj
extern BOOL alertClick;
extern NSString *SelectedTab;
//tanuj
extern int check;
@end
