//  Config.m
//  StormPins
//  Created by ashish sharma on 29/10/12.
//  Copyright (c) 2012 Octal. All rights reserved.


#import "Config.h"

#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)


@implementation Config


BOOL isSocialMediaLogin=NO;
NSString *checkLoginProfile = @"";
NSString *GpsCity=@"";
NSString *currentLat=@"";
NSString *currentLong=@"";
NSString *checkNavigatesFrom=@"";
BOOL isGPSOn;
NSString *GpsCurrentCity=@"";
NSString *checkRegisterProfile=@"";
int directionRowSelect;
NSString *dirStr=@"";
BOOL imageFlag=FALSE;
NSString *weatherKey = @"1bc302eb5fd57065";
NSString *useremailG = @"";
BOOL loginSuccess=FALSE;
bool loginflag=FALSE;
BOOL pinDrop=FALSE;
float lat;
float longi;
int directionRowSelect;
UIImage *flagImage;
BOOL alertClick;
NSString *SelectedTab=@"";
int check;

+(UIImage*)imageWithImage:(UIImage*)image
			 scaledToSize:(CGSize)newSize
{
	UIGraphicsBeginImageContext( newSize );
	[image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
	UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	return newImage;
}

//NSString *WebserviceUrl=@"http://www.twinrealty.com/realestateapp/WebServices/";
NSString *WebserviceUrl= @"https://www.twinrealty.com/realestateapp/WebServices/";
NSString *WebserviceImageUrl = @"https://www.twinrealty.com/realestateapp/uploads/profile/small_thumb/";
NSString *WebserviceSaveSearch = @"https://www.twinrealty.com/realestateapp/uploads/saveSearch/";
NSString *DatabaseName		 = @"DataBase.sqlite";
NSString *profileImage      = @"https://www.twinrealty.com/realestateapp/uploads/profile/small_thumb/";





@end
