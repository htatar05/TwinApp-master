//  FavouriteProperties.m
//  RealEstate_App
//  Created by Octal on 27/09/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import "FavouriteProperties.h"
#import "AppDelegate.h"
#import "PropertyTvCellView.h"
#import "PropertyDetail.h"
#import "UIImageView+UIActivityIndicatorForSDWebImage.h"
#import "UIImageView+HighlightedWebCache.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "PropertyDetailViewController.h"
#import "Utils.h"
#import "SortViewController.h"
#import "MainViewController.h"

@interface FavouriteProperties ()

@end

@implementation FavouriteProperties

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.revealSidebarDelegate=self;
    appdelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    [btnNavigation addTarget:self action:@selector(revealLeftSidebar:) forControlEvents:UIControlEventTouchUpInside];
    _isEdit = NO;
    deleteIdArr = [[NSMutableArray alloc]init];
    
    tblFavourite.delegate = self;
    tblFavourite.allowsMultipleSelectionDuringEditing = YES;
    
    btnDelete.hidden = YES;
    btnShare.hidden = YES;
    btnMap.hidden  = NO;
    btnSortOrder.hidden  = NO;
  
    indexes = [NSMutableIndexSet new];
    refreshControl = [[UIRefreshControl alloc]init];
    refreshControl.backgroundColor = [UIColor whiteColor];
    [tblFavourite addSubview:refreshControl];
    refreshControl.tintColor = [UIColor lightGrayColor];
    [refreshControl addTarget:self action:@selector(callGetFavouriteProperties) forControlEvents:UIControlEventValueChanged];
    
}


-(void)viewWillAppear:(BOOL)animated
{
   [self callGetFavouriteProperties];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)callGetFavouriteProperties
{
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"user_id"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"SortOrder"] forKey:@"sortt"];
    [MBProgressHUD showHUDAddedTo:appdelegate.window animated:YES];
    [REWebService CallGetFavouriteProperties:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self->appdelegate.window animated:YES];
        
        if (!error) {
            [self->refreshControl endRefreshing];
            self->count = 0;
            self->favouritePopertyData = [[NSMutableArray alloc]init];
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"] isEqualToString:@"success"])
            {
                self->tblFavourite.hidden = NO;
                [self->btnDelete setTitle:@"Delete" forState:UIControlStateNormal];
                [self->btnShare setTitle:@"Share"forState:UIControlStateNormal];
                
                int newCount = [[[dictResult valueForKey:@"response"] valueForKey:@"menu_favourite_property_count"] intValue];
                NSString *str = [NSString stringWithFormat:@"%d",newCount];
                [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"FavouriteCount"];
                NSArray *dataArr = [[dictResult valueForKey:@"response"] valueForKey:@"data"];
                for (NSInteger i = 0; i<dataArr.count; i++) {
                    
                    NSDictionary *temp = [dataArr objectAtIndex:i];
                    [self->favouritePopertyData addObject:temp];
                }
                for(UILabel *lbl in [self.view subviews])
                {
                    if(lbl.tag == 50)
                    {
                        [lbl removeFromSuperview];
                    }
                    
                }
                [self->tblFavourite reloadData];
                [[NSNotificationCenter defaultCenter] postNotificationName:@"ReloadSideMenu" object:nil];
                
            }
            else
            {
                for(UILabel *lbl in [self.view subviews])
                {
                    if(lbl.tag == 50)
                    {
                        [lbl removeFromSuperview];
                    }
                    
                }
                [self noRecordFoundLabel];
                [self->tblFavourite reloadData];
                self->tblFavourite.hidden = YES;
            }
            
        }
        
    }];
}


#pragma mark JTRevealSidebarDelegate
- (void)revealLeftSidebar:(id)sender
{
    [self.navigationController toggleRevealState:JTRevealedStateLeft];
}

- (UIView *)viewForLeftSidebar{
   
    CGRect viewFrame = self.navigationController.applicationViewFrame;
    UITableViewController *controller = self.leftSidebarViewController;
    if (!controller)
    {
        self.leftSidebarViewController = [[SidebarViewController alloc] init];
        self.leftSidebarViewController.sidebarDelegate = [AppDelegate sharedDelegate];
        controller = self.leftSidebarViewController;
    }
    controller.view.frame = CGRectMake(0, viewFrame.origin.y, 270, viewFrame.size.height);
    controller.view.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
    return controller.view;
}


- (void)didChangeRevealedStateForViewController:(UIViewController *)viewController {
   
    if (viewController.revealedState == JTRevealedStateNo)
        tblFavourite.userInteractionEnabled=YES;
    else
        tblFavourite.userInteractionEnabled=NO;
}


#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [favouritePopertyData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    PropertyTvCellView *cell = (PropertyTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
            view = [[UIViewController alloc]initWithNibName:@"PropertyTvCellView_iPhone" bundle:nil];
        } else {
           view = [[UIViewController alloc]initWithNibName:@"PropertyTvCellView_iPad" bundle:nil];
        }
        cell = (PropertyTvCellView *)view.view;
    }
    if (favouritePopertyData.count){
        
        theProperty = [favouritePopertyData objectAtIndex:indexPath.row];
        
        if ([[theProperty valueForKey:@"status"] isEqualToString:@"for_sale"])
        {
            cell.lblHomeType.text = @"For Sale";
            cell.lblHomeType.textColor = [UIColor colorWithRed:(38/255.f) green:(133/255.f) blue:(9/255.f) alpha:1.0f];
            cell.imgViewPropertyType.image = [UIImage imageNamed:@"for_sale"];
            NSInteger *intPrice = [[theProperty valueForKey:@"price_for_sale"] integerValue];
            NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
            NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                               numberStyle:NSNumberFormatterCurrencyStyle];
            
            NSString *newString;
            if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
            {
                newString = [price substringFromIndex:3];
                newString =  [newString substringToIndex:[newString length]-3];
                
            }
            cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
            
        }
        else if ([[theProperty valueForKey:@"status"] isEqualToString:@"for_rent"])
        {
            cell.lblHomeType.text = @"For Rent";
            cell.lblHomeType.textColor = [UIColor orangeColor];
            cell.imgViewPropertyType.image = [UIImage imageNamed:@"for_rent"];
            
            NSInteger *intPrice = [[theProperty valueForKey:@"pricerented"] integerValue];
            NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
            NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                               numberStyle:NSNumberFormatterCurrencyStyle];
            
            NSString *newString;
            if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
            {
                newString = [price substringFromIndex:3];
                newString =  [newString substringToIndex:[newString length]-3];
                
            }
            cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
            
        }
        else if ( [[theProperty valueForKey:@"status"] isEqualToString:@"Inactive"])
        {
           cell.imgViewPropertyType.image = [UIImage imageNamed:@"for_sale"];
           cell.lblHomeType.textColor = [UIColor colorWithRed:(38/255.f) green:(133/255.f) blue:(9/255.f) alpha:1.0f];
           cell.btnRemoveMarket.hidden = NO;
           cell.contentView.alpha = 0.7;
           cell.btnRemoveMarket.userInteractionEnabled = false;
           [[cell.btnRemoveMarket layer] setBorderWidth:1.0f];
           [[cell.btnRemoveMarket layer] setBorderColor:[UIColor redColor].CGColor];
           
        }
        else
        {
            cell.lblHomeType.text = @"Sold";
            cell.imgViewPropertyType.image = [UIImage imageNamed:@""];
            NSInteger *intPrice = [[theProperty valueForKey:@"price_sold"] integerValue];
            NSNumber *tempPrice = [NSNumber numberWithInteger:intPrice];
            NSString *price = [NSNumberFormatter localizedStringFromNumber:tempPrice
                                                               numberStyle:NSNumberFormatterCurrencyStyle];
            
            NSString *newString;
            if ([price hasPrefix:@"CUP"] && [price hasSuffix:@".00"])
            {
                newString = [price substringFromIndex:3];
                newString =  [newString substringToIndex:[newString length]-3];
                
            }
            cell.lblPrice.text = [NSString stringWithFormat:@"$%@",newString];
            
        }
        
        cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
        cell.imgBackground.layer.borderWidth=0.75;
        cell.lblSaleType.text = [NSString stringWithFormat:@"%@",[theProperty valueForKey:@"id"]];
        cell.lblBedBath.text = [NSString stringWithFormat:@"%@bd-%@ba %@ sq ft",[theProperty valueForKey:@"numbedrooms"],[theProperty valueForKey:@"totalfullbaths"],[theProperty valueForKey:@"sqft"]];
        cell.lblPhotoCount.text = [NSString stringWithFormat:@"%@ Photos",[theProperty valueForKey:@"num_images"]];
        cell.lblAddress.text = [NSString stringWithFormat:@"%@",[theProperty valueForKey:@"fulladdress"]];
        cell.lblAddress1.text = [NSString stringWithFormat:@"%@",[theProperty valueForKey:@"fulladdress1"]];
        cell.lblListingCourtesy.text = [NSString stringWithFormat:@"%@",[theProperty valueForKey:@"listing_courtesy"]];
        
        if ([[theProperty valueForKey:@"OpenHouseUpcoming"] isEqualToString:@""]) {
            cell.lblOpenHouse.text = [NSString stringWithFormat:@"Open House Not Available"];
        } else{
            cell.lblOpenHouse.text = [NSString stringWithFormat:@"%@",[theProperty valueForKey:@"OpenHouseUpcoming"]];
        }
        
        [cell.imgViewProperty setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",[theProperty valueForKey:@"first_image_path"]]] placeholderImage:[UIImage imageNamed:@"image_preview.jpeg"] options:SDWebImageRefreshCached usingActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        
        cell.selectionStyle = UITableViewCellSelectionStyleDefault;
        
    }
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (IS_IPHONE) {
        return 150;
    } else {
        return 170;
    }
    
}

/*
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_isEdit==NO)
    {
        PropertyDetailViewController*detail = [[PropertyDetailViewController alloc]initWithNibName:@"PropertyDetailViewController_iPhone" bundle:nil];
        NSDictionary *dict = [favouritePopertyData objectAtIndex:indexPath.row];
        detail.PropertyId = [dict valueForKey:@"id"];
        detail.totalPropertyArr = favouritePopertyData;
        detail.selectedIndex = indexPath.row;
        [self.navigationController pushViewController:detail animated:YES];
    }
    else
    {
        PropertyTvCellView *cell = [tblFavourite cellForRowAtIndexPath:indexPath];
        cell.btnRemoveMarket.hidden = NO;
        [cell.btnRemoveMarket addTarget:self action:@selector(removeFromMarket:) forControlEvents:UIControlEventTouchUpInside];
        cell.btnRemoveMarket.tag = indexPath.row;
        [[cell.btnRemoveMarket layer] setBorderWidth:1.0f];
        [[cell.btnRemoveMarket layer] setBorderColor:[UIColor redColor].CGColor];
        [[cell.btnRemoveMarket layer] setCornerRadius:2.0f];
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
    }
    
}
 */

/*
- (void)tableView:(UITableView *)tableView
didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    PropertyTvCellView *cell = [tblFavourite cellForRowAtIndexPath:indexPath];
    cell.btnRemoveMarket.hidden = YES;
}
*/



- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tblFavourite.isEditing)
    {
        count--;
    }
    
    theProperty = [favouritePopertyData objectAtIndex:indexPath.row];
    [deleteIdArr removeObject:[theProperty valueForKey:@"id"]];
    [indexes removeIndex:indexPath.row];
    [self updateSelectionCount];
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    theProperty = [favouritePopertyData objectAtIndex:indexPath.row];
    if (tblFavourite.isEditing){
        count++;
        [deleteIdArr addObject:[theProperty valueForKey:@"id"]];
        [indexes addIndex:indexPath.row];
        
        [self updateSelectionCount];
    }
    else
    {
        PropertyDetailViewController*detail;
        if (IS_IPHONE) {
            detail = [[PropertyDetailViewController alloc]initWithNibName:@"PropertyDetailViewController_iPhone" bundle:nil];
        } else {
            detail = [[PropertyDetailViewController alloc]initWithNibName:@"PropertyDetailViewController_iPad" bundle:nil];
        }
        NSDictionary *dict = [favouritePopertyData objectAtIndex:indexPath.row];
        detail.PropertyId = [dict valueForKey:@"id"];
        detail.totalPropertyArr = favouritePopertyData;
        detail.selectedIndex = indexPath.row;
        [self.navigationController pushViewController:detail animated:YES];
        [tblFavourite deselectRowAtIndexPath:indexPath animated:YES];
     
    }
}

#pragma mark Actions


-(IBAction)btnEditClicked
{
    
    if (favouritePopertyData.count) {
        if([btnEdit.titleLabel.text isEqualToString:@"Edit"])
        {
            count = 0;
            [tblFavourite setEditing:YES animated:YES];
            [btnEdit setTitle:@"Cancel" forState:UIControlStateNormal];
            btnSortOrder.hidden = YES;
            btnMap.hidden = YES;
            
            btnDelete.hidden = NO;
            btnShare.hidden = NO;
            btnDelete.alpha=0.5;
            btnShare.alpha=0.5;
            btnDelete.userInteractionEnabled=FALSE;
            btnShare.userInteractionEnabled=FALSE;
            
        }
        else
        {
            [btnEdit setTitle:@"Edit" forState:UIControlStateNormal];
            [tblFavourite setEditing:NO animated:YES];
            [btnDelete setTitle:@"Delete" forState:UIControlStateNormal];
            [btnShare setTitle:@"Share"forState:UIControlStateNormal];
            btnDelete.alpha=0.5;
            btnShare.alpha=0.5;
            btnDelete.userInteractionEnabled=FALSE;
            btnShare.userInteractionEnabled=FALSE;
            btnMap.hidden = NO;
            btnSortOrder.hidden = NO;
            btnDelete.hidden = YES;
            btnShare.hidden = YES;
        }
    }
    
}


-(void)updateSelectionCount
{
    if(count==0)
    {
        [btnDelete setTitle:@"Delete" forState:UIControlStateNormal];
        [btnShare setTitle:@"Share"forState:UIControlStateNormal];
         btnDelete.alpha=0.5;
         btnShare.alpha=0.5;
         btnDelete.userInteractionEnabled=FALSE;
         btnShare.userInteractionEnabled=FALSE;
    }
    if(count>0)
    {
        btnShare.alpha=1.0;
        btnDelete.alpha=1.0;
        btnDelete.userInteractionEnabled=TRUE;
        btnShare.userInteractionEnabled=TRUE;
        [btnDelete setTitle:[NSString stringWithFormat:@"Delete (%d)", count] forState:UIControlStateNormal];
        [btnShare setTitle:[NSString stringWithFormat:@"Share (%d)", count] forState:UIControlStateNormal];
      
    }
}

-(IBAction)removeFromMarket:(id)sender
{
    NSLog(@"remove from market");
    
}

-(IBAction)deleteButtonClicked:(id)sender
{
    NSMutableDictionary *dataDict  = [[NSMutableDictionary alloc]init];
    [dataDict setValue:deleteIdArr forKey:@"ids"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"user_id"];
    [MBProgressHUD showHUDAddedTo:appdelegate.window animated:YES];
    [REWebService deleteFavouriteProperties:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self->appdelegate.window animated:YES];
        
        if (!error) {
            
            if ([[[dictResult valueForKey:@"response"]valueForKey:@"message"]isEqualToString:@"success"])
            {
                [self->favouritePopertyData removeObjectsAtIndexes:self->indexes];
                if (self->favouritePopertyData.count)
                {
                    self->btnDelete.hidden = NO;
                    self->btnShare.hidden = NO;
                    self->btnMap.hidden = YES;
                    self->btnSortOrder.hidden = YES;
                }
                else
                {
                    self->btnDelete.hidden = YES;
                    self->btnShare.hidden = YES;
                    self->btnMap.hidden = NO;
                    self->btnSortOrder.hidden = NO;
                    
                }
                [self->tblFavourite reloadData];
            }
            
        } else {
            
        }
        
    }];
    
    
}
-(IBAction)shareButtonClicked:(id)sender
{
    NSLog(@"multiple Share");
}

-(void)noRecordFoundLabel
{
    lblNoRecord = [[UILabel alloc]init];
    [lblNoRecord setFrame:CGRectMake(tblFavourite.frame.size.width / 2-100, tblFavourite.frame.size.height / 2-10, 200, 20)];
    lblNoRecord.text = @"No Favorite Homes";
    lblNoRecord.numberOfLines = 1;
    lblNoRecord.tag = 50;
    lblNoRecord.font = [UIFont systemFontOfSize:20];
    lblNoRecord.baselineAdjustment = UIBaselineAdjustmentAlignBaselines;
    lblNoRecord.adjustsFontSizeToFitWidth = YES;
    lblNoRecord.minimumScaleFactor = 10.0f/12.0f;
    lblNoRecord.clipsToBounds = YES;
    lblNoRecord.backgroundColor = [UIColor clearColor];
    lblNoRecord.textColor = [UIColor lightGrayColor];
    lblNoRecord.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:lblNoRecord];
    //lblNoRecord2
    
    lblNoRecord2 = [[UILabel alloc]init];
    [lblNoRecord2 setFrame:CGRectMake(tblFavourite.frame.size.width / 2-100, tblFavourite.frame.size.height / 2+20, 200, 40)];
    lblNoRecord2.text = @"Save properties from map or list";
    lblNoRecord2.numberOfLines = 2;
    lblNoRecord2.tag = 50;
    lblNoRecord2.font = [UIFont systemFontOfSize:12];
    lblNoRecord2.baselineAdjustment = UIBaselineAdjustmentAlignBaselines;
    lblNoRecord2.adjustsFontSizeToFitWidth = YES;
    lblNoRecord2.minimumScaleFactor = 10.0f/12.0f;
    lblNoRecord2.clipsToBounds = YES;
    lblNoRecord2.backgroundColor = [UIColor clearColor];
    lblNoRecord2.textColor = [UIColor lightGrayColor];
    lblNoRecord2.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:lblNoRecord2];
    
}

-(IBAction)sortOrderClicked:(id)sender
{
    
    if (IS_IPHONE) {
        
        SortViewController*sort = [[SortViewController alloc]initWithNibName:@"SortViewController_iPhone" bundle:nil];
        sort.selectedOrder = [[NSUserDefaults standardUserDefaults]valueForKey:@"FavoriteSortOrder"];
        [self.navigationController presentViewController:sort animated:YES completion:nil];
    } else {
        SortViewController*sort = [[SortViewController alloc]initWithNibName:@"SortViewController_iPad" bundle:nil];
        sort.selectedOrder = [[NSUserDefaults standardUserDefaults]valueForKey:@"FavoriteSortOrder"];
        [self.navigationController presentViewController:sort animated:YES completion:nil];
    }
    
}

-(IBAction)mapButtonClicked:(id)sender
{
    if (IS_IPHONE) {
        
        MainViewController*map = [[MainViewController alloc]initWithNibName:@"MainViewController_iPhone" bundle:nil];
        map.isFromFavourite = @"Yes" ;
        [self.navigationController pushViewController:map animated:YES];
        
    } else {
        
        MainViewController*map = [[MainViewController alloc]initWithNibName:@"MainViewController_iPad" bundle:nil];
        map.isFromFavourite = @"Yes" ;
        [self.navigationController pushViewController:map animated:YES];
    }
    
}
@end
