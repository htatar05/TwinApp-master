//
//  PrivacyPolicyVC.h
//  RealEstate_App
//
//  Created by Octal on 12/08/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"


@interface PrivacyPolicyVC : UIViewController<UIWebViewDelegate>
{
    IBOutlet UIWebView *webView;
    IBOutlet UILabel *lblTitle;
    AppDelegate * _delegate;
}

@property(nonatomic,strong)NSString *isPrivacyPolicy;
@end
