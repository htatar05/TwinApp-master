//
//  PrivacyPolicyVC.m
//  RealEstate_App
//
//  Created by Octal on 12/08/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import "PrivacyPolicyVC.h"
#import "MBProgressHUD.h"
#import "AppDelegate.h"
@interface PrivacyPolicyVC ()

@end

@implementation PrivacyPolicyVC

- (void)viewDidLoad {
    [super viewDidLoad];
     _delegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
     webView.delegate = self;
    if ([self.isPrivacyPolicy isEqualToString:@"YES"]) {
        lblTitle.text = @"Privacy Policy";
        [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
        [self getprivacyPolicyData];
    }
    else
    {
      lblTitle.text = @"Terms of Use";
      [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
      [self getTermsAndConditionData];
    }
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
-(void)getprivacyPolicyData
{
    NSString *urlString = [NSString stringWithFormat:@"https://www.twinrealty.com/realestateapp/admin/contents/show_privacy"];
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:urlString]]];
    
}
-(void)getTermsAndConditionData
{
    NSString *urlString = [NSString stringWithFormat:@"https://www.twinrealty.com/realestateapp/admin/contents/show_terms"];
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:urlString]]];
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
   [MBProgressHUD hideAllHUDsForView:_delegate.window animated:YES];
}
-(IBAction)backButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
