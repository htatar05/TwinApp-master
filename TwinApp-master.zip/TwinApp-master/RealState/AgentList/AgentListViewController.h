//
//  AgentListViewController.h
//  RealState
//
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "JTRevealSidebarV2Delegate.h"
#import "UIViewController+JTRevealSidebarV2.h"
#import "UINavigationItem+JTRevealSidebarV2.h"
#import "AppDelegate.h"
#import "AgentDetailView.h"
#import "AgentTvCellView.h"

#import "RealEstateService.h"
#import "AgentListDetailInvocation.h"

@interface AgentListViewController : UIViewController<UITableViewDelegate, UITableViewDataSource,JTRevealSidebarV2Delegate>
{
    IBOutlet UITableView *tblAgentList;
    IBOutlet UIView *viewAgentList;
    IBOutlet UIButton *btnNavigation;
    AgentDetailView *agentDetailView;
    RealEstateService *service;
    IBOutlet UILabel *lblTitle;
    AppDelegate *appDelegate;
    NSMutableArray *arrAgentData;
    AgentDetail *agentDetail;
}

@property(nonatomic, strong) SidebarViewController *leftSidebarViewController;
@property (nonatomic,strong) NSString*isMyAgent;
@end
