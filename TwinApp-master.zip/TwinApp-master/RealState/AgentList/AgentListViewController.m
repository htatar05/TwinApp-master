//
//  AgentListViewController.m
//  RealState
//
//  Created by Kapil Goyal on 24/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "AgentListViewController.h"
#import "AgentDetailViewController.h"
#import "MBProgressHUD.h"
#import "Utils.h"
#import "AgentDetail.h"
#import "Config.h"
#import "REWebService.h"

@interface AgentListViewController (Private)<AgentListDetailInvocationDelegate>
@end

@implementation AgentListViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    self.navigationItem.revealSidebarDelegate=self;
    [btnNavigation addTarget:self action:@selector(revealLeftSidebar:) forControlEvents:UIControlEventTouchUpInside];
    
    service = [[RealEstateService alloc] init];
    arrAgentData = [[NSMutableArray alloc] init];
    appDelegate = (AppDelegate*)[UIApplication sharedApplication].delegate;

    
    if(IsRunningTallPhone())
    {
        [viewAgentList setFrame:CGRectMake(0, 0, 320, 578)];
        //[tblAgentList setFrame:CGRectMake(0, 44, 320, 518)];
    }
    else
    {
        [viewAgentList setFrame:CGRectMake(0, 0, 320, 490)];
        //[tblAgentList setFrame:CGRectMake(0, 44, 320, 428)];
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [AppDelegate sharedDelegate].globalReference = nil;
    [AppDelegate sharedDelegate].globalReference = self.navigationController;
    if(isInternetAvailable())
    {   arrAgentData = [[NSMutableArray alloc] init];
        if ([self.isMyAgent isEqualToString:@"Yes"]) {
            lblTitle.text = @"My Agents";
             [self getMyAgent];
            
        } else
        {
            lblTitle.text = @"Assigned Agent";
            [self getAssignedAgent];
        }
       
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Internet connection is not available"];
    }
}


#pragma mark JTRevealSidebarDelegate
- (void)revealLeftSidebar:(id)sender
{
    [self.navigationController toggleRevealState:JTRevealedStateLeft];
}

- (UIView *)viewForLeftSidebar{
    // Use applicationViewFrame to get the correctly calculated view's frame
    // for use as a reference to our sidebar's view
    CGRect viewFrame = self.navigationController.applicationViewFrame;
    UITableViewController *controller = self.leftSidebarViewController;
    if (!controller)
    {
        self.leftSidebarViewController = [[SidebarViewController alloc] init];
        self.leftSidebarViewController.sidebarDelegate = [AppDelegate sharedDelegate];
        controller = self.leftSidebarViewController;
    }
    controller.view.frame = CGRectMake(0, viewFrame.origin.y, 270, viewFrame.size.height);
    controller.view.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight;
    return controller.view;
}

//Optional delegate methods for additional configuration after reveal state changed
- (void)didChangeRevealedStateForViewController:(UIViewController *)viewController {
    // Example to disable userInteraction on content view while sidebar is revealing
    if (viewController.revealedState == JTRevealedStateNo)
        tblAgentList.userInteractionEnabled=YES;
    else
        tblAgentList.userInteractionEnabled=NO;
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrAgentData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    AgentTvCellView *cell = (AgentTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
            view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPhone" bundle:nil];
        } else {
           view = [[UIViewController alloc]initWithNibName:@"AgentTvCellView_iPad" bundle:nil];
        }
        
        cell = (AgentTvCellView *)view.view;
    }
    
    cell.imgBackground.layer.borderColor = [UIColor colorWithRed:217/255.0 green:217/255.0 blue:217/255.0 alpha:1].CGColor;
    if (IS_IPHONE) {
         cell.imgBackground.layer.borderWidth=0.5;
    } else {
         cell.imgBackground.layer.borderWidth=1.5;
    }
    cell.imgUserPhoto.backgroundColor = [UIColor clearColor];
    cell.imgUserPhoto.layer.borderColor = [UIColor grayColor].CGColor;
    cell.imgUserPhoto.placeholderImage = [UIImage imageNamed:@"upload_pic"];
    agentDetail = [arrAgentData objectAtIndex:indexPath.row];
    NSString *url = [NSString stringWithFormat:@"%@%@",WebserviceImageUrl,agentDetail.strImage];
    cell.imgUserPhoto.imageURL  = [NSURL URLWithString:url];
    cell.lblUserName.text = agentDetail.strName;
    cell.lblUserEmailId.text = agentDetail.strEmail;
    cell.lblUserPhone.text = agentDetail.strPhoneNo;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tblAgentList deselectRowAtIndexPath:indexPath animated:YES];
    AgentDetailViewController *agent;
    if (IS_IPHONE) {
        
        agent = [[AgentDetailViewController alloc] initWithNibName:@"AgentDetailViewController_iPhone" bundle:nil];
    } else {
        
       agent = [[AgentDetailViewController alloc] initWithNibName:@"AgentDetailViewController_iPad" bundle:nil];
    }
    
    agent.intType=2;
    agent.agentDetail = [arrAgentData objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:agent animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{

    if (IS_IPHONE) {
        return 100.0;
    } else {
        return 130.0;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)getMyAgent
{
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
     NSMutableDictionary *dataDict  = [[NSMutableDictionary alloc]init];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults]valueForKey:@"RoleId"] forKey:@"role_id"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"user_id"];
    [REWebService myAgentList:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
        
        if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"])
        {
            NSArray *result = [[dictResult valueForKey:@"response"] valueForKey:@"data"];
            
            for (int i=0; i<[result count]; i++)
            {
                agentDetail = [[AgentDetail alloc] init];
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"user_id"]!=[NSNull null])
                    agentDetail.strId = [[result objectAtIndex:i] objectForKey:@"user_id"];
                
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"name"]!=[NSNull null])
                    agentDetail.strName = [[result objectAtIndex:i] objectForKey:@"name"];
                
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"email"]!=[NSNull null])
                    agentDetail.strEmail = [[result objectAtIndex:i] objectForKey:@"email"];
                
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"phone"]!=[NSNull null])
                    agentDetail.strPhoneNo = [[result objectAtIndex:i] objectForKey:@"phone"];
                
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"address"]!=[NSNull null])
                    agentDetail.strAddress = [[result objectAtIndex:i] objectForKey:@"address"];
                
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"image"]!=[NSNull null])
                    agentDetail.strImage = [[result objectAtIndex:i] objectForKey:@"image"];
                [arrAgentData addObject:agentDetail];
            }
            [tblAgentList reloadData];
            
        }else
        {
          [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
        }
        
    }];

}

-(void)getAssignedAgent
{
    [MBProgressHUD showHUDAddedTo:appDelegate.window animated:YES];
    NSMutableDictionary *dataDict  = [[NSMutableDictionary alloc]init];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"client_id"];
    [REWebService AssignedAgentList:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:appDelegate.window animated:YES];
        
        if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"])
        {
            NSArray *result = [[dictResult valueForKey:@"response"] valueForKey:@"data"];
            
            for (int i=0; i<[result count]; i++)
            {
                agentDetail = [[AgentDetail alloc] init];
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"user_id"]!=[NSNull null])
                    agentDetail.strId = [[result objectAtIndex:i] objectForKey:@"user_id"];
                
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"name"]!=[NSNull null])
                    agentDetail.strName = [[result objectAtIndex:i] objectForKey:@"name"];
                
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"email"]!=[NSNull null])
                    agentDetail.strEmail = [[result objectAtIndex:i] objectForKey:@"email"];
                
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"phone"]!=[NSNull null])
                    agentDetail.strPhoneNo = [[result objectAtIndex:i] objectForKey:@"phone"];
                
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"address"]!=[NSNull null])
                    agentDetail.strAddress = [[result objectAtIndex:i] objectForKey:@"address"];
                
                if((NSNull*)[[result objectAtIndex:i] objectForKey:@"image"]!=[NSNull null])
                    agentDetail.strImage = [[result objectAtIndex:i] objectForKey:@"image"];
                [arrAgentData addObject:agentDetail];
            }
            [tblAgentList reloadData];
            
            
        } else
        {
            [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
        }
        
    }];

}
@end
