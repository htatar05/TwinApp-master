//
//  DisclaimerViewController.m
//  RealState
//
//  Created by Kapil Goyal on 14/11/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "DisclaimerViewController.h"
#import "NSAttributedString+Attributes.h"

@interface DisclaimerViewController ()
@end

@implementation DisclaimerViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    if(IsRunningTallPhone())
        [scrlView setFrame:CGRectMake(0, 44, 320, 524)];
    else
        [scrlView setFrame:CGRectMake(0, 44, 320, 434)];
    
    
    NSString *str = @"jkshfjkhs fjkhdsfjk hsjkfhsdj fhsdjkfahjksa fhsjkadhf jskdfh jksafhkjshdf jksdhfjks hfjkshadfkj sdhfjksdhfsdj ksjh sfhhjksh sjdhf jskshfsksd hsfjkshf sdjkfhh sdjkfhsdh sjdkhf sfhs sjdfhsh sdfhshshfh sdhfshfsdj jsdhf jkshfkjsdh fjksdhfshfsjdhfjsk hfjksh fjksh fjsdhf jsdhfj";
    
    arrText = [[NSMutableArray alloc] initWithObjects:@"210, Plassdfssj sjksjksj klsjkj ksjklsjfklsjkl kdsjklsdjksj sdjfkljs klsdj ksdfjklskls sklfklj dskljfksl jsdfdf sdf ssdgh sdjhfjksdhjksh jksdfhjk hs dfssdf sdfs sdfs s",
               
        @"sdf sdfs fdsfsfssdfsdjfh kjdshfsh hsdjfhsdjk sdhfh sdf d sdfsjdhjskhjksdhjsh jksdhjksh jskdhsjhsjkhsjkfhsjkhdsh sdjfhjsdhjksdfhjfhh sdjkh sdjfhshjksfhj hsdjkfhsjk sdhfjksdhfjksdhjksdhfjh jsdkfhsjkdh kjsfh sfsdfsdf sdfsadsfdsfsd sdf sdjksdhjksh s fsdfs fsdfsf sdfsdf",
               
        @"dfsdfsf ss fsdfsdf sdfs s fdsfsddfs fsdf safsd d sdfjhsfjhsjhsh sdfhjk hjsfdhjksh jksfdsf sdfdsfsdfsdf sdfsdf sdfs fsdfs dfsdfsdwerwerds fsdcgdg dsfsfsa sdds fds",
    
        @"dfsdf fdssd fsd fsdfs sddsfsdfsjk fjskshfjshfjkhf jksdfhjksfhjksdhjk hdsfjkhdkjsfhjksdjk hsdjkfhjksdh jksfhfhjsk  dssdjfkhsdjfhjskdhf jshsdf sadfwerwef dfvgfsafsd rwe dsvdfg gds werwejsfh jskdfhsjhfkjshfjksfh s fsadf d" ,nil];
    
    arrDisclaimer = [[NSMutableArray alloc] initWithObjects:@"iHome Finder",@"Smartidx",@"Finder1111",@"kapil goyal",nil];
    arrtxtViewHeight = [[NSMutableArray alloc] init];
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:str];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:16.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        h1=0.0;
        if(height1>34)
        {
            h1=height1-34;
        }
    }
    else
    {
        txtViewHeight = [[UITextView alloc] init];
        txtViewHeight.font = [UIFont fontWithName:@"Helvetica" size:16.0];
        txtViewHeight.text = str;
        txtViewHeight.frame = CGRectMake(0, 0, 315, 34);
        [self.view addSubview:txtViewHeight];
        rect = txtViewHeight.frame;
        rect.size = txtViewHeight.contentSize;
        txtViewHeight.frame = rect;
        [txtViewHeight removeFromSuperview];
        if(rect.size.height>34)
            h1=rect.size.height-34;
    }
    txtView1.text =  str;
    [txtView1 setFrame:CGRectMake(4, 0, 315, 34+h1)];
    [imgSep1 setFrame:CGRectMake(0, 35+h1, 320, 1)];


    /***********Dynamic View***********/
    for(int i=0;i<[arrText count];i++)
    {
        CGFloat height = [self txtViewHeight:i];
        [arrtxtViewHeight addObject:[NSNumber numberWithFloat:height]];
    }

    CGFloat height = 0.0;
    CGFloat ht=0.0;
    for(int i=0;i<4;i++)
    {
        UILabel *lblDisClaimer = [[UILabel alloc] init];
        lblDisClaimer.frame = CGRectMake(9, height+h1+44+65*i, 127, 21);
        lblDisClaimer.backgroundColor = [UIColor clearColor];
        lblDisClaimer.textColor = [UIColor colorWithRed:84/255.0 green:84/255.0 blue:84/255.0 alpha:1.0];
        lblDisClaimer.font = [UIFont fontWithName:@"Helvetica-Bold" size:18.0];
        lblDisClaimer.text = [arrDisclaimer objectAtIndex:i];
        [scrlView addSubview:lblDisClaimer];
        
        ht = [[arrtxtViewHeight objectAtIndex:i] floatValue];
        UITextView *txtViewDisclaimer = [[UITextView alloc] init];
        txtViewDisclaimer.frame = CGRectMake(4, height+h1+60+65*i, 315, 34+ht);
        txtViewDisclaimer.editable=NO;
        txtViewDisclaimer.scrollEnabled=NO;
        txtViewDisclaimer.backgroundColor = [UIColor clearColor];
        txtViewDisclaimer.font = [UIFont fontWithName:@"Helvetica" size:16.0];
        txtViewDisclaimer.textColor = [UIColor colorWithRed:118/255.0 green:118/255.0 blue:118/255.0 alpha:1.0];
        txtViewDisclaimer.text =[arrText objectAtIndex:i];
        [scrlView addSubview:txtViewDisclaimer];
        
        height= ht+height;
        imgSep = [[UIImageView alloc] init];
        imgSep.image = [UIImage imageNamed:@"sep.png"];
        [imgSep setFrame:CGRectMake(0, height+h1+97+66*i, 320, 1)];
        [scrlView addSubview:imgSep];
        NSLog(@"height=%f",height);
    }
    if(IsRunningTallPhone())
        [scrlView setContentSize:CGSizeMake(320, scrlView.frame.size.height-120+h1+height)];
    else
        [scrlView setContentSize:CGSizeMake(320, scrlView.frame.size.height-80+h1+height)];

}

-(IBAction)btnBackClicked
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(CGFloat)txtViewHeight:(int)index
{
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[arrText objectAtIndex:index]];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:16.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        h2=0.0;
        if(height1>34)
        {
            h2=height1-34;
        }
    }
    else
    {
        txtViewHeight = [[UITextView alloc] init];
        txtViewHeight.font = [UIFont fontWithName:@"Helvetica" size:16.0];
        txtViewHeight.text = [arrText objectAtIndex:index];
        txtViewHeight.frame = CGRectMake(0, 0, 315, 34);
        [self.view addSubview:txtViewHeight];
        rect = txtViewHeight.frame;
        rect.size = txtViewHeight.contentSize;
        txtViewHeight.frame = rect;
        [txtViewHeight removeFromSuperview];
        if(rect.size.height>34)
            h2=rect.size.height-34;
    }
    return h2;
}

- (CGFloat)textViewHeightForAttributedText:(NSMutableAttributedString*)text
{
    UITextView *txtSavedSearch = [[UITextView alloc] init];
    [txtSavedSearch setAttributedText:text];
    CGSize size = [txtSavedSearch sizeThatFits:CGSizeMake(315, 34)];
    return size.height;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
