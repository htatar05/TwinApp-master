//
//  DisclaimerViewController.h
//  RealState
//
//  Created by Kapil Goyal on 14/11/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DisclaimerViewController : UIViewController
{
    IBOutlet UITextView *txtView1;
    IBOutlet UITextView *txtView2;
    IBOutlet UITextView *txtView3;
    
    IBOutlet UILabel *lblHeading1;
    IBOutlet UILabel *lblHeading2;

    IBOutlet UIImageView *imgSep1;
    IBOutlet UIImageView *imgSep2;
    
    IBOutlet UIScrollView *scrlView;
    
    float h1,h2,h3;
    CGRect rect;
    NSMutableArray *arrText;
    UITextView *txtViewHeight;
    NSMutableArray *arrDisclaimer;
    NSMutableArray *arrtxtViewHeight;
    UIImageView *imgSep;
}
-(IBAction)btnBackClicked;
@end
