//  RenameSavedSearchViewController.m
//  Created by Kapil Goyal on 11/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "RenameSavedSearchViewController.h"
#import "Utils.h"

@interface RenameSavedSearchViewController ()

@end

@implementation RenameSavedSearchViewController
@synthesize delegate;

- (void)viewDidLoad
{
    [super viewDidLoad];
     self.navigationController.navigationBarHidden = YES;
    txtPropertyName.text = self.strGenAdd;
    txtPropertyName.delegate = self;
    [txtPropertyName becomeFirstResponder];
    
}

#pragma mark Actions
-(IBAction)btnRenameSaved
{
    if (txtPropertyName.text.length == 0)
    {
        [delegate sendPropertyName:self.strGenAdd];
    }
    else
    {
        [delegate sendPropertyName:txtPropertyName.text];
        [self.navigationController popViewControllerAnimated:YES];
    }
    
    
}

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
        [textView resignFirstResponder];
    return YES;
}
-(IBAction)btnBackClicked
{
    
    if (txtPropertyName.text.length == 0)
    {
        [delegate sendPropertyName:self.strGenAdd];
    }
    else
    {
        [delegate sendPropertyName:txtPropertyName.text];
        
    }
    [self.navigationController popViewControllerAnimated:YES];
    [txtPropertyName resignFirstResponder];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
