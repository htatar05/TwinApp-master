//  RenameSavedSearchViewController.h
//  RealState
//  Created by Kapil Goyal on 11/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import <UIKit/UIKit.h>


@protocol senddataProtocol <NSObject>

-(void)sendPropertyName:(NSString *)string;

@end

@interface RenameSavedSearchViewController : UIViewController<UITextViewDelegate>
{
    IBOutlet UITextView *txtPropertyName;
    
}

@property(nonatomic,assign)id delegate;
@property (nonatomic,strong)NSString *strGenAdd;

@end
