//  AppDelegate.m
//  RealState
//  Created by Kapil Goyal on 27/08/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "AppDelegate.h"
#import "AskForLoginViewController.h"
#import "MainViewController.h"
#import "SettingsViewController.h"
#import "ShowingsViewController.h"
#import "AgentListViewController.h"
#import "ClientListViewController.h"
#import "NonClientListViewController.h"
#import "LoginViewController.h"
#import "SavedSearchPropertyViewController.h"
#import "FavouriteProperties.h"
#import "ShowingDataView.h"
#import "ShowingAgentVC.h"
#import "ShowingClientVC.h"
#import "RegisterViewController.h"
#import "ProfileVC.h"
#import "AGPushNoteView.h"


@implementation AppDelegate

@synthesize globalReference;
@synthesize viewController;
@synthesize navigationController;
@synthesize arrSectionCount;
@synthesize strTitle;
@synthesize boolLogin;
@synthesize user;
@synthesize boolLoginNotNow;
@synthesize sideBar;

-(BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.user = [[User alloc] init];
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"RealEstate.sqlite"];
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [locationManager requestWhenInUseAuthorization];
    [locationManager startUpdatingLocation];
    
    [self saveAllPropertySearchintoDatabase];
    [self saveRentPropertySearchintoDatabase];
    [self saveSalePropertyData];
    [self saveSoldPropertyData];
    
    if([[UIDevice currentDevice] systemVersion].floatValue >= 8.0)
    {
        UIUserNotificationSettings* notificationSettings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:notificationSettings];
    }
    else
    {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound|UIRemoteNotificationTypeBadge)];
    }

    if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]) {
        MainViewController *main;
        if (IS_IPHONE) {
            
            main = [[MainViewController alloc] initWithNibName:@"MainViewController_iPhone" bundle:nil];

        } else {
             main = [[MainViewController alloc] initWithNibName:@"MainViewController_iPad" bundle:nil];
        }
        self.navigationController = [[UINavigationController alloc] initWithRootViewController:main] ;
        self.window.rootViewController = self.navigationController;
        [self.window makeKeyAndVisible];
        self.window.backgroundColor = [UIColor whiteColor];
    } else {
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
        {
            self.viewController = [[AskForLoginViewController alloc] initWithNibName:@"AskForLoginViewController_iPhone" bundle:nil];
            self.navigationController = [[UINavigationController alloc] initWithRootViewController:self.viewController] ;
        }
        else
        {
            self.viewController = [[AskForLoginViewController alloc] initWithNibName:@"AskForLoginViewController_iPad" bundle:nil];
            self.navigationController = [[UINavigationController alloc] initWithRootViewController:self.viewController] ;
        }
        self.window.rootViewController = self.navigationController;
        [self.window makeKeyAndVisible];
      
        
    }
    return YES;
}



- (void)applicationDidBecomeActive:(UIApplication *)application
{
  
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ReloadSideMenu" object:nil];
}
- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSString *token = [[deviceToken description] stringByTrimmingCharactersInSet: [NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    token = [token stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSLog(@"content---%@", token);
    [[NSUserDefaults standardUserDefaults]setValue:token forKey:@"devicetoken"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSLog(@"my token--%@",[[NSUserDefaults standardUserDefaults]valueForKey:@"devicetoken"]);
}

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
#if !TARGET_IPHONE_SIMULATOR
   
#endif
    
    [[NSUserDefaults standardUserDefaults]setValue:@"0000" forKey:@"devicetoken"];
}


-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
   
    if ([[[userInfo objectForKey:@"aps"] objectForKey:@"type_push"]isEqualToString:@"saved_search"]) {
        
        self.saveSearchCount = [[[userInfo objectForKey:@"aps"] objectForKey:@"count"] intValue];
         NSString *str = [NSString stringWithFormat:@"%d",self.saveSearchCount];
        [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"SavedSearchCount"];
        
        
    }
    
    else if ([[[userInfo objectForKey:@"aps"] objectForKey:@"type_push"]isEqualToString:@"Favourite"]) {
        
        self.favouriteCount = [[[userInfo objectForKey:@"aps"] objectForKey:@"count"] intValue];
        NSString *str = [NSString stringWithFormat:@"%d",self.favouriteCount];
        [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"FavouriteCount"];
        
    }
    else if ([[[userInfo objectForKey:@"aps"] objectForKey:@"type_push"]isEqualToString:@"Showing"]) {
        self.showingCount = [[[userInfo objectForKey:@"aps"] objectForKey:@"count"] intValue];
        NSString *str = [NSString stringWithFormat:@"%d",self.showingCount];
        [[NSUserDefaults standardUserDefaults] setObject:str forKey:@"showingCount"];
    
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ReloadSideMenu" object:nil];
    
    
}

- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
    //register to receive notifications
    [application registerForRemoteNotifications];
}

//For interactive notification only
- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler
{
    //handle the actions
    if ([identifier isEqualToString:@"declineAction"]){
    }
    else if ([identifier isEqualToString:@"answerAction"]){
    }
}

+(AppDelegate*)sharedDelegate
{
    return (AppDelegate*)[UIApplication sharedApplication].delegate;
}



-(void)sidebarViewController:(SidebarViewController *)sidebarViewController didSelectObject:(NSObject *)object atIndexPath:(NSIndexPath *)indexPath
{
    [self.globalReference setRevealedState:JTRevealedStateNo];
    MainViewController * mvc;
    SettingsViewController *svc ;
    ShowingsViewController *showVC;
    ShowingDataView *showData;
    AgentListViewController *agentVC;
    ClientListViewController *ClientVC;
    NonClientListViewController *nonClientVC;
    SavedSearchPropertyViewController *savedSearch;
    FavouriteProperties *favProperties;
    LoginViewController *loginVC;
    
    if(indexPath.section==0)
    {
        switch (indexPath.row)
        {
            case 0:
                
                if (IS_IPHONE) {
                    
                    mvc = [[MainViewController alloc] initWithNibName:@"MainViewController_iPhone" bundle:nil];
                    mvc.selectedValue = @"";
                    mvc.leftSidebarViewController  = sidebarViewController;
                    mvc.isFromSavedSearch = @"No";
                    self.sideBar=sidebarViewController;
                    [self.globalReference pushViewController:mvc animated:NO];
                    break;
                    
                } else {
                    mvc = [[MainViewController alloc] initWithNibName:@"MainViewController_iPad" bundle:nil];
                    mvc.selectedValue = @"";
                    mvc.leftSidebarViewController  = sidebarViewController;
                    mvc.isFromSavedSearch = @"No";
                    self.sideBar=sidebarViewController;
                    [self.globalReference pushViewController:mvc animated:NO];
                    break;
                    
                }
                
                
            case 1:
                if (IS_IPHONE) {
                    
                    mvc = [[MainViewController alloc] initWithNibName:@"MainViewController_iPhone" bundle:nil];
                    mvc.selectedValue = @"For_Rent";
                    mvc.isFromSavedSearch = @"No";
                    mvc.leftSidebarViewController  = sidebarViewController;
                    self.sideBar=sidebarViewController;
                    [self.globalReference pushViewController:mvc animated:NO];
                    break;
                } else {
                    
                    mvc = [[MainViewController alloc] initWithNibName:@"MainViewController_iPad" bundle:nil];
                    mvc.selectedValue = @"For_Rent";
                    mvc.isFromSavedSearch = @"No";
                    mvc.leftSidebarViewController  = sidebarViewController;
                    self.sideBar=sidebarViewController;
                    [self.globalReference pushViewController:mvc animated:NO];
                    break;
                }
                
            case 2:
                if (IS_IPHONE){
                    
                    mvc = [[MainViewController alloc] initWithNibName:@"MainViewController_iPhone" bundle:nil];
                    mvc.selectedValue = @"For_Sold";
                    mvc.isFromSavedSearch = @"No";
                    mvc.leftSidebarViewController  = sidebarViewController;
                    self.sideBar=sidebarViewController;
                    [self.globalReference pushViewController:mvc animated:NO];
                    break;
                } else {
                    
                    mvc = [[MainViewController alloc] initWithNibName:@"MainViewController_iPad" bundle:nil];
                    mvc.selectedValue = @"For_Sold";
                    mvc.isFromSavedSearch = @"No";
                    mvc.leftSidebarViewController  = sidebarViewController;
                    self.sideBar=sidebarViewController;
                    [self.globalReference pushViewController:mvc animated:NO];
                    break;
                }
                
            case 3:
                
                if (IS_IPHONE) {
                    
                    mvc = [[MainViewController alloc] initWithNibName:@"MainViewController_iPhone" bundle:nil];
                    mvc.selectedValue = @"All_Property";
                    mvc.isFromSavedSearch = @"No";
                    mvc.leftSidebarViewController  = sidebarViewController;
                    self.sideBar=sidebarViewController;
                    [self.globalReference pushViewController:mvc animated:NO];
                    break;
                } else {
                    
                    mvc = [[MainViewController alloc] initWithNibName:@"MainViewController_iPad" bundle:nil];
                    mvc.selectedValue = @"All_Property";
                    mvc.isFromSavedSearch = @"No";
                    mvc.leftSidebarViewController  = sidebarViewController;
                    self.sideBar=sidebarViewController;
                    [self.globalReference pushViewController:mvc animated:NO];
                    break;
                }
                
            default:
                break;
        }
    }
    else if(indexPath.section==1)
    {
        switch (indexPath.row)
        {
            case 0:
                if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| self.loginUser) {
                    
                    if (IS_IPHONE){
                        
                        savedSearch = [[SavedSearchPropertyViewController alloc] initWithNibName:@"SavedSearchPropertyViewController_iPhone" bundle:nil];
                    } else {
                        
                        savedSearch = [[SavedSearchPropertyViewController alloc] initWithNibName:@"SavedSearchPropertyViewController_iPad" bundle:nil];
                    }
                    
                    savedSearch.leftSidebarViewController  = sidebarViewController;
                    self.sideBar=sidebarViewController;
                    [self.globalReference pushViewController:savedSearch animated:NO];
                } else
                {
                    if (IS_IPHONE) {
                        
                        loginVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPhone" bundle:nil];
                        [self.navigationController presentViewController:loginVC animated:YES completion:nil];
                    } else {
                        
                        loginVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPad" bundle:nil];
                        [self.navigationController presentViewController:loginVC animated:YES completion:nil];
                    }
                   
                }
                break;
            case 1:
                if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| self.loginUser) {
                    if (IS_IPHONE) {
                        favProperties = [[FavouriteProperties alloc] initWithNibName:@"FavouriteProperties" bundle:nil];
                    } else {
                        favProperties = [[FavouriteProperties alloc] initWithNibName:@"FavouriteProperties_iPad" bundle:nil];
                    }
                    favProperties.leftSidebarViewController  = sidebarViewController;
                    self.sideBar=sidebarViewController;
                    [self.globalReference pushViewController:favProperties animated:NO];
                    
                } else
                {
                    if (IS_IPHONE) {
                        
                        loginVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPhone" bundle:nil];
                        [self.navigationController presentViewController:loginVC animated:YES completion:nil];
                    } else {
                        
                        loginVC = [[LoginViewController alloc] initWithNibName:@"LoginViewController_iPad" bundle:nil];
                        [self.navigationController presentViewController:loginVC animated:YES completion:nil];
                    }
                    
                }
                break;
            case 2:
                
                if ([[NSUserDefaults standardUserDefaults]objectForKey:@"userData"]|| self.loginUser){
                    
                    if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"RoleId"] isEqualToString:@"1"])
                    {
                        if (IS_IPHONE) {
                            showData = [[ShowingDataView alloc] initWithNibName:@"ShowingDataView" bundle:nil];
                        } else {
                            showData = [[ShowingDataView alloc] initWithNibName:@"ShowingDataView_iPad" bundle:nil];
                        }
                        showData.leftSidebarViewController  = sidebarViewController;
                        self.sideBar=sidebarViewController;
                        [self.globalReference pushViewController:showData animated:NO];
                    }
                    else if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"RoleId"] isEqualToString:@"2"])
                    {
                        ShowingAgentVC *managerLogin;
                        if (IS_IPHONE) {
                            managerLogin = [[ShowingAgentVC alloc]initWithNibName:@"ShowingAgentVC" bundle:nil];
                        } else {
                            managerLogin = [[ShowingAgentVC alloc]initWithNibName:@"ShowingAgentVC_iPad" bundle:nil];
                        }
                        
                        managerLogin.isFromAddShowing = @"Yes";
                        managerLogin.managerId = [[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"];
                        [self.navigationController pushViewController:managerLogin animated:YES];
                    }
                    else if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"RoleId"] isEqualToString:@"3"])
                    {
                        ShowingClientVC *client;
                        if (IS_IPHONE) {
                            client = [[ShowingClientVC alloc]initWithNibName:@"ShowingClientVC" bundle:nil];
                        } else {
                            client = [[ShowingClientVC alloc]initWithNibName:@"ShowingClientVC_iPad" bundle:nil];
                        }
                        
                        client.isFromAddShowing = @"Yes";
                        client.agentId =[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"];
                        [self.navigationController pushViewController:client animated:YES];
                        
                    }
                    else
                    {
                        if (IS_IPHONE) {
                            showVC = [[ShowingsViewController alloc] initWithNibName:@"ShowingsViewController_iPhone" bundle:nil];
                        } else {
                            showVC = [[ShowingsViewController alloc] initWithNibName:@"ShowingsViewController_iPad" bundle:nil];
                        }
                        showVC.clientId = [[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"];
                        [self.navigationController pushViewController:showVC animated:YES];
                    }
                    
                } else
                {
                    [Utils showAlertMessage:@"Twin Realty" Message:@"Please login first"];
                }
                break;
            default:
                break;
        }
    }
    else if([arrSectionCount count]==3)
    {
        if(indexPath.section==2)
        {
             user.strRoleId = [[NSUserDefaults standardUserDefaults] objectForKey:@"RoleId"];
            if([user.strRoleId isEqualToString:@"0"])
            {
                switch (indexPath.row)
                {
                    case 1:
                        
                        if (IS_IPHONE) {
                            
                            svc= [[SettingsViewController alloc] initWithNibName:@"SettingsViewController_iPhone" bundle:nil];
                            svc.leftSidebarViewController  = sidebarViewController;
                            self.sideBar=sidebarViewController;
                            [self.globalReference pushViewController:svc animated:NO];
                            break;
                        }
                        else
                        {
                            svc= [[SettingsViewController alloc] initWithNibName:@"SettingsViewController_iPad" bundle:nil];
                            svc.leftSidebarViewController  = sidebarViewController;
                            self.sideBar=sidebarViewController;
                            [self.globalReference pushViewController:svc animated:NO];
                            break;
                        }
                        
                    default:
                        break;
                }
            }
            else
            {
                switch (indexPath.row)
                {
                    case 0:
                    case 2:
                        if (IS_IPHONE) {
                            
                            svc= [[SettingsViewController alloc] initWithNibName:@"SettingsViewController_iPhone" bundle:nil];
                            svc.leftSidebarViewController  = sidebarViewController;
                            self.sideBar=sidebarViewController;
                            [self.globalReference pushViewController:svc animated:NO];
                            break;
                        } else {
                            
                            svc= [[SettingsViewController alloc] initWithNibName:@"SettingsViewController_iPad" bundle:nil];
                            svc.leftSidebarViewController  = sidebarViewController;
                            self.sideBar=sidebarViewController;
                            [self.globalReference pushViewController:svc animated:NO];
                            break;
                        }
                        
                        
                    default:
                        break;
                }
            }
        }
    }
    
    else if([arrSectionCount count]==4)
    {
        if(indexPath.section==2)
        {
            switch (indexPath.row)
            {
                case 0:
                    if ([[[NSUserDefaults standardUserDefaults]valueForKey:@"RoleId"] isEqualToString:@"4"]) {
                        
                        if (IS_IPHONE) {
                            agentVC= [[AgentListViewController alloc] initWithNibName:@"AgentListViewController_iPhone" bundle:nil];
                        } else {
                            agentVC= [[AgentListViewController alloc] initWithNibName:@"AgentListViewController_iPad" bundle:nil];
                        }
                        
                        agentVC.leftSidebarViewController  = sidebarViewController;
                        agentVC.isMyAgent = @"No";
                        NSLog(@"Assigned agent");
                        [AppDelegate sharedDelegate].strTitle = @"Contact Agent";
                        self.sideBar=sidebarViewController;
                        [self.globalReference pushViewController:agentVC animated:NO];
                        break;
                    } else
                    {
                        if (IS_IPHONE) {
                            ClientVC= [[ClientListViewController alloc] initWithNibName:@"ClientListViewController_iPhone" bundle:nil];
                        } else {
                            ClientVC= [[ClientListViewController alloc] initWithNibName:@"ClientListViewController_iPad" bundle:nil];
                        }
                        ClientVC.leftSidebarViewController  = sidebarViewController;
                        [AppDelegate sharedDelegate].strTitle = @"Contact Client";
                        self.sideBar=sidebarViewController;
                        [self.globalReference pushViewController:ClientVC animated:NO];
                        break;
                    }
                    
                case 1:
                    
                    
                    if (IS_IPHONE) {
                        nonClientVC= [[NonClientListViewController alloc] initWithNibName:@"NonClientListViewController_iPhone" bundle:nil];
                    } else {
                        nonClientVC= [[NonClientListViewController alloc] initWithNibName:@"NonClientListViewController_iPad" bundle:nil];
                    }
                    
                    nonClientVC.leftSidebarViewController  = sidebarViewController;
                    [AppDelegate sharedDelegate].strTitle = @"Contact Client";
                    self.sideBar=sidebarViewController;
                    [self.globalReference pushViewController:nonClientVC animated:NO];
                    break;
                case 2:
                    if (IS_IPHONE) {
                        agentVC = [[AgentListViewController alloc] initWithNibName:@"AgentListViewController_iPhone" bundle:nil];
                    } else {
                        agentVC = [[AgentListViewController alloc] initWithNibName:@"AgentListViewController_iPad" bundle:nil];
                    }
                    agentVC.leftSidebarViewController  = sidebarViewController;
                    agentVC.isMyAgent = @"Yes";
                    [AppDelegate sharedDelegate].strTitle = @"Contact Agent";
                    NSLog(@"my agent clicked");
                    self.sideBar=sidebarViewController;
                    
                    [self.globalReference pushViewController:agentVC animated:NO];
                    break;
                    
                default:
                    break;
            }
        }
        else if(indexPath.section==3)
        {
            switch (indexPath.row)
            {
                case 0:
                {
                    if (IS_IPHONE) {
                        
                        ProfileVC *pVC = [[ProfileVC alloc]initWithNibName:@"ProfileVC" bundle:nil];
                        [self.navigationController pushViewController:pVC animated:YES];
                        
                    } else {
                        
                        ProfileVC *pVC = [[ProfileVC alloc]initWithNibName:@"ProfileVC_iPad" bundle:nil];
                        [self.navigationController pushViewController:pVC animated:YES];
                    }
                    
                    break;
                }
                case 1:
                {
                    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
                    [dict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] forKey:@"user_id"];
                    [REWebService CallLogout:dict withBlock:^(NSDictionary *dictResult, NSError *error) {
                        if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]){
                            
                            [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                            
                            [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"userData"];
                            [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"user_id"];
                            self.loginUser = NO;
                            [[NSUserDefaults standardUserDefaults]setBool:NO forKey:@"loginstatus"];
                            AskForLoginViewController *pVC = [[AskForLoginViewController alloc] initWithNibName:@"AskForLoginViewController_iPhone" bundle:nil];
                            self.navigationController = [[UINavigationController alloc] initWithRootViewController:pVC] ;
                            self.window.rootViewController = self.navigationController;
                            
                        }
                        else{
                            
                            [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"message"]];
                        }
                        
                        NSLog(@"%@",dictResult);
                        
                    }];
                }
                    
                case 2:
                    
                    if (IS_IPHONE) {
                        svc= [[SettingsViewController alloc] initWithNibName:@"SettingsViewController_iPhone" bundle:nil];
                        svc.leftSidebarViewController  = sidebarViewController;
                        self.sideBar=sidebarViewController;
                        [self.globalReference pushViewController:svc animated:NO];
                        break;
                    } else {
                        
                        svc= [[SettingsViewController alloc] initWithNibName:@"SettingsViewController_iPad" bundle:nil];
                        svc.leftSidebarViewController  = sidebarViewController;
                        self.sideBar=sidebarViewController;
                        [self.globalReference pushViewController:svc animated:NO];
                        break;
                    }
                    
                    
                default:
                    break;
            }
        }
    }
}
-(BOOL)prefersStatusBarHidden{
    return YES;
}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
}

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    CLLocation *currentLocation = newLocation;
    if (currentLocation != nil)
    {
        self.currentLocation = newLocation;
    }
}


-(void)saveAllPropertySearchintoDatabase
{
    NSString *existData = @"select * from AllProperties";
    if (self.propertyDetail != nil) {
        self.propertyDetail = nil;
    }
    self.propertyDetail = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:existData]];
    NSLog(@"DATA---%@",_propertyDetail);
    NSLog(@"Count---%lu",(unsigned long)self.propertyDetail.count);
    if (self.propertyDetail.count)
    {
        
    } else
    {
        [[NSUserDefaults standardUserDefaults] setValue:@"SQFT" forKey:@"AllPropertyLotType"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
         NSString *insert = [NSString stringWithFormat:@"INSERT INTO AllProperties (id) values(1)"];
         [self.dbManager executeQuery:insert];
        
        NSString *defaultProperties = @"SF/CA/MF";
        NSString *update = [NSString stringWithFormat:@"update AllProperties SET property_type='%@' where id='1'",defaultProperties];
        [self.dbManager executeQuery:update];
        
    }
    
}

-(void)saveRentPropertySearchintoDatabase
{
    NSString *existData = @"select * from RentProperties";
    if (self.RentDetail != nil) {
        self.RentDetail = nil;
    }
    self.RentDetail = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:existData]];
    NSLog(@"DATA---%@",_RentDetail);
    NSLog(@"Count---%lu",(unsigned long)self.RentDetail.count);
    if (self.RentDetail.count)
    {
        
    } else
    {
        [[NSUserDefaults standardUserDefaults] setValue:@"SQFT" forKey:@"RentPropertyLotType"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NSString *insert = [NSString stringWithFormat:@"INSERT INTO RentProperties (id) values(1)"];
        [self.dbManager executeQuery:insert];
        [[NSUserDefaults standardUserDefaults]setValue:@"True" forKey:@"NotificationSwitch"];
        [[NSUserDefaults standardUserDefaults]setValue:@"True" forKey:@"EmailSwitch"];
        
        NSString *defaultProperties = @"SF/CA/MF";
        NSString *update = [NSString stringWithFormat:@"update RentProperties SET property_type='%@' where id='1'",defaultProperties];
        [self.dbManager executeQuery:update];
        [[NSUserDefaults standardUserDefaults]setValue:@"Recently Changed" forKey:@"SortOrder"];
        [[NSUserDefaults standardUserDefaults]setValue:@"Recently Changed" forKey:@"FavoriteSortOrder"];
    }
}

-(void)saveSalePropertyData
{
    NSString *existData = @"SELECT * FROM SaleProperties";
    if (self.RentDetail != nil) {
        self.RentDetail = nil;
    }
    self.RentDetail = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:existData]];
    NSLog(@"DATA---%@",_RentDetail);
    NSLog(@"Count---%lu",(unsigned long)self.RentDetail.count);
    if (self.RentDetail.count)
    {
        
    } else
    {
//        [[NSUserDefaults standardUserDefaults] setValue:@"SQFT" forKey:@"RentPropertyLotType"];
//        [[NSUserDefaults standardUserDefaults] synchronize];
        NSString *insert = [NSString stringWithFormat:@"INSERT INTO SaleProperties (id) values(1)"];
        [self.dbManager executeQuery:insert];
        NSString *defaultProperties = @"SF/CA/MF";
        NSString *update = [NSString stringWithFormat:@"update SaleProperties SET property_type='%@' where id='1'",defaultProperties];
        [self.dbManager executeQuery:update];
    }
}

-(void)saveSoldPropertyData
{
    NSString *existData = @"SELECT * FROM SoldProperties";
    if (self.RentDetail != nil) {
        self.RentDetail = nil;
    }
    self.RentDetail = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:existData]];
    NSLog(@"DATA---%@",_RentDetail);
    NSLog(@"Count---%lu",(unsigned long)self.RentDetail.count);
    if (self.RentDetail.count)
    {
        
    } else
    {
        NSString *insert = [NSString stringWithFormat:@"INSERT INTO SoldProperties (id) values(1)"];
        [self.dbManager executeQuery:insert];
        
        NSString *defaultProperties = @"SF/CA/MF";
        NSString *update = [NSString stringWithFormat:@"update SoldProperties SET property_type='%@' where id='1'",defaultProperties];
        [self.dbManager executeQuery:update];
    }
}

@end
