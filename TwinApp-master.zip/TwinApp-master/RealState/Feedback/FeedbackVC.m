//  FeedbackVC.m
//  RealEstate_App
//  Created by Octal on 12/08/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import "FeedbackVC.h"
#import "REWebService.h"
#import "Utils.h"
#import "MBProgressHUD.h"
#import "AppDelegate.h"

@interface FeedbackVC ()

@end

@implementation FeedbackVC


- (void)viewDidLoad
{
    [super viewDidLoad];
    _delegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    txtComment.delegate = self;
}

- (void)didReceiveMemoryWarning
{
   [super didReceiveMemoryWarning];
}

#pragma Actions

-(IBAction)backButtonClicked:(id)sender
{
    [txtComment resignFirstResponder];
    [self.navigationController popViewControllerAnimated:YES];

}

-(IBAction)sendFeedbackDetail:(id)sender
{
    [txtComment resignFirstResponder];
    NSString *trimmedString = [txtComment.text stringByTrimmingCharactersInSet:
                               [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if([trimmedString isEqualToString:@""])
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter comment."];
    }
    else
    {
        [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
        NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
        [dataDict setValue:[[NSUserDefaults standardUserDefaults]objectForKey:@"user_id"] forKey:@"user_id"];
        [dataDict setValue:txtComment.text forKey:@"comment"];
        [REWebService CallSendFeedback:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
            [MBProgressHUD hideAllHUDsForView:self->_delegate.window animated:YES];
        if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"])
        {
            [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
            [self.navigationController popViewControllerAnimated:YES];
            
        } else
        {
            [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                
        }
            
        }];
    }
}


- (BOOL)textView:(UITextView *)textView
shouldChangeTextInRange:(NSRange)range
 replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
    }
    return YES;
}
@end
