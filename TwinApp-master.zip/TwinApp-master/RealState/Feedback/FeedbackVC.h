//
//  FeedbackVC.h
//  RealEstate_App
//
//  Created by Octal on 12/08/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface FeedbackVC : UIViewController<UITextViewDelegate>

{
    IBOutlet UITextView *txtComment;
    AppDelegate * _delegate;

}
@end
