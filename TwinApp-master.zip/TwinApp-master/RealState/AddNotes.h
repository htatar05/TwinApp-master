//
//  AddNotes.h
//  RealEstate_App
//
//  Created by Octal on 13/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface AddNotes : UIViewController

{
    IBOutlet UITextView *txtNote;
    AppDelegate *appDelegate;
}

@property (nonatomic,strong)NSString *propertyId;


@end
