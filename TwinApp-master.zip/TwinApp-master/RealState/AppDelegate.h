//  AppDelegate.h
//  RealState
//  Created by Kapil Goyal on 27/08/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import <UIKit/UIKit.h>

#import "SidebarViewController.h"
#import "UIViewController+JTRevealSidebarV2.h"
#import "AgentDetailView.h"
#import "User.h"
#import "DBManager.h"
#import <CoreLocation/CoreLocation.h>
@class AskForLoginViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate,SidebarViewControllerDelegate,CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
}

@property(strong,nonatomic) UIWindow *window;
@property(strong,nonatomic) AskForLoginViewController *viewController;
@property(strong,nonatomic) UINavigationController *globalReference;
@property(strong,nonatomic) UINavigationController *navigationController;
@property(strong,nonatomic) NSMutableArray *arrSectionCount;
@property(strong,nonatomic) SidebarViewController *sideBar;
@property(strong,nonatomic) NSString *strTitle;
@property(assign,nonatomic) BOOL isAutoLogin;
@property(assign,nonatomic) BOOL boolLogin;
@property(assign,nonatomic) BOOL boolLoginNotNow;
@property(assign,nonatomic) BOOL boolLoginPresent;
@property (nonatomic, strong) DBManager *dbManager;
@property (strong, nonatomic) CLLocation *currentLocation;
@property (nonatomic, strong) NSArray *propertyDetail;
@property (nonatomic, strong) NSArray *RentDetail;
@property(assign,nonatomic) BOOL loginUser;

@property(nonatomic, assign) int saveSearchCount;
@property(nonatomic, assign) int favouriteCount;
@property(nonatomic, assign) int showingCount;


@property(strong,nonatomic) User *user;

+(AppDelegate*)sharedDelegate;
@end
