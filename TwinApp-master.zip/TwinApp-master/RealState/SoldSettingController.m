//  SoldSettingController.m
//  RealEstate_App
//  Created by Octal on 20/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.

#import "SoldSettingController.h"
#import "MARKRangeSlider.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "Utils.h"
#import "AppDelegate.h"
#import "PropertyTypeViewController.h"
#import "PropertyType.h"

static CGFloat const kViewControllerRangeSliderWidth = 290.0;
static CGFloat const kViewControllerLabelWidth = 100.0;

@interface SoldSettingController ()

@property (nonatomic, strong) MARKRangeSlider *sliderListPrice;
@property (nonatomic, strong) UILabel *lblPriceValue;
@property (nonatomic, strong) NSArray *propertyDetail;

@end

@implementation SoldSettingController
{
    NSString *strPriceMinimum;
    NSString *strPriceMaximum;
    NSString *strFullAddress;
    NSString *strSelectedBaths;
    NSString *strSelectedBeds;
    NSString *strPropertyType;
    NSString *strSqftMin;
    NSString *strSqftMax;
    NSString *strForclosures;
    NSString *strShortSale;
    NSString *strPickerType;
    NSMutableString *propertyType;
    NSMutableArray *squareFeetMini;
    NSMutableArray *squareFeetMaxi;
    NSMutableArray *foreClosuresArr;
    NSString *PickerSubType;
    NSString *searchByKeyword;
    
    NSMutableArray *lotSquaremini;
    NSMutableArray *lotSquaremaxi;
    NSMutableArray *acresMini;
    NSMutableArray *acresMaxi;
    NSMutableArray *yearsMini;
    NSMutableArray *yearsMaxi;
    
    NSString *lotSquareMin;
    NSString *lotSquareMax;
    NSString *lotAcreMin;
    NSString *lotAcreMax;
    NSString *yearBuiltMin;
    NSString *yearBuiltMax;
    NSString *daysOnMarket;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _delegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    lotSquaremini = [[NSMutableArray alloc]init];
    lotSquaremaxi = [[NSMutableArray alloc]init];
    
    //[self addKeyboardControls];
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"RealEstate.sqlite"];
    [Picker setDelegate:self];
    
    squareFeetMini = [[NSMutableArray alloc]initWithObjects:@"minimum",@"100",@"200",@"300",@"400",@"500",@"600",@"700",@"800",@"900",@"1000",@"1100",@"1200",@"1300",@"1400",@"1500",@"1600",@"1700",@"1800",@"1900",@"2000",@"2100",@"2200",@"2300",@"2400",@"2500",@"2600",@"2700",@"2800",@"2900",@"3000",@"3100",@"3200",@"3300",@"3400",@"3500",@"3600",@"3700",@"3800",@"3900",@"4000",@"4500",@"5000",@"5500",@"6000",@"7000",@"8000",@"9000",@"10000", nil];
    
    squareFeetMaxi = [[NSMutableArray alloc]initWithObjects:@"100",@"200",@"300",@"400",@"500",@"600",@"700",@"800",@"900",@"1000",@"1100",@"1200",@"1300",@"1400",@"1500",@"1600",@"1700",@"1800",@"1900",@"2000",@"2100",@"2200",@"2300",@"2400",@"2500",@"2600",@"2700",@"2800",@"2900",@"3000",@"3100",@"3200",@"3300",@"3400",@"3500",@"3600",@"3700",@"3800",@"3900",@"4000",@"4500",@"5000",@"5500",@"6000",@"7000",@"8000",@"9000",@"10000",@"maximum", nil];
    
    
    strPickerType = @"SquareFeet";
    viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, 260);
    [self.view addSubview:viewSelect];
    UIColor *borderColor = [UIColor colorWithRed:59.0/255.0 green:132.0/255.0 blue:229.0/255.0 alpha:1.0];
    
    txtLocationView.layer.borderColor = borderColor.CGColor;
    txtLocationView.layer.cornerRadius=8.0f;
    txtLocationView.layer.masksToBounds=YES;
    txtLocationView.layer.borderWidth= 1.0f;
    
    txtSearchKeywordsView.layer.cornerRadius=8.0f;
    txtSearchKeywordsView.layer.masksToBounds=YES;
    txtSearchKeywordsView.layer.borderColor=borderColor.CGColor;
    txtSearchKeywordsView.layer.borderWidth= 1.0f;
    txtLocation.delegate = self;
    txtSearchByKeywords.delegate = self;
    
    btnLocationDelete.layer.cornerRadius = 9.0;
    btnSearchKeyDelete.layer.cornerRadius = 9.0;
    
    btnForclosures.layer.cornerRadius=8.0f;
    btnForclosures.layer.masksToBounds=YES;
    btnForclosures.layer.borderColor=borderColor.CGColor;
    btnForclosures.layer.borderWidth= 1.0f;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


-(IBAction)locationDeleteButton:(id)sender
{
    txtLocation.text = @"";
    [txtLocation becomeFirstResponder];
    
}

-(IBAction)searchDeleteButton:(id)sender
{
    txtSearchByKeywords.text = @"";
    [txtSearchByKeywords becomeFirstResponder];
}
-(void)viewWillAppear:(BOOL)animated
{
    [self.lblPriceValue removeFromSuperview];
    [_sliderListPrice removeFromSuperview];
    NSString *existData = @"select * from SoldProperties";
    if (self.propertyDetail != nil)
    {
        self.propertyDetail = nil;
    }
    self.propertyDetail = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:existData]];
    NSLog(@"DATA---%@",_propertyDetail);
    NSLog(@"Count---%lu",(unsigned long)self.propertyDetail.count);
    if (self.propertyDetail.count)
    {
        [self loadDataFromLocalDatabase];
    }
}
#pragma mark Actions
-(IBAction)backButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)selectBeds:(id)sender
{
    strSelectedBeds = [NSString stringWithFormat:@"%ld",bedSegment.selectedSegmentIndex];
    NSString *update = [NSString stringWithFormat:@"update SoldProperties SET no_of_beds='%ld' where id='1'",bedSegment.selectedSegmentIndex];
    [self.dbManager executeQuery:update];
    [self CallGetTotalPropertyCount];
    
}

-(IBAction)selectBathroom:(id)sender
{
    strSelectedBaths = [NSString stringWithFormat:@"%ld",bathroomSegment.selectedSegmentIndex];
    NSLog(@"%ld",(long)bathroomSegment.selectedSegmentIndex);
    NSString *update = [NSString stringWithFormat:@"update SoldProperties SET no_of_baths='%ld' where id='1'",bathroomSegment.selectedSegmentIndex];
    [self.dbManager executeQuery:update];
    [self CallGetTotalPropertyCount];
    
}

-(IBAction)selectPropertyType:(id)sender
{
    PropertyType *thetype;
    if (IS_IPHONE) {
        thetype = [[PropertyType alloc]initWithNibName:@"PropertyType" bundle:nil];
    } else {
        thetype = [[PropertyType alloc]initWithNibName:@"PropertyType_iPad" bundle:nil];
    }
   
    thetype.selectedPropertyType = [dataDuplicate objectAtIndex:5];
    thetype.isFrom = @"SoldProperties";
    [self.navigationController pushViewController:thetype animated:YES];
}

-(IBAction)selectSquareFeet:(id)sender
{
    NSInteger min = 0;
    NSInteger max = 0;
    NSInteger setselectedmin = 0;
    NSInteger setselectedmax = 0;
    min = [[dataDuplicate objectAtIndex:6] integerValue];
    max = [[dataDuplicate objectAtIndex:7] integerValue];
    for (NSInteger i = 0; i<squareFeetMini.count; i++)
    {
        if (min==[[squareFeetMini objectAtIndex:i] integerValue])
        {
            NSLog(@" minimum %ld",(long)i);
            setselectedmin = i;
        }
        if (max==[[squareFeetMaxi objectAtIndex:i] integerValue])
        {
            NSLog(@" maximum %ld",(long)i);
            setselectedmax = i;
        }
    }
    
    acresSegment.hidden = YES;
    lblPickerTitle.hidden = NO;
    lblPickerTitle.text = @"Square Feet";
    strPickerType = @"SquareFeet";
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
    [UIView commitAnimations];
    Picker.tag=1;
    [Picker reloadInputViews];
    [Picker reloadAllComponents];
    [Picker selectRow:setselectedmin inComponent:0 animated:YES];
    [Picker selectRow:setselectedmax inComponent:2 animated:YES];
    [self.view addSubview:viewSelect];
    [viewSelect bringSubviewToFront:self.view];
    
}

-(IBAction)selectForclosures:(id)sender
{
    foreClosuresArr = [[NSMutableArray alloc]initWithObjects:@"Foreclosures only",@"Short sale only",@"Both", nil];
    strPickerType = @"Forclosures";
    acresSegment.hidden = YES;
    lblPickerTitle.hidden = NO;
    lblPickerTitle.text = @"Select Type";
    int selectedIndex = 0;
    
    for (int i=0; i<foreClosuresArr.count; i++) {
        
        if ([[dataDuplicate objectAtIndex:8] isEqualToString:[foreClosuresArr objectAtIndex:i]]) {
            selectedIndex = i;
            
        }
    }
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
    [UIView commitAnimations];
    Picker.tag=1;
    [Picker reloadInputViews];
    [Picker reloadAllComponents];
    
    [Picker selectRow:selectedIndex inComponent:0 animated:YES];
    
    [self.view addSubview:viewSelect];
    [viewSelect bringSubviewToFront:self.view];
}


-(IBAction)selectLotSize:(id)sender
{
    strPickerType = @"LotSize";
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"SoldPropertyLotType"]isEqualToString:@"SQFT"]) {
        
        if (lotSquaremini.count==0) {
            NSInteger myInt = [@"minimum" intValue];
            [lotSquaremini addObject:[NSNumber numberWithInteger:myInt]];
            PickerSubType = @"SQFT";
            NSInteger j = 0;
            for (NSInteger i = 1; i<=70; i++)
            {
                if (i<=50) {
                    j = i*1000;
                }
                else{
                    j = j+10000;
                }
                [lotSquaremini addObject:[NSNumber numberWithInteger:j]];
                [lotSquaremaxi addObject:[NSNumber numberWithInteger:j]];
            }
            NSInteger myIntmax = [@"maximum" intValue];
            [lotSquaremaxi addObject:[NSNumber numberWithInteger:myIntmax]];
            
        }
        NSInteger min = 0;
        NSInteger max = 0;
        NSInteger setselectedmin = 0;
        NSInteger setselectedmax = 0;
        min = [[dataDuplicate objectAtIndex:11] floatValue];
        max = [[dataDuplicate objectAtIndex:12] floatValue];
        
        for (NSInteger i = 0; i<lotSquaremini.count; i++)
        {
            if (min==[[lotSquaremini objectAtIndex:i] integerValue])
            {
                NSLog(@" minimum %ld",(long)i);
                setselectedmin = i;
            }
            if (max==[[lotSquaremaxi objectAtIndex:i] integerValue])
            {
                NSLog(@" maximum %ld",(long)i);
                setselectedmax = i;
            }
        }
        
        
        [Picker reloadInputViews];
        [Picker reloadAllComponents];
        [Picker selectRow:setselectedmin inComponent:0 animated:YES];
        [Picker selectRow:setselectedmax inComponent:2 animated:YES];
        
        acresSegment.hidden = NO;
        lblPickerTitle.hidden = YES;
        lblPickerTitle.hidden = YES;
        strPickerType = @"LotSize";
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
        [UIView commitAnimations];
        Picker.tag=1;
        [self.view addSubview:viewSelect];
        [viewSelect bringSubviewToFront:self.view];
        
    } else{
        PickerSubType = @"Acres";
        
        if (acresMini.count==0) {
            
            acresMini =  [[NSMutableArray alloc]initWithObjects:@"minimum",@"0.5",@"1",@"1.5",@"2",@"2.5",@"3",@"3.5",@"4",@"4.5",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25", nil];
            
            acresMaxi =  [[NSMutableArray alloc]initWithObjects:@"0.5",@"1",@"1.5",@"2",@"2.5",@"3",@"3.5",@"4",@"4.5",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"maximum", nil];
        }
        
        float min = 0;
        float max = 0;
        NSInteger setselectedmin = 0;
        NSInteger setselectedmax = 0;
        min = [[dataDuplicate objectAtIndex:9] floatValue];
        max = [[dataDuplicate objectAtIndex:10] floatValue];
        
        for (NSInteger i = 0; i<acresMini.count; i++)
        {
            if (min==[[acresMini objectAtIndex:i] floatValue])
            {
                NSLog(@" minimum %ld",(long)i);
                setselectedmin = i;
            }
            if (max==[[acresMaxi objectAtIndex:i] floatValue])
            {
                NSLog(@" maximum %ld",(long)i);
                setselectedmax = i;
            }
        }
        
        [Picker reloadInputViews];
        [Picker reloadAllComponents];
        [Picker selectRow:setselectedmin inComponent:0 animated:YES];
        [Picker selectRow:setselectedmax inComponent:2 animated:YES];
        acresSegment.hidden = NO;
        lblPickerTitle.hidden = YES;
        lblPickerTitle.hidden = YES;
        
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
        [UIView commitAnimations];
        Picker.tag=1;
        [self.view addSubview:viewSelect];
        [viewSelect bringSubviewToFront:self.view];
        
    }
    
}

-(IBAction)yearBuildSelect:(id)sender
{
    yearsMini = [[NSMutableArray alloc]init];
    yearsMaxi  = [[NSMutableArray alloc]init];
    [yearsMini addObject:@"minimum"];
    for (NSInteger i = 0; i<=116; i++)
    {
        NSInteger j = 1900;
        j = j+i;
        
        [yearsMini addObject:[NSNumber numberWithInteger:j]];
        [yearsMaxi addObject:[NSNumber numberWithInteger:j]];
    }
    [yearsMaxi addObject:@"maximum"];
    NSInteger min = 0;
    NSInteger max = 0;
    NSInteger setselectedmin = 0;
    NSInteger setselectedmax = 0;
    min = [[dataDuplicate objectAtIndex:13] integerValue];
    max = [[dataDuplicate objectAtIndex:14] integerValue];
    for (NSInteger i = 0; i<yearsMini.count; i++)
    {
        if (min==[[yearsMini objectAtIndex:i] integerValue])
        {
            NSLog(@" minimum %ld",(long)i);
            setselectedmin = i;
        }
        if (max==[[yearsMaxi objectAtIndex:i] integerValue])
        {
            NSLog(@" maximum %ld",(long)i);
            setselectedmax = i;
        }
    }
    
    acresSegment.hidden = YES;
    lblPickerTitle.hidden = NO;
    lblPickerTitle.text = @"Year Built";
    strPickerType = @"Yearbuilt";
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
    [UIView commitAnimations];
    Picker.tag=1;
    [Picker reloadInputViews];
    [Picker reloadAllComponents];
    
    [Picker selectRow:setselectedmin inComponent:0 animated:YES];
    [Picker selectRow:setselectedmax inComponent:2 animated:YES];
    
    [self.view addSubview:viewSelect];
    [viewSelect bringSubviewToFront:self.view];
    
}
-(IBAction)selectAreaType:(id)sender
{
    if (acresSegment.selectedSegmentIndex==0)
    {
        [[NSUserDefaults standardUserDefaults] setValue:@"SQFT" forKey:@"SoldPropertyLotType"];
        PickerSubType = @"SQFT";
        if (lotSquaremini.count == 0) {
            [lotSquaremini addObject:@"minimum"];
            
            NSInteger j = 0;
            for (NSInteger i = 1; i<=70; i++)
            {
                if (i<=50) {
                    j = i*1000;
                }
                else{
                    j = j+10000;
                }
                [lotSquaremini addObject:[NSNumber numberWithInteger:j]];
                [lotSquaremaxi addObject:[NSNumber numberWithInteger:j]];
            }
            [lotSquaremaxi addObject:@"maximum"];
        }
        
        NSInteger min = 0;
        NSInteger max = 0;
        NSInteger setselectedmin = 0;
        NSInteger setselectedmax = 0;
        
        min = [[dataDuplicate objectAtIndex:10] integerValue];
        max = [[dataDuplicate objectAtIndex:11] integerValue];
        
        for (NSInteger i = 0; i<lotSquaremini.count; i++)
        {
            if (min==[[lotSquaremini objectAtIndex:i] integerValue])
            {
                NSLog(@" minimum %ld",(long)i);
                setselectedmin = i;
            }
            if (max==[[lotSquaremaxi objectAtIndex:i] integerValue])
            {
                NSLog(@" maximum %ld",(long)i);
                setselectedmax = i;
            }
        }
        
        [Picker reloadInputViews];
        [Picker reloadAllComponents];
        [Picker selectRow:setselectedmin inComponent:0 animated:YES];
        [Picker selectRow:setselectedmax inComponent:2 animated:YES];
        
    }
    else
    {
        [[NSUserDefaults standardUserDefaults] setValue:@"Acres" forKey:@"SoldPropertyLotType"];
        
        PickerSubType = @"Acres";
        acresMini =  [[NSMutableArray alloc]initWithObjects:@"minimum",@"0.5",@"1",@"1.5",@"2",@"2.5",@"3",@"3.5",@"4",@"4.5",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25", nil];
        
        acresMaxi =  [[NSMutableArray alloc]initWithObjects:@"0.5",@"1",@"1.5",@"2",@"2.5",@"3",@"3.5",@"4",@"4.5",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"maximum", nil];
        
        float min = 0;
        float max = 0;
        NSInteger setselectedmin = 0;
        NSInteger setselectedmax = 0;
        
        min = [[dataDuplicate objectAtIndex:12] floatValue];
        max = [[dataDuplicate objectAtIndex:13] floatValue];
        
        for (NSInteger i = 0; i<acresMini.count; i++)
        {
            if (min==[[acresMini objectAtIndex:i] floatValue])
            {
                NSLog(@" minimum %ld",(long)i);
                setselectedmin = i;
            }
            if (max==[[acresMaxi objectAtIndex:i] floatValue])
            {
                NSLog(@" maximum %ld",(long)i);
                setselectedmax = i;
            }
        }
        [Picker reloadInputViews];
        [Picker reloadAllComponents];
        [Picker selectRow:setselectedmin inComponent:0 animated:YES];
        [Picker selectRow:setselectedmax inComponent:2 animated:YES];
    }
}
- (void)setUpViewComponents
{
    self.lblPriceValue = [[UILabel alloc] initWithFrame:CGRectZero];
    self.lblPriceValue.numberOfLines = 1;
    self.lblPriceValue.textColor = [UIColor whiteColor];
    self.lblPriceValue.font = [UIFont systemFontOfSize:12];
    self.lblPriceValue.backgroundColor = [UIColor blackColor];
    
    self.sliderListPrice = [[MARKRangeSlider alloc] initWithFrame:CGRectZero];
    self.sliderListPrice.backgroundColor = [UIColor whiteColor];
    [self.sliderListPrice addTarget:self
                             action:@selector(listPriceValueDidChange:)
                   forControlEvents:UIControlEventValueChanged];
    
    [self.sliderListPrice addTarget:self
                             action:@selector(dragEndedForSlider1:)
                   forControlEvents:UIControlEventTouchUpOutside];
    
    [self.sliderListPrice setMinValue:0 maxValue:50000000];
    [self.sliderListPrice setLeftValue:[strPriceMinimum floatValue] rightValue:[strPriceMaximum floatValue]];
    self.sliderListPrice.minimumDistance = 6000000;
    
    
    [self updateListPriceText];
    [_myScrollView addSubview:self.lblPriceValue];
    [_myScrollView addSubview:self.sliderListPrice];
}

- (void)listPriceValueDidChange:(MARKRangeSlider *)slider
{
    [self updateListPriceText];
    
}

-(void)dragEndedForSlider1:(MARKRangeSlider *)slider {
    
    double miniFinal;
    double maximumFinal;
    miniFinal = [[NSString stringWithFormat:@"%0.0f",self.sliderListPrice.leftValue] doubleValue];
    maximumFinal= [[NSString stringWithFormat:@"%0.0f",self.sliderListPrice.rightValue] doubleValue];
    
    strPriceMinimum = [NSString stringWithFormat:@"%0.0f",miniFinal];
    strPriceMaximum = [NSString stringWithFormat:@"%0.0f",maximumFinal];
    
    NSString *update = [NSString stringWithFormat:@"update SoldProperties SET sold_minimum='%@',sold_maximum='%@' where id='1'",strPriceMinimum,strPriceMaximum];
    [self.dbManager executeQuery:update];
    [self CallGetTotalPropertyCount];
    
}


- (void)updateListPriceText
{
    NSString *str1 = [self abbreviateNumber:self.sliderListPrice.leftValue];
    NSString *str2 = [self abbreviateNumber:self.sliderListPrice.rightValue];
    self.lblPriceValue.text = [NSString stringWithFormat:@"$%@ - $%@",
                               str1, str2];
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    self.lblPriceValue.textAlignment = NSTextAlignmentCenter;
    CGFloat labelX = (CGRectGetWidth(self.view.frame) - kViewControllerLabelWidth) / 2;
    self.lblPriceValue.frame = CGRectMake(labelX, 25.0, kViewControllerLabelWidth, 18.0);
    CGFloat sliderX = (CGRectGetWidth(self.view.frame) - kViewControllerRangeSliderWidth) / 2;
    self.sliderListPrice.frame = CGRectMake(sliderX, CGRectGetMaxY(self.lblPriceValue.frame) + 15.0, 290.0, 12.0);
    _myScrollView.contentSize = CGSizeMake(self.view.bounds.size.width, 750);
    
}

-(NSString *)abbreviateNumber:(int)num {
    
    NSString *abbrevNum;
    float number = (float)num;
    
    //Prevent numbers smaller than 1000 to return NULL
    if (num >= 1000) {
        NSArray *abbrev = @[@"K", @"M", @"B"];
        
        for (int i = abbrev.count - 1; i >= 0; i--) {
            
            // Convert array index to "1000", "1000000", etc
            int size = pow(10,(i+1)*3);
            
            if(size <= number) {
                // Removed the round and dec to make sure small numbers are included like: 1.1K instead of 1K
                number = number/size;
                NSString *numberString = [self floatToString:number];
                
                // Add the letter for the abbreviation
                abbrevNum = [NSString stringWithFormat:@"%@%@", numberString, [abbrev objectAtIndex:i]];
            }
            
        }
    } else {
        
        // Numbers like: 999 returns 999 instead of NULL
        abbrevNum = [NSString stringWithFormat:@"%d", (int)number];
    }
    
    return abbrevNum;
}

- (NSString *) floatToString:(float) val {
    NSString *ret = [NSString stringWithFormat:@"%.1f", val];
    unichar c = [ret characterAtIndex:[ret length] - 1];
    
    while (c == 48) { // 0
        ret = [ret substringToIndex:[ret length] - 1];
        c = [ret characterAtIndex:[ret length] - 1];
        
        //After finding the "." we know that everything left is the decimal number, so get a substring excluding the "."
        if(c == 46) { // .
            ret = [ret substringToIndex:[ret length] - 1];
        }
    }
    return ret;
}

/*
    Convert into K
 */


-(NSString *)convertNumberIntoK:(int)num {
    
    NSString *abbrevNum;
    float number = (float)num;
    
    //Prevent numbers smaller than 1000 to return NULL
    if (num >= 1000) {
        NSArray *abbrev = @[@"K", @"M", @"B"];
        
        for (int i = abbrev.count - 1; i >= 0; i--) {
            
            // Convert array index to "1000", "1000000", etc
            int size = pow(10,(i+1)*3);
            
            if(size <= number) {
                // Removed the round and dec to make sure small numbers are included like: 1.1K instead of 1K
                number = number/size;
                NSString *numberString =  [NSString stringWithFormat:@"%.0f",number]; //[self floatToString2:number];
                
                // Add the letter for the abbreviation
                abbrevNum = [NSString stringWithFormat:@"%@%@", numberString, [abbrev objectAtIndex:i]];
            }
            
        }
    } else {
        
        // Numbers like: 999 returns 999 instead of NULL
        abbrevNum = [NSString stringWithFormat:@"%d", (int)number];
    }
    
    return abbrevNum;
}

- (NSString *) floatToString2:(float) val {
    NSString *ret = [NSString stringWithFormat:@"%.0f", val];
    unichar c = [ret characterAtIndex:[ret length] - 1];
    
    while (c == 48) { // 0
        ret = [ret substringToIndex:[ret length] - 1];
        c = [ret characterAtIndex:[ret length] - 1];
        
        //After finding the "." we know that everything left is the decimal number, so get a substring excluding the "."
        if(c == 46) { // .
            ret = [ret substringToIndex:[ret length] - 1];
        }
    }
    return ret;
}



-(void)CallGetTotalPropertyCount
{
    [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:self.strLat1 forKey:@"latitude1"];
    [dataDict setValue:self.strLat2 forKey:@"longitude1"];
    [dataDict setValue:self.strLat3 forKey:@"latitude2"];
    [dataDict setValue:self.strLat4 forKey:@"longitude2"];
    [dataDict setValue:strPriceMinimum forKey:@"pricesold1"];
    [dataDict setValue:strPriceMaximum forKey:@"pricesold2"];
    [dataDict setValue:strFullAddress forKey:@"fulladdress"];
    [dataDict setValue:strSelectedBaths forKey:@"totalfullbaths"];
    [dataDict setValue:strSelectedBeds forKey:@"numbedrooms"];
    [dataDict setValue:strPropertyType forKey:@"propertytype"];
    [dataDict setValue:strSqftMin forKey:@"sqft1"];
    [dataDict setValue:strSqftMax forKey:@"sqft2"];
    [dataDict setValue:strForclosures forKey:@"foreclosedyn"];
    [dataDict setValue:strShortSale forKey:@"shortsaleyn"];
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"SoldPropertyLotType"]isEqualToString:@"SQFT"]) {
        
        [dataDict setValue:lotSquareMin forKey:@"lot_size_square1"];
        [dataDict setValue:lotSquareMax forKey:@"lot_size_square2"];
    }else{
        [dataDict setValue:lotAcreMin forKey:@"lot_size_acres1"];
        [dataDict setValue:lotAcreMax forKey:@"lot_size_acres2"];
    }
    
    [dataDict setValue:daysOnMarket forKey:@"days_on_market"];
    [dataDict setValue:yearBuiltMin forKey:@"yearbuilt1"];
    [dataDict setValue:yearBuiltMax forKey:@"yearbuilt2"];
    [dataDict setValue:searchByKeyword forKey:@"search_by_keyword"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"user_id"];
    [dataDict setValue:@"sold" forKey:@"status"];
    [REWebService CallGetPropertCountFromServer:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self->_delegate.window animated:YES];
        NSLog( @"%@",dictResult);
        
        if (!error) {
            
            if ([[[dictResult objectForKey:@"response"] objectForKey:@"message"]isEqualToString:@"success"]) {
                
                int final = (int)[[[dictResult objectForKey:@"response"] objectForKey:@"count"] integerValue];
                NSString *str1 = [self convertNumberIntoK:final];
                self->lblTotalCount.text = [NSString stringWithFormat:@"%@ Results",str1];
                
                
            } else
            {
                self->lblTotalCount.text = @"0 Results";
            }
        }
        
    }];
}


#pragma mark UIPicker view
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView;
{
    if ([strPickerType isEqualToString:@"Forclosures"]) {
        return 1;
    }
    else{
        
        return 3;
    }
    
}


- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
    
    if ([strPickerType isEqualToString:@"Forclosures"]){
        return self.view.frame.size.width;
        
    }
    else
    {
        switch (component)
        {
            case 0:
                return (self.view.frame.size.width/2)-40;
            case 1:
                return 50.0f;
            case 2:
                return (self.view.frame.size.width/2)-40;
        }
    }
    
    return self.view.frame.size.width;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;
{
    
    if ([strPickerType isEqualToString:@"SquareFeet"])
    {
        switch (component)
        {
            case 0:
                return squareFeetMini.count;;
                break;
            case 1:
                return 1;
                break;
            case 2:
                return squareFeetMaxi.count;;
                break;
            default:
                break;
        }
        
    }
    else if ([strPickerType isEqualToString:@"Yearbuilt"])
    {
        switch (component)
        {
            case 0:
                return yearsMini.count;;
                break;
            case 1:
                return 1;
                break;
            case 2:
                return yearsMaxi.count;;
                break;
            default:
                break;
        }
        
    }
    else if ([strPickerType isEqualToString:@"LotSize"])
    {
        if ([PickerSubType isEqualToString:@"Acres"]){
            
            switch (component)
            {
                case 0:
                    return acresMini.count;;
                    break;
                case 1:
                    return 1;
                    break;
                case 2:
                    return acresMaxi.count;;
                    break;
                default:
                    break;
            }
        }
        else
        {
            switch (component)
            {
                case 0:
                    return lotSquaremini.count;;
                    break;
                case 1:
                    return 1;
                    break;
                case 2:
                    return lotSquaremaxi.count;;
                    break;
                default:
                    break;
            }
            
        }
        
    }
    
    else{
        
        return foreClosuresArr.count;
    }
    return 1;
    
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSInteger mini = 0;
    NSInteger maxi = 0;
    if ([strPickerType isEqualToString:@"SquareFeet"])
    {
        switch (component) {
            case 0:
            {
                mini = [[squareFeetMini objectAtIndex:row] integerValue];
                maxi = [[squareFeetMaxi objectAtIndex:[pickerView selectedRowInComponent:2]] integerValue];
                if (mini>=maxi && maxi!=0)
                {
                    [Picker selectRow:row inComponent:2 animated:YES];
                }
                break;
            }
            case 2:
            {
                maxi = [[squareFeetMaxi objectAtIndex:row] integerValue];
                mini = [[squareFeetMini objectAtIndex:[pickerView selectedRowInComponent:0]] integerValue];
                if (maxi<=mini && mini!=0)
                {
                    [Picker selectRow:row inComponent:0 animated:YES];
                    
                }
                break;
            }
            default:
                break;
        }
    }
    else if ([strPickerType isEqualToString:@"Yearbuilt"])
    {
        switch (component) {
            case 0:
                mini = [[yearsMini objectAtIndex:row] integerValue];
                maxi = [[yearsMaxi objectAtIndex:[pickerView selectedRowInComponent:2]] integerValue];
                
                if (mini>=maxi && maxi!=0)
                {
                    [Picker selectRow:row inComponent:2 animated:YES];
                }
                break;
            case 2:
                maxi = [[yearsMaxi objectAtIndex:row] integerValue];
                mini = [[yearsMini objectAtIndex:[pickerView selectedRowInComponent:0]] integerValue];
                if (maxi<=mini)
                {
                    [Picker selectRow:row inComponent:0 animated:YES];
                }
                break;
            default:
                break;
        }
        
    }
    else if ([strPickerType isEqualToString:@"LotSize"])
    {
        if ([PickerSubType isEqualToString:@"Acres"]) {
            switch (component) {
                case 0:
                    mini = [[acresMini objectAtIndex:row] integerValue];
                    maxi = [[acresMaxi objectAtIndex:[pickerView selectedRowInComponent:2]] integerValue];
                    
                    if (mini>=maxi && maxi!=0)
                    {
                        [Picker selectRow:row inComponent:2 animated:YES];
                    }
                    break;
                case 2:
                    maxi = [[acresMaxi objectAtIndex:row] integerValue];
                    mini = [[acresMini objectAtIndex:[pickerView selectedRowInComponent:0]] integerValue];
                    if (maxi<=mini)
                    {
                        [Picker selectRow:row inComponent:0 animated:YES];
                    }
                    break;
                default:
                    break;
            }
            
        } else {
            
            switch (component) {
                case 0:
                    mini = [[lotSquaremini objectAtIndex:row] integerValue];
                    maxi = [[lotSquaremaxi objectAtIndex:[pickerView selectedRowInComponent:2]] integerValue];
                    
                    if (mini>=maxi && maxi!=0)
                    {
                        [Picker selectRow:row inComponent:2 animated:YES];
                    }
                    break;
                case 2:
                    maxi = [[lotSquaremaxi objectAtIndex:row] integerValue];
                    mini = [[lotSquaremini objectAtIndex:[pickerView selectedRowInComponent:0]] integerValue];
                    if (maxi<=mini)
                    {
                        [Picker selectRow:row inComponent:0 animated:YES];
                    }
                    break;
                default:
                    break;
            }
            
        }
        
    }
    
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component;
{
    
    if ([strPickerType isEqualToString:@"SquareFeet"])
    {
        switch (component) {
            case 0:
                return [squareFeetMini objectAtIndex:row];
                
                break;
            case 1:
                return @"to";
                break;
            case 2:
                return [squareFeetMaxi objectAtIndex:row];
                
                break;
            default:
                break;
        }
    }
    else if ([strPickerType isEqualToString:@"Yearbuilt"])
    {
        switch (component) {
            case 0:
                return [NSString stringWithFormat:@"%@",[yearsMini objectAtIndex:row]];
                break;
            case 1:
                return @"to";
                break;
            case 2:
                return [NSString stringWithFormat:@"%@",[yearsMaxi objectAtIndex:row]];
                break;
            default:
                break;
        }
        
    }
    else if ([strPickerType isEqualToString:@"LotSize"])
    {
        
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"SoldPropertyLotType"]isEqualToString:@"SQFT"]) {
            
            switch (component){
                case 0:
                    if (row==0) {
                        return [NSString stringWithFormat:@"minimum"];
                    } else {
                        return [NSString stringWithFormat:@"%ld",(long)[[lotSquaremini objectAtIndex:row]integerValue]];
                    }
                    
                    break;
                case 1:
                    return @"to";
                    break;
                case 2:
                    if (row==lotSquaremaxi.count-1) {
                        return [NSString stringWithFormat:@"maximum"];
                    } else {
                        return [NSString stringWithFormat:@"%ld",(long)[[lotSquaremaxi objectAtIndex:row] integerValue]];
                    }
                    
                    break;
                default:
                    break;
            }
            
            
        } else {
            
            switch (component) {
                case 0:
                    return [NSString stringWithFormat:@"%@",[acresMini objectAtIndex:row]];
                    break;
                case 1:
                    return @"to";
                    break;
                case 2:
                    return [NSString stringWithFormat:@"%@",[acresMaxi objectAtIndex:row]];
                    break;
                default:
                    break;
            }
        }
        
    }
    else
    {
        return [foreClosuresArr objectAtIndex:row];
    }
    return nil;
}

-(IBAction)daysOnMarketClicked:(id)sender
{
    PropertyTypeViewController *thetype;
    if (IS_IPHONE) {
        thetype = [[PropertyTypeViewController alloc]initWithNibName:@"PropertyTypeViewController_iPhone" bundle:nil];
    } else {
        thetype = [[PropertyTypeViewController alloc]initWithNibName:@"PropertyTypeViewController_iPad" bundle:nil];
    }
    
    thetype.PropertyType = @"Number_of_days";
    thetype.selectedDays = [dataDuplicate objectAtIndex:15];
    thetype.isFrom = @"SoldProperties";
    [self.navigationController pushViewController:thetype animated:YES];
}

-(IBAction)btnPickerDoneClicked:(id)sender
{
    if ([strPickerType isEqualToString:@"SquareFeet"])
    {
        if ([[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]] isEqualToString:@"minimum"]&&[[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]] isEqualToString:@"maximum"])
        {
            lblSquareFeet.text = @"";
            strSqftMin = @"0";
            strSqftMax = @"0";
        }
        else if ([[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]] isEqualToString:@"minimum"])
        {
            lblSquareFeet.text = [NSString stringWithFormat:@"0-%@ sqft",[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
            strSqftMin = @"1";
            strSqftMax = [squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]];
        }
        else if ([[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]] isEqualToString:@"maximum"])
        {
            lblSquareFeet.text = [NSString stringWithFormat:@"%@+ sqft",[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]]];
            strSqftMin = [squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]];
            strSqftMax = @"500000";
        }
        else
        {
            lblSquareFeet.text = [NSString stringWithFormat:@"%@-%@ sqft",[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]],[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
            
            strSqftMin = [NSString stringWithFormat:@"%ld",(long)[[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]];
            
            strSqftMax = [NSString stringWithFormat:@"%ld",(long)[[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
            
        }
        NSString *update = [NSString stringWithFormat:@"update SoldProperties SET square_feets_min='%ld',square_feets_max='%ld' where id='1'",(long)[[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue],[[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
        [self.dbManager executeQuery:update];
        
        
    }
    else if ([strPickerType isEqualToString:@"Yearbuilt"])
    {
        if ([[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]==0&&[[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]==0)
        {
            lblYearBuild.text = @"";
            yearBuiltMin= @"0";
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"yyyy"];
            yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
        }
        else if ([[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]==0)
        {
            lblYearBuild.text = [NSString stringWithFormat:@"min-%ld",(long)[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]];
            yearBuiltMin= @"0";
            yearBuiltMax =[NSString stringWithFormat:@"%ld",(long)[[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
            
        }
        else if ([[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]==0)
        {
            lblYearBuild.text = [NSString stringWithFormat:@"%ld-max",(long)[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]];
            
            yearBuiltMin = [NSString stringWithFormat:@"%ld",(long)[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]];
            
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"yyyy"];
            yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
        }
        else
        {
            lblYearBuild.text = [NSString stringWithFormat:@"%ld-%ld",(long)[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue],(long)[[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
            yearBuiltMin = [NSString stringWithFormat:@"%ld",(long)[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]];
            yearBuiltMax = [NSString stringWithFormat:@"%ld",(long)[[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
            
        }
        NSString *update = [NSString stringWithFormat:@"update SoldProperties SET year_built_min='%ld',year_built_max='%ld' where id='1'",[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue],[[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
        [self.dbManager executeQuery:update];
    }
    
    else if ([strPickerType isEqualToString:@"LotSize"])
    {
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"SoldPropertyLotType"]isEqualToString:@"SQFT"]) {
            
            
            if ([[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]==0 &&[[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]==0)
            {
                lblLotSize.text = @"";
                lotSquareMin  = @"1";
                lotSquareMax = @"500000000000";
                
            }
            else if ([[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue] ==0)
            {
                lblLotSize.text = [NSString stringWithFormat:@"0-%@ sqft lot",[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
                
                lotSquareMin  = @"0";
                lotSquareMax = [NSString stringWithFormat:@"%@",[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
            }
            else if ([[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]==0)
            {
                lblLotSize.text = [NSString stringWithFormat:@"%@+ sqft lot",[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]]];
                lotSquareMin  = [NSString stringWithFormat:@"%@",[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]]];
                lotSquareMax = @"500000000000";
                
            }
            else
            {
                lblLotSize.text = [NSString stringWithFormat:@"%@-%@ sqft lot",[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]],[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
                
                lotSquareMax = [NSString stringWithFormat:@"%@",[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
                lotSquareMin  = [NSString stringWithFormat:@"%@",[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]]];
                
            }
            NSString *update = [NSString stringWithFormat:@"update SoldProperties SET lot_square_feets_min='%ld',lot_square_feets_max='%ld' where id='1'",[[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue],[[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
            [self.dbManager executeQuery:update];
            
            
        } else {
            
            if ([[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue] ==0&&[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue] ==0)
            {
                lblLotSize.text = @"";
                lotAcreMin = @"0";
                lotAcreMax = @"0";
            }
            else if ([[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue] ==0)
            {
                lblLotSize.text = [NSString stringWithFormat:@"0-%.1f acre lot",[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue]];
                lotAcreMin = @"0";
                lotAcreMax = [NSString stringWithFormat:@"%.1f",[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue]];
                
            }
            else if ([[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue] ==0)
            {
                lblLotSize.text = [NSString stringWithFormat:@"%.1f+ acre lot",[[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue]];
                lotAcreMin = [NSString stringWithFormat:@"%.1f",[[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue]];
                
                lotAcreMax =@"500000";
            }
            else
            {
                lblLotSize.text = [NSString stringWithFormat:@"%.1f-%.1f acre lot",[[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue],[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue]];
                
                lotAcreMin = [NSString stringWithFormat:@"%.1f",[[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue]];
                
                lotAcreMax = [NSString stringWithFormat:@"%.1f",[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue]];
                
            }
            
            NSString *update = [NSString stringWithFormat:@"update SoldProperties SET lot_acres_min='%f',lot_acres_max='%f' where id='1'",[[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue],[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue]];
            [self.dbManager executeQuery:update];
            
        }
    }
    else
    {
        
        [btnForclosures setTitle:[foreClosuresArr objectAtIndex:[Picker selectedRowInComponent:0]] forState:UIControlStateNormal];
        NSString *update = [NSString stringWithFormat:@"update SoldProperties SET foreclosures='%@' where id='1'",[foreClosuresArr objectAtIndex:[Picker selectedRowInComponent:0]]];
        [self.dbManager executeQuery:update];
        
        if ([[foreClosuresArr objectAtIndex:[Picker selectedRowInComponent:0]] isEqualToString:@"Foreclosures only"]){
            strForclosures = @"Yes";
            strShortSale = @"No";
            
        }
        else if ([[foreClosuresArr objectAtIndex:[Picker selectedRowInComponent:0]] isEqualToString:@"Short sale only"]){
            strForclosures = @"No";
            strShortSale = @"Yes";
            
        }
        else if ([[foreClosuresArr objectAtIndex:[Picker selectedRowInComponent:0]] isEqualToString:@"Both"]){
            strForclosures = @"Yes";
            strShortSale = @"Yes";
            
        }
        else{
            strForclosures = @"0";
            strShortSale = @"0";
            
        }
        
    }
    
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
    [UIView commitAnimations];
    [self CallGetTotalPropertyCount];
    
}

-(IBAction)btnCancelClicked:(id)sender
{
    if ([sender tag]==1)
    {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        viewSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
        [UIView commitAnimations];
    }
    else
    {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        viewSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
        [UIView commitAnimations];
    }
}

#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    
   // keyboardControls.textFields = [NSArray arrayWithObjects: nil];
    
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"";
    [keyboardControls hidePrevNextButtons:YES];
    
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] bounds];
    
    CGFloat availableHeight = applicationFrame.size.height - 230;
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    strFullAddress = txtLocation.text;
    searchByKeyword = txtSearchByKeywords.text;
    [controls.activeTextField resignFirstResponder];
    if (controls.activeTextField==txtLocation)
    {
        NSString *update = [NSString stringWithFormat:@"update SoldProperties SET location='%@' where id='1'",txtLocation.text];
        [self.dbManager executeQuery:update];
        
    }
    else
    {
        NSString *update = [NSString stringWithFormat:@"update SoldProperties SET search_by_keywords='%@' where id='1'",txtSearchByKeywords.text];
        [self.dbManager executeQuery:update];
       
    }
    [self CallGetTotalPropertyCount];
    
}

- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([keyboardControls.textFields containsObject:textField])
        keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField {
    //Keyboard becomes visible
    _myScrollView.frame = CGRectMake(_myScrollView.frame.origin.x,
                                     _myScrollView.frame.origin.y,
                                     _myScrollView.frame.size.width,
                                     _myScrollView.frame.size.height - 315 + 50);
}

-(void)textFieldDidEndEditing:(UITextField *)textField {
    //keyboard will hide
    _myScrollView.frame = CGRectMake(_myScrollView.frame.origin.x,
                                     _myScrollView.frame.origin.y,
                                     _myScrollView.frame.size.width,
                                     _myScrollView.frame.size.height + 315 - 50);
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
     strFullAddress = txtLocation.text;
     searchByKeyword = txtSearchByKeywords.text;
    if (textField==txtLocation) {
        NSLog(@"text location");
        NSString *update = [NSString stringWithFormat:@"update SoldProperties SET location='%@' where id='1'",txtLocation.text];
        [self.dbManager executeQuery:update];
        
    } else {
        NSLog(@"search by keyword location");
        NSString *update = [NSString stringWithFormat:@"update SoldProperties SET search_by_keywords='%@' where id='1'",txtSearchByKeywords.text];
        [self.dbManager executeQuery:update];
    }
    
    [textField resignFirstResponder];
    [self CallGetTotalPropertyCount];
    return YES;
}
-(void)loadDataFromLocalDatabase
{
    dataDuplicate =    [self.propertyDetail objectAtIndex:0];
    strPriceMinimum  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:0]];
    strPriceMaximum  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:1]];
    strFullAddress   = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
    strSelectedBeds  = [NSString stringWithFormat:@"%ld",[[dataDuplicate objectAtIndex:3] integerValue]];
    strSelectedBaths = [NSString stringWithFormat:@"%ld",[[dataDuplicate objectAtIndex:4] integerValue]];
    strPropertyType  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:5]];
    strSqftMin       = [NSString stringWithFormat:@"%ld",[[dataDuplicate objectAtIndex:6] integerValue]];
    strSqftMax       = [NSString stringWithFormat:@"%ld",[[dataDuplicate objectAtIndex:7] integerValue]];
    propertyType = [[NSMutableString alloc]init];
    NSArray *selectedItems = [strPropertyType componentsSeparatedByString:@"/"];
    for (NSInteger i = 0; i<selectedItems.count; i++) {
        [propertyType appendString:[NSString stringWithFormat:@"%@,",[selectedItems objectAtIndex:i]]];
    }
    strPropertyType = [propertyType substringToIndex:[propertyType length]-1];
    
    
    if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Foreclosures only"]){
        strForclosures = @"Yes";
        strShortSale = @"No";
        
    }
    else if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Short sale only"]){
        strForclosures = @"No";
        strShortSale = @"Yes";
        
    }
    else if ([[dataDuplicate objectAtIndex:8] isEqualToString:@"Both"])
    {
        strForclosures = @"Yes";
        strShortSale = @"Yes";
        
    }
    else{
        strForclosures = @"0";
        strShortSale = @"0";
    }
    
    if (![[dataDuplicate objectAtIndex:2] isEqualToString:@"0"])
    {
        txtLocation.text = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
    }
    else
    {
        txtLocation.text = @"";
    }
    
    [bedSegment setSelectedSegmentIndex:[[dataDuplicate objectAtIndex:3] integerValue]];
    [bathroomSegment setSelectedSegmentIndex:[[dataDuplicate objectAtIndex:4] integerValue]];
    // Update square feet label
    
    if ([[dataDuplicate objectAtIndex:6] integerValue] ==0&&[[dataDuplicate objectAtIndex:7] integerValue] ==0)
    {
        lblSquareFeet.text = @"";
        strSqftMin = @"0";
        strSqftMax = @"0";
        
    }
    else if ([[dataDuplicate objectAtIndex:6] integerValue] ==0)
    {
        lblSquareFeet.text = [NSString stringWithFormat:@"0-%ld sqft",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
        strSqftMin = @"1";
        strSqftMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
        
    }
    else if ([[dataDuplicate objectAtIndex:7] integerValue] ==0)
    {
        lblSquareFeet.text = [NSString stringWithFormat:@"%ld+ sqft",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
        strSqftMax = @"500000";
        strSqftMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
    }
    else
    {
        lblSquareFeet.text = [NSString stringWithFormat:@"%ld-%ld sqft",(long)[[dataDuplicate objectAtIndex:6] integerValue],(long)[[dataDuplicate objectAtIndex:7] integerValue]];
        strSqftMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
        strSqftMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
        
    }
    
    if (![[dataDuplicate objectAtIndex:5]isEqualToString:@"0"]) {
        lblPropertyType.text = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:5]];
    }
    
    if (![[dataDuplicate objectAtIndex:8] isEqualToString:@"0"]) {
        
        [btnForclosures setTitle:[dataDuplicate objectAtIndex:8] forState:UIControlStateNormal];
    }
    else
    {
        [btnForclosures setTitle:@"Select Type" forState:UIControlStateNormal];
    }
    
    //Update Lot size label;
    
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"SoldPropertyLotType"]isEqualToString:@"SQFT"]) {
        //11 12
        acresSegment.selectedSegmentIndex = 0;
        
        if ([[dataDuplicate objectAtIndex:11] floatValue] ==0&&[[dataDuplicate objectAtIndex:12] integerValue] ==0)
        {
            lblLotSize.text = @"";
            lotSquareMin = @"1";
            lotSquareMax = @"500000000000";
        }
        else if ([[dataDuplicate objectAtIndex:11] floatValue] ==0)
        {
            lblLotSize.text = [NSString stringWithFormat:@"0-%ld sqft lot",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
            
            lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
            lotSquareMin = @"0";
        }
        else if ([[dataDuplicate objectAtIndex:12] floatValue] ==0)
        {
            lblLotSize.text = [NSString stringWithFormat:@"%.1ld+ sqft lot",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
            lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
            lotSquareMax = @"500000000000";
        }
        else
        {
            lblLotSize.text = [NSString stringWithFormat:@"%.1ld-%.1ld sqft lot",(long)[[dataDuplicate objectAtIndex:11] integerValue],(long)[[dataDuplicate objectAtIndex:12] integerValue]];
            lotSquareMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
            lotSquareMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
        }
        
    } else {
        
        //9 10
        
        if ([[dataDuplicate objectAtIndex:9] floatValue] ==0&&[[dataDuplicate objectAtIndex:10] floatValue] ==0)
        {
            lblLotSize.text = @"";
            lotAcreMin= @"0";
            lotAcreMax  = @"0";
        }
        else if ([[dataDuplicate objectAtIndex:9] floatValue] ==0)
        {
            lblLotSize.text = [NSString stringWithFormat:@"0-%.1f acre lot",[[dataDuplicate objectAtIndex:10] floatValue]];
            lotAcreMin = @"0";
            lotAcreMax = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:10] floatValue]];
        }
        else if ([[dataDuplicate objectAtIndex:10] floatValue] ==0)
        {
            lblLotSize.text = [NSString stringWithFormat:@"%.1f+ acre lot",[[dataDuplicate objectAtIndex:9] floatValue]];
            lotAcreMin = [NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:9] floatValue]];
            lotAcreMax = @"500000000";
        }
        else
        {
            lblLotSize.text = [NSString stringWithFormat:@"%.1f-%.1f acre lot",[[dataDuplicate objectAtIndex:9] floatValue],[[dataDuplicate objectAtIndex:10] floatValue]];
            lotAcreMin =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:9] floatValue]];
            lotAcreMax =[NSString stringWithFormat:@"%.1f",[[dataDuplicate objectAtIndex:10] floatValue]];
        }
        acresSegment.selectedSegmentIndex = 1;
    }
    
    
    // Update year label
    
    if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"]&&[[dataDuplicate objectAtIndex:14] isEqualToString:@"0"]) {
        
        lblYearBuild.text = @"";
        yearBuiltMin = @"0";
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy"];
        yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
        
    }
    else if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"])
    {
        lblYearBuild.text = [NSString stringWithFormat:@"min-%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
        yearBuiltMin= @"0";
        yearBuiltMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
    }
    else if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
    {
        lblYearBuild.text = [NSString stringWithFormat:@"%ld-max",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
        yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy"];
        yearBuiltMax  = [formatter stringFromDate:[NSDate date]];
    }
    else
    {
        lblYearBuild.text = [NSString stringWithFormat:@"%ld-%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue],(long)[[dataDuplicate objectAtIndex:14] integerValue]];
        yearBuiltMin= [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
        yearBuiltMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
        
    }
    if ([[dataDuplicate objectAtIndex:15]isEqualToString:@"Any"]) {
        
        daysOnMarket =@"0";
    } else {
        daysOnMarket =[NSString stringWithFormat:@"-%@",[dataDuplicate objectAtIndex:15]];
    }
    
    if (![[dataDuplicate objectAtIndex:15]isEqualToString:@"0"]){
        
        lblDaysOnMarket.text = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:15]];
    }
    else
    {
        lblDaysOnMarket.text = @"Any";
    }
    if (![[dataDuplicate objectAtIndex:16] isEqualToString:@"0"]) {
        txtSearchByKeywords.text = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:16]];
        searchByKeyword = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:16]];
        
    }
    else
    {
        txtSearchByKeywords.text = @"";
        searchByKeyword = @"";
    }
    
    [self CallGetTotalPropertyCount];
    [self setUpViewComponents];
}

-(IBAction)resetFilters:(id)sender
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"Do you want to reset filters" preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"Confirm" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self reset];
    }]];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"Not now" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self closeAlertview];
    }]];
    
    dispatch_async(dispatch_get_main_queue(), ^ {
        [self presentViewController:alertController animated:YES completion:nil];
    });
    
}
-(void)closeAlertview
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)reset
{
    NSString *updateColumns = [NSString stringWithFormat:@"UPDATE SoldProperties SET sold_minimum='%d',sold_maximum='%d',location='%@',no_of_beds='%d',no_of_baths='%d',property_type='%@',square_feets_min='%d',square_feets_max='%d',foreclosures='%@',lot_acres_min='%f',lot_acres_max='%f',lot_square_feets_min='%d',lot_square_feets_max='%d',year_built_min='%d',year_built_max='%d',days_on_market='%@',search_by_keywords='%@' where id='1'",0,0,@"0",0,0,@"SF/CA/MF",0,0,@"0",0.0,0.0,0,0,0,0,@"0",@"0"];
    
    [self.dbManager executeQuery:updateColumns];
    [self.lblPriceValue removeFromSuperview];
    [_sliderListPrice removeFromSuperview];
    NSString *existData = @"select * from SoldProperties";
    if (self.propertyDetail != nil)
    {
        self.propertyDetail = nil;
    }
    self.propertyDetail = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:existData]];
    NSLog(@"DATA---%@",_propertyDetail);
    NSLog(@"Count---%lu",(unsigned long)self.propertyDetail.count);
    if (self.propertyDetail.count)
    {
        [self loadDataFromLocalDatabase];
    }
}

-(IBAction)resultButtonTaped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
