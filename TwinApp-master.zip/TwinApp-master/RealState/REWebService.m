//  OpenInstagramController
//  Created by Octal on 28/03/16.

#import "REWebService.h"
#import "CFNetwork/CFHTTPMessage.h"
#import <SystemConfiguration/SCNetworkReachability.h>
#import "SBJSON.h"
#import "Config.h"
#import "Reachability.h"
#import "Utils.h"
#import "AFNetworking.h"
#import "SBAPIManager.h"
#import "MainViewController.h"

@interface REWebService ()

@end



@implementation REWebService


+ (BOOL) IsServerReachable
{
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable)
    {
        return FALSE;
    }else
    {
        return TRUE;
    }
}


+ (NSDictionary *)parse_data:(NSString *)datastring {
    
    SBJsonParser* parser = [[SBJsonParser alloc] init];
    NSArray *arrResult=[[NSArray alloc]init];
    id result = [parser objectWithString:datastring];
    if([result isKindOfClass:[NSArray class]]) {
        arrResult = [parser objectWithString: datastring ];
    } else if( [result isKindOfClass:[NSDictionary class]]) {
        arrResult = [NSArray arrayWithObject : [parser objectWithString:datastring ] ];
    } else if([result isKindOfClass:[NSString class]]){
        arrResult = [NSArray arrayWithObject:datastring];
    }
    
    NSDictionary *dict = [[NSDictionary alloc] init];
    
    if([arrResult count]>0)
    {
        dict = [[arrResult objectAtIndex:0] objectForKey:@"response"];
    }
    
    return dict;
}

+ (void)CallRegistrationWithImage:(NSMutableDictionary *)dict image:(UIImage *)image withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{

    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@register",WebserviceUrl];
        NSData *imageData = UIImagePNGRepresentation(image);
       
       
        AFHTTPRequestOperation *op = [manager POST:urlStr parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData){
            if (imageData){
                
                [formData appendPartWithFileData:imageData name:@"image" fileName:@"image.png" mimeType:@"image/png"];
            }
        } success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            NSError *jsonError;
            NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                 options:NSJSONReadingMutableContainers
                                                                   error:&jsonError];
            block(json,nil);
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            NSLog(@"Error: %@", error);
            block(nil,error);
        }];
        
        [op start];
        
      
    }
}

+ (void)CallLogout:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
    
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@logout",WebserviceUrl];
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                });
            }
            
        }];
        
        
    } else
    {
        
       [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
    }

}

+ (void)CallEnableDisablePush:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@push_enable_disable",WebserviceUrl];
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
        NSData *responseData = (NSData*)responseObject;
        NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
        dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else {
        
     
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)CallFavouriteHomeEmails:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@favorite_email_enable_disable",WebserviceUrl];
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else {
        
      
       [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)CallSendFeedback:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@feedback_save",WebserviceUrl];
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
    } else
    {
      
      [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
    }
}

+ (void)CallGetTermsAndCondition:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@admin_show_terms",WebserviceUrl];
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else {
        
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }

}

+ (void)CallGetPrivacyPolicy:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@feedback_save",WebserviceUrl];
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else{
        
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
    }

}

+ (void)CallGetPropertDataFromServer:(NSMutableDictionary *)dict :(UIViewController *)view :(UIView *)subview withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{

    if ([self IsServerReachable])
    {
        [SBAPIManager cancelAllRequests];
        [view.view addSubview:subview];
        SBAPIManager *manager = [SBAPIManager sharedManager];
        //manager = [AFHTTPRequestOperationManager manager];
        
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
       // get_property_data_development
       // get_property_data
        NSString *urlStr = [NSString stringWithFormat:@"%@get_property_data_development",WebserviceUrl];
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    [subview removeFromSuperview];
                    block(json,nil);
                    NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
               
            }
            
        }];
        
        
        
    } else {
        
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}


+ (void)CallGetPropertCountFromServer:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{

    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@get_property_count",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        NSLog(@"url--->%@",urlStr);
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
           
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)CallGetParticularPropertyDetail:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@get_particular_property_data",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    //NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)CallGetShowingDetail:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@showing_of_client",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    //NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }

}

+ (void)CallGetFavouriteProperties:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@show_favourite",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    //NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }

}
+ (void)addFavouriteProperties:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@add_favourite",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    //NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)deleteFavouriteProperties:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@delete_favourite",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}
+ (void)propertyListingWithPaging:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@get_property_paging_data",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                   
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                  dispatch_async(dispatch_get_main_queue(), ^{
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)savedSearch:(NSMutableDictionary *)dict image:(UIImage *)image withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable])
    {
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@save_saved_search",WebserviceUrl];
        NSData *imageData = UIImagePNGRepresentation(image);
        
        AFHTTPRequestOperation *op = [manager POST:urlStr parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            
            [formData appendPartWithFileData:imageData name:@"image" fileName:@"image.jpeg" mimeType:@"image/jpeg"];
        } success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            NSError *jsonError;
            NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                 options:NSJSONReadingMutableContainers
                                                                   error:&jsonError];
            block(json,nil);
            
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            NSLog(@"Error: %@", error);
            block(nil,error);
            
        }];
        [op start];
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }

}


+ (void)GetsavedSearchList:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@saved_search_list",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)GetParticularSavedSearch:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@saved_search_data",WebserviceUrl];
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }

}


+ (void)CallDrawServiceFromServer:(NSMutableDictionary *)dict :(UIViewController *)view :(UIView *)subview withBlock:(void (^)(NSDictionary * dictResult, NSError *error))block{
    
    if ([self IsServerReachable]){
        [SBAPIManager cancelAllRequests];
        [view.view addSubview:subview];
        SBAPIManager *manager =[SBAPIManager sharedManager];
        manager.requestSerializer=[AFJSONRequestSerializer serializer];
        manager.responseSerializer=[AFHTTPResponseSerializer serializer];
        [manager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
        NSString *urlStr=[NSString stringWithFormat:@"%@draw", WebserviceUrl];
        NSLog(@"UU %@",urlStr);
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject){
            
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    [subview removeFromSuperview];
                    block(json,nil);
                    NSLog(@"Success: %@ ", json);
                }
            });
            
            
            
        }failure:^(AFHTTPRequestOperation *operation, NSError *error){
            
            [subview removeFromSuperview];
            NSLog(@"Error: %@", error.description);
            block(nil, error);
            
            
            
            
        }];
        
    }
}

+ (void)CallSearchWithTextWithPaging:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@search_get_property_paging_data",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    //NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }

}

+ (void)userRelatedData:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@under_user_related_to_showing",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                   
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)showingProperty:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@get_property_list_of_showing",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    //NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }

}

+ (void)disclaimerDetailFromServer:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@disclaimers",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)userRelatedShowingData:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
   
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@get_users_for_showing_add_dropdown",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}



+ (void)showingDataAccordingToLoginUser:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@under_user_related_to_showing_add",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    //NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
    }
}

+ (void)addShowingWithData:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@save_showing_add",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                   dispatch_async(dispatch_get_main_queue(), ^{
                    
                });
            }
            
        }];
        
        
    } else
    {
        
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)addNoteProperty:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@add_note_on_property_description",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    //NSLog(@"Success: %@ ", json);
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
      
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}


+ (void)addImageProperty:(NSMutableDictionary *)dict image:(UIImage *)image withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@add_photo_on_property_description",WebserviceUrl];
        NSData *imageData = UIImagePNGRepresentation(image);
        
        AFHTTPRequestOperation *op = [manager POST:urlStr parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            
            [formData appendPartWithFileData:imageData name:@"image" fileName:@"image.png" mimeType:@"image/png"];
        } success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            NSError *jsonError;
            NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                 options:NSJSONReadingMutableContainers
                                                                   error:&jsonError];
            block(json,nil);
            
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            NSLog(@"Error: %@", error);
            block(nil,error);
        }];
        [op start];
        
        
    }
}

+ (void)checkPropertyIdExistInDb:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@check_property_id",WebserviceUrl];
        NSLog(@"Rk-%@",dict);
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)myAgentList:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@my_agent",WebserviceUrl];
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)AssignedAgentList:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@assigned_agent",WebserviceUrl];
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)sendMailToUsers:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@send_mail_to_users",WebserviceUrl];
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)getUserProfile:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@user_profile",WebserviceUrl];
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}


+ (void)UpdateUserProfile:(NSMutableDictionary *)dict image:(UIImage *)image withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@user_profile_edit",WebserviceUrl];
        NSData *imageData = UIImagePNGRepresentation(image);
        
        AFHTTPRequestOperation *op = [manager POST:urlStr parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            
            [formData appendPartWithFileData:imageData name:@"image" fileName:@"image.jpeg" mimeType:@"image/jpeg"];
        } success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            NSError *jsonError;
            NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                 options:NSJSONReadingMutableContainers
                                                                   error:&jsonError];
            block(json,nil);
            
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            NSLog(@"Error: %@", error);
            block(nil,error);
        }];
        [op start];
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }

}
+ (void)developmentOnOff:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@development_layer_on_off",WebserviceUrl];
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
}

+ (void)deleteSaveSeraches:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@delete_save_search_multiple",WebserviceUrl];
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }

}

+ (void)showFavoriteOnMap:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    if ([self IsServerReachable]){
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@get_property_data_of_favourite",WebserviceUrl];
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
    
}


+ (void)editConnectedClient:(NSMutableDictionary *)dict withBlock:(void (^)(NSDictionary *dictResult, NSError *error))block
{
    
    if ([self IsServerReachable])
    {
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@update_connected_client_profile",WebserviceUrl];
       // NSData *imageData = UIImagePNGRepresentation(image);
        
        AFHTTPRequestOperation *op = [manager POST:urlStr parameters:dict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
            
           // [formData appendPartWithFileData:imageData name:@"image" fileName:@"image.jpeg" mimeType:@"image/jpeg"];
        } success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            NSError *jsonError;
            NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                 options:NSJSONReadingMutableContainers
                                                                   error:&jsonError];
            block(json,nil);
            
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            NSLog(@"Error: %@", error);
            block(nil,error);
        }];
        [op start];
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
    /*
    if ([self IsServerReachable]){
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        [manager.operationQueue cancelAllOperations];
        NSString *urlStr = [NSString stringWithFormat:@"%@update_connected_client_profile",WebserviceUrl];
        [manager POST:urlStr parameters:dict success:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSData *responseData = (NSData*)responseObject;
            NSString *str = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if(responseData !=nil){
                    
                    NSError *jsonError;
                    NSData *objectData = [str dataUsingEncoding:NSUTF8StringEncoding];
                    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                         options:NSJSONReadingMutableContainers
                                                                           error:&jsonError];
                    block(json,nil);
                    
                }
            });
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            if(error)
            {
                NSLog(@"Error: %@", error);
                block(nil,error);
                
            }else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    
                });
            }
            
        }];
        
        
    } else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please check your internet connection."];
        
    }
     */
}
@end
