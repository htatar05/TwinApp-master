//
//  SortTvCellView.h
//  RealState
//
//  Created by Kapil Goyal on 12/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SortTvCellView : UITableViewCell
{
}
@property(nonatomic,strong)IBOutlet UILabel *lblSortType;
@property(nonatomic,strong)IBOutlet UIImageView *imgCheck;

@end
