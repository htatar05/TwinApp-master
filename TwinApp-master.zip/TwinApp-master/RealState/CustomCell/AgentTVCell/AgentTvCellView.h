//
//  SortTvCellView.h
//  RealState
//
//  Created by Kapil Goyal on 12/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EGOImageView.h"

@interface AgentTvCellView : UITableViewCell
{
}
@property(nonatomic,strong)IBOutlet UIImageView *imgBackground;
@property(nonatomic,strong)IBOutlet EGOImageView *imgUserPhoto;
@property(nonatomic,strong)IBOutlet UILabel *lblUserName;
@property(nonatomic,strong)IBOutlet UILabel *lblUserEmailId;
@property(nonatomic,strong)IBOutlet UILabel *lblUserPhone;

@end
