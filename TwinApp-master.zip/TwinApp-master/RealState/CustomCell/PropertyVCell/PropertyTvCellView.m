//
//  SortTvCellView.m
//  RealState
//
//  Created by Kapil Goyal on 12/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "PropertyTvCellView.h"

@implementation PropertyTvCellView
@synthesize imgBackground,lblHomeType,lblPhotoCount,lblSaleType,lblAddress,lblBedBath,lblOpenHouse,lblPrice,imgViewProperty,imgViewPropertyType,btnRemoveMarket,lblAddress1;


/*
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (void)setSelectedBackgroundView:(UIView *)selectedBackgroundView
{
    //Cell Selected Color: CLEAR
    [super setSelectedBackgroundView:selectedBackgroundView];
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    //Cell Edit Mode NO Indent & Selected Color: CLEAR
    [super setEditing:NO animated:animated];
    [self setNeedsLayout];
}
*/
@end
