//
//  ShowingPropertyCell.m
//  RealEstate_App
//
//  Created by Octal on 23/12/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import "ShowingPropertyCell.h"

@implementation ShowingPropertyCell

@synthesize imgBackground,lblHomeType,lblPhotoCount,lblSaleType,lblAddress,lblBedBath,lblOpenHouse,lblPrice,imgViewProperty,imgViewPropertyType,btnRemoveMarket,lblAgentName,lblAgentCell;


- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
