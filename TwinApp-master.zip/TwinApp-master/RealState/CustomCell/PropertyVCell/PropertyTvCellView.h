//
//  SortTvCellView.h
//  RealState
//
//  Created by Kapil Goyal on 12/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PropertyTvCellView : UITableViewCell
{
    
}
@property(nonatomic,strong)IBOutlet UIImageView *imgBackground;
@property(nonatomic,strong)IBOutlet UIImageView *imgViewProperty;
@property(nonatomic,strong)IBOutlet UIImageView *imgViewPropertyType;
@property(nonatomic,strong)IBOutlet UILabel *lblHomeType;
@property(nonatomic,strong)IBOutlet UILabel *lblPhotoCount;
@property(nonatomic,strong)IBOutlet UILabel *lblSaleType;
@property(nonatomic,strong)IBOutlet UILabel *lblAddress;
@property(nonatomic,strong)IBOutlet UILabel *lblAddress1;
@property(nonatomic,strong)IBOutlet UILabel *lblBedBath;
@property(nonatomic,strong)IBOutlet UILabel *lblOpenHouse;
@property(nonatomic,strong)IBOutlet UILabel *lblPrice;
@property(nonatomic,strong)IBOutlet UILabel *lblListingCourtesy;
@property(nonatomic,retain)IBOutlet UIButton *btnRemoveMarket;
@property(nonatomic,strong)IBOutlet UIImageView *sepLine;

@end
