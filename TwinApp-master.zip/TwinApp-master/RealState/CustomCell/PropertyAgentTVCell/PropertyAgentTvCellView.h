//
//  SortTvCellView.h
//  RealState
//
//  Created by Kapil Goyal on 12/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PropertyAgentTvCellView : UITableViewCell
{
}
@property(nonatomic,strong)IBOutlet UIImageView *imgBackground;
@property(nonatomic,strong)IBOutlet UIImageView *imgAgentPhoto;
@property(nonatomic,strong)IBOutlet UILabel *lblAgentName;
@property(nonatomic,strong)IBOutlet UILabel *lblReview;
@property(nonatomic,strong)IBOutlet UILabel *lblAgentType;
@property(nonatomic,strong)IBOutlet UIButton *btnCheck;
@property(nonatomic,strong)IBOutlet UIButton *btnMessage;
@property(nonatomic,strong)IBOutlet UIButton *btnPhone;
@property(nonatomic,strong)IBOutlet UIImageView *imgRate1;
@property(nonatomic,strong)IBOutlet UIImageView *imgRate2;
@property(nonatomic,strong)IBOutlet UIImageView *imgRate3;
@property(nonatomic,strong)IBOutlet UIImageView *imgRate4;
@property(nonatomic,strong)IBOutlet UIImageView *imgRate5;
@property(nonatomic,assign)BOOL boolCheck;

@end
