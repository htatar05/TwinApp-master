//
//  SortTvCellView.m
//  RealState
//
//  Created by Kapil Goyal on 12/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "PropertyAgentTvCellView.h"

@implementation PropertyAgentTvCellView
@synthesize imgBackground,imgAgentPhoto, imgRate1,imgRate2,imgRate3,imgRate4,imgRate5,btnCheck,btnMessage,btnPhone,lblAgentName,lblAgentType,lblReview,boolCheck;



@end
