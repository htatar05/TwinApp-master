//  RentSettingController.m
//  RealEstate_App
//  Created by Octal on 06/09/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.


#import "RentSettingController.h"
#import "MARKRangeSlider.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "Utils.h"
#import "AppDelegate.h"
#import "DBManager.h"
#import "PropertyTypeViewController.h"
#import "JSON.h"
#import "PropertyType/PropertyType.h"


static CGFloat const kViewControllerRangeSliderWidth = 290.0;
static CGFloat const kViewControllerLabelWidth = 100.0;


@interface RentSettingController ()

@property (nonatomic, strong) MARKRangeSlider *sliderListPrice;
@property (nonatomic, strong) UILabel *lblPriceValue;



@end

@implementation RentSettingController
{
    NSString *strPriceMinimum;
    NSString *strPriceMaximum;
    NSString *strFullAddress;
    NSString *strSelectedBaths;
    NSString *strSelectedBeds;
    NSString *strPropertyType;
    NSString *strSquareFeetMin;
    NSString *strSquareFeetMax;
    NSString *strLotsizeMin;
    NSString *strLotsizeMax;
    NSString *strLotAcreMin;
    NSString *strLotAcreMax;
    NSString *strPetPolicy;
    NSString *strYearMin;
    NSString *strYearMax;
    NSString *strDaysOnMarket;
    NSString *strSearchByKeywords;
    NSString *strForclosures;
    NSString *strShortSale;
    NSString *searchByKeyword;
    NSMutableString *propertyType;
    
    
    NSMutableArray *squareFeetMini;
    NSMutableArray *squareFeetMaxi;
    NSMutableArray *lotSquaremini;
    NSMutableArray *lotSquaremaxi;
    NSMutableArray *yearsMini;
    NSMutableArray * yearsMaxi;
    NSMutableArray *acresMini;
    NSMutableArray * acresMaxi;
    NSMutableArray * petPolicyArr;
    NSArray *dataDuplicate;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _delegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
  
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"RealEstate.sqlite"];
   // [self addKeyboardControls];
    
    squareFeetMini = [[NSMutableArray alloc]initWithObjects:@"minimum",@"100",@"200",@"300",@"400",@"500",@"600",@"700",@"800",@"900",@"1000",@"1100",@"1200",@"1300",@"1400",@"1500",@"1600",@"1700",@"1800",@"1900",@"2000",@"2100",@"2200",@"2300",@"2400",@"2500",@"2600",@"2700",@"2800",@"2900",@"3000",@"3100",@"3200",@"3300",@"3400",@"3500",@"3600",@"3700",@"3800",@"3900",@"4000",@"4500",@"5000",@"5500",@"6000",@"7000",@"8000",@"9000",@"10000", nil];
    
    squareFeetMaxi = [[NSMutableArray alloc]initWithObjects:@"100",@"200",@"300",@"400",@"500",@"600",@"700",@"800",@"900",@"1000",@"1100",@"1200",@"1300",@"1400",@"1500",@"1600",@"1700",@"1800",@"1900",@"2000",@"2100",@"2200",@"2300",@"2400",@"2500",@"2600",@"2700",@"2800",@"2900",@"3000",@"3100",@"3200",@"3300",@"3400",@"3500",@"3600",@"3700",@"3800",@"3900",@"4000",@"4500",@"5000",@"5500",@"6000",@"7000",@"8000",@"9000",@"10000",@"maximum", nil];
    
    viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, 260);
    [self.view addSubview:viewSelect];
    
    UIColor *borderColor = [UIColor colorWithRed:59.0/255.0 green:132.0/255.0 blue:229.0/255.0 alpha:1.0];
    txtLocationView.layer.borderColor = borderColor.CGColor;
    
    txtLocationView.layer.cornerRadius=8.0f;
    txtLocationView.layer.masksToBounds=YES;
    txtLocationView.layer.borderWidth= 1.0f;
    txtSearchKeywordsView.layer.cornerRadius=8.0f;
    txtSearchKeywordsView.layer.masksToBounds=YES;
    txtSearchKeywordsView.layer.borderColor=borderColor.CGColor;
    txtSearchKeywordsView.layer.borderWidth= 1.0f;
    
    txtLocation.delegate = self;
    txtSearchByKeywords.delegate = self;
    
    btnLocationDelete.layer.cornerRadius = 9.0;
    btnSearchKeyDelete.layer.cornerRadius = 9.0;
    
}


-(void)viewWillAppear:(BOOL)animated
{
    [self.lblPriceValue removeFromSuperview];
    [_sliderListPrice removeFromSuperview];
    NSString *existData = @"select * from RentProperties";
    if (self.propertyDetail != nil)
    {
        self.propertyDetail = nil;
    }
    self.propertyDetail = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:existData]];
    NSLog(@"DATA---%@",_propertyDetail);
    NSLog(@"Count---%lu",(unsigned long)self.propertyDetail.count);
    if (self.propertyDetail.count)
    {
        [self loadDataFromLocalDatabase];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark Actions


-(IBAction)locationDeleteButton:(id)sender
{
    txtLocation.text = @"";
    [txtLocation becomeFirstResponder];
    
}

-(IBAction)searchDeleteButton:(id)sender
{
    txtSearchByKeywords.text = @"";
    [txtSearchByKeywords becomeFirstResponder];
}
-(IBAction)backButtonClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)selectBeds:(id)sender
{
    strSelectedBeds = [NSString stringWithFormat:@"%ld",bedSegment.selectedSegmentIndex];
    NSString *update = [NSString stringWithFormat:@"update RentProperties SET no_of_beds='%ld' where id='1'",bedSegment.selectedSegmentIndex];
    [self.dbManager executeQuery:update];
    [self CallGetTotalPropertyCount];
}

-(IBAction)selectBathroom:(id)sender
{
    strSelectedBaths = [NSString stringWithFormat:@"%ld",bathroomSegment.selectedSegmentIndex];
    NSLog(@"%ld",(long)bathroomSegment.selectedSegmentIndex);
    NSString *update = [NSString stringWithFormat:@"update RentProperties SET no_of_baths='%ld' where id='1'",bathroomSegment.selectedSegmentIndex];
    [self.dbManager executeQuery:update];
    [self CallGetTotalPropertyCount];
}

-(IBAction)selectPetPolicy:(id)sender
{
    petPolicyArr = [[NSMutableArray alloc]initWithObjects:@"Limits",@"No Approval Needed",@"Not Allowed",@"With Approval", nil];
    
    NSInteger selectedIndex = 0;
    for (NSInteger i = 0; i<petPolicyArr.count; i++) {
        
        if ([strPetPolicy isEqualToString:[petPolicyArr objectAtIndex:i]]) {
            selectedIndex = i;
        }
    }
    
    acresSegment.hidden = YES;
    lblPickerTitle.hidden = NO;
    lblPickerTitle.text = @"Pet Policy";
    strPickerType = @"petPolicy";
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
    [UIView commitAnimations];
    Picker.tag=1;
    [Picker reloadInputViews];
    [Picker reloadAllComponents];
    
    [Picker selectRow:selectedIndex inComponent:0 animated:YES];
    [self.view addSubview:viewSelect];
    [viewSelect bringSubviewToFront:self.view];
}


-(IBAction)selectPropertyType:(id)sender
{
    /*
    PropertyTypeViewController *thetype = [[PropertyTypeViewController alloc]initWithNibName:@"PropertyTypeViewController_iPhone" bundle:nil];
    thetype.PropertyType = @"property_type";
    thetype.selectedPropertyType = [dataDuplicate objectAtIndex:5];
    thetype.isFrom = @"RentProperties";
    [self.navigationController pushViewController:thetype animated:YES];
    */
    PropertyType *thetype;
    if (IS_IPHONE) {
        
        thetype = [[PropertyType alloc]initWithNibName:@"PropertyType" bundle:nil];
    } else {
        thetype = [[PropertyType alloc]initWithNibName:@"PropertyType_iPad" bundle:nil];
    }
    thetype.selectedPropertyType = [dataDuplicate objectAtIndex:5];
    thetype.isFrom = @"RentProperties";
    [self.navigationController pushViewController:thetype animated:YES];
    
}

-(IBAction)selectSquareFeet:(id)sender
{
    
    NSInteger min = 0;
    NSInteger max = 0;
    NSInteger setselectedmin = 0;
    NSInteger setselectedmax = 0;
    min = [[dataDuplicate objectAtIndex:6] integerValue];
    max = [[dataDuplicate objectAtIndex:7] integerValue];
    
    for (NSInteger i = 0; i<squareFeetMini.count; i++)
    {
        if (min==[[squareFeetMini objectAtIndex:i] integerValue])
        {
            NSLog(@" minimum %ld",(long)i);
            setselectedmin = i;
        }
        if (max==[[squareFeetMaxi objectAtIndex:i] integerValue])
        {
            NSLog(@" maximum %ld",(long)i);
            setselectedmax = i;
        }
    }
    
    acresSegment.hidden = YES;
    lblPickerTitle.hidden = NO;
    lblPickerTitle.text = @"Square Feet";
    strPickerType = @"SquareFeet";
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
     [UIView commitAnimations];
     Picker.tag=1;
    [Picker reloadInputViews];
    [Picker reloadAllComponents];
    [Picker selectRow:setselectedmin inComponent:0 animated:YES];
    [Picker selectRow:setselectedmax inComponent:2 animated:YES];
    [self.view addSubview:viewSelect];
    [viewSelect bringSubviewToFront:self.view];
    
}

-(IBAction)selectLotSize:(id)sender
{
    strPickerType = @"LotSize";
    lotSquaremini = [[NSMutableArray alloc]init];
    lotSquaremaxi = [[NSMutableArray alloc]init];
    
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"RentPropertyLotType"]isEqualToString:@"SQFT"]) {
        
        NSInteger min = 0;
        NSInteger max = 0;
        NSInteger setselectedmin = 0;
        NSInteger setselectedmax = 0;
        min = [[dataDuplicate objectAtIndex:8] integerValue];
        max = [[dataDuplicate objectAtIndex:9] integerValue];
        
        if (lotSquaremini.count==0) {
            NSInteger myInt = [@"minimum" intValue];
            [lotSquaremini addObject:[NSNumber numberWithInteger:myInt]];
            PickerSubType = @"SQFT";
            NSInteger j = 0;
            for (NSInteger i = 1; i<=70; i++)
            {
                if (i<=50) {
                    j = i*1000;
                }
                else{
                    j = j+10000;
                }
                [lotSquaremini addObject:[NSNumber numberWithInteger:j]];
                [lotSquaremaxi addObject:[NSNumber numberWithInteger:j]];
            }
            NSInteger myIntmax = [@"maximum" intValue];
            [lotSquaremaxi addObject:[NSNumber numberWithInteger:myIntmax]];
            
        }
        
        for (NSInteger i = 0; i<lotSquaremini.count; i++)
        {
            if (min==[[lotSquaremini objectAtIndex:i] integerValue])
            {
                NSLog(@" minimum %ld",(long)i);
                setselectedmin = i;
            }
            if (max==[[lotSquaremaxi objectAtIndex:i] integerValue])
            {
                NSLog(@" maximum %ld",(long)i);
                setselectedmax = i;
            }
        }
        
        
        [Picker reloadInputViews];
        [Picker reloadAllComponents];
        [Picker selectRow:setselectedmin inComponent:0 animated:YES];
        [Picker selectRow:setselectedmax inComponent:2 animated:YES];
        
        acresSegment.hidden = NO;
        lblPickerTitle.hidden = YES;
        lblPickerTitle.hidden = YES;
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
        [UIView commitAnimations];
        Picker.tag=1;
        [self.view addSubview:viewSelect];
        [viewSelect bringSubviewToFront:self.view];
        
    } else{
        PickerSubType = @"Acres";
        acresMini =  [[NSMutableArray alloc]initWithObjects:@"minimum",@"0.5",@"1",@"1.5",@"2",@"2.5",@"3",@"3.5",@"4",@"4.5",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25", nil];
        
        acresMaxi =  [[NSMutableArray alloc]initWithObjects:@"0.5",@"1",@"1.5",@"2",@"2.5",@"3",@"3.5",@"4",@"4.5",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"maximum", nil];
        
        
        
        NSInteger min = 0;
        NSInteger max = 0;
        NSInteger setselectedmin = 0;
        NSInteger setselectedmax = 0;
        min = [[dataDuplicate objectAtIndex:11] integerValue];
        max = [[dataDuplicate objectAtIndex:12] integerValue];
        
        for (NSInteger i = 0; i<acresMini.count; i++)
        {
            if (min==[[acresMini objectAtIndex:i] integerValue])
            {
                NSLog(@" minimum %ld",(long)i);
                setselectedmin = i;
            }
            if (max==[[acresMaxi objectAtIndex:i] integerValue])
            {
                NSLog(@" maximum %ld",(long)i);
                setselectedmax = i;
            }
        }
        
        
        [Picker reloadInputViews];
        [Picker reloadAllComponents];
        [Picker selectRow:setselectedmin inComponent:0 animated:YES];
        [Picker selectRow:setselectedmax inComponent:2 animated:YES];
        acresSegment.hidden = NO;
        lblPickerTitle.hidden = YES;
        lblPickerTitle.hidden = YES;
        
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
        [UIView commitAnimations];
        Picker.tag=1;
        [self.view addSubview:viewSelect];
        [viewSelect bringSubviewToFront:self.view];
        
    }
}

-(IBAction)selectYearBuild:(id)sender
{
    yearsMini = [[NSMutableArray alloc]init];
    yearsMaxi  = [[NSMutableArray alloc]init];
    [yearsMini addObject:@"minimum"];
    for (NSInteger i = 0; i<=116; i++)
    {
        NSInteger j = 1900;
        j = j+i;
        
        [yearsMini addObject:[NSNumber numberWithInteger:j]];
        [yearsMaxi addObject:[NSNumber numberWithInteger:j]];
    }
    [yearsMaxi addObject:@"maximum"];
    
    
    NSInteger min = 0;
    NSInteger max = 0;
    NSInteger setselectedmin = 0;
    NSInteger setselectedmax = 0;
    min = [[dataDuplicate objectAtIndex:13] integerValue];
    max = [[dataDuplicate objectAtIndex:14] integerValue];
    for (NSInteger i = 0; i<yearsMini.count; i++)
    {
        if (min==[[yearsMini objectAtIndex:i] integerValue])
        {
            NSLog(@" minimum %ld",(long)i);
            setselectedmin = i;
        }
        if (max==[[yearsMaxi objectAtIndex:i] integerValue])
        {
            NSLog(@" maximum %ld",(long)i);
            setselectedmax = i;
        }
    }
    
    acresSegment.hidden = YES;
    lblPickerTitle.hidden = NO;
    lblPickerTitle.text = @"Year Built";
    strPickerType = @"YearBuild";
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewSelect.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height-260, [UIScreen mainScreen].bounds.size.width, 260);
    [UIView commitAnimations];
    Picker.tag=1;
    [Picker reloadInputViews];
    [Picker reloadAllComponents];
    
    [Picker selectRow:setselectedmin inComponent:0 animated:YES];
    [Picker selectRow:setselectedmax inComponent:2 animated:YES];
    
    [self.view addSubview:viewSelect];
    [viewSelect bringSubviewToFront:self.view];
}


-(IBAction)selectAreaType:(id)sender
{
    NSInteger min = 0;
    NSInteger max = 0;
    NSInteger setselectedmin = 0;
    NSInteger setselectedmax = 0;
    
    if (acresSegment.selectedSegmentIndex==0)
    {
        lotSquaremini = [[NSMutableArray alloc]init];
        lotSquaremaxi = [[NSMutableArray alloc]init];
        [[NSUserDefaults standardUserDefaults] setValue:@"SQFT" forKey:@"RentPropertyLotType"];
         PickerSubType = @"SQFT";
        if (lotSquaremini.count == 0) {
            [lotSquaremini addObject:@"minimum"];
           
            NSInteger j = 0;
            for (NSInteger i = 1; i<=70; i++)
            {
                if (i<=50){
                    
                    j = i*1000;
                }
                else{
                    j = j+10000;
                }
                [lotSquaremini addObject:[NSNumber numberWithInteger:j]];
                [lotSquaremaxi addObject:[NSNumber numberWithInteger:j]];
            }
            [lotSquaremaxi addObject:@"maximum"];
        }
        
        min = [[dataDuplicate objectAtIndex:8] integerValue];
        max = [[dataDuplicate objectAtIndex:9] integerValue];
        
        for (NSInteger i = 0; i<lotSquaremini.count; i++)
        {
            if (min==[[lotSquaremini objectAtIndex:i] integerValue])
            {
                NSLog(@" minimum %ld",(long)i);
                setselectedmin = i;
            }
            if (max==[[lotSquaremaxi objectAtIndex:i] integerValue])
            {
                NSLog(@" maximum %ld",(long)i);
                setselectedmax = i;
            }
        }
        
        [Picker reloadInputViews];
        [Picker reloadAllComponents];
        [Picker selectRow:setselectedmin inComponent:0 animated:YES];
        [Picker selectRow:setselectedmax inComponent:2 animated:YES];
        
    }
    else
    {
       [[NSUserDefaults standardUserDefaults] setValue:@"Acres" forKey:@"RentPropertyLotType"];
        PickerSubType = @"Acres";
        acresMini =  [[NSMutableArray alloc]initWithObjects:@"minimum",@"0.5",@"1",@"1.5",@"2",@"2.5",@"3",@"3.5",@"4",@"4.5",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25", nil];
        
        acresMaxi =  [[NSMutableArray alloc]initWithObjects:@"0.5",@"1",@"1.5",@"2",@"2.5",@"3",@"3.5",@"4",@"4.5",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25",@"maximum", nil];
        
        
        min = [[dataDuplicate objectAtIndex:11] integerValue];
        max = [[dataDuplicate objectAtIndex:12] integerValue];
        
        for (NSInteger i = 0; i<acresMini.count; i++)
        {
            if (min==[[acresMini objectAtIndex:i] integerValue])
            {
                NSLog(@" minimum %ld",(long)i);
                setselectedmin = i;
            }
            if (max==[[acresMaxi objectAtIndex:i] integerValue])
            {
                NSLog(@" maximum %ld",(long)i);
                setselectedmax = i;
            }
        }
        [Picker reloadInputViews];
        [Picker reloadAllComponents];
        [Picker selectRow:setselectedmin inComponent:0 animated:YES];
        [Picker selectRow:setselectedmax inComponent:2 animated:YES];
        
    }
    
}

-(IBAction)selectDaysOnMarket:(id)sender
{
    PropertyTypeViewController *thetype ;
    if (IS_IPHONE) {
        thetype = [[PropertyTypeViewController alloc]initWithNibName:@"PropertyTypeViewController_iPhone" bundle:nil];
    } else {
        thetype = [[PropertyTypeViewController alloc]initWithNibName:@"PropertyTypeViewController_iPad" bundle:nil];
    }
    
    thetype.PropertyType = @"Number_of_days";
    thetype.selectedDays = [dataDuplicate objectAtIndex:15];
    thetype.isFrom = @"RentProperties";
    [self.navigationController pushViewController:thetype animated:YES];
}

-(IBAction)switchRecentlyRented:(id)sender
{
    if (recentlyRentSwitch.on )
    {
        NSString *update = [NSString stringWithFormat:@"update RentProperties SET recently_rented='Yes' where id='1'"];
        [self.dbManager executeQuery:update];
    }
    else
    {
        NSString *update = [NSString stringWithFormat:@"update RentProperties SET recently_rented='No' where id='1'"];
        [self.dbManager executeQuery:update];
    }
}

- (void)setUpViewComponents
{
    self.lblPriceValue = [[UILabel alloc] initWithFrame:CGRectZero];
    self.lblPriceValue.backgroundColor = [UIColor whiteColor];
    self.lblPriceValue.numberOfLines = 1;
    self.lblPriceValue.font = [UIFont systemFontOfSize:12];
    self.lblPriceValue.textColor = [UIColor whiteColor];
    self.lblPriceValue.backgroundColor = [UIColor blackColor];
    
    self.sliderListPrice = [[MARKRangeSlider alloc] initWithFrame:CGRectZero];
    self.sliderListPrice.backgroundColor = [UIColor whiteColor];
    [self.sliderListPrice addTarget:self
                             action:@selector(listPriceValueDidChange:)
                   forControlEvents:UIControlEventValueChanged];
    
    [self.sliderListPrice addTarget:self
                             action:@selector(dragEndedForSlider1:)
                   forControlEvents:UIControlEventTouchUpOutside];
    
    [self.sliderListPrice setMinValue:0 maxValue:50000000];
    [self.sliderListPrice setLeftValue:[strPriceMinimum floatValue] rightValue:[strPriceMaximum floatValue]];
    self.sliderListPrice.minimumDistance = 6000000;
    [self updateListPriceText];
    [_myScrollView addSubview:self.lblPriceValue];
    [_myScrollView addSubview:self.sliderListPrice];
}

- (void)listPriceValueDidChange:(MARKRangeSlider *)slider
{
    [self updateListPriceText];
}

-(void)dragEndedForSlider1:(MARKRangeSlider *)slider
{
    double miniFinal;
    double maximumFinal;
    
    miniFinal = [[NSString stringWithFormat:@"%0.0f",self.sliderListPrice.leftValue] doubleValue];
    maximumFinal= [[NSString stringWithFormat:@"%0.0f",self.sliderListPrice.rightValue] doubleValue];
    
    strPriceMinimum = [NSString stringWithFormat:@"%0.0f",miniFinal];
    strPriceMaximum = [NSString stringWithFormat:@"%0.0f",maximumFinal];
    
    NSString *update = [NSString stringWithFormat:@"update RentProperties SET rental_min='%@',rental_max='%@' where id='1'",strPriceMinimum,strPriceMaximum];
    [self.dbManager executeQuery:update];
    [self CallGetTotalPropertyCount];
}
- (void)updateListPriceText
{
    NSString *str1 = [self abbreviateNumber:self.sliderListPrice.leftValue];
    NSString *str2 = [self abbreviateNumber:self.sliderListPrice.rightValue];
    self.lblPriceValue.text = [NSString stringWithFormat:@"$%@ - $%@",
                               str1, str2];
    
}

-(NSString *)abbreviateNumber:(int)num {
    
    NSString *abbrevNum;
    float number = (float)num;
    
    //Prevent numbers smaller than 1000 to return NULL
    if (num >= 1000) {
        NSArray *abbrev = @[@"K", @"M", @"B"];
        
        for (int i = abbrev.count - 1; i >= 0; i--) {
            
            // Convert array index to "1000", "1000000", etc
            int size = pow(10,(i+1)*3);
            
            if(size <= number) {
                // Removed the round and dec to make sure small numbers are included like: 1.1K instead of 1K
                number = number/size;
                NSString *numberString = [self floatToString:number];
                
                // Add the letter for the abbreviation
                abbrevNum = [NSString stringWithFormat:@"%@%@", numberString, [abbrev objectAtIndex:i]];
            }
            
        }
    } else {
        
        // Numbers like: 999 returns 999 instead of NULL
        abbrevNum = [NSString stringWithFormat:@"%d", (int)number];
    }
    
    return abbrevNum;
}

- (NSString *) floatToString:(float) val {
    NSString *ret = [NSString stringWithFormat:@"%.1f", val];
    unichar c = [ret characterAtIndex:[ret length] - 1];
    
    while (c == 48) { // 0
        ret = [ret substringToIndex:[ret length] - 1];
        c = [ret characterAtIndex:[ret length] - 1];
        
        //After finding the "." we know that everything left is the decimal number, so get a substring excluding the "."
        if(c == 46) { // .
            ret = [ret substringToIndex:[ret length] - 1];
        }
    }
    
    return ret;
}

-(NSString *)convertNumberIntoK:(int)num {
    
    NSString *abbrevNum;
    float number = (float)num;
    
    //Prevent numbers smaller than 1000 to return NULL
    if (num >= 1000) {
        NSArray *abbrev = @[@"K", @"M", @"B"];
        
        for (int i = abbrev.count - 1; i >= 0; i--) {
            
            // Convert array index to "1000", "1000000", etc
            int size = pow(10,(i+1)*3);
            
            if(size <= number) {
                // Removed the round and dec to make sure small numbers are included like: 1.1K instead of 1K
                number = number/size;
                NSString *numberString =  [NSString stringWithFormat:@"%.0f",number]; //[self floatToString2:number];
                
                // Add the letter for the abbreviation
                abbrevNum = [NSString stringWithFormat:@"%@%@", numberString, [abbrev objectAtIndex:i]];
            }
            
        }
    } else {
        
       
        abbrevNum = [NSString stringWithFormat:@"%d", (int)number];
    }
    
    return abbrevNum;
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    self.lblPriceValue.textAlignment = NSTextAlignmentCenter;
    CGFloat labelX = (CGRectGetWidth(self.view.frame) - kViewControllerLabelWidth) / 2;
    self.lblPriceValue.frame = CGRectMake(labelX, 25.0, kViewControllerLabelWidth, 18.0);
    CGFloat sliderX = (CGRectGetWidth(self.view.frame) - kViewControllerRangeSliderWidth) / 2;
    self.sliderListPrice.frame = CGRectMake(sliderX, CGRectGetMaxY(self.lblPriceValue.frame) + 15.0, 290.0, 12.0);
    if (IS_IPHONE) {
         _myScrollView.contentSize = CGSizeMake(self.view.bounds.size.width, 790);
    } else {
        
         _myScrollView.contentSize = CGSizeMake(self.view.bounds.size.width, 950);
    }
   
}
-(void)CallGetTotalPropertyCount
{
    [MBProgressHUD showHUDAddedTo:_delegate.window animated:YES];
    NSMutableDictionary *dataDict = [[NSMutableDictionary alloc]init];
    [dataDict setValue:self.strLat1 forKey:@"latitude1"];
    [dataDict setValue:self.strLat2 forKey:@"longitude1"];
    [dataDict setValue:self.strLat3 forKey:@"latitude2"];
    [dataDict setValue:self.strLat4 forKey:@"longitude2"];
    [dataDict setValue:strPriceMinimum forKey:@"pricerented1"];
    [dataDict setValue:strPriceMaximum forKey:@"pricerented2"];
    [dataDict setValue:strFullAddress forKey:@"fulladdress"];
    [dataDict setValue:strSelectedBaths forKey:@"totalfullbaths"];
    [dataDict setValue:strSelectedBeds forKey:@"numbedrooms"];
    [dataDict setValue:strPropertyType forKey:@"propertytype"];
    [dataDict setValue:strSquareFeetMin forKey:@"sqft1"];
    [dataDict setValue:strSquareFeetMax forKey:@"sqft2"];
    [dataDict setValue:strPetPolicy forKey:@"pet_policy"];
     if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"RentPropertyLotType"]isEqualToString:@"SQFT"])
     {
         [dataDict setValue:strLotsizeMin forKey:@"lot_size_square1"];
         [dataDict setValue:strLotsizeMax forKey:@"lot_size_square2"];
     }
     else
     {
         [dataDict setValue:strLotAcreMin forKey:@"lot_size_acres1"];
         [dataDict setValue:strLotAcreMax forKey:@"lot_size_acres2"];
     }
    
    [dataDict setValue:strYearMin forKey:@"yearbuilt1"];
    [dataDict setValue:strYearMax forKey:@"yearbuilt2"];
    [dataDict setValue:strDaysOnMarket forKey:@"days_on_market"];
    [dataDict setValue:searchByKeyword forKey:@"search_by_keyword"];
    [dataDict setValue:@"for_rent" forKey:@"status"];
    [dataDict setValue:[[NSUserDefaults standardUserDefaults] valueForKey:@"user_id"] forKey:@"user_id"];
    NSLog(@"[bodyD JSONRepresentation]:%@",[dataDict JSONRepresentation]);
    [REWebService CallGetPropertCountFromServer:dataDict withBlock:^(NSDictionary *dictResult, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self->_delegate.window animated:YES];
        NSLog( @"%@",dictResult);
        
        if (!error) {
            
            if ([[[dictResult objectForKey:@"response"] objectForKey:@"message"]isEqualToString:@"success"]) {
                
                int final = (int)[[[dictResult objectForKey:@"response"] objectForKey:@"count"] integerValue];
                
                NSString *str1 = [self convertNumberIntoK:final];
                self->lblTotalCount.text = [NSString stringWithFormat:@"%@ Results",str1];
                
                
            } else
            {
                self->lblTotalCount.text = @"0 Results";
            }
            
        }
        
    }];
}


#pragma mark UIPicker view
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView;
{
    if ([strPickerType isEqualToString:@"petPolicy"]) {
        return 1;
    } else {
        return 3;
    }
    
}


- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
    
    
    if ([strPickerType isEqualToString:@"petPolicy"]) {
        
        return self.view.frame.size.width;
        
    } else {
        switch (component)
        {
            case 0:
                return (self.view.frame.size.width/2)-40;
            case 1:
                return 50.0f;
            case 2:
                return (self.view.frame.size.width/2)-40;
        }
    }
    
    return self.view.frame.size.width;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;
{
    
    if ([strPickerType isEqualToString:@"SquareFeet"])
    {
        switch (component)
        {
            case 0:
                return squareFeetMini.count;;
                break;
            case 1:
                return 1;
                break;
            case 2:
                return squareFeetMaxi.count;;
                break;
            default:
                break;
        }
        
    }
    
    else if ([strPickerType isEqualToString:@"LotSize"])
    {
        if ([PickerSubType isEqualToString:@"Acres"]){
            
            switch (component)
            {
                case 0:
                    return acresMini.count;
                    break;
                case 1:
                    return 1;
                    break;
                case 2:
                    return acresMaxi.count;
                    break;
                default:
                    break;
            }
        }
        else
        {
            switch (component)
            {
                case 0:
                    return lotSquaremini.count;
                    break;
                case 1:
                    return 1;
                    break;
                case 2:
                    return lotSquaremaxi.count;
                    break;
                default:
                    break;
            }
            
        }
        
    }
    else if ([strPickerType isEqualToString:@"petPolicy"])
    {
        return petPolicyArr.count;
        
    }
    else
    {
        switch (component)
        {
            case 0:
                return yearsMini.count;
                break;
            case 1:
                return 1;
                break;
            case 2:
                return yearsMaxi.count;
                break;
            default:
                break;
        }
    }
    return 1;
    
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSInteger mini = 0;
    NSInteger maxi = 0;
    if ([strPickerType isEqualToString:@"SquareFeet"])
    {
        switch (component) {
            case 0:
            {
                mini = [[squareFeetMini objectAtIndex:row] integerValue];
                maxi = [[squareFeetMaxi objectAtIndex:[pickerView selectedRowInComponent:2]] integerValue];
                if (mini>=maxi && maxi!=0)
                {
                    [Picker selectRow:row inComponent:2 animated:YES];
                }
                break;
            }
            case 2:
            {
                maxi = [[squareFeetMaxi objectAtIndex:row] integerValue];
                mini = [[squareFeetMini objectAtIndex:[pickerView selectedRowInComponent:0]] integerValue];
                if (maxi<=mini && mini!=0)
                {
                    [Picker selectRow:row inComponent:0 animated:YES];
                    
                }
                break;
            }
            default:
                break;
        }
    }
    else if ([strPickerType isEqualToString:@"LotSize"])
    {
        if ([PickerSubType isEqualToString:@"Acres"]) {
            switch (component) {
                case 0:
                    mini = [[acresMini objectAtIndex:row] integerValue];
                    maxi = [[acresMaxi objectAtIndex:[pickerView selectedRowInComponent:2]] integerValue];
                    
                    if (mini>=maxi && maxi!=0)
                    {
                        [Picker selectRow:row inComponent:2 animated:YES];
                    }
                    break;
                case 2:
                    maxi = [[acresMaxi objectAtIndex:row] integerValue];
                    mini = [[acresMini objectAtIndex:[pickerView selectedRowInComponent:0]] integerValue];
                    if (maxi<=mini)
                    {
                        [Picker selectRow:row inComponent:0 animated:YES];
                    }
                    break;
                default:
                    break;
            }
            
        } else {
            
            switch (component) {
                case 0:
                    mini = [[lotSquaremini objectAtIndex:row] integerValue];
                    maxi = [[lotSquaremaxi objectAtIndex:[pickerView selectedRowInComponent:2]] integerValue];
                    
                    if (mini>=maxi && maxi!=0)
                    {
                        [Picker selectRow:row inComponent:2 animated:YES];
                    }
                    break;
                case 2:
                    maxi = [[lotSquaremaxi objectAtIndex:row] integerValue];
                    mini = [[lotSquaremini objectAtIndex:[pickerView selectedRowInComponent:0]] integerValue];
                    if (maxi<=mini)
                    {
                        [Picker selectRow:row inComponent:0 animated:YES];
                    }
                    break;
                default:
                    break;
            }
            
        }
        
    }
    else if ([strPickerType isEqualToString:@"petPolicy"])
    {
        NSLog(@"petPolicy");
    
    }
    else
    {
        switch (component) {
            case 0:
                mini = [[yearsMini objectAtIndex:row] integerValue];
                maxi = [[yearsMaxi objectAtIndex:[pickerView selectedRowInComponent:2]] integerValue];
                
                if (mini>=maxi && maxi!=0)
                {
                    [Picker selectRow:row inComponent:2 animated:YES];
                }
                break;
            case 2:
                maxi = [[yearsMaxi objectAtIndex:row] integerValue];
                mini = [[yearsMini objectAtIndex:[pickerView selectedRowInComponent:0]] integerValue];
                if (maxi<=mini)
                {
                    [Picker selectRow:row inComponent:0 animated:YES];
                }
                break;
            default:
                break;
        }
        
        
    }
    
}


- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component;
{
    
    if ([strPickerType isEqualToString:@"SquareFeet"])
    {
        switch (component) {
            case 0:
                return [squareFeetMini objectAtIndex:row];
                
                break;
            case 1:
                return @"to";
                break;
            case 2:
                return [squareFeetMaxi objectAtIndex:row];
                
                break;
            default:
                break;
        }
    }
    else if ([strPickerType isEqualToString:@"LotSize"])
    {
        
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"RentPropertyLotType"]isEqualToString:@"SQFT"]) {
            
            switch (component){
                case 0:
                    if (row==0) {
                        return [NSString stringWithFormat:@"minimum"];
                    } else {
                        return [NSString stringWithFormat:@"%ld",(long)[[lotSquaremini objectAtIndex:row]integerValue]];
                    }
                    
                    break;
                case 1:
                    return @"to";
                    break;
                case 2:
                    if (row==lotSquaremaxi.count-1) {
                        return [NSString stringWithFormat:@"maximum"];
                    } else {
                        return [NSString stringWithFormat:@"%ld",(long)[[lotSquaremaxi objectAtIndex:row] integerValue]];
                    }
                    
                    break;
                default:
                    break;
            }
            
            
        } else {
            
            switch (component) {
                case 0:
                    return [NSString stringWithFormat:@"%@",[acresMini objectAtIndex:row]];
                    break;
                case 1:
                    return @"to";
                    break;
                case 2:
                    return [NSString stringWithFormat:@"%@",[acresMaxi objectAtIndex:row]];
                    break;
                default:
                    break;
            }
        }
        
    }
    else if ([strPickerType isEqualToString:@"petPolicy"])
    {
         return [NSString stringWithFormat:@"%@",[petPolicyArr objectAtIndex:row]];
    }
    else{
        switch (component) {
            case 0:
                return [NSString stringWithFormat:@"%@",[yearsMini objectAtIndex:row]];
                break;
            case 1:
                return @"to";
                break;
            case 2:
                return [NSString stringWithFormat:@"%@",[yearsMaxi objectAtIndex:row]];
                break;
            default:
                break;
        }
        
    }
    return nil;
}


-(IBAction)btnPickerDoneClicked:(id)sender
{
    if ([strPickerType isEqualToString:@"SquareFeet"])
    {
        if ([[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]] isEqualToString:@"minimum"]&&[[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]] isEqualToString:@"maximum"])
        {
            lblSquareFeet.text = @"";
            strSquareFeetMin= @"1";
            strSquareFeetMax = @"500000";
        }
        else if ([[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]] isEqualToString:@"minimum"])
        {
            lblSquareFeet.text = [NSString stringWithFormat:@"0-%@ sqft",[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
            strSquareFeetMin = @"1";
            strSquareFeetMax = [NSString stringWithFormat:@"%@",[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
        }
        else if ([[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]] isEqualToString:@"maximum"])
        {
            lblSquareFeet.text = [NSString stringWithFormat:@"%@+ sqft",[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]]];
            
            strSquareFeetMin =[NSString stringWithFormat:@"%@",[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]]];
            strSquareFeetMax = @"500000";
            
        }
        else
        {
            lblSquareFeet.text = [NSString stringWithFormat:@"%@-%@ sqft",[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]],[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
            
            strSquareFeetMin = [NSString stringWithFormat:@"%@",[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]]];
            strSquareFeetMax = [NSString stringWithFormat:@"%@",[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
            
        }
        NSString *update = [NSString stringWithFormat:@"update RentProperties SET square_feets_min='%ld',square_feets_max='%ld' where id='1'",[[squareFeetMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue],[[squareFeetMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
        [self.dbManager executeQuery:update];
        
    }
    else if ([strPickerType isEqualToString:@"LotSize"])
    {
        if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"RentPropertyLotType"]isEqualToString:@"SQFT"]) {
            
            
            if ([[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]==0 &&[[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]==0)
            {
                lblLotSize.text = @"";
                strLotsizeMin = @"1";
                strLotsizeMax = @"5000000000000";
                
            }
            else if ([[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue] ==0)
            {
                lblLotSize.text = [NSString stringWithFormat:@"0-%@ sqft lot",[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
                strLotsizeMin = @"1";
                strLotsizeMax = [NSString stringWithFormat:@"%@",[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
            }
            else if ([[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]==0)
            {
                lblLotSize.text = [NSString stringWithFormat:@"%@+ sqft lot",[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]]];
                strLotsizeMin =[NSString stringWithFormat:@"%@",[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]]];
                strLotsizeMax = @"5000000000000";
                
            }
            else
            {
                lblLotSize.text = [NSString stringWithFormat:@"%@-%@ sqft lot",[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]],[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
                strLotsizeMin = [NSString stringWithFormat:@"%@",[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]]];
                strLotsizeMax= [NSString stringWithFormat:@"%@",[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]]];
                
            }
            
            NSString *update = [NSString stringWithFormat:@"update RentProperties SET lot_square_feets_min='%ld',lot_square_feets_max='%ld' where id='1'",[[lotSquaremini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue],[[lotSquaremaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
            [self.dbManager executeQuery:update];
            
            
        } else {
            
            if ([[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue] ==0&&[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue] ==0)
            {
                lblLotSize.text = @"";
                strLotAcreMin = @"0";
                strLotAcreMax = @"500000";
            }
            else if ([[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue] ==0)
            {
                lblLotSize.text = [NSString stringWithFormat:@"0-%.1f acre lot",[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue]];
                strLotAcreMin = @"0";
                strLotAcreMax = [NSString stringWithFormat:@"%.1f",[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue]];
            }
            else if ([[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue] ==0)
            {
                lblLotSize.text = [NSString stringWithFormat:@"%.1f+ acre lot",[[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue]];
                strLotAcreMin = [NSString stringWithFormat:@"%.1f",[[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue]];
                strLotAcreMax = @"500000";
            }
            else
            {
                lblLotSize.text = [NSString stringWithFormat:@"%.1f-%.1f acre lot",[[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue],[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue]];
                strLotAcreMin = [NSString stringWithFormat:@"%.1f",[[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue]];
                
                strLotAcreMax = [NSString stringWithFormat:@"%.1f",[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue]];
                
            }
            
            NSString *update = [NSString stringWithFormat:@"update RentProperties SET lot_acres_min='%f',lot_acres_max='%f' where id='1'",[[acresMini objectAtIndex:[Picker selectedRowInComponent:0]] floatValue],[[acresMaxi objectAtIndex:[Picker selectedRowInComponent:2]] floatValue]];
            [self.dbManager executeQuery:update];
            
        }
    }
    else if ([strPickerType isEqualToString:@"petPolicy"])
    {
        lblPetPolicy.text = [NSString stringWithFormat:@"%@",[petPolicyArr objectAtIndex:[Picker selectedRowInComponent:0]]];
        strPetPolicy = [NSString stringWithFormat:@"%@",[petPolicyArr objectAtIndex:[Picker selectedRowInComponent:0]]];
        NSString *update = [NSString stringWithFormat:@"update RentProperties SET pet_policy='%@' where id='1'",[petPolicyArr objectAtIndex:[Picker selectedRowInComponent:0]]];
        [self.dbManager executeQuery:update];
    
    }
    else{
        
       if ([[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]==0&&[[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]==0)
        {
            lblYearBuild.text = @"";
            strYearMin= @"0";
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"yyyy"];
            strYearMax  = [formatter stringFromDate:[NSDate date]];
        }
        else if ([[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]==0)
        {
            lblYearBuild.text = [NSString stringWithFormat:@"min-%ld",(long)[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]];
            strYearMin= @"0";
            strYearMax =[NSString stringWithFormat:@"%ld",(long)[[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
            
        }
        else if ([[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]==0)
        {
            lblYearBuild.text = [NSString stringWithFormat:@"%ld-max",(long)[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]];
            
            strYearMin = [NSString stringWithFormat:@"%ld",(long)[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]];
           
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            [formatter setDateFormat:@"yyyy"];
            strYearMax  = [formatter stringFromDate:[NSDate date]];
        }
        else
        {
            
            lblYearBuild.text = [NSString stringWithFormat:@"%ld-%ld",(long)[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue],(long)[[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
            strYearMin = [NSString stringWithFormat:@"%ld",(long)[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue]];
            strYearMax = [NSString stringWithFormat:@"%ld",(long)[[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
            
            
        }
        NSString *update = [NSString stringWithFormat:@"update RentProperties SET year_built_min='%ld',year_built_max='%ld' where id='1'",[[yearsMini objectAtIndex:[Picker selectedRowInComponent:0]] integerValue],[[yearsMaxi objectAtIndex:[Picker selectedRowInComponent:2]] integerValue]];
        [self.dbManager executeQuery:update];
        
    }
    [self CallGetTotalPropertyCount];
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.3];
    viewSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
    [UIView commitAnimations];
    
}

-(IBAction)btnCancelClicked:(id)sender
{
    if ([sender tag]==1)
    {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        viewSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
        [UIView commitAnimations];
    }
    else
    {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.3];
        viewSelect.frame = CGRectMake(0,[UIScreen mainScreen].bounds.size.height,[UIScreen mainScreen].bounds.size.width,260);
        [UIView commitAnimations];
    }
}


#pragma mark BsKeyBoardContrrols delegate
-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    
    keyboardControls.textFields = [NSArray arrayWithObjects:txtLocation,txtSearchByKeywords, nil];
    
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    keyboardControls.previousTitle = @"";
    
    // Set title for the "Next button". Default is "Next".
    keyboardControls.nextTitle = @"";
    [keyboardControls hidePrevNextButtons:YES];
    
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    for (id textField in keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] bounds];
    
    CGFloat availableHeight = applicationFrame.size.height - 230;
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }
}

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    strFullAddress = txtLocation.text;
    searchByKeyword = txtSearchByKeywords.text;
    [controls.activeTextField resignFirstResponder];
    if (controls.activeTextField==txtLocation)
    {
        NSString *update = [NSString stringWithFormat:@"update RentProperties SET location='%@' where id='1'",txtLocation.text];
        [self.dbManager executeQuery:update];
        NSLog(@"foreClosures true");
    }
    else{
        
        NSString *update = [NSString stringWithFormat:@"update RentProperties SET search_by_keywords='%@' where id='1'",txtSearchByKeywords.text];
        [self.dbManager executeQuery:update];
        NSLog(@"foreClosures true");
    }
    
    [self CallGetTotalPropertyCount];
}

- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}

//- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
//{
//    if ([keyboardControls.textFields containsObject:textField])
//        keyboardControls.activeTextField = textField;
//    
//    [self scrollViewToCenterOfScreen:textField];
//    return YES;
//}

-(void)textFieldDidBeginEditing:(UITextField *)textField {
    //Keyboard becomes visible
    _myScrollView.frame = CGRectMake(_myScrollView.frame.origin.x,
                                     _myScrollView.frame.origin.y,
                                     _myScrollView.frame.size.width,
                                     _myScrollView.frame.size.height - 315 + 50);
}

-(void)textFieldDidEndEditing:(UITextField *)textField {
    //keyboard will hide
    _myScrollView.frame = CGRectMake(_myScrollView.frame.origin.x,
                                     _myScrollView.frame.origin.y,
                                     _myScrollView.frame.size.width,
                                     _myScrollView.frame.size.height + 315 - 50);
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    strFullAddress = txtLocation.text;
    searchByKeyword = txtSearchByKeywords.text;
    if (textField==txtLocation)
    {
        NSString *update = [NSString stringWithFormat:@"update RentProperties SET location='%@' where id='1'",txtLocation.text];
        [self.dbManager executeQuery:update];
        
    } else {
        
        NSString *update = [NSString stringWithFormat:@"update RentProperties SET search_by_keywords='%@' where id='1'",txtSearchByKeywords.text];
        [self.dbManager executeQuery:update];
    }
    [textField resignFirstResponder];
    [self CallGetTotalPropertyCount];
    
    
    return YES;
}

-(void)loadDataFromLocalDatabase
{
    dataDuplicate = [self.propertyDetail objectAtIndex:0];
    if ([[dataDuplicate objectAtIndex:17] isEqualToString:@"Yes"]){
        recentlyRentSwitch.on = YES;
    }
    if ([[dataDuplicate objectAtIndex:17] isEqualToString:@"No"]){
        recentlyRentSwitch.on = NO;
    }
    
    if (![[dataDuplicate objectAtIndex:2] isEqualToString:@"0"]) {
        txtLocation.text = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
        strFullAddress   = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:2]];
    }
    else{
         txtLocation.text = @"";
    }
    
    if (![[dataDuplicate objectAtIndex:16] isEqualToString:@"0"])
    {
        txtSearchByKeywords.text = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:16]];
        searchByKeyword = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:16]];
    }
    else
    {
        txtSearchByKeywords.text =@"";
    }
    [bedSegment setSelectedSegmentIndex:[[dataDuplicate objectAtIndex:3] integerValue]];
    [bathroomSegment setSelectedSegmentIndex:[[dataDuplicate objectAtIndex:4] integerValue]];
    
    strPriceMinimum  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:0]];
    strPriceMaximum  = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:1]];
    
    // Update square feet label  6 ,7
    
    if ([[dataDuplicate objectAtIndex:6] integerValue] ==0 && [[dataDuplicate objectAtIndex:7] integerValue] ==0)
    {
        lblSquareFeet.text = @"";
        strSquareFeetMin = @"0";
        strSquareFeetMax = @"0";
        
    }
    else if ([[dataDuplicate objectAtIndex:6] integerValue] ==0)
    {
        lblSquareFeet.text = [NSString stringWithFormat:@"0-%ld sqft",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
        strSquareFeetMin = @"1";
        strSquareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
    }
    else if ([[dataDuplicate objectAtIndex:7] integerValue] ==0)
    {
        lblSquareFeet.text = [NSString stringWithFormat:@"%ld+ sqft",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
        strSquareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
        strSquareFeetMax = @"500000";
    }
    else
    {
        lblSquareFeet.text = [NSString stringWithFormat:@"%ld-%ld sqft",(long)[[dataDuplicate objectAtIndex:6] integerValue],(long)[[dataDuplicate objectAtIndex:7] integerValue]];
        
        strSquareFeetMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:6] integerValue]];
        strSquareFeetMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:7] integerValue]];
        
    }
    //Update Lot size label;  8,9
    
    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"RentPropertyLotType"]isEqualToString:@"SQFT"]) {
   
        acresSegment.selectedSegmentIndex = 0;
        
        if ([[dataDuplicate objectAtIndex:8] floatValue] ==0&&[[dataDuplicate objectAtIndex:9] integerValue] ==0)
        {
            lblLotSize.text = @"";
            strLotsizeMin = @"0";
            strLotsizeMax = @"0";
        }
        else if ([[dataDuplicate objectAtIndex:8] floatValue] ==0)
        {
            lblLotSize.text = [NSString stringWithFormat:@"0-%ld sqft lot",(long)[[dataDuplicate objectAtIndex:9] integerValue]];
          strLotsizeMin = @"1";
          strLotsizeMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:9] integerValue]];
        }
        else if ([[dataDuplicate objectAtIndex:9] floatValue] ==0)
        {
            lblLotSize.text = [NSString stringWithFormat:@"%.1ld+ sqft lot",(long)[[dataDuplicate objectAtIndex:8] integerValue]];
            strLotsizeMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:8] integerValue]];
            strLotsizeMax = @"500000000000";
        }
        else
        {
            lblLotSize.text = [NSString stringWithFormat:@"%.1ld-%.1ld sqft lot",(long)[[dataDuplicate objectAtIndex:8] integerValue],(long)[[dataDuplicate objectAtIndex:9] integerValue]];
             strLotsizeMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:8] integerValue]];
             strLotsizeMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:9] integerValue]];
        }
        
    } else
    {
        //11 12
        
        if ([[dataDuplicate objectAtIndex:11] floatValue] ==0 &&[[dataDuplicate objectAtIndex:12] floatValue] ==0)
        {
            lblLotSize.text = @"";
            strLotAcreMin = @"0";
            strLotAcreMax = @"0";
        }
        else if ([[dataDuplicate objectAtIndex:11] floatValue] ==0)
        {
            lblLotSize.text = [NSString stringWithFormat:@"0-%.1f acre lot",[[dataDuplicate objectAtIndex:12] floatValue]];
            strLotAcreMin = @"0";
            strLotAcreMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
        }
        else if ([[dataDuplicate objectAtIndex:12] floatValue] ==0)
        {
            lblLotSize.text = [NSString stringWithFormat:@"%.1f+ acre lot",[[dataDuplicate objectAtIndex:11] floatValue]];
            strLotAcreMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
            strLotAcreMax = @"500000";
        }
        else
        {
            lblLotSize.text = [NSString stringWithFormat:@"%.1f-%.1f acre lot",[[dataDuplicate objectAtIndex:11] floatValue],[[dataDuplicate objectAtIndex:12] floatValue]];
            strLotAcreMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:11] integerValue]];
            strLotAcreMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:12] integerValue]];
        }
        acresSegment.selectedSegmentIndex = 1;
    }
    
    if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"]&&[[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
    {
        lblYearBuild.text = @"";
        strYearMin= @"0";
       
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy"];
         strYearMax  = [formatter stringFromDate:[NSDate date]];
    }
    else if ([[dataDuplicate objectAtIndex:13] isEqualToString:@"0"])
    {
        lblYearBuild.text = [NSString stringWithFormat:@"min-%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
        strYearMin= @"0";
        strYearMax =[NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
       
    }
    else if ([[dataDuplicate objectAtIndex:14] isEqualToString:@"0"])
    {
        lblYearBuild.text = [NSString stringWithFormat:@"%ld-max",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
        strYearMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"yyyy"];
        strYearMax  = [formatter stringFromDate:[NSDate date]];
    }
    else
    {
        
     lblYearBuild.text = [NSString stringWithFormat:@"%ld-%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue],(long)[[dataDuplicate objectAtIndex:14] integerValue]];
        strYearMin = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:13] integerValue]];
        strYearMax = [NSString stringWithFormat:@"%ld",(long)[[dataDuplicate objectAtIndex:14] integerValue]];
    }
    
    if ([[dataDuplicate objectAtIndex:15] isEqualToString:@"Any"]) {
        
        strDaysOnMarket = @"0";
    } else {
        
        strDaysOnMarket = [NSString stringWithFormat:@"-%@",[dataDuplicate objectAtIndex:15]];
    }
    strPetPolicy = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:10]];
    if (![[dataDuplicate objectAtIndex:10] isEqualToString:@"0"]) {
        lblPetPolicy.text = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:10]];
        
    }
    else
    {
        lblPetPolicy.text = @"";
    }
    if (![[dataDuplicate objectAtIndex:5]isEqualToString:@"0"]) {
        lblPropertyType.text = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:5]];
        strPropertyType = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:5]];
         propertyType = [[NSMutableString alloc]init];
        NSArray *selectedItems = [strPropertyType componentsSeparatedByString:@"/"];
        for (NSInteger i = 0; i<selectedItems.count; i++) {
            [propertyType appendString:[NSString stringWithFormat:@"%@,",[selectedItems objectAtIndex:i]]];
        }
        strPropertyType = [propertyType substringToIndex:[propertyType length]-1];
    }
    if (![[dataDuplicate objectAtIndex:15]isEqualToString:@"0"]){
        
       lblDaysOnMarket.text = [NSString stringWithFormat:@"%@",[dataDuplicate objectAtIndex:15]];
    }
    else
    {
       lblDaysOnMarket.text = @"Any";
    }
    
    [self setUpViewComponents];
    [self CallGetTotalPropertyCount];
    
}


-(IBAction)resetFilters:(id)sender
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:@"Do you want to reset filters" preferredStyle:UIAlertControllerStyleAlert];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"Confirm" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self reset];
    }]];
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"Not now" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self closeAlertview];
        
    }]];
    
    dispatch_async(dispatch_get_main_queue(), ^ {
        [self presentViewController:alertController animated:YES completion:nil];
    });
    
}
-(void)closeAlertview
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)reset
{
    NSString *updateColumns = [NSString stringWithFormat:@"UPDATE RentProperties SET rental_min='%d',rental_max='%d',location='%@',no_of_beds='%d',no_of_baths='%d',property_type='%@',square_feets_min='%d',square_feets_max='%d',pet_policy='%@',lot_acres_min='%f',lot_acres_max='%f',year_built_min='%d',year_built_max='%d',days_on_market='%@',search_by_keywords='%@',recently_rented='%@',lot_square_feets_min='%d',lot_square_feets_max='%d' where id='1'",0,0,@"0",0,0,@"SF/CA/MF",0,0,@"0",0.0,0.0,0,0,@"0",@"0",@"Yes",0,0];
    
    [self.dbManager executeQuery:updateColumns];
    [self.lblPriceValue removeFromSuperview];
    [_sliderListPrice removeFromSuperview];
    NSString *existData = @"select * from RentProperties";
    if (self.propertyDetail != nil)
    {
        self.propertyDetail = nil;
    }
    self.propertyDetail = [[NSArray alloc] initWithArray:[self.dbManager loadDataFromDB:existData]];
    NSLog(@"DATA---%@",_propertyDetail);
    NSLog(@"Count---%lu",(unsigned long)self.propertyDetail.count);
    if (self.propertyDetail.count)
    {
        [self loadDataFromLocalDatabase];
    }
}

-(IBAction)resultButtonTaped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
