//
//  FavouriteProperties.h
//  RealEstate_App
//
//  Created by Octal on 27/09/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JTRevealSidebarV2Delegate.h"
#import "UIViewController+JTRevealSidebarV2.h"
#import "UINavigationItem+JTRevealSidebarV2.h"
#import "SidebarViewController.h"
#import "AppDelegate.h"
#import "PropertyDetail.h"

@interface FavouriteProperties : UIViewController<JTRevealSidebarV2Delegate,UITableViewDataSource,UITableViewDelegate>
{
    IBOutlet UIButton *btnNavigation;
    IBOutlet UITableView *tblFavourite;
    NSMutableArray *favouritePopertyData;
    AppDelegate*appdelegate;
    IBOutlet UIButton *btnDelete;
    IBOutlet UIButton *btnShare;
    IBOutlet UIButton *btnEdit;
    NSMutableArray *deleteIdArr;
    PropertyDetail *theProperty;
    NSMutableIndexSet *indexes;
    UIRefreshControl *refreshControl;
    UILabel *lblNoRecord;
    UILabel *lblNoRecord2;
    int count;
    
    IBOutlet UIButton *btnSortOrder;
    IBOutlet UIButton *btnMap;
    
}

@property(nonatomic,strong)SidebarViewController *leftSidebarViewController;
@property(assign,nonatomic) BOOL isEdit;

@end
