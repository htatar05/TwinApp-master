//
//  SortViewController.m
//  RealState
//
//  Created by Kapil Goyal on 12/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import "PropertyTypeViewController.h"
#import "SortTvCellView.h"



@interface PropertyTypeViewController ()
@end



@implementation PropertyTypeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    selectedIndex = 0;
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"RealEstate.sqlite"];
    arrPropertyType = [[NSMutableArray alloc] initWithObjects:@"Single Family",@"Condo/Apartment",@"Multi Family",@"Manufactured",@"Lot/Land",@"Boat Dock",@"Commercial", nil];
    
    shortArray = [[NSMutableArray alloc]initWithObjects:@"SF",@"CA",@"MF",@"MD",@"LL",@"BD",@"CL", nil];
    
    arrDaysType = [[NSMutableArray alloc]initWithObjects:@"Any",@"1 day",@"7 days",@"14 days",@"30 days",@"90 days",@"6 months",@"12 months",@"24 months",@"36 months", nil];
    
    tblViewPropertyType.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    if (IS_IPHONE) {
        
        if(IsRunningTallPhone())
        {
            [viewPropertyType setFrame:CGRectMake(0, 0, 320, 568)];
            [scrlViewPropertyType setContentSize:CGSizeMake(320, 480)];
        }
        else
        {
            [viewPropertyType setFrame:CGRectMake(0, 0, 320, 480)];
            [scrlViewPropertyType setContentSize:CGSizeMake(320, 460)];
        }
    }
   
    

    dictCheck = [[NSMutableDictionary alloc] init];
     if ([self.PropertyType isEqualToString:@"property_type"])
     {
          lblTitle.text = @"Property Type";
         for (int j=0;j<[arrPropertyType count];j++)
         {
             [dictCheck setValue:@"0" forKey:[NSString stringWithFormat:@"%d",j]];
             
             if ([self.selectedPropertyType isEqualToString:[arrPropertyType objectAtIndex:j]]) {
                 selectedIndex = j;
                 
             }
             
         }
     
     }
    else
    {
         lblTitle.text = @"Select Days";
        for (int j=0;j<[arrDaysType count];j++)
        {
            [dictCheck setValue:@"0" forKey:[NSString stringWithFormat:@"%d",j]];
            if ([self.selectedDays isEqualToString:[arrDaysType objectAtIndex:j]]) {
                selectedIndex = j;
                
            }
        }
    
    }
}

-(IBAction)btnBackClicked;
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if ([self.PropertyType isEqualToString:@"property_type"])
    {
         return [arrPropertyType count];
    }
    else
    {
         return [arrDaysType count];
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    SortTvCellView *cell = (SortTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
            view = [[UIViewController alloc]initWithNibName:@"SortTvCellView_iPhone" bundle:nil];
        } else {
            view = [[UIViewController alloc]initWithNibName:@"SortTvCellView_iPad" bundle:nil];
        }
        
        cell = (SortTvCellView *)view.view;
    }
    cell.tag = indexPath.row;
    
    if ([self.PropertyType isEqualToString:@"property_type"])
    {
        cell.lblSortType.text = [arrPropertyType objectAtIndex:indexPath.row];
    }
    else
    {
         cell.lblSortType.text = [arrDaysType objectAtIndex:indexPath.row];
    }
   
    if ([[dictCheck valueForKey:[NSString stringWithFormat:@"%ld",(long)indexPath.row]] isEqualToString:@"1"]|| selectedIndex==indexPath.row) {
        
        cell.imgCheck.image = [UIImage imageNamed:@"blue_tick.png"];
    }
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE) {
        return 40;
    } else {
        return 60;
    }
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SortTvCellView *cell = (SortTvCellView*)[tblViewPropertyType cellForRowAtIndexPath:indexPath];
    ipath = [tblViewPropertyType indexPathForCell:cell];
    
    NSArray *arrKeys = [dictCheck allKeys];
    NSArray *arr = [arrKeys sortedArrayUsingSelector:@selector(compare:)];
    
    for (int i=0; i<[arr count]; i++)
    {
        if([[arr objectAtIndex:i] isEqualToString:[NSString stringWithFormat:@"%ld",(long)ipath.row]])
        {
            [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:[NSString stringWithFormat:@"a%d",i]];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [dictCheck setValue:@"1" forKey:[NSString stringWithFormat:@"%d",i]];
        }
        else
        {
            [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:[NSString stringWithFormat:@"a%d",i]];
            [[NSUserDefaults standardUserDefaults] synchronize];
            [dictCheck setValue:@"0" forKey:[NSString stringWithFormat:@"%d",i]];
        }
    }
    
     if ([self.PropertyType isEqualToString:@"property_type"])
     {
         
         if ([self.isFrom isEqualToString:@"AllProperties"]) {
             NSString *update = [NSString stringWithFormat:@"update AllProperties SET property_type='%@' where id='1'",[arrPropertyType objectAtIndex:indexPath.row]];
             [self.dbManager executeQuery:update];
             
         }
         else if ([self.isFrom isEqualToString:@"RentProperties"])
         {
             NSString *update = [NSString stringWithFormat:@"update RentProperties SET property_type='%@' where id='1'",[arrPropertyType objectAtIndex:indexPath.row]];
             [self.dbManager executeQuery:update];
         }
         else if ([self.isFrom isEqualToString:@"SaleProperties"])
         {
             NSLog(@"from sale");
             NSString *update = [NSString stringWithFormat:@"update SaleProperties SET property_type='%@' where id='1'",[arrPropertyType objectAtIndex:indexPath.row]];
             [self.dbManager executeQuery:update];
             
         }
         else{
             //sold
             NSString *update = [NSString stringWithFormat:@"update SoldProperties SET property_type='%@' where id='1'",[arrPropertyType objectAtIndex:indexPath.row]];
             [self.dbManager executeQuery:update];
         
         }
        
     }
     else
     {
         
         if ([self.isFrom isEqualToString:@"AllProperties"]) {
             
             NSString *update = [NSString stringWithFormat:@"update AllProperties SET days_on_market='%@' where id='1'",[arrDaysType objectAtIndex:indexPath.row]];
             [self.dbManager executeQuery:update];
             
         }
         else if ([self.isFrom isEqualToString:@"RentProperties"])
         {
             NSString *update = [NSString stringWithFormat:@"update RentProperties SET days_on_market='%@' where id='1'",[arrDaysType objectAtIndex:indexPath.row]];
             [self.dbManager executeQuery:update];
         }
         else if ([self.isFrom isEqualToString:@"SaleProperties"])
         {
             NSString *update = [NSString stringWithFormat:@"update SaleProperties SET days_on_market='%@' where id='1'",[arrDaysType objectAtIndex:indexPath.row]];
             [self.dbManager executeQuery:update];
         }
         else
         {
             NSString *update = [NSString stringWithFormat:@"update SoldProperties SET days_on_market='%@' where id='1'",[arrDaysType objectAtIndex:indexPath.row]];
             [self.dbManager executeQuery:update];
         }
        
     }
   
    selectedIndex = indexPath.row;
    [tblViewPropertyType deselectRowAtIndexPath:indexPath animated:YES];
    [self performSelector:@selector(LoadData) withObject:nil afterDelay:0.2];
}

-(void)LoadData
{
    [tblViewPropertyType reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
