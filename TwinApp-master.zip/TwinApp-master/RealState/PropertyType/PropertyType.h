//
//  PropertyType.h
//  RealEstate_App
//
//  Created by Octal on 25/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBManager.h"

@interface PropertyType : UIViewController
{

    IBOutlet UITableView *tblViewPropertyType;
    NSMutableArray *arrPropertyType;
    NSMutableArray *shortArray;
    NSMutableArray *cellSelected;
    NSMutableString *appendString;
    NSMutableArray *selectedItems;
}

@property (nonatomic, strong)DBManager *dbManager;
@property (nonatomic,strong)NSString *isFrom;
@property (nonatomic,strong)NSString *selectedPropertyType;

@end
