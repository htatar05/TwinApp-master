//  PropertyType.m
//  RealEstate_App
//  Created by Octal on 25/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.


#import "PropertyType.h"
#import "SortTvCellView.h"

@interface PropertyType ()

@end

@implementation PropertyType

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"selected items %@",self.selectedPropertyType);
    cellSelected = [NSMutableArray array];
    NSMutableArray *tempArr = [[NSMutableArray alloc] initWithObjects:@"Single Family",@"CondoApartment",@"Multi Family",@"Manufactured",@"LotLand",@"Boat Dock",@"Commercial", nil];
    
    selectedItems = [[NSMutableArray alloc]init];
    arrPropertyType = [[NSMutableArray alloc]init];
    
    shortArray = [[NSMutableArray alloc]initWithObjects:@"SF",@"CA",@"MF",@"M",@"LL",@"BD",@"C", nil];
    self.dbManager = [[DBManager alloc] initWithDatabaseFilename:@"RealEstate.sqlite"];
    tblViewPropertyType.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    NSArray *arr = [self.selectedPropertyType componentsSeparatedByString:@"/"];

    for (NSInteger i=0; i<tempArr.count; i++){
         NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
        [dict setValue:[tempArr objectAtIndex:i] forKey:@"full_name"];
        [dict setValue:[shortArray objectAtIndex:i] forKey:@"short_name"];
        [dict setValue:@"No" forKey:@"is_selected"];
        [arrPropertyType addObject:dict];
        
    }
  
    
    for (NSInteger i = 0; i<arr.count; i++){
        for (NSInteger j = 0; j<shortArray.count; j++) {
            
            if ([[arr objectAtIndex:i]isEqualToString:[shortArray objectAtIndex:j]]) {
                NSMutableDictionary *newDict = [[NSMutableDictionary alloc] init];
                NSDictionary *oldDict = (NSDictionary *)[arrPropertyType objectAtIndex:j];
                [newDict addEntriesFromDictionary:oldDict];
                [newDict setObject:@"Yes" forKey:@"is_selected"];
                [arrPropertyType replaceObjectAtIndex:j withObject:newDict];
                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:j inSection:0];
                [cellSelected addObject:indexPath];
                [selectedItems addObject:[shortArray objectAtIndex:j]];
                
            }
            
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
        return [arrPropertyType count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    SortTvCellView *cell = (SortTvCellView *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        UIViewController *view;
        if (IS_IPHONE) {
            view = [[UIViewController alloc]initWithNibName:@"SortTvCellView_iPhone" bundle:nil];
        } else {
            view = [[UIViewController alloc]initWithNibName:@"SortTvCellView_iPad" bundle:nil];
        }
        
        cell = (SortTvCellView *)view.view;
    }
    cell.tag = indexPath.row;
    NSMutableDictionary *tempDict = [arrPropertyType objectAtIndex:indexPath.row];
    cell.lblSortType.text = [tempDict valueForKey:@"full_name"];
    if ([cellSelected containsObject:indexPath]||[[tempDict valueForKey:@"is_selected"]isEqualToString:@"Yes"])
    {
         cell.imgCheck.image = [UIImage imageNamed:@"blue_tick.png"];
    }
    else
    {
        cell.imgCheck.image = [UIImage imageNamed:@"gray_tick.png"];
        
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SortTvCellView *cell = (SortTvCellView*)[tblViewPropertyType cellForRowAtIndexPath:indexPath];
    cell.imgCheck.image = [UIImage imageNamed:@"blue_tick.png"];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if ([cellSelected containsObject:indexPath])
    {
        [cellSelected removeObject:indexPath];
        [selectedItems removeObject:[shortArray objectAtIndex:indexPath.row]];
        NSMutableDictionary *newDict = [[NSMutableDictionary alloc] init];
        NSDictionary *oldDict = (NSDictionary *)[arrPropertyType objectAtIndex:indexPath.row];
        [newDict addEntriesFromDictionary:oldDict];
        [newDict setObject:@"No" forKey:@"is_selected"];
        [arrPropertyType replaceObjectAtIndex:indexPath.row withObject:newDict];
    }
    else
    {
        [cellSelected addObject:indexPath];
        [selectedItems addObject:[shortArray objectAtIndex:indexPath.row]];
        NSMutableDictionary *newDict = [[NSMutableDictionary alloc] init];
        NSDictionary *oldDict = (NSDictionary *)[arrPropertyType objectAtIndex:indexPath.row];
        [newDict addEntriesFromDictionary:oldDict];
        [newDict setObject:@"Yes" forKey:@"is_selected"];
        [arrPropertyType replaceObjectAtIndex:indexPath.row withObject:newDict];
    }
    [tblViewPropertyType reloadData];

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE) {
        return 40;
    } else {
        return 60;
    }
    
}
-(IBAction)backButtonClicked:(id)sender
{
    appendString  = [[NSMutableString alloc] init];
    
    for (NSInteger i = 0; i<selectedItems.count; i++) {
        [appendString appendString:[NSString stringWithFormat:@"%@/",[selectedItems objectAtIndex:i]]];
    }
    
    NSString *str;
    if ([appendString hasSuffix:@"/"]){
      str = [appendString substringToIndex:[appendString length]-1];
    }
    
    if (str==nil){
        
        str = @"";
    }
    if ([self.isFrom isEqualToString:@"AllProperties"]) {
        NSString *update = [NSString stringWithFormat:@"update AllProperties SET property_type='%@' where id='1'",str];
        [self.dbManager executeQuery:update];
        
    }
    else if ([self.isFrom isEqualToString:@"RentProperties"])
    {
        NSString *update = [NSString stringWithFormat:@"update RentProperties SET property_type='%@' where id='1'",str];
        [self.dbManager executeQuery:update];
    }
    else if ([self.isFrom isEqualToString:@"SaleProperties"])
    {
        NSLog(@"from sale");
        NSString *update = [NSString stringWithFormat:@"update SaleProperties SET property_type='%@' where id='1'",str];
        [self.dbManager executeQuery:update];
        
    }
    else{
        //sold
        NSString *update = [NSString stringWithFormat:@"update SoldProperties SET property_type='%@' where id='1'",str];
        [self.dbManager executeQuery:update];
        
    }
   
    [self.navigationController popViewControllerAnimated:YES];
}

@end
