//
//  SortViewController.h
//  RealState
//
//  Created by Kapil Goyal on 12/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBManager.h"

@interface PropertyTypeViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet UIView *viewPropertyType;
    IBOutlet UITableView *tblViewPropertyType;
    NSMutableArray *arrPropertyType;
    IBOutlet UIScrollView *scrlViewPropertyType;
    NSMutableArray *arrDaysType;
    IBOutlet UILabel *lblTitle;
    NSIndexPath *ipath;
    NSMutableDictionary * dictCheck;
    NSInteger selectedIndex;
    NSMutableArray *shortArray;
}

@property (nonatomic,strong)NSString *PropertyType;
@property (nonatomic, strong)DBManager *dbManager;
@property (nonatomic,strong)NSString *selectedPropertyType;
@property (nonatomic,strong)NSString *selectedDays;
@property (nonatomic,strong)NSString *isFrom;

-(IBAction)btnBackClicked;
@end
