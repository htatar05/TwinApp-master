//  SavedSearchViewController.m
//  RealState
//  Created by Kapil Goyal on 11/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import "SavedSearchViewController.h"
#import "RenameSavedSearchViewController.h"
#import "NSAttributedString+Attributes.h"
#import "Utils.h"
#import "REWebService.h"
#import "MBProgressHUD.h"
#import "JSON.h"

@interface SavedSearchViewController ()
@end

@implementation SavedSearchViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    emailStatus = @"Yes";
    pushStatus = @"Yes";
    appdelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    strPropertyName = self.genratedAddress;
    NSLog(@"%@",self.genratedAddress);
    
   }

- (CGFloat)textViewHeightForAttributedText:(NSMutableAttributedString*)text
{
    UITextView *txtSavedSearch = [[UITextView alloc] init];
    [txtSavedSearch setAttributedText:text];
    CGSize size = [txtSavedSearch sizeThatFits:CGSizeMake(188, 30)];
    NSLog(@"height111=%f",size.height);
    return size.height;
}

-(void)viewWillAppear:(BOOL)animated
{
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        if (strPropertyName!=nil) {
            
            NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:strPropertyName];
            [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:15.0]];
            CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
            height=0.0;
            if(height1>30)
            {
                height=height1-30;
            }
        }
        else
        {
            NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:self.genratedAddress];
            [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:15.0]];
            CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
            height=0.0;
            if(height1>30)
            {
                height=height1-30;
            }
        }
        
    }
    else
    {
        UITextView *txtSavedSearch = [[UITextView alloc] init];
        txtSavedSearch.frame = CGRectMake(0, 0, 188, 30);
        txtSavedSearch.font = [UIFont fontWithName:@"Helvetica" size:15.0];
        txtSavedSearch.text = strPropertyName;
        [self.view addSubview:txtSavedSearch];
        CGRect rect = txtSavedSearch.frame;
        rect.size = txtSavedSearch.contentSize;
        txtSavedSearch.frame = rect;
        height=0.0;
        if(rect.size.height>30)
            height=rect.size.height-30;
        [txtSavedSearch removeFromSuperview];
    }

    if(IsRunningTallPhone())
    {
        [viewSavedSearch setFrame:CGRectMake(0, 0, 320, 568)];
        CGFloat h2 = 88+height;
        NSLog(@"h2= %f",h2);
        [tblSaveSearch setFrame:CGRectMake(0, 0, 320, 88+height+50)];
        NSLog(@"height of tbl=%f",tblSaveSearch.frame.size.height);
        [scrlViewSavedSearch setFrame:CGRectMake(0, 44, 320, 524)];
        if(tblSaveSearch.frame.size.height>524)
        {
            CGFloat h1 = height-524;
            [scrlViewSavedSearch setContentSize:CGSizeMake(320, 524+h1+88+50)];
        }
        else
            [scrlViewSavedSearch setContentSize:CGSizeMake(320, 524+30)];
    }
    else
    {
        if (IS_IPHONE) {
            
            [viewSavedSearch setFrame:CGRectMake(0, 0, 320, 480)];
            [tblSaveSearch setFrame:CGRectMake(0, 0, 320, 88+height)];
            [scrlViewSavedSearch setFrame:CGRectMake(0, 44, 320, 436)];
            if(tblSaveSearch.frame.size.height>436)
            {
                CGFloat h1 = height-436;
                [scrlViewSavedSearch setContentSize:CGSizeMake(320, 436+h1+88+50)];
            }
            else
            {
                [scrlViewSavedSearch setContentSize:CGSizeMake(320, 436+30)];
            }
        }
        else
        {
            [viewSavedSearch setFrame:CGRectMake(0, 0, 768, 1024)];
            [tblSaveSearch setFrame:CGRectMake(0, 0, 768, 150+height)];
            [scrlViewSavedSearch setFrame:CGRectMake(0, 60, 768, 436)];
            
//            tblSaveSearch.backgroundColor = [UIColor yellowColor];
//            scrlViewSavedSearch.backgroundColor = [UIColor redColor];
//            viewSavedSearch.backgroundColor = [UIColor greenColor];
//            if(tblSaveSearch.frame.size.height>436)
//            {
//                CGFloat h1 = height-436;
//                [scrlViewSavedSearch setContentSize:CGSizeMake(320, 436+h1+88+50)];
//            }
//            else
//            {
//                [scrlViewSavedSearch setContentSize:CGSizeMake(320, 436+30)];
//            }
        }
        
    }
}

#pragma mark Actions

-(IBAction)btnCancelClicked
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnSaveClicked
{
    if (strPropertyName!=nil) {
        [self savedFilterOnServer];
    }
    else
    {
        [Utils showAlertMessage:@"Twin Realty" Message:@"Please enter name"];
    }
}

-(void)btnEmailNotificationClicked:(id)sender
{
    
}

-(void)sendPropertyName:(NSString *)string
{
    if (string!=nil) {
        
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:string];
        [attributedString setFont:[UIFont fontWithName:@"Helvetica" size:15.0]];
        CGFloat height1 = [self textViewHeightForAttributedText:attributedString];
        height=0.0;
        if(height1>30)
        {
            height=height1-30;
        }
    }
    
    strPropertyName = string;
    NSLog(@" you got %@",string);
    [tblSaveSearch reloadData];
    
}


#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row==0)
        return 44+height;
    else
        return 50;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell=nil;
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.backgroundColor = [UIColor clearColor];
    if(indexPath.row==0)
    {
        UILabel *lblName = [[UILabel alloc] initWithFrame:CGRectMake(10, 12+height/2, 52, 21)];
        lblName.text = @"Name";
        lblName.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
        lblName.textColor = [UIColor colorWithRed:57/255.0 green:97/255.0 blue:252/255.0 alpha:1];
        lblName.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:lblName];
        UITextView *txtViewSaved;
        UIButton *btnArrow ;
        if (IS_IPHONE) {
            txtViewSaved = [[UITextView alloc] initWithFrame:CGRectMake(72, 7, 188, 30+height)];
            btnArrow = [UIButton buttonWithType:UIButtonTypeCustom];
            [btnArrow setFrame:CGRectMake(276, 15+height/2, 8, 14)];
        } else {
            txtViewSaved = [[UITextView alloc] initWithFrame:CGRectMake(72, 15, 620, 30+height)];
            btnArrow = [UIButton buttonWithType:UIButtonTypeCustom];
            [btnArrow setFrame:CGRectMake(700, 15+height/2, 8, 14)];
            txtViewSaved.backgroundColor = [UIColor redColor];
            scrlViewSavedSearch.backgroundColor = [UIColor whiteColor];
            
        }
        txtViewSaved.userInteractionEnabled=FALSE;
        txtViewSaved.font = [UIFont fontWithName:@"Helvetica" size:16.0];
        txtViewSaved.text = strPropertyName;
        txtViewSaved.textColor = [UIColor colorWithRed:158/255.0 green:158/255.0 blue:158/255.0 alpha:1];
        txtViewSaved.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:txtViewSaved];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
       
        [btnArrow setImage:[UIImage imageNamed:@"blue_arrow.png"] forState:UIControlStateNormal];
        [cell.contentView addSubview:btnArrow];
    }
    
    else if(indexPath.row==1)
    {
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UILabel *lblEmailNotification = [[UILabel alloc] initWithFrame:CGRectMake(10, 8, 161, 27)];
        lblEmailNotification.text = @"E-Mail Notifications";
        lblEmailNotification.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
        lblEmailNotification.textColor = [UIColor colorWithRed:57/255.0 green:97/255.0 blue:252/255.0 alpha:1];
        lblEmailNotification.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:lblEmailNotification];
        if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
        {
            if (IS_IPHONE) {
                emailSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(260, 7, 51, 31)];
            } else {
                emailSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(680, 7, 51, 31)];
            }
            emailSwitch.onTintColor = [UIColor colorWithRed:0/255.0 green:122/255.0 blue:255/255.0 alpha:1];
            emailSwitch.on=YES;
        }
        else
        {
            emailSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(232, 8, 79, 27)];
            emailSwitch.on=YES;
        }
        emailSwitch.tag = 100;
        [emailSwitch addTarget: self action: @selector(callSwitch:) forControlEvents:UIControlEventValueChanged];
        [cell.contentView addSubview:emailSwitch];
    }
    else
    {
        NSLog(@"third row ");
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UILabel *lblEmailNotification = [[UILabel alloc] initWithFrame:CGRectMake(10, 8, 161, 27)];
        lblEmailNotification.text = @"Push Notifications";
        lblEmailNotification.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.0];
        lblEmailNotification.textColor = [UIColor colorWithRed:57/255.0 green:97/255.0 blue:252/255.0 alpha:1];
        lblEmailNotification.backgroundColor = [UIColor clearColor];
        [cell.contentView addSubview:lblEmailNotification];
        if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
        {
            if (IS_IPHONE) {
                pushSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(260, 7, 51, 31)];
            } else {
                pushSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(680, 7, 51, 31)];
            }
            pushSwitch.onTintColor = [UIColor colorWithRed:0/255.0 green:122/255.0 blue:255/255.0 alpha:1];
            pushSwitch.on=YES;
        }
        else
        {
            pushSwitch = [[UISwitch alloc] initWithFrame:CGRectMake(232, 8, 79, 27)];
            pushSwitch.on=YES;
        }
         pushSwitch.tag = 200;
        [pushSwitch addTarget: self action: @selector(callSwitch:) forControlEvents:UIControlEventValueChanged];
        [cell.contentView addSubview:pushSwitch];
    }
    return cell;
}

-(IBAction)callSwitch:(id)sender
{
    if ([sender tag]==100) {
        
      if (emailSwitch.on)
      {
          emailStatus = @"Yes";
      } else
      {
        emailStatus = @"No";
      }
        
    }
    else
    {
        if (pushSwitch.on)
        {
           pushStatus = @"Yes";
            
        } else
        {
             pushStatus = @"No";
        }
    
    }
   
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row==0)
    {
        RenameSavedSearchViewController *renameSavedSearch;
        if (IS_IPHONE) {
            renameSavedSearch = [[RenameSavedSearchViewController alloc] initWithNibName:@"RenameSavedSearchViewController_iPhone" bundle:nil];
        } else {
            renameSavedSearch = [[RenameSavedSearchViewController alloc] initWithNibName:@"RenameSavedSearchViewController_iPad" bundle:nil];
        }
       
        renameSavedSearch.delegate = self;
        renameSavedSearch.strGenAdd = strPropertyName;
        [self.navigationController pushViewController:renameSavedSearch animated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)savedFilterOnServer
{
    [MBProgressHUD showHUDAddedTo:appdelegate.window animated:YES];
    NSMutableDictionary *data = _parameterDict;
    [data setValue:strPropertyName forKey:@"name"];
    [data setValue:[[[NSUserDefaults standardUserDefaults]objectForKey:@"userData"] objectForKey:@"user_id"] forKey:@"user_id"];
    [data setValue:_strPnCount forKey:@"pcount"];
    [data setValue:emailStatus forKey:@"email"];
    [data setValue:pushStatus forKey:@"push"];
    NSLog(@"%@",[data JSONRepresentation]);
    [REWebService savedSearch:data image:self.imageCapture withBlock:^(NSDictionary *dictResult, NSError *error) {
        [MBProgressHUD hideAllHUDsForView:self->appdelegate.window animated:YES];
        
        if (!error){
            
            if ([[[dictResult valueForKey:@"response"] valueForKey:@"message"]isEqualToString:@"success"]) {
                
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                [self.navigationController popViewControllerAnimated:YES];
                
            }
            else{
                [Utils showAlertMessage:@"Twin Realty" Message:[[dictResult valueForKey:@"response"] valueForKey:@"msg"]];
                
            }
            
            
        }
        
    }];
    

}

@end
