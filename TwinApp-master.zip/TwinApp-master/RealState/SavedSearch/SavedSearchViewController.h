//  SavedSearchViewController.h
//  RealState
//  Created by Kapil Goyal on 11/09/13.
//  Copyright (c) 2013 Octal Info Solution Private Limited. All rights reserved.

#import <UIKit/UIKit.h>
#import "AppDelegate.h"


@interface SavedSearchViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet UIView *viewSavedSearch;
    IBOutlet UITableView *tblSaveSearch;
    IBOutlet UIScrollView *scrlViewSavedSearch;
    float height;
    float maxHeight;
    NSString *strPropertyName;
    UISwitch *emailSwitch;
    UISwitch *pushSwitch;
    NSString *emailStatus;
    NSString *pushStatus;
    AppDelegate * appdelegate;
    
}

-(IBAction)btnCancelClicked;
-(IBAction)btnSaveClicked;

@property (nonatomic ,strong)NSString *strPnCount;
@property (nonatomic ,strong)NSString *genratedAddress;
@property (nonatomic ,strong)UIImage *imageCapture;
@property (nonatomic ,strong)NSMutableDictionary *parameterDict;


@end
