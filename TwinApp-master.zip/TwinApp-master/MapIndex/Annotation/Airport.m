//
//  Aiport.m
//  Airports
//

#import "Airport.h"

static NSDictionary* icons;

@implementation Airport

@synthesize coordinate,city,code,icon,detailDict;

+(void)initialize {
    if (self == [Airport class]) {
        icons = [[NSDictionary alloc] initWithObjectsAndKeys: 
                 [UIImage imageNamed:@"small_airport"], @"small_airport", 
                 [UIImage imageNamed:@"heliport.png"], @"heliport", 
                 [UIImage imageNamed:@"big_airport.png"], @"big_airport", 
                 [UIImage imageNamed:@"seaplane_base.png"],@"seaplane_base",
                 [UIImage imageNamed:@"closed.png"],@"closed",
                 nil];
    }
}
/*
-(id)initWithCode:(NSString*)aCode city:(NSString*)aCity latitude:(CLLocationDegrees)latitude longitude:(CLLocationDegrees)longitude type:(NSString*)aType {
    if ((self = [super init])) {
        coordinate.latitude = latitude;
        coordinate.longitude = longitude;
        
        self.code = aCode;
        self.city = aCity;
        
        icon = [icons objectForKey:aType];
        if (!icon) icon = [icons objectForKey:@"big_airport"];
    }
    return self;
}
 */

-(id)initWithCode:(NSString*)aCode city:(NSString*)aCity latitude:(CLLocationDegrees)latitude longitude:(CLLocationDegrees)longitude type:(NSString*)aType :(NSDictionary*)detail{
    if ((self = [super init])) {
        coordinate.latitude = latitude;
        coordinate.longitude = longitude;
        
        self.code = aCode;
        self.city = aCity;
        self.detailDict = detail;
        
        icon = [icons objectForKey:aType];
        if (!icon) icon = [icons objectForKey:@"big_airport"];
    }
    return self;
}

-(NSString*)title {

    return self.code;
}

-(NSString*)subtitle {
    return self.city;
}

//-(NSString*)status {
//    return self.status;
//}


+(NSArray*)allPropertyData:(NSArray*)aArray{

    NSMutableArray* result = [NSMutableArray array];
    for (NSDictionary* d in aArray) {
        CLLocationDegrees lat = [(NSNumber*)[d objectForKey:@"latitude"] floatValue];
        CLLocationDegrees lng = [(NSNumber*)[d objectForKey:@"longitude"] floatValue];
//        [result addObject:[[self alloc] initWithCode:[d objectForKey:@"id"] city:[d objectForKey:@"fulladdress"] latitude:lat  longitude:lng type:[d objectForKey:@"status"]]];
        
        
        [result addObject:[[self alloc] initWithCode:[d objectForKey:@"status"] city:[d objectForKey:@"fulladdress"] latitude:lat longitude:lng type:[d objectForKey:@"status"] :d]];
    }
    return result;
}

@end
