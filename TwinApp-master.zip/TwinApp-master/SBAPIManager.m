//
//  SBAPIManager.m
//  RealEstate_App
//
//  Created by admin on 10/10/16.
//  Copyright © 2016 Octal Info Solution Private Limited. All rights reserved.
//

#import "SBAPIManager.h"
#import "AFNetworkActivityIndicatorManager.h"
#import "CFNetwork/CFHTTPMessage.h"
#import <SystemConfiguration/SCNetworkReachability.h>
#import "SBJSON.h"
#import "Config.h"
#import "Reachability.h"
#import "Utils.h"

@implementation SBAPIManager

- (void)setUsername:(NSString *)username andPassword:(NSString *)password
{
    [self.requestSerializer clearAuthorizationHeader];
    [self.requestSerializer setAuthorizationHeaderFieldWithUsername:username password:password];
}

#pragma mark - Initialization

- (id)initWithBaseURL:(NSURL *)url
{
    self = [super initWithBaseURL:url];
    if(!self)
        return nil;
    
    self.requestSerializer = [AFJSONRequestSerializer serializer];
    [[AFNetworkActivityIndicatorManager sharedManager] setEnabled:YES];
    
    return self;
}

#pragma mark - Singleton Methods

+ (SBAPIManager *)sharedManager
{
    static SBAPIManager *instance=nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [self manager];
    });
    return instance;
    
//    static dispatch_once_t pred;
//    static SBAPIManager *_sharedManager = nil;
//    
//    dispatch_once(&pred, ^{ _sharedManager = [[self alloc] initWithBaseURL:[NSURL URLWithString:WebserviceUrl]]; }); // You should probably make this a constant somewhere
//    return _sharedManager;
}
+ (void)cancelAllRequests {
    [[SBAPIManager sharedManager].operationQueue cancelAllOperations];
}




@end
//Then, in your code, you can call it like this:

//[[SBAPIManager sharedManager] setUsername:yourUsernameVariableHere andPassword:yourPasswordVariableHere];
//
//[[SBAPIManager sharedManager] GET:@"/tasks.json" parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
//    self.tasks = [responseObject objectForKey:@"results"];
//    [self.activityIndicatorView stopAnimating];
//    [self.tableView setHidden:NO];
//    [self.tableView reloadData];
//    
//    NSLog(@"JSON");
//} failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//    // error stuff here
//}];
//@end
